import { Router, type Request, type Response } from 'express';
import { asyncHandler } from '../../middleware/asyncHandler';
import { requireAuth } from '../../middleware/requireAuth';
import { aiStatus, analyzePhoto, forecastReport, labRiskReport } from './ai.service';

/**
 * AI Center endpoints. Read-only over existing data (like the assistant), so
 * any authenticated role may call them; photo analysis stores nothing.
 */
export const aiRouter = Router();

aiRouter.use(requireAuth);

aiRouter.get('/status', (_req: Request, res: Response) => {
  res.json({ success: true, data: aiStatus() });
});

aiRouter.get(
  '/lab-risk',
  asyncHandler(async (_req: Request, res: Response) => {
    res.json({ success: true, data: await labRiskReport() });
  }),
);

aiRouter.get(
  '/forecasts',
  asyncHandler(async (_req: Request, res: Response) => {
    res.json({ success: true, data: await forecastReport() });
  }),
);

aiRouter.post(
  '/photo-analysis',
  asyncHandler(async (req: Request, res: Response) => {
    res.json({ success: true, data: await analyzePhoto(req.body ?? {}) });
  }),
);
