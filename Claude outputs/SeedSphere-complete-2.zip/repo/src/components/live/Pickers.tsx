import { useEffect, useState } from 'react';
import { fetchLotOptions, fetchParties, type LotOption, type Party } from '@/services/live/foundations';
import { fmtQty, styles } from './ui';

/** Select a seed lot by code, crop or variety (search-as-you-type). */
export function LotPicker({ token, value, onChange, crop, id, allowEmpty = true }: { token: string | null; value: string; onChange: (lotId: string, lot: LotOption | null) => void; crop?: string; id?: string; allowEmpty?: boolean }) {
  const [q, setQ] = useState('');
  const [options, setOptions] = useState<LotOption[]>([]);
  useEffect(() => {
    if (!token) return;
    const t = window.setTimeout(() => {
      fetchLotOptions(token, q || undefined, crop).then(setOptions).catch(() => setOptions([]));
    }, 250);
    return () => window.clearTimeout(t);
  }, [token, q, crop]);
  return (
    <div style={{ display: 'grid', gap: 6 }}>
      <input className={styles.textInput} placeholder="Search lot code, crop or variety" value={q} onChange={(e) => setQ(e.target.value)} />
      <select id={id} className={styles.select} value={value} onChange={(e) => onChange(e.target.value, options.find((o) => o.id === e.target.value) ?? null)}>
        {allowEmpty && <option value="">— no lot —</option>}
        {options.map((o) => (
          <option key={o.id} value={o.id}>
            {o.lot_code} · {o.crop} {o.variety} · {o.stage} · {fmtQty(o.quantity_total, o.unit)}
            {o.on_hold ? ' · ON HOLD' : ''}
          </option>
        ))}
      </select>
    </div>
  );
}

/** Select an active party of the given types. */
export function PartyPicker({ token, types, value, onChange, id, includeInactive = false }: { token: string | null; types: string[]; value: string; onChange: (partyId: string, party: Party | null) => void; id?: string; includeInactive?: boolean }) {
  const [options, setOptions] = useState<Party[]>([]);
  useEffect(() => {
    if (!token) return;
    Promise.all(types.map((type) => fetchParties(token, { type, status: includeInactive ? undefined : 'active' })))
      .then((lists) => setOptions(lists.flat().sort((a, b) => a.name.localeCompare(b.name))))
      .catch(() => setOptions([]));
  }, [token, types.join(','), includeInactive]);  
  return (
    <select id={id} className={styles.select} value={value} onChange={(e) => onChange(e.target.value, options.find((o) => o.id === e.target.value) ?? null)}>
      <option value="">— select —</option>
      {options.map((p) => (
        <option key={p.id} value={p.id}>
          {p.name} ({p.party_code}){p.village ? ` · ${p.village}` : ''}
        </option>
      ))}
    </select>
  );
}
