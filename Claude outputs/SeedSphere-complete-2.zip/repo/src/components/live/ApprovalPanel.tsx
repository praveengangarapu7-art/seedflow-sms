import { useState } from 'react';
import { Check, X } from 'lucide-react';
import { Button } from '@/components/common/Button/Button';
import { Modal } from '@/components/common/Modal/Modal';
import { decideApproval, fetchEntityApprovals, type ApprovalRequest } from '@/services/live/foundations';
import { Empty, Field, Notice, PromptModal, Section, StatusPill, fmtDateTime, fmtMoney, humanize, styles, useAction, useLoad } from './ui';

/** Asks the approver to sign: their own password, entered again, with the meaning of the signature shown. */
export function SignModal({ isOpen, title, meaning, busy, onClose, onSign }: { isOpen: boolean; title: string; meaning?: string | null; busy?: boolean; onClose: () => void; onSign: (password: string) => void | Promise<void> }) {
  const [pw, setPw] = useState('');
  return (
    <Modal isOpen={isOpen} onClose={() => { setPw(''); onClose(); }} title={title} size="md">
      <div className={styles.modalStack}>
        <Notice tone="warn">This approval is signed electronically. Your name, the time and the meaning below are recorded permanently.</Notice>
        {meaning && <p><strong>“{meaning}”</strong></p>}
        <Field label="Your password" htmlFor="sig-pw"><input id="sig-pw" type="password" autoComplete="current-password" className={styles.textInput} value={pw} onChange={(e) => setPw(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter' && pw) void onSign(pw); }} /></Field>
        <div className={styles.actionsRow}>
          <Button isLoading={busy} disabled={!pw} onClick={async () => { await onSign(pw); setPw(''); }}>Sign and approve</Button>
          <Button variant="secondary" onClick={() => { setPw(''); onClose(); }}>Cancel</Button>
        </div>
      </div>
    </Modal>
  );
}

interface ApprovalPanelProps {
  token: string | null;
  entityType: string;
  entityId: string;
  /** Server permissions of the viewer — decides whether decide buttons appear. */
  can: (permission: string) => boolean;
  currentEmail: string | null | undefined;
  /** Bump to reload after the record is submitted. */
  refreshKey?: unknown;
  onDecided?: () => void;
}

/** The approval trail of one record, with approve/reject for the person whose step it is. */
export function ApprovalPanel({ token, entityType, entityId, can, currentEmail, refreshKey, onDecided }: ApprovalPanelProps) {
  const history = useLoad<ApprovalRequest[]>(token, (t) => fetchEntityApprovals(t, entityType, entityId), [entityType, entityId, refreshKey]);
  const { run, busy } = useAction();
  const [rejecting, setRejecting] = useState<ApprovalRequest | null>(null);
  const [signing, setSigning] = useState<ApprovalRequest | null>(null);
  const requests = history.data ?? [];

  const decide = async (req: ApprovalRequest, decision: 'approve' | 'reject', comment?: string, password?: string) => {
    if (!token) return;
    const r = await run(() => decideApproval(token, req.id, decision, comment, password), (res) =>
      res.status === 'approved' ? `${res.entity_code} approved` : res.status === 'rejected' ? `${res.entity_code} rejected` : 'Approved — passed to the next approver',
    );
    if (r) {
      setRejecting(null);
      setSigning(null);
      await history.reload();
      onDecided?.();
    }
  };

  return (
    <Section title="Approvals" subtitle="Each step needs a different person holding the step's permission; nobody approves their own request.">
      {history.error && <p className={styles.errorText}>{history.error}</p>}
      {!history.loading && requests.length === 0 && <Empty>Not submitted for approval yet.</Empty>}
      {requests.map((req) => {
        const pending = req.steps?.find((s) => s.status === 'pending');
        const decidedByMe = req.steps?.some((s) => s.decided_by === currentEmail);
        const mayDecide = req.status === 'pending' && pending && can(pending.required_permission) && req.requested_by !== currentEmail && !decidedByMe;
        return (
          <div key={req.id} style={{ marginBottom: 16 }}>
            <p className={styles.muted} style={{ marginBottom: 8 }}>
              Submitted by {req.requested_by} · {fmtDateTime(req.requested_at)}
              {req.amount ? ` · ${fmtMoney(req.amount)}` : ''} · <StatusPill status={req.status} />
            </p>
            <ol className={styles.stepList}>
              {req.steps?.map((s) => (
                <li key={s.id} className={styles.stepItem}>
                  <span>
                    <strong>
                      {s.step_order}. {s.step_name}
                    </strong>
                    <br />
                    <span className={styles.muted}>
                      {s.decided_by ? `${humanize(s.status)} by ${s.decided_by} · ${fmtDateTime(s.decided_at)}` : `Needs ${humanize(s.required_permission)}`}
                      {s.comment ? ` — “${s.comment}”` : ''}
                      {s.signature && <><br />Signed by {s.signature.signer_name} · “{s.signature.meaning}” · {fmtDateTime(s.signature.signed_at)} · ref {s.signature.record_hash.slice(0, 10)}</>}
                    </span>
                  </span>
                  <StatusPill status={s.status} />
                </li>
              ))}
            </ol>
            {mayDecide && (
              <div className={styles.actionsRow} style={{ marginTop: 10 }}>
                <Button leftIcon={Check} isLoading={busy} onClick={() => (pending?.signature_required ? setSigning(req) : void decide(req, 'approve'))}>
                  {pending?.signature_required ? 'Sign and approve' : 'Approve'}
                </Button>
                <Button variant="danger" leftIcon={X} onClick={() => setRejecting(req)}>
                  Reject
                </Button>
              </div>
            )}
          </div>
        );
      })}
      <SignModal isOpen={!!signing} title={`Sign approval of ${signing?.entity_code ?? ''}`} meaning={signing?.steps?.find((x) => x.status === 'pending')?.signature_meaning} busy={busy} onClose={() => setSigning(null)} onSign={async (pw) => { if (signing) await decide(signing, 'approve', undefined, pw); }} />
      <PromptModal
        isOpen={!!rejecting}
        title={`Reject ${rejecting?.entity_code ?? ''}`}
        label="Reason for rejecting"
        confirmLabel="Reject"
        confirmVariant="danger"
        busy={busy}
        onClose={() => setRejecting(null)}
        onSubmit={(text) => rejecting && decide(rejecting, 'reject', text)}
      />
    </Section>
  );
}
