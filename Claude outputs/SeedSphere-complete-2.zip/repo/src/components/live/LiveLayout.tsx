import type { ReactNode } from 'react';
import { ClipboardCheck, Cog, FlaskConical, ShieldCheck, ShoppingCart, Warehouse } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { ModuleLayout } from '@/components/layout/ModuleLayout/ModuleLayout';
import { adminNav } from '@/config/adminNav';
import { labNav } from '@/config/labNav';
import { processingNav } from '@/config/processingNav';
import { procurementNav } from '@/config/procurementNav';
import { qualityNav } from '@/config/qualityNav';
import { rdNav } from '@/config/rdNav';
import { warehouseNav } from '@/config/warehouseNav';
import { useAuth } from '@/context/AuthContext';
import type { NavItem, UserRole } from '@/types';
import { ADMIN_ROLES, LAB_ROLES, PROCESSING_ROLES, PROCUREMENT_ROLES, QUALITY_ROLES, RD_ROLES, WAREHOUSE_ROLES } from '@/types';
import { ErrorCard, styles } from './ui';

export type ModuleKey = 'procurement' | 'warehouse' | 'rd' | 'processing' | 'lab' | 'quality' | 'admin';

const MODULES: Record<ModuleKey, { name: string; icon: LucideIcon; nav: NavItem[] }> = {
  procurement: { name: 'Procurement', icon: ShoppingCart, nav: procurementNav as unknown as NavItem[] },
  warehouse: { name: 'Warehouse', icon: Warehouse, nav: warehouseNav as unknown as NavItem[] },
  rd: { name: 'Research & Development', icon: FlaskConical, nav: rdNav as unknown as NavItem[] },
  processing: { name: 'Processing', icon: Cog, nav: processingNav as unknown as NavItem[] },
  lab: { name: 'Laboratory', icon: FlaskConical, nav: labNav as unknown as NavItem[] },
  quality: { name: 'Quality', icon: ClipboardCheck, nav: qualityNav as unknown as NavItem[] },
  admin: { name: 'Administration', icon: ShieldCheck, nav: adminNav as unknown as NavItem[] },
};

/** The module a role works in — used by cross-module pages such as the approvals inbox. */
export function moduleForRole(role: UserRole | undefined): ModuleKey {
  if (!role) return 'quality';
  if (PROCUREMENT_ROLES.includes(role)) return 'procurement';
  if (WAREHOUSE_ROLES.includes(role)) return 'warehouse';
  if (RD_ROLES.includes(role)) return 'rd';
  if (PROCESSING_ROLES.includes(role)) return 'processing';
  if (LAB_ROLES.includes(role)) return 'lab';
  if (QUALITY_ROLES.includes(role)) return 'quality';
  if (ADMIN_ROLES.includes(role)) return 'admin';
  return 'quality';
}

export function useHomeModule(): ModuleKey {
  const { user } = useAuth();
  return moduleForRole(user?.role);
}

interface LiveLayoutProps {
  module: ModuleKey;
  /** Session error from useStaffSession — shown above the page when the server is unreachable. */
  sessionError?: string | null;
  children: ReactNode;
}

export function LiveLayout({ module, sessionError, children }: LiveLayoutProps) {
  const m = MODULES[module];
  return (
    <ModuleLayout moduleName={m.name} moduleIcon={m.icon} navItems={m.nav}>
      <div className={styles.page}>
        <ErrorCard message={sessionError} />
        {children}
      </div>
    </ModuleLayout>
  );
}
