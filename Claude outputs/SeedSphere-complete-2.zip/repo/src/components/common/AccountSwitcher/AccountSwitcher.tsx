import { useAuth } from '@/context/AuthContext';
import { ROLE_LABELS } from '@/types';
import styles from './AccountSwitcher.module.css';

interface Account {
  role: string;
  email: string;
}

interface AccountSwitcherProps {
  accounts?: readonly Account[];
  accountIndex?: number;
  onChange?: (index: number) => void;
}

/**
 * Shows who the page is acting as. Every request uses the signed-in person's
 * own session, so there is nothing to switch: to act as someone else, sign
 * out and sign in with their account. (The props are kept so older pages
 * compile unchanged.)
 */
export function AccountSwitcher(_props: AccountSwitcherProps) {
  const { user } = useAuth();
  if (!user) return null;
  return (
    <span className={styles.wrap}>
      Signed in as <strong>{user.name}</strong> · {ROLE_LABELS[user.role]}
    </span>
  );
}
