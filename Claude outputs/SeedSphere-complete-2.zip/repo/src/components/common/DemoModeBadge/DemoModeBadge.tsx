import { useEffect, useState } from 'react';
import { Database } from 'lucide-react';
import { isDemoMode, onDemoModeChange } from '@/services/seedLotRealtimeClient';
import { readAdminSettings } from '@/services/adminSettings';
import styles from './DemoModeBadge.module.css';

/**
 * Shown while the server cannot be reached. Pages then show the last data this
 * browser saved, which may be out of date, and changes cannot be saved. It
 * disappears by itself when the connection returns. An administrator can hide
 * it from Administration → Admin settings.
 */
export function DemoModeBadge() {
  const [active, setActive] = useState(isDemoMode());

  useEffect(() => onDemoModeChange(setActive), []);

  if (!active) return null;
  if (!readAdminSettings().showDemoBadge) return null;

  return (
    <div className={styles.badge} title="SeedSphere cannot reach the server. You are seeing the last data saved in this browser, and changes cannot be saved until the connection returns.">
      <Database size={13} />
      Offline — showing saved data
    </div>
  );
}
