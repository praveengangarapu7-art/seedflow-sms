import { forwardRef } from 'react';
import { Link, type LinkProps } from 'react-router-dom';
import { useCanOpen } from '@/hooks/useCanOpen';

/**
 * A router Link that only links when the signed-in person can open the
 * target page. Otherwise it shows the same text without a link, instead of a
 * click that lands on "Access denied".
 */
export const AppLink = forwardRef<HTMLAnchorElement, LinkProps>(function AppLink(props, ref) {
  const canOpen = useCanOpen();
  const { to, children, className, style, title } = props;
  if (typeof to === 'string' && to.startsWith('/') && !canOpen(to)) {
    return (
      <span className={className} style={style} title={title}>
        {children}
      </span>
    );
  }
  return <Link ref={ref} {...props} />;
});
