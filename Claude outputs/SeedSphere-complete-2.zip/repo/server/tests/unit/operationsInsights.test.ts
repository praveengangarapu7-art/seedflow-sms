import { describe, expect, it } from 'vitest';
import { operationsExtras } from '../../src/modules/ai/operationsInsights';
import { moduleInsights } from '../../src/modules/ai/moduleInsights';

describe('AI module insights from live operational data', () => {
  it('returns metrics and findings for every operational module without throwing', async () => {
    for (const m of ['procurement', 'warehouse', 'processing', 'rd', 'quality', 'administration', 'laboratory'] as const) {
      const extra = await operationsExtras(m);
      expect(Array.isArray(extra.metrics)).toBe(true);
      expect(Array.isArray(extra.insights)).toBe(true);
      const full = await moduleInsights(m);
      expect(full.metrics.length).toBeLessThanOrEqual(4);
      expect(full.insights.length).toBeGreaterThan(0);
    }
  });

  it('does not count approvals for modules that own none', async () => {
    const lab = await operationsExtras('laboratory');
    expect(lab.insights.find((i) => i.id === 'approvals-waiting')).toBeUndefined();
  });
});
