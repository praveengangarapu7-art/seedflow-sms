import request from 'supertest';
import type { JobRole } from '../../../src/auth/permissions';
import { createTestUser, type TestUser } from '../../factories';
import { loginAs } from '../authHelper';
import { app } from '../testApp';

export interface Actor {
  user: TestUser;
  token: string;
}

export async function jobActor(jobRole: JobRole): Promise<Actor> {
  const user = await createTestUser({ jobRole });
  return { user, token: await loginAs(user) };
}

export async function legacyActor(role: 'Admin' | 'Inspector' | 'Producer' | 'Breeder' | 'Warehouse Manager'): Promise<Actor> {
  const user = await createTestUser({ role });
  return { user, token: await loginAs(user) };
}

export function api(base: string) {
  return (a: Actor) => ({
    get: (path: string) => request(app).get(`${base}${path}`).set('Authorization', `Bearer ${a.token}`),
    post: (path: string, body: object = {}) => request(app).post(`${base}${path}`).set('Authorization', `Bearer ${a.token}`).send(body),
    put: (path: string, body: object = {}) => request(app).put(`${base}${path}`).set('Authorization', `Bearer ${a.token}`).send(body),
    patch: (path: string, body: object = {}) => request(app).patch(`${base}${path}`).set('Authorization', `Bearer ${a.token}`).send(body),
    del: (path: string) => request(app).delete(`${base}${path}`).set('Authorization', `Bearer ${a.token}`),
  });
}

export function inDays(days: number): string {
  const d = new Date();
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}

/** A valid-looking unique 10-digit Indian mobile number. */
export function phone(): string {
  return `9${String(Math.floor(Math.random() * 1e9)).padStart(9, '0')}`;
}
