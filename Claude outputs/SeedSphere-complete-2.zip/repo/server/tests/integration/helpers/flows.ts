import { randomUUID } from 'node:crypto';
import { expect } from 'vitest';
import { createTestSeedLot } from '../../factories';
import { api, inDays, phone, type Actor } from './actors';

const parties = api('/api/v1/parties');
const approvals = api('/api/v1/approvals');
const insp = api('/api/v1/inspections');
const P = api('/api/v1/procurement');

export async function activeParty(creator: Actor, approver: Actor, type: string, extra: Record<string, unknown> = {}) {
  const created = await parties(creator).post('/', { partyType: type, name: `${type} ${randomUUID().slice(0, 8)}`, phone: phone(), ...extra });
  expect(created.status).toBe(201);
  const approved = await parties(approver).post(`/${created.body.data.id}/approve`);
  expect(approved.status).toBe(200);
  return created.body.data as { id: string; name: string; party_code: string };
}

export async function approve(a: Actor, entityType: string, entityId: string, decision: 'approve' | 'reject' = 'approve', comment?: string) {
  const reqs = await approvals(a).get(`/entity/${entityType}/${entityId}`);
  const open = reqs.body.data.find((r: { status: string }) => r.status === 'pending');
  expect(open, `no pending ${entityType} approval`).toBeTruthy();
  return approvals(a).post(`/requests/${open.id}/decide`, { decision, comment, password: a.user.password });
}

/** Runs an inspection on a subject using the active template whose name matches, filling numeric checks from `values` by label. */
export async function runInspection(
  inspector: Actor,
  opts: { type: string; templateName?: RegExp; subjectType: string; subjectId?: string; subjectLabel?: string; seedLotId?: string },
  values: Record<string, number>,
  decision: string,
  extra: Record<string, unknown> = {},
) {
  const templates = await insp(inspector).get(`/templates?type=${opts.type}&status=active`);
  const summary = opts.templateName ? templates.body.data.find((x: { name: string }) => opts.templateName!.test(x.name)) : templates.body.data[0];
  expect(summary, `no active ${opts.type} template`).toBeTruthy();
  const t = (await insp(inspector).get(`/templates/${summary.id}`)).body.data;
  const started = await insp(inspector).post('/', { templateId: t.id, subjectType: opts.subjectType, subjectId: opts.subjectId, subjectLabel: opts.subjectLabel, seedLotId: opts.seedLotId });
  expect(started.status, JSON.stringify(started.body)).toBe(201);
  const results = t.items.map((i: { id: string; label: string; item_type: string; min_value: string | null; max_value: string | null }) => {
    if (i.label in values) return { itemId: i.id, numericValue: values[i.label] };
    if (i.item_type === 'numeric') {
      const v = i.min_value !== null ? Number(i.min_value) + 1 : i.max_value !== null ? Number(i.max_value) / 2 : 1;
      return { itemId: i.id, numericValue: v };
    }
    if (i.item_type === 'pass_fail') return { itemId: i.id, boolValue: true };
    return { itemId: i.id, textValue: 'ok' };
  });
  expect((await insp(inspector).put(`/${started.body.data.id}/results`, { results })).status).toBe(200);
  return insp(inspector).post(`/${started.body.data.id}/submit`, { decision, decisionNotes: 'checked', ...extra });
}

/** An approved, active grower agreement with an accepted, priced delivery. Returns ids. */
export async function acceptedGrowerDelivery(actors: { exec: Actor; manager: Actor; inspector: Actor }, opts: { netKg?: number; variety?: string } = {}) {
  const variety = opts.variety ?? `BPT-${randomUUID().slice(0, 4)}`;
  const grower = await activeParty(actors.exec, actors.manager, 'contract_grower', { village: 'Ponnur' });
  const foundation = await createTestSeedLot({ crop: 'Paddy', variety, stage: 'Foundation', quantityTotal: 3000, productionDate: '2025-06-01' });
  const a = await P(actors.exec).post('/growers/agreements', {
    growerId: grower.id,
    season: 'kharif',
    seasonYear: 2026,
    crop: 'Paddy',
    variety,
    seedClass: 'Certified',
    plotVillage: 'Ponnur',
    plotSurveyNumber: '112/3',
    areaAcres: 4,
    parentLotId: foundation.id,
    parentQtyIssuedKg: 80,
    expectedYieldKg: 10000,
    buybackPricePerKg: 30,
    procurementWindowStart: inDays(-3),
    procurementWindowEnd: inDays(20),
  });
  expect(a.status, JSON.stringify(a.body)).toBe(201);
  await P(actors.exec).post(`/growers/agreements/${a.body.data.id}/submit`);
  await approve(actors.manager, 'grower_agreement', a.body.data.id);
  const net = opts.netKg ?? 2000;
  const d = await P(actors.exec).post('/growers/deliveries', { agreementId: a.body.data.id, grossWeightKg: 5000 + net, tareWeightKg: 5000, bags: Math.ceil(net / 40) });
  expect(d.status).toBe(201);
  const ins = await runInspection(actors.inspector, { type: 'procurement_receipt', templateName: /Grower delivery/, subjectType: 'grower_delivery', subjectId: d.body.data.id }, { Moisture: 15, 'Physical purity': 98.5 }, 'accept');
  expect(ins.status, JSON.stringify(ins.body)).toBe(200);
  return { grower, foundation, agreementId: a.body.data.id as string, deliveryId: d.body.data.id as string, variety, netKg: net };
}
