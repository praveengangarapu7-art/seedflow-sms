import { describe, expect, it } from 'vitest';
import { pool } from '../../src/db/pool';
import { api, jobActor } from './helpers/actors';
import { approve } from './helpers/flows';
import { registerApprovalHandler } from '../../src/modules/approvals/approvals.service';

registerApprovalHandler('sig_test', { onApproved: async () => undefined, onRejected: async () => undefined });

const A = api('/api/v1/approvals');

describe('electronic signatures on approvals', () => {
  it('needs the approver’s own password on a signed step and records who signed what', async () => {
    const rdMgr = await jobActor('rd_manager');
    const rdExec = await jobActor('rd_executive');
    const code = `SIG${Date.now() % 100000}`;
    const entityId = (await pool.query(`SELECT gen_random_uuid() AS id`)).rows[0].id as string;
    const req = (await pool.query(`INSERT INTO approval_requests (entity_type, entity_id, entity_code, title, requested_by) VALUES ('sig_test', $1, $2, 'Release test', $3) RETURNING id`, [entityId, code, rdExec.user.email])).rows[0].id as string;
    await pool.query(`INSERT INTO approval_steps (request_id, step_order, step_name, required_permission, status) VALUES ($1, 1, 'R&D manager approves release', 'approve_variety_release', 'pending')`, [req]);
    await pool.query(`INSERT INTO approval_rules (entity_type, step_order, step_name, required_permission, requires_signature, signature_meaning) VALUES ('sig_test', 1, 'R&D manager approves release', 'approve_variety_release', TRUE, 'I approve this release') ON CONFLICT (entity_type, step_order) DO NOTHING`);

    const noPw = await A(rdMgr).post(`/requests/${req}/decide`, { decision: 'approve' });
    expect(noPw.status).toBe(400);
    expect(noPw.body.error?.message ?? noPw.body.message ?? JSON.stringify(noPw.body)).toMatch(/signature|password/i);
    const bad = await A(rdMgr).post(`/requests/${req}/decide`, { decision: 'approve', password: 'wrong-password' });
    expect(bad.status).toBe(400);
    expect((await pool.query(`SELECT count(*)::int AS n FROM approval_signatures WHERE request_id = $1`, [req])).rows[0].n).toBe(0);

    const good = await A(rdMgr).post(`/requests/${req}/decide`, { decision: 'approve', password: rdMgr.user.password });
    expect(good.status).toBe(200);
    const step = good.body.data.steps[0];
    expect(step.signature_required).toBe(true);
    expect(step.signature.signer_email).toBe(rdMgr.user.email);
    expect(step.signature.meaning).toMatch(/release/i);
    expect(step.signature.record_hash).toHaveLength(64);
  });

  it('does not ask for a password on steps that are not marked for signing', async () => {
    const mgr = await jobActor('purchase_manager');
    const rows = (await pool.query(`SELECT count(*)::int AS n FROM approval_rules WHERE entity_type = 'purchase_requisition' AND requires_signature`)).rows[0].n;
    expect(rows).toBe(0);
    expect(typeof approve).toBe('function');
    expect(mgr.token).toBeTruthy();
  });
});
