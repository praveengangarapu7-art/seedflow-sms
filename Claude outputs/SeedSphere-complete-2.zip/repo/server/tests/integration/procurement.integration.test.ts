import { randomUUID } from 'node:crypto';
import { beforeAll, describe, expect, it } from 'vitest';
import { pool } from '../../src/db/pool';
import { createTestSeedLot } from '../factories';
import { api, inDays, jobActor, phone, type Actor } from './helpers/actors';

const P = api('/api/v1/procurement');
const parties = api('/api/v1/parties');
const insp = api('/api/v1/inspections');
const approvals = api('/api/v1/approvals');

let exec: Actor;
let manager: Actor;
let finance: Actor;
let finance2: Actor;
let inspector: Actor;
let seedItem: { id: string };
let bagItem: { id: string };

async function activeParty(type: string, extra: Record<string, unknown> = {}) {
  const created = await parties(exec).post('/', { partyType: type, name: `${type} ${randomUUID().slice(0, 8)}`, phone: phone(), ...extra });
  expect(created.status).toBe(201);
  const approved = await parties(manager).post(`/${created.body.data.id}/approve`);
  expect(approved.status).toBe(200);
  return created.body.data as { id: string; name: string };
}

/** Approves whatever step of the entity's open request is pending, as the given actor. */
async function approve(a: Actor, entityType: string, entityId: string, decision: 'approve' | 'reject' = 'approve', comment?: string) {
  const reqs = await approvals(a).get(`/entity/${entityType}/${entityId}`);
  const open = reqs.body.data.find((r: { status: string }) => r.status === 'pending');
  expect(open).toBeTruthy();
  return approvals(a).post(`/requests/${open.id}/decide`, { decision, comment, password: a.user.password });
}

async function inspect(subjectType: string, subjectId: string, values: { moisture: number; purity: number }, decision: string, extra: Record<string, unknown> = {}) {
  const templates = await insp(inspector).get('/templates?type=procurement_receipt&status=active');
  // grower deliveries use the raw-intake checklist (moisture is priced, not a gate failure)
  const wanted = subjectType === 'grower_delivery' ? /Grower delivery/ : /Procurement receipt/;
  const summary = templates.body.data.find((x: { name: string }) => wanted.test(x.name));
  const t = (await insp(inspector).get(`/templates/${summary.id}`)).body.data;
  const started = await insp(inspector).post('/', { templateId: t.id, subjectType, subjectId });
  expect(started.status).toBe(201);
  const results = t.items.map((i: { id: string; label: string; item_type: string }) => {
    if (i.label === 'Moisture') return { itemId: i.id, numericValue: values.moisture };
    if (i.label === 'Physical purity') return { itemId: i.id, numericValue: values.purity };
    if (i.item_type === 'numeric') return { itemId: i.id, numericValue: 1 };
    if (i.item_type === 'pass_fail') return { itemId: i.id, boolValue: true };
    return { itemId: i.id, textValue: 'ok' };
  });
  expect((await insp(inspector).put(`/${started.body.data.id}/results`, { results })).status).toBe(200);
  return insp(inspector).post(`/${started.body.data.id}/submit`, { decision, decisionNotes: 'checked', ...extra });
}

beforeAll(async () => {
  exec = await jobActor('purchase_executive');
  manager = await jobActor('purchase_manager');
  finance = await jobActor('finance_manager');
  finance2 = await jobActor('finance_manager');
  inspector = await jobActor('procurement_quality_field_inspector');
  const tag = randomUUID().slice(0, 6);
  seedItem = (await P(exec).post('/items', { name: `Paddy BPT-5204 raw seed ${tag}`, category: 'seed', unit: 'kg', crop: 'Paddy', variety: 'BPT-5204', gstRate: 0 })).body.data;
  bagItem = (await P(exec).post('/items', { name: `HDPE bag 25 kg ${tag}`, category: 'packaging', unit: 'nos', gstRate: 18 })).body.data;
});

describe('requisition to payment', () => {
  it('runs PR → RFQ → award → PO → receipts with inspection → matched invoice → segregated payment', async () => {
    const supplierA = await activeParty('supplier');
    const supplierB = await activeParty('supplier');
    const cc = await P(finance).post('/cost-centres', { code: `PRC${randomUUID().slice(0, 4)}`, name: 'Procurement Kharif', budgetAmount: 50000 });
    expect(cc.status).toBe(201);

    // requisition
    const pr = await P(exec).post('/requisitions', {
      title: 'Raw seed and bags for kharif',
      department: 'procurement',
      costCentreId: cc.body.data.id,
      lines: [
        { itemId: seedItem.id, quantity: 1000, unitPrice: 40 },
        { itemId: bagItem.id, quantity: 40, unitPrice: 20 },
      ],
    });
    expect(pr.status).toBe(201);
    expect(pr.body.data.status).toBe('draft');
    expect(Number(pr.body.data.estimated_total)).toBe(40800);
    expect((await P(exec).post(`/requisitions/${pr.body.data.id}/submit`)).status).toBe(200);
    expect((await approve(manager, 'purchase_requisition', pr.body.data.id)).body.data.status).toBe('approved');

    // RFQ with two quotes; awarding the dearer one needs a reason
    const rfq = await P(exec).post('/rfqs', { title: 'Kharif raw seed', dueDate: inDays(5), requisitionId: pr.body.data.id });
    expect(rfq.status).toBe(201);
    const [l1, l2] = rfq.body.data.lines;
    const qA = await P(exec).post(`/rfqs/${rfq.body.data.id}/quotes`, { supplierId: supplierA.id, lines: [{ rfqLineId: l1.id, unitPrice: 41 }, { rfqLineId: l2.id, unitPrice: 19 }], deliveryDays: 10 });
    expect(qA.status).toBe(200);
    const qB = await P(exec).post(`/rfqs/${rfq.body.data.id}/quotes`, { supplierId: supplierB.id, lines: [{ rfqLineId: l1.id, unitPrice: 39 }, { rfqLineId: l2.id, unitPrice: 20 }], deliveryDays: 25 });
    const quotes = qB.body.data.quotes as { id: string; supplier_id: string }[];
    const quoteA = quotes.find((q) => q.supplier_id === supplierA.id)!;
    const award = { quoteId: quoteA.id, expectedDeliveryDate: inDays(10), deliveryAddress: 'Plant 1, Guntur', costCentreId: cc.body.data.id };
    expect((await P(exec).post(`/rfqs/${rfq.body.data.id}/award`, award)).status).toBe(403); // executives cannot award
    expect((await P(manager).post(`/rfqs/${rfq.body.data.id}/award`, award)).status).toBe(400); // not lowest, no reason
    const awarded = await P(manager).post(`/rfqs/${rfq.body.data.id}/award`, { ...award, reason: 'Supplier B cannot deliver within the sowing window' });
    expect(awarded.status).toBe(200);
    const po = awarded.body.data.order;
    expect(po.status).toBe('draft');
    expect(Number(po.grand_total)).toBe(41000 + 760 + 136.8);

    // the order is above the 50k? no: 41,896.80 is within budget — submit and approve
    const submitted = await P(manager).post(`/orders/${po.id}/submit`);
    expect(submitted.status).toBe(200);
    expect((await approve(manager, 'purchase_order', po.id)).status).toBe(403); // submitter cannot approve
    const mgr2 = await jobActor('purchase_manager');
    expect((await approve(mgr2, 'purchase_order', po.id)).body.data.status).toBe('approved');
    expect((await P(exec).post(`/orders/${po.id}/send`)).body.data.status).toBe('sent');
    expect((await P(exec).get(`/requisitions/${pr.body.data.id}`)).body.data.status).toBe('ordered');

    const full = (await P(exec).get(`/orders/${po.id}`)).body.data;
    const seedLine = full.lines.find((l: { item_id: string }) => l.item_id === seedItem.id);
    const bagLine = full.lines.find((l: { item_id: string }) => l.item_id === bagItem.id);

    // bags need no inspection: accepted on receipt, less damage
    const bags = await P(exec).post('/receipts', { poId: po.id, lines: [{ poLineId: bagLine.id, receivedQuantity: 40, damagedQuantity: 2 }] });
    expect(bags.status).toBe(201);
    expect(bags.body.data.status).toBe('accepted');

    // over-receipt beyond 5% tolerance is refused
    expect((await P(exec).post('/receipts', { poId: po.id, lines: [{ poLineId: seedLine.id, receivedQuantity: 1100 }] })).status).toBe(409);

    // seed waits for gate inspection; accept moves it onto the order
    const seed = await P(exec).post('/receipts', { poId: po.id, grossWeightKg: 12500, tareWeightKg: 11500, vehicleNumber: 'AP09TX4471', lines: [{ poLineId: seedLine.id, receivedQuantity: 1000 }] });
    expect(seed.body.data.status).toBe('awaiting_inspection');
    expect(Number(seed.body.data.net_weight_kg)).toBe(1000);
    const passed = await inspect('goods_receipt', seed.body.data.id, { moisture: 11.5, purity: 98.6 }, 'accept');
    expect(passed.status).toBe(200);
    const afterSeed = (await P(exec).get(`/receipts/${seed.body.data.id}`)).body.data;
    expect(afterSeed.status).toBe('accepted');
    const order = (await P(exec).get(`/orders/${po.id}`)).body.data;
    expect(order.status).toBe('partially_received'); // 38 of 40 bags good

    // invoice: price drift on bags → mismatch, needs a reason to send for payment
    const inv = await P(exec).post('/invoices', {
      poId: po.id,
      supplierInvoiceNo: `SA-${randomUUID().slice(0, 6)}`,
      invoiceDate: inDays(0),
      lines: [
        { poLineId: seedLine.id, quantity: 1000, unitPrice: 41 },
        { poLineId: bagLine.id, quantity: 40, unitPrice: 19 },
      ],
    });
    expect(inv.status).toBe(201);
    expect(inv.body.data.match_status).toBe('mismatch'); // 40 bags invoiced, only 38 accepted
    expect((await P(exec).post(`/invoices/${inv.body.data.id}/submit`, {})).status).toBe(400);
    expect((await P(exec).post('/invoices', { poId: po.id, supplierInvoiceNo: inv.body.data.supplier_invoice_no, invoiceDate: inDays(0), lines: [{ poLineId: seedLine.id, quantity: 1, unitPrice: 41 }] })).status).toBe(409);
    expect((await P(exec).post(`/invoices/${inv.body.data.id}/cancel`, { reason: 'Supplier to re-issue for 38 bags' })).status).toBe(200);

    const inv2 = await P(exec).post('/invoices', {
      poId: po.id,
      supplierInvoiceNo: `SA-${randomUUID().slice(0, 6)}`,
      invoiceDate: inDays(0),
      lines: [
        { poLineId: seedLine.id, quantity: 1000, unitPrice: 41 },
        { poLineId: bagLine.id, quantity: 38, unitPrice: 19 },
      ],
    });
    expect(inv2.body.data.match_status).toBe('matched');
    expect((await P(exec).post(`/invoices/${inv2.body.data.id}/submit`, {})).body.data.status).toBe('pending_approval');
    expect((await approve(finance, 'invoice_payment', inv2.body.data.id)).body.data.status).toBe('approved');
    expect((await P(finance).post(`/invoices/${inv2.body.data.id}/pay`, { paymentReference: 'UTR123', paymentMode: 'neft' })).status).toBe(403);
    const paid = await P(finance2).post(`/invoices/${inv2.body.data.id}/pay`, { paymentReference: 'UTR123', paymentMode: 'neft' });
    expect(paid.body.data.status).toBe('paid');

    const ccs = (await P(exec).get('/cost-centres')).body.data;
    const mine = ccs.find((c: { id: string }) => c.id === cc.body.data.id);
    expect(mine.spent).toBeCloseTo(41851.96, 2); // 41,000 seed + 722 bags + 18% GST on bags
  });

  it('adds a finance step above the threshold and demands a reason to go over budget', async () => {
    const supplier = await activeParty('supplier');
    const cc = await P(finance).post('/cost-centres', { code: `SM${randomUUID().slice(0, 4)}`, name: 'Small budget', budgetAmount: 100000 });
    const po = await P(exec).post('/orders', {
      supplierId: supplier.id,
      costCentreId: cc.body.data.id,
      expectedDeliveryDate: inDays(20),
      deliveryAddress: 'Plant 1',
      lines: [{ itemId: seedItem.id, quantity: 20000, unitPrice: 40 }],
    });
    expect(po.status).toBe(201);
    expect((await P(exec).post(`/orders/${po.body.data.id}/submit`, {})).status).toBe(409);
    const sub = await P(exec).post(`/orders/${po.body.data.id}/submit`, { budgetOverrideReason: 'Kharif expansion approved by board' });
    expect(sub.status).toBe(200);
    expect(sub.body.data.approvals[0].steps).toHaveLength(2);
    expect((await approve(manager, 'purchase_order', po.body.data.id)).body.data.status).toBe('pending');
    expect((await approve(finance, 'purchase_order', po.body.data.id)).body.data.status).toBe('approved');
  });

  it('amends an approved order through approval and cancels it, recording why', async () => {
    const supplier = await activeParty('supplier');
    const po = await P(exec).post('/orders', { supplierId: supplier.id, expectedDeliveryDate: inDays(15), deliveryAddress: 'Plant 2', lines: [{ itemId: bagItem.id, quantity: 100, unitPrice: 20 }] });
    await P(exec).post(`/orders/${po.body.data.id}/submit`);
    await approve(manager, 'purchase_order', po.body.data.id);
    const amended = await P(exec).post(`/orders/${po.body.data.id}/amend`, { reason: 'Increase to 150 bags', lines: [{ itemId: bagItem.id, quantity: 150, unitPrice: 20 }] });
    expect(amended.status).toBe(200);
    expect(amended.body.data.status).toBe('pending_approval');
    expect(amended.body.data.amendment_no).toBe(1);
    expect(amended.body.data.amendments[0].reason).toBe('Increase to 150 bags');
    expect((await P(exec).post(`/orders/${po.body.data.id}/cancel`, {})).status).toBe(400);
    expect((await P(exec).post(`/orders/${po.body.data.id}/cancel`, { reason: 'Supplier withdrew' })).body.data.status).toBe('cancelled');
  });
});

describe('contracts', () => {
  it('enforces contract rates and the value cap, with activation by a second person', async () => {
    const supplier = await activeParty('supplier');
    const c = await P(manager).post('/contracts', {
      contractType: 'rate_contract',
      supplierId: supplier.id,
      title: 'Bags rate contract 2026',
      startDate: inDays(-1),
      endDate: inDays(200),
      valueCap: 3000,
      rates: [{ itemId: bagItem.id, unitPrice: 18 }],
    });
    expect(c.status).toBe(201);
    expect((await P(manager).post(`/contracts/${c.body.data.id}/activate`)).status).toBe(403);
    const mgr2 = await jobActor('purchase_manager');
    expect((await P(mgr2).post(`/contracts/${c.body.data.id}/activate`)).body.data.lifecycle).toBe('in_force');

    const base = { supplierId: supplier.id, contractId: c.body.data.id, expectedDeliveryDate: inDays(10), deliveryAddress: 'Plant 1' };
    expect((await P(exec).post('/orders', { ...base, lines: [{ itemId: bagItem.id, quantity: 10, unitPrice: 19 }] })).status).toBe(409);
    expect((await P(exec).post('/orders', { ...base, lines: [{ itemId: bagItem.id, quantity: 200, unitPrice: 18 }] })).status).toBe(409); // over cap incl. GST
    expect((await P(exec).post('/orders', { ...base, lines: [{ itemId: bagItem.id, quantity: 100, unitPrice: 18 }] })).status).toBe(201);
  });
});

describe('contract growers', () => {
  async function foundationLot() {
    return createTestSeedLot({ crop: 'Paddy', variety: 'BPT-5204', stage: 'Foundation', quantityTotal: 2000, productionDate: '2025-06-01' });
  }

  async function agreement(overrides: Record<string, unknown> = {}) {
    const grower = await activeParty('contract_grower', { village: 'Ponnur', bankAccountName: 'R Reddy', bankAccountNumber: '123456789012', bankIfsc: 'SBIN0001234' });
    const lot = await foundationLot();
    const created = await P(exec).post('/growers/agreements', {
      growerId: grower.id,
      season: 'kharif',
      seasonYear: 2026,
      crop: 'Paddy',
      variety: 'BPT-5204',
      seedClass: 'Certified',
      plotVillage: 'Ponnur',
      areaAcres: 5,
      parentLotId: lot.id,
      parentQtyIssuedKg: 100,
      expectedYieldKg: 10000,
      buybackPricePerKg: 30,
      advanceAmount: 20000,
      inputCostAmount: 5000,
      procurementWindowStart: inDays(-5),
      procurementWindowEnd: inDays(30),
      ...overrides,
    });
    expect(created.status).toBe(201);
    return { grower, lot, agreement: created.body.data };
  }

  it('prices a delivery on dry weight and purity, then pays it net of the advance and inputs', async () => {
    const { lot, agreement: a } = await agreement();
    expect((await P(exec).post(`/growers/agreements/${a.id}/submit`)).status).toBe(200);
    expect((await approve(manager, 'grower_agreement', a.id)).status).toBe(200);

    const after = (await P(exec).get(`/growers/agreements/${a.id}`)).body.data;
    expect(after.status).toBe('active');
    const lotRow = await pool.query('SELECT quantity_allocated FROM seed_lots WHERE id = $1', [lot.id]);
    expect(Number(lotRow.rows[0].quantity_allocated)).toBe(100);
    // inputs are a debit; the advance waits for finance
    expect(after.ledger.map((e: { entry_type: string; amount: string }) => [e.entry_type, Number(e.amount)])).toEqual([['inputs', -5000]]);
    const adv = after.settlements.find((s: { settlement_type: string }) => s.settlement_type === 'advance');
    expect(adv.status).toBe('pending_approval');
    await approve(finance, 'grower_settlement', adv.id);
    expect((await P(finance).post(`/growers/settlements/${adv.id}/pay`, { paymentReference: 'ADV1', paymentMode: 'upi' })).status).toBe(403);
    expect((await P(finance2).post(`/growers/settlements/${adv.id}/pay`, { paymentReference: 'ADV1', paymentMode: 'upi' })).body.data.status).toBe('paid');

    // 3,000 kg at 14% moisture (standard 12) and 97% purity (minimum 98, 2% per point)
    const d = await P(exec).post('/growers/deliveries', { agreementId: a.id, grossWeightKg: 8000, tareWeightKg: 5000, bags: 75, vehicleNumber: 'AP07AB1234' });
    expect(d.status).toBe(201);
    expect(d.body.data.status).toBe('awaiting_inspection');
    const res = await inspect('grower_delivery', d.body.data.id, { moisture: 14, purity: 97 }, 'accept');
    expect(res.status).toBe(200);
    const priced = (await P(exec).get(`/growers/agreements/${a.id}`)).body.data.deliveries[0];
    // payable = 3000 × 86 / 88 = 2931.82 kg; value = 87,954.60; deduction 2% = 1,759.09
    expect(Number(priced.payable_weight_kg)).toBeCloseTo(2931.82, 2);
    expect(Number(priced.gross_value)).toBeCloseTo(87954.6, 2);
    expect(Number(priced.quality_deduction)).toBeCloseTo(1759.09, 2);
    expect(Number(priced.net_value)).toBeCloseTo(86195.51, 2);

    const s = await P(exec).post('/growers/settlements', { agreementId: a.id });
    expect(s.status).toBe(201);
    expect(Number(s.body.data.net_payable)).toBeCloseTo(86195.51 - 5000 - 20000, 2);
    expect((await P(exec).post('/growers/settlements', { agreementId: a.id })).status).toBe(409); // nothing left open
    await approve(finance, 'grower_settlement', s.body.data.id);
    const paid = await P(finance2).post(`/growers/settlements/${s.body.data.id}/pay`, { paymentReference: 'UTR-GR-1', paymentMode: 'neft' });
    expect(paid.body.data.status).toBe('paid');
    expect(paid.body.data.days_to_payment).not.toBeNull();

    const account = (await P(exec).get(`/growers/${after.grower_id}/account`)).body.data;
    expect(account.balance).toBeCloseTo(0, 2);
  });

  it('refuses to accept a delivery outside the agreed reject limits and checks the parent lot', async () => {
    const lot = await foundationLot();
    const grower = await activeParty('contract_grower', { village: 'Bapatla' });
    const wrongVariety = await P(exec).post('/growers/agreements', {
      growerId: grower.id, season: 'rabi', seasonYear: 2026, crop: 'Paddy', variety: 'MTU-1010', seedClass: 'Certified', plotVillage: 'Bapatla', areaAcres: 2,
      parentLotId: lot.id, parentQtyIssuedKg: 40, expectedYieldKg: 4000, buybackPricePerKg: 28, procurementWindowStart: inDays(-1), procurementWindowEnd: inDays(10),
    });
    expect(wrongVariety.status).toBe(400);

    const { agreement: a } = await agreement({ advanceAmount: 0, inputCostAmount: 0 });
    await P(exec).post(`/growers/agreements/${a.id}/submit`);
    await approve(manager, 'grower_agreement', a.id);
    const d = await P(exec).post('/growers/deliveries', { agreementId: a.id, grossWeightKg: 6000, tareWeightKg: 5000 });
    const wet = await inspect('grower_delivery', d.body.data.id, { moisture: 19, purity: 98 }, 'accept', { decisionNotes: 'wet' });
    expect(wet.status).toBe(400);
    expect(wet.body.message).toMatch(/reject limit/);
    // over the buy-back limit (120% of 10,000 kg)
    expect((await P(exec).post('/growers/deliveries', { agreementId: a.id, grossWeightKg: 20000, tareWeightKg: 5000 })).status).toBe(409);
  });
});
