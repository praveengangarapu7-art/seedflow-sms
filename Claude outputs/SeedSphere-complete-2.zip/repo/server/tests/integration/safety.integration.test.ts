import { beforeAll, describe, expect, it } from 'vitest';
import { api, jobActor, type Actor } from './helpers/actors';

const S = api('/api/v1/safety');
let officer: Actor, supervisor: Actor, plantMgr: Actor;

beforeAll(async () => {
  [officer, supervisor, plantMgr] = await Promise.all((['safety_officer', 'warehouse_supervisor', 'plant_manager'] as const).map((r) => jobActor(r)));
});

describe('safety incidents', () => {
  it('lets anyone report, raises an NCR for serious ones, and requires a cause to close', async () => {
    const minor = await S(supervisor).post('/incidents', { incidentType: 'near_miss', severity: 'minor', area: 'warehouse', description: 'Pallet nearly toppled' });
    expect(minor.status, JSON.stringify(minor.body)).toBe(201);
    expect(minor.body.data.ncr_id).toBeNull();
    expect((await S(supervisor).post('/incidents', { incidentType: 'fire', severity: 'major', area: 'bad', description: 'x' })).status).toBe(400);
    expect((await S(supervisor).post('/incidents', { incidentType: 'fire', severity: 'major', area: 'warehouse', description: 'x', occurredAt: new Date(Date.now() + 86_400_000).toISOString() })).status).toBe(400);

    const major = await S(supervisor).post('/incidents', { incidentType: 'chemical_spill', severity: 'major', area: 'processing', description: 'Treatment slurry spilled', chemical: 'Thiram', quantity: 2, unit: 'kg', lostTime: true });
    expect(major.status).toBe(201);
    expect(major.body.data.ncr_id).not.toBeNull();

    const id = major.body.data.id;
    expect((await S(supervisor).post(`/incidents/${id}/investigate`, {})).status).toBe(403);
    expect((await S(officer).post(`/incidents/${id}/investigate`, { rootCause: 'Torn drum' })).body.data.status).toBe('investigating');
    expect((await S(officer).post(`/incidents/${id}/close`, {})).status).toBe(400);
    const closed = await S(officer).post(`/incidents/${id}/close`, { correctiveAction: 'Replace drums; add secondary containment' });
    expect(closed.body.data.status).toBe('closed');
    expect((await S(officer).post(`/incidents/${id}/close`, { correctiveAction: 'again' })).status).toBe(409);

    const dash = await S(officer).get('/dashboard');
    expect(dash.body.data.open).toBeGreaterThanOrEqual(1);
    expect(dash.body.data.daysSinceLostTime).toBe(0);
    expect((await S(officer).get('/incidents?severity=major')).body.data.length).toBeGreaterThanOrEqual(1);
  });

  it('keeps a chemical balance and blocks use beyond what was received', async () => {
    const name = `Thiram-${Date.now()}`;
    expect((await S(plantMgr).post('/chemicals', { chemical: name, action: 'received', quantity: 20, unit: 'kg', supplier: 'AgroChem' })).status).toBe(201);
    expect((await S(plantMgr).post('/chemicals', { chemical: name, action: 'used', quantity: 5, unit: 'kg' })).status).toBe(201);
    expect((await S(plantMgr).post('/chemicals', { chemical: name, action: 'used', quantity: 50, unit: 'kg' })).status).toBe(409);
    expect((await S(plantMgr).post('/chemicals', { chemical: name, action: 'disposed', quantity: 1, unit: 'kg' })).status).toBe(400);
    expect((await S(plantMgr).post('/chemicals', { chemical: name, action: 'disposed', quantity: 1, unit: 'kg', disposalMethod: 'Licensed incinerator' })).status).toBe(201);
    expect((await S(supervisor).post('/chemicals', { chemical: name, action: 'received', quantity: 1 })).status).toBe(403);
    const reg = await S(officer).get('/chemicals');
    const row = reg.body.data.balances.find((b: { chemical: string }) => b.chemical === name);
    expect(row.on_hand).toBe(14);
  });
});
