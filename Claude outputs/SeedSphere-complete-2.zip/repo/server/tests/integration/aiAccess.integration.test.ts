import { describe, expect, it } from 'vitest';
import request from 'supertest';
import { pool } from '../../src/db/pool';
import { knowledgeIsStale, reindexKnowledge, resetKnowledgeCheck, ensureKnowledgeIndexed } from '../../src/modules/ai/knowledge.service';
import { jobActor, type Actor } from './helpers/actors';
import { app } from './testApp';

const get = (a: Actor, path: string) => request(app).get(`/api/v1${path}`).set('Authorization', `Bearer ${a.token}`);
const ask = (a: Actor, question: string) => request(app).post('/api/v1/assistant/ask').set('Authorization', `Bearer ${a.token}`).send({ question });

describe('AI access follows the job role', () => {
  it('keeps growers and dealers out of the AI and the assistant', async () => {
    for (const role of ['grower', 'dealer'] as const) {
      const a = await jobActor(role);
      expect((await get(a, '/ai/status')).status).toBe(403);
      expect((await get(a, '/ai/insights')).status).toBe(403);
      expect((await ask(a, 'which lots are low on stock?')).status).toBe(403);
    }
  });

  it('shows a module only to the roles that work in it', async () => {
    const tech = await jobActor('lab_technician');
    expect((await get(tech, '/ai/insights/laboratory')).status).toBe(200);
    expect((await get(tech, '/ai/insights/procurement')).status).toBe(403);
    const all = await get(tech, '/ai/insights');
    expect(all.status).toBe(200);
    expect(all.body.data.map((m: { module: string }) => m.module)).toEqual(['laboratory']);
  });

  it('gives administrators and module managers every module', async () => {
    for (const role of ['super_admin', 'purchase_manager'] as const) {
      const a = await jobActor(role);
      const all = await get(a, '/ai/insights');
      expect(all.body.data).toHaveLength(7);
    }
  });

  it('limits lot risk and stock forecasts to the teams that use them', async () => {
    const exec = await jobActor('purchase_executive');
    expect((await get(exec, '/ai/lab-risk')).status).toBe(403);
    expect((await get(exec, '/ai/forecasts')).status).toBe(200);
    const analyst = await jobActor('lab_quality_analyst');
    expect((await get(analyst, '/ai/lab-risk')).status).toBe(200);
    expect((await get(analyst, '/ai/forecasts')).status).toBe(403);
  });

  it('answers data questions only inside the role, with no records attached otherwise', async () => {
    const exec = await jobActor('purchase_executive');
    const res = await ask(exec, 'which lab results failed germination?');
    expect(res.status).toBe(200);
    expect(res.body.data.answer).toMatch(/area your role doesn't work in/);
    expect(res.body.data.citations).toEqual([]);
    const analyst = await jobActor('lab_quality_analyst');
    const ok = await ask(analyst, 'which lab results failed germination?');
    expect(ok.body.data.answer).not.toMatch(/area your role doesn't work in/);
  });
});

describe('knowledge index stays current', () => {
  it('re-indexes when a quality record changes after the last index', async () => {
    await reindexKnowledge();
    expect(await knowledgeIsStale()).toBe(false);

    const qo = await jobActor('quality_officer');
    const word = `zzfreshness${Date.now()}`;
    const created = await request(app)
      .post('/api/v1/quality/ncrs')
      .set('Authorization', `Bearer ${qo.token}`)
      .send({ title: `Seal failure ${word}`, description: 'Bag seal opened in transit', department: 'production', source: 'inspection', severity: 'minor' });
    expect(created.status).toBe(201);
    expect(await knowledgeIsStale()).toBe(true);

    resetKnowledgeCheck();
    await ensureKnowledgeIndexed();
    expect(await knowledgeIsStale()).toBe(false);
    const hit = await pool.query('SELECT 1 FROM ai_knowledge_docs WHERE title LIKE $1', [`%${word}%`]);
    expect(hit.rowCount).toBe(1);
  });
});
