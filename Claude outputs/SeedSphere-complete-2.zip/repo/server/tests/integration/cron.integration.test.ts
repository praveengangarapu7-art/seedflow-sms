import { describe, expect, it } from 'vitest';
import request from 'supertest';
import { env } from '../../src/config/env';
import { app } from './testApp';

describe('cron endpoints', () => {
  it('refuses a call without the secret, and runs the outbox with it', async () => {
    const before = env.cronSecret;
    (env as { cronSecret: string }).cronSecret = 'test-cron-secret-123';
    try {
      expect((await request(app).get('/api/v1/cron/outbox')).status).toBe(401);
      expect((await request(app).get('/api/v1/cron/outbox').set('Authorization', 'Bearer wrong')).status).toBe(401);
      const res = await request(app).get('/api/v1/cron/outbox').set('Authorization', 'Bearer test-cron-secret-123');
      expect(res.status).toBe(200);
      expect(res.body.data).toHaveProperty('attempted');
    } finally {
      (env as { cronSecret: string }).cronSecret = before;
    }
  });

  it('is switched off when no secret is configured', async () => {
    const before = env.cronSecret;
    (env as { cronSecret: string }).cronSecret = '';
    try {
      expect((await request(app).get('/api/v1/cron/outbox').set('Authorization', 'Bearer ')).status).toBe(401);
    } finally {
      (env as { cronSecret: string }).cronSecret = before;
    }
  });
});
