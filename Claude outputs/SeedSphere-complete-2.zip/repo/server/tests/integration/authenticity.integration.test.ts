import { describe, expect, it } from 'vitest';
import request from 'supertest';
import { createTestSeedLot, createTestUser } from '../factories';
import { loginAs } from './authHelper';
import { app } from './testApp';

describe('lot authenticity chain', () => {
  it('reports a lot with no history as not started, and starts the chain when a certificate is issued', async () => {
    const admin = await createTestUser({ role: 'Admin' });
    const token = await loginAs(admin);
    const lot = await createTestSeedLot();

    const before = await request(app).get(`/api/v1/authenticity/seed-lots/${lot.id}/verify-chain`).set('Authorization', `Bearer ${token}`);
    expect(before.status).toBe(200);
    expect(before.body.data).toMatchObject({ valid: true, length: 0 });

    const cert = await request(app).post(`/api/v1/authenticity/seed-lots/${lot.id}/certificates`).set('Authorization', `Bearer ${token}`).send({});
    expect(cert.status).toBe(201);

    const chain = await request(app).get(`/api/v1/authenticity/seed-lots/${lot.id}/chain`).set('Authorization', `Bearer ${token}`);
    expect(chain.body.data[0].event_type ?? chain.body.data[0].eventType).toBe('BASELINE');

    const after = await request(app).get(`/api/v1/authenticity/seed-lots/${lot.id}/verify-chain`).set('Authorization', `Bearer ${token}`);
    expect(after.body.data).toMatchObject({ valid: true, length: 1 });
  });

  it('still answers 404 for a lot that does not exist', async () => {
    const admin = await createTestUser({ role: 'Admin' });
    const token = await loginAs(admin);
    const res = await request(app).get('/api/v1/authenticity/seed-lots/00000000-0000-0000-0000-000000000000/verify-chain').set('Authorization', `Bearer ${token}`);
    expect(res.status).toBe(404);
  });
});
