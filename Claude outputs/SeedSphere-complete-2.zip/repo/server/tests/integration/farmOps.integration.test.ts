import { randomUUID } from 'node:crypto';
import { pool } from '../../src/db/pool';
import { beforeAll, describe, expect, it } from 'vitest';
import { api, inDays, jobActor, type Actor } from './helpers/actors';

const API = api('/api/v1');
let admin: Actor, supervisor: Actor;
const sfx = () => randomUUID().slice(0, 5);

beforeAll(async () => {
  [admin, supervisor] = await Promise.all((['super_admin', 'warehouse_supervisor'] as const).map((r) => jobActor(r)));
});

describe('production planning', () => {
  it('registers farms, plans crops and records inspections', async () => {
    const crop = `Chilli-${sfx()}`;
    const farmer = (await pool.query(`INSERT INTO farmers (name, region) VALUES ($1,'Guntur') RETURNING id`, [`Farmer ${sfx()}`])).rows[0].id;
    const variety = (await pool.query(`INSERT INTO varieties (crop, variety_name, botanical_name, status, created_by) VALUES ($1,'V1','Bot','approved','test') RETURNING id`, [crop])).rows[0].id;

    const farm = await API(admin).post('/master-data/farms', { farmerId: farmer, name: 'Plot A', area: 5, soilType: 'red', irrigationType: 'drip' });
    expect(farm.status, JSON.stringify(farm.body)).toBe(201);
    expect(farm.body.data.area).toBe(5);
    expect((await API(admin).post('/master-data/farms', { farmerId: farmer, name: 'plot a', area: 5 })).status).toBe(409);
    expect((await API(admin).post('/master-data/farms', { farmerId: farmer, name: 'Zero', area: 0 })).status).toBe(400);

    const plan = await API(admin).post('/production/crop-plans', { farmId: farm.body.data.id, varietyId: variety, crop, season: 'Kharif 2026', targetArea: 5, targetProduction: 2000, sowingDate: inDays(-5) });
    expect(plan.status, JSON.stringify(plan.body)).toBe(201);
    expect(plan.body.data.planCode).toMatch(/^CRP-/);
    const upd = await API(admin).put(`/production/crop-plans/${plan.body.data.id}`, { status: 'Growing' });
    expect(upd.body.data.status).toBe('Growing');
    expect((await API(admin).put(`/production/crop-plans/${plan.body.data.id}`, { status: 'Bogus' })).status).toBe(400);

    const fi = await API(admin).post('/production/farm-inspections', { farmId: farm.body.data.id, cropStage: 'Flowering', healthScore: 70, diseaseDetected: true, diseaseName: 'Rust' });
    expect(fi.status, JSON.stringify(fi.body)).toBe(201);
    expect((await API(admin).get('/production/farm-inspections')).body.data.some((x: { id: string }) => x.id === fi.body.data.id)).toBe(true);
    const rec = await API(admin).post('/production/inspections', { farmId: farm.body.data.id, crop, status: 'Scheduled' });
    expect((await API(admin).patch(`/production/inspections/${rec.body.data.id}/approve`)).status).toBe(409);
    await API(admin).put(`/production/inspections/${rec.body.data.id}`, { status: 'Completed' });
    expect((await API(admin).patch(`/production/inspections/${rec.body.data.id}/approve`)).body.data.status).toBe('Approved');

    const dash = await API(admin).get('/analytics/production-dashboard');
    expect(dash.body.data.activeFarms).toBeGreaterThan(0);
    expect((await API(supervisor).get('/master-data/farms')).status).toBe(200);
    expect((await API(admin).get('/master-data/varieties')).body.data.some((v: { id: string }) => v.id === variety)).toBe(true);
  });

  it('runs a harvest request through approval, harvest, transport and delivery', async () => {
    const farmer = (await pool.query(`INSERT INTO farmers (name, region) VALUES ($1,'Warangal') RETURNING id`, [`Farmer ${sfx()}`])).rows[0].id;
    const farm = (await API(admin).post('/master-data/farms', { farmerId: farmer, name: `Plot ${sfx()}`, area: 3 })).body.data.id;
    const hr = await API(supervisor).post('/production/harvests', { farmId: farm, crop: 'Maize', estimatedQuantityKg: 1200, requestedHarvestDate: inDays(4) });
    expect(hr.status, JSON.stringify(hr.body)).toBe(201);
    const id = hr.body.data.id;
    expect(hr.body.data.status).toBe('Pending Approval');
    expect((await API(supervisor).post(`/production/harvests/${id}/approve`, {})).status).toBe(409); // requester cannot approve
    expect((await API(admin).post(`/production/harvests/${id}/reject`, {})).status).toBe(400); // needs a reason
    expect((await API(admin).post(`/production/harvests/${id}/complete`, { actualQuantityKg: 100 })).status).toBe(409); // not approved yet
    const ap = await API(admin).post(`/production/harvests/${id}/approve`, { inspectorNotes: 'Ready' });
    expect(ap.body.data.status).toBe('Approved');
    expect(ap.body.data.lotId).toMatch(/^LOT-\d{4}-\d{4}$/);
    expect((await API(admin).post(`/production/harvests/${id}/transport`, { transporterName: 'T', vehicleNumber: 'ap09', destination: 'Plant', dispatchDate: inDays(5) })).status).toBe(409);
    expect((await API(admin).post(`/production/harvests/${id}/complete`, { actualQuantityKg: 1100 })).body.data.status).toBe('Harvested');
    const tr = await API(admin).post(`/production/harvests/${id}/transport`, { transporterName: 'T', vehicleNumber: 'ap09', destination: 'Plant', dispatchDate: inDays(5) });
    expect(tr.body.data.transport.vehicleNumber).toBe('AP09');
    const done = await API(admin).post(`/production/harvests/${id}/deliver`, {});
    expect(done.body.data.status).toBe('Delivered to Processing');
    expect(done.body.data.history.length).toBeGreaterThanOrEqual(5);
  });
});
