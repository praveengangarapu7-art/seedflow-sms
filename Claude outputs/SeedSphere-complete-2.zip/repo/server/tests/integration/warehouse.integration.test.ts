import { randomUUID } from 'node:crypto';
import { beforeAll, describe, expect, it } from 'vitest';
import request from 'supertest';
import { pool } from '../../src/db/pool';
import { createTestSeedLot } from '../factories';
import { api, inDays, jobActor, legacyActor, type Actor } from './helpers/actors';
import { activeParty, approve, runInspection } from './helpers/flows';
import { app } from './testApp';

const W = api('/api/v1/warehouse');

let sup: Actor;
let mgr: Actor;
let whInspector: Actor;
let exec: Actor;
let pmgr: Actor;
let warehouseId: string;
let binA: string;
let binB: string;
let quarantine: string;
let dealer: { id: string; name: string };

async function testedLot(opts: { variety?: string; testedOn?: string; germ?: number; qty?: number } = {}) {
  const lot = await createTestSeedLot({ crop: 'Paddy', variety: opts.variety ?? `WH-${randomUUID().slice(0, 5)}`, quantityTotal: opts.qty ?? 2000 });
  const t = await W(sup).post('/lot-tests', { seedLotId: lot.id, testedOn: opts.testedOn ?? inDays(-10), germinationPct: opts.germ ?? 88, minGerminationPct: 80, laboratory: 'State Seed Testing Laboratory, Guntur', reportNumber: `STL-${randomUUID().slice(0, 4)}` });
  expect(t.status).toBe(201);
  return lot;
}

async function stockIn(lotId: string, kg: number, locationId = binA) {
  const r = await W(sup).post('/receipts', { seedLotId: lotId, locationId, quantityKg: kg, sourceType: 'processing' });
  expect(r.status, JSON.stringify(r.body)).toBe(201);
}

async function approvedDispatch(lotId: string, kg: number) {
  const d = await W(sup).post('/dispatches', { dealerId: dealer.id, warehouseId, requestedDate: inDays(1), lines: [{ seedLotId: lotId, locationId: binA, quantityKg: kg }] });
  expect(d.status, JSON.stringify(d.body)).toBe(201);
  expect((await W(sup).post(`/dispatches/${d.body.data.id}/submit`)).status).toBe(200);
  expect((await approve(mgr, 'dispatch_order', d.body.data.id)).body.data.status).toBe('approved');
  return d.body.data;
}

beforeAll(async () => {
  sup = await jobActor('warehouse_supervisor');
  mgr = await jobActor('warehouse_manager');
  whInspector = await jobActor('warehouse_quality_field_inspector');
  exec = await jobActor('purchase_executive');
  pmgr = await jobActor('purchase_manager');
  const w = await W(mgr).post('/warehouses', { code: `WH${randomUUID().slice(0, 4)}`, name: 'Guntur central godown' });
  expect(w.status).toBe(201);
  warehouseId = w.body.data.id;
  binA = (await W(mgr).post('/locations', { warehouseId, code: 'A-01-01', zone: 'A', capacityKg: 20000 })).body.data.id;
  binB = (await W(mgr).post('/locations', { warehouseId, code: 'B-01-01', zone: 'B' })).body.data.id;
  quarantine = (await W(mgr).get(`/locations?warehouseId=${warehouseId}`)).body.data.find((l: { location_type: string }) => l.location_type === 'quarantine').id;
  dealer = await activeParty(exec, pmgr, 'dealer', { licenceNumber: 'SDL/GNT/2026/41', licenceValidUntil: inDays(300), village: 'Tenali' });
});

describe('stock ledger', () => {
  it('receives no more than the lot holds and moves stock between bins, never out of quarantine by transfer', async () => {
    const lot = await testedLot({ qty: 1000 });
    await stockIn(lot.id, 800);
    expect((await W(sup).post('/receipts', { seedLotId: lot.id, locationId: binA, quantityKg: 300, sourceType: 'processing' })).status).toBe(409);
    expect((await W(sup).post('/receipts', { seedLotId: lot.id, locationId: quarantine, quantityKg: 100, sourceType: 'processing' })).status).toBe(409);
    expect((await W(sup).post('/transfers', { seedLotId: lot.id, fromLocationId: binA, toLocationId: binB, quantityKg: 900 })).status).toBe(409);
    expect((await W(sup).post('/transfers', { seedLotId: lot.id, fromLocationId: binA, toLocationId: binB, quantityKg: 300 })).status).toBe(200);
    const s = (await W(sup).get(`/stock/lots/${lot.id}`)).body.data;
    expect(s.locations.map((l: { location_code: string; quantity_kg: number }) => [l.location_code, Number(l.quantity_kg)]).sort()).toEqual([
      ['A-01-01', 500],
      ['B-01-01', 300],
    ]);
    expect(s.sale.status).toBe('sellable');
  });

  it('routes adjustments and count variances through the warehouse manager', async () => {
    const lot = await testedLot();
    await stockIn(lot.id, 500, binB);
    const adj = await W(sup).post('/adjustments', { seedLotId: lot.id, locationId: binB, quantityChange: -20, reason: 'damage', details: 'Rat damage to 1 bag' });
    expect(adj.status).toBe(201);
    expect((await approve(sup, 'stock_adjustment', adj.body.data.id)).status).toBe(403);
    await approve(mgr, 'stock_adjustment', adj.body.data.id);
    const count = await W(mgr).post('/counts', { warehouseId, zone: 'B' });
    expect(count.status, JSON.stringify(count.body)).toBe(201);
    const line = count.body.data.lines.find((l: { seed_lot_id: string }) => l.seed_lot_id === lot.id);
    expect(Number(line.system_kg)).toBe(480);
    const others = count.body.data.lines.filter((l: { id: string }) => l.id !== line.id).map((l: { id: string; system_kg: number }) => ({ lineId: l.id, countedKg: Number(l.system_kg) }));
    await W(sup).put(`/counts/${count.body.data.id}/lines`, { lines: [{ lineId: line.id, countedKg: 470 }, ...others] });
    const sub = await W(sup).post(`/counts/${count.body.data.id}/submit`);
    expect(sub.body.data.adjustments).toHaveLength(1);
    expect(Number(sub.body.data.adjustments[0].quantity_change)).toBe(-10);
  });
});

describe('dispatch to dealers', () => {
  it('dispatches saleable stock after approval and confirms delivery, building the recall list', async () => {
    const lot = await testedLot();
    await stockIn(lot.id, 1000);
    const d = await approvedDispatch(lot.id, 300);
    expect((await W(sup).post(`/dispatches/${d.id}/ship`, {})).status).toBe(400); // vehicle required
    const shipped = await W(sup).post(`/dispatches/${d.id}/ship`, { vehicleNumber: 'AP 07 TB 2231', lrNumber: 'LR-551' });
    expect(shipped.body.data.status).toBe('dispatched');
    expect((await W(sup).post(`/dispatches/${d.id}/deliver`, { receivedByName: 'K. Srinivas' })).body.data.status).toBe('delivered');
    const recip = (await W(sup).get(`/lots/${lot.id}/recipients`)).body.data;
    expect(recip[0].name).toBe(dealer.name);
    expect(Number(recip[0].dispatched_kg)).toBe(300);
    const s = (await W(sup).get(`/stock/lots/${lot.id}`)).body.data;
    expect(Number(s.locations[0].quantity_kg)).toBe(700);
  });

  it('refuses untested, expired and failed seed, reserved stock, and an unlicensed dealer', async () => {
    const untested = await createTestSeedLot({ crop: 'Paddy', variety: 'UNT', quantityTotal: 500 });
    await stockIn(untested.id, 200);
    expect((await W(sup).post('/dispatches', { dealerId: dealer.id, warehouseId, requestedDate: inDays(1), lines: [{ seedLotId: untested.id, locationId: binA, quantityKg: 10 }] })).body.message).toMatch(/no germination test/);
    const expired = await testedLot({ testedOn: inDays(-300) });
    await stockIn(expired.id, 100);
    expect((await W(sup).post('/dispatches', { dealerId: dealer.id, warehouseId, requestedDate: inDays(1), lines: [{ seedLotId: expired.id, locationId: binA, quantityKg: 10 }] })).body.message).toMatch(/validity/);
    const failed = await testedLot({ germ: 70 });
    await stockIn(failed.id, 100);
    expect((await W(sup).post('/dispatches', { dealerId: dealer.id, warehouseId, requestedDate: inDays(1), lines: [{ seedLotId: failed.id, locationId: binA, quantityKg: 10 }] })).body.message).toMatch(/failed/);

    const lot = await testedLot();
    await stockIn(lot.id, 100);
    await approvedDispatch(lot.id, 80);
    expect((await W(sup).post('/dispatches', { dealerId: dealer.id, warehouseId, requestedDate: inDays(1), lines: [{ seedLotId: lot.id, locationId: binA, quantityKg: 30 }] })).status).toBe(409);

    const lapsed = await activeParty(exec, pmgr, 'dealer', { licenceNumber: 'SDL/OLD/1', licenceValidUntil: inDays(30) });
    await pool.query('UPDATE parties SET licence_valid_until = $2 WHERE id = $1', [lapsed.id, inDays(-1)]);
    expect((await W(sup).post('/dispatches', { dealerId: lapsed.id, warehouseId, requestedDate: inDays(1), lines: [{ seedLotId: lot.id, locationId: binA, quantityKg: 5 }] })).body.message).toMatch(/licence expired/);
  });

  it('blocks shipping when the lot is put on hold after approval, and advises first-expiry-first-out', async () => {
    const variety = `FEFO-${randomUUID().slice(0, 4)}`;
    const older = await testedLot({ variety, testedOn: inDays(-200) });
    const newer = await testedLot({ variety, testedOn: inDays(-5) });
    await stockIn(older.id, 100);
    await stockIn(newer.id, 100);
    const draft = await W(sup).post('/dispatches', { dealerId: dealer.id, warehouseId, requestedDate: inDays(1), lines: [{ seedLotId: newer.id, locationId: binA, quantityKg: 50 }] });
    expect(draft.body.data.warnings[0]).toMatch(/First-expiry-first-out/);

    const d = await approvedDispatch(newer.id, 20);
    const qi = await legacyActor('Inspector');
    const hold = await request(app).post('/api/v1/quality/holds').set('Authorization', `Bearer ${qi.token}`).send({ seedLotId: newer.id, reason: 'Farmer complaints of poor emergence' });
    expect(hold.status).toBe(201);
    const blocked = await W(sup).post(`/dispatches/${d.id}/ship`, { vehicleNumber: 'AP07TB2231' });
    expect(blocked.status).toBe(409);
    expect(blocked.body.message).toMatch(/quality hold/);
  });
});

describe('returns', () => {
  it('quarantines a returned lot, logs the complaint, and restocks only after an accepting inspection', async () => {
    const lot = await testedLot();
    await stockIn(lot.id, 500);
    const d = await approvedDispatch(lot.id, 200);
    await W(sup).post(`/dispatches/${d.id}/ship`, { vehicleNumber: 'AP07TB1111' });
    expect((await W(sup).post('/returns', { dealerId: dealer.id, dispatchId: d.id, seedLotId: lot.id, quarantineLocationId: quarantine, quantityKg: 250, reason: 'unsold' })).status).toBe(409);
    const ret = await W(sup).post('/returns', { dealerId: dealer.id, dispatchId: d.id, seedLotId: lot.id, quarantineLocationId: quarantine, quantityKg: 40, reason: 'quality_complaint', details: 'Bags swollen, seed smells musty', complaintSeverity: 'minor' });
    expect(ret.status, JSON.stringify(ret.body)).toBe(201);
    expect(ret.body.data.complaint_code).toMatch(/^CMP-/);
    expect((await W(mgr).post(`/returns/${ret.body.data.id}/decide`, { disposition: 'restock', note: 'ok', toLocationId: binA })).status).toBe(409); // not inspected
    const ins = await runInspection(whInspector, { type: 'warehouse_return', subjectType: 'stock_return', subjectId: ret.body.data.id }, {}, 'accept');
    expect(ins.status, JSON.stringify(ins.body)).toBe(200);
    expect((await W(sup).post(`/returns/${ret.body.data.id}/decide`, { disposition: 'restock', note: 'ok', toLocationId: binA })).status).toBe(403);
    const done = await W(mgr).post(`/returns/${ret.body.data.id}/decide`, { disposition: 'restock', note: 'Seal intact, dried and rebagged', toLocationId: binA, creditNoteAmount: 0 });
    expect(done.body.data.status).toBe('restocked');
    const s = (await W(sup).get(`/stock/lots/${lot.id}`)).body.data;
    expect(Number(s.locations.find((l: { location_code: string }) => l.location_code === 'A-01-01').quantity_kg)).toBe(340);
  });
});

describe('storage sensors', () => {
  it('opens a breach with a non-conformance when out of range, closes it on recovery, and accepts device readings by key', async () => {
    const lot = await testedLot();
    await stockIn(lot.id, 100, binB);
    const s = await W(mgr).post('/sensors', { code: `T-${randomUUID().slice(0, 5)}`, locationId: binB, sensorType: 'temperature', unit: '°C', maxValue: 25 });
    expect(s.status).toBe(201);
    const { sensor, deviceKey } = s.body.data;
    const hot = await W(sup).post(`/sensors/${sensor.id}/readings`, { value: 31.5 });
    expect(hot.body.data.outOfRange).toBe(true);
    let list = (await W(sup).get('/sensors')).body.data.find((x: { id: string }) => x.id === sensor.id);
    expect(list.breach_ncr_code).toMatch(/^NCR-/);
    await W(sup).post(`/sensors/${sensor.id}/readings`, { value: 33 });
    const ok = await request(app).post('/api/v1/warehouse/devices/sensor-readings').set('X-Sensor-Code', sensor.code).set('X-Device-Key', deviceKey).send({ value: 22.4 });
    expect(ok.status).toBe(201);
    list = (await W(sup).get('/sensors')).body.data.find((x: { id: string }) => x.id === sensor.id);
    expect(list.open_breach_id).toBeNull();
    const hist = (await W(sup).get(`/sensors/${sensor.id}/history`)).body.data;
    expect(Number(hist.breaches[0].worst_value)).toBe(33);
    const bad = await request(app).post('/api/v1/warehouse/devices/sensor-readings').set('X-Sensor-Code', sensor.code).set('X-Device-Key', 'wrong').send({ value: 20 });
    expect(bad.status).toBe(401);
  });
});
