import { randomUUID } from 'node:crypto';
import request from 'supertest';
import { beforeAll, describe, expect, it } from 'vitest';
import { pool } from '../../src/db/pool';
import { createTestSeedLot } from '../factories';
import { api, inDays, jobActor, type Actor } from './helpers/actors';
import { activeParty, approve } from './helpers/flows';
import { app } from './testApp';

const A = api('/api/v1/assurance');
const W = api('/api/v1/warehouse');
const R = api('/api/v1/reach');
const PORTAL = api('/api/v1/portal');
const parties = api('/api/v1/parties');

let rdExec: Actor, rdMgr: Actor, qMgr: Actor, qOff: Actor, sup: Actor, whMgr: Actor, exec: Actor, pmgr: Actor, plantMgr: Actor, dealerUser: Actor, admin: Actor, plantSup: Actor;
let warehouseId: string, binA: string, dealer: { id: string };

beforeAll(async () => {
  [rdExec, rdMgr, qMgr, qOff, sup, whMgr, exec, pmgr, plantMgr, dealerUser, admin, plantSup] = await Promise.all(
    ['rd_executive', 'rd_manager', 'quality_manager', 'quality_officer', 'warehouse_supervisor', 'warehouse_manager', 'purchase_executive', 'purchase_manager', 'plant_manager', 'dealer', 'system_admin', 'plant_supervisor'].map((r) => jobActor(r as never)),
  );
  warehouseId = (await W(whMgr).post('/warehouses', { code: `AS${randomUUID().slice(0, 4)}`, name: 'Assurance test godown' })).body.data.id;
  binA = (await W(whMgr).post('/locations', { warehouseId, code: 'A-01-01', zone: 'A', capacityKg: 50000 })).body.data.id;
  dealer = await activeParty(exec, pmgr, 'dealer', { licenceNumber: 'SDL/A/1', licenceValidUntil: inDays(300), village: 'Tenali' });
  expect((await parties(pmgr).post(`/${dealer.id}/portal-user`, { email: dealerUser.user.email })).status).toBe(200);
});

describe('R&D trial → candidate → release', () => {
  it('runs a trial, ranks entries against the check, and releases a variety only with a prepared spec and two sign-offs', async () => {
    const crop = `Chilli-${randomUUID().slice(0, 4)}`;
    const t = await A(rdExec).post('/rd/trials', {
      title: 'Yield trial', crop, season: 'Kharif 2026', location: 'Guntur', replications: 2,
      traits: [{ name: 'yield', unit: 'q/ha', higherIsBetter: true }, { name: 'days_to_flower', unit: 'days', higherIsBetter: false }],
      entries: [{ name: 'Check-1', isCheck: true }, { name: 'Line-A' }, { name: 'Line-B' }],
    });
    expect(t.status, JSON.stringify(t.body)).toBe(201);
    const id = t.body.data.id;
    expect((await A(rdExec).post(`/rd/trials/${id}/start`)).status).toBe(409); // not approved
    expect((await A(rdExec).post(`/rd/trials/${id}/submit`)).status).toBe(200);
    expect((await approve(rdExec, 'trial_protocol', id)).status).toBe(403); // not their permission
    expect((await approve(rdMgr, 'trial_protocol', id)).status).toBe(200);
    expect((await A(rdExec).post(`/rd/trials/${id}/start`)).status).toBe(200);

    const detail = (await A(rdExec).get(`/rd/trials/${id}`)).body.data;
    const e = Object.fromEntries(detail.entries.map((x: { name: string; id: string }) => [x.name, x.id]));
    const obs = [];
    for (const rep of [1, 2]) {
      obs.push({ entryId: e['Check-1'], replication: rep, trait: 'yield', value: 20 }, { entryId: e['Line-A'], replication: rep, trait: 'yield', value: 25 }, { entryId: e['Line-B'], replication: rep, trait: 'yield', value: 18 });
      obs.push({ entryId: e['Check-1'], replication: rep, trait: 'days_to_flower', value: 50 }, { entryId: e['Line-A'], replication: rep, trait: 'days_to_flower', value: 45 }, { entryId: e['Line-B'], replication: rep, trait: 'days_to_flower', value: 55 });
    }
    expect((await A(rdExec).post(`/rd/trials/${id}/observations`, { observations: [{ ...obs[0], trait: 'nonsense' }] })).status).toBe(400);
    expect((await A(rdExec).post(`/rd/trials/${id}/observations`, { observations: [{ ...obs[0], replication: 3 }] })).status).toBe(400);
    expect((await A(rdExec).post(`/rd/trials/${id}/observations`, { observations: obs })).status).toBe(200);
    expect((await A(rdExec).post(`/rd/trials/${id}/complete`)).status).toBe(200);

    const done = (await A(rdExec).get(`/rd/trials/${id}`)).body.data;
    const yieldRows = done.analysis.perTrait.find((p: { trait: string }) => p.trait === 'yield').rows;
    const lineA = yieldRows.find((r: { name: string }) => r.name === 'Line-A');
    expect(lineA.mean).toBe(25);
    expect(lineA.overCheckPct).toBe(25);
    expect(lineA.rank).toBe(1);
    const flower = done.analysis.perTrait.find((p: { trait: string }) => p.trait === 'days_to_flower').rows.find((r: { name: string }) => r.name === 'Line-A');
    expect(flower.overCheckPct).toBe(10); // earlier is better
    expect(done.analysis.overall[0].name).toBe('Line-A');

    const c = await A(rdExec).post('/rd/candidates', { name: `Line-A-${randomUUID().slice(0, 3)}`, sourceTrialId: id });
    expect(c.status, JSON.stringify(c.body)).toBe(201);
    const cid = c.body.data.id;
    const a1 = await A(rdExec).post(`/rd/candidates/${cid}/advance`, { toStage: 'multi_location', justification: 'Beat the check by 25%' });
    expect(a1.status).toBe(201);
    expect((await A(rdExec).post(`/rd/candidates/${cid}/advance`, { toStage: 'pre_release', justification: 'x' })).status).toBe(409); // one at a time
    expect((await approve(rdMgr, 'variety_advancement', a1.body.data.id)).status).toBe(200);
    expect((await A(rdExec).post(`/rd/candidates/${cid}/advance`, { toStage: 'released', justification: 'skip' })).status).toBe(409); // cannot skip stages
    const a2 = await A(rdExec).post(`/rd/candidates/${cid}/advance`, { toStage: 'pre_release', justification: 'Confirmed at 3 sites' });
    expect((await approve(rdMgr, 'variety_advancement', a2.body.data.id)).status).toBe(200);

    // release needs a prepared spec
    expect((await A(rdExec).post(`/rd/candidates/${cid}/advance`, { toStage: 'released', justification: 'ready' })).status).toBe(409);
    expect((await A(rdExec).put(`/rd/candidates/${cid}/spec`, { descriptors: { plant_height: '90 cm' }, ready: true })).status).toBe(400);
    expect((await A(rdExec).put(`/rd/candidates/${cid}/spec`, { descriptors: { plant_height: '90 cm' }, minGerminationPct: 70, minPurityPct: 98, maxMoisturePct: 8, ready: true })).status).toBe(200);
    const rel = await A(rdExec).post(`/rd/candidates/${cid}/advance`, { toStage: 'released', justification: 'Release for Kharif 2027' });
    expect(rel.status, JSON.stringify(rel.body)).toBe(201);
    expect((await approve(rdMgr, 'variety_release', rel.body.data.id)).status).toBe(200);
    expect((await A(rdExec).get(`/rd/candidates/${cid}`)).body.data.stage).toBe('pre_release'); // still waiting for quality sign-off
    expect((await approve(rdMgr, 'variety_release', rel.body.data.id)).status).toBe(403); // wrong permission for step 2 / same person
    expect((await approve(qMgr, 'variety_release', rel.body.data.id)).status).toBe(200);
    const final = (await A(rdExec).get(`/rd/candidates/${cid}`)).body.data;
    expect(final.stage).toBe('released');
    expect(final.variety_id).toBeTruthy();
    expect(final.spec.status).toBe('handed_over');
    expect((await A(rdExec).put(`/rd/candidates/${cid}/spec`, { descriptors: { a: 1 } })).status).toBe(409); // locked
    const v = await pool.query('SELECT status FROM varieties WHERE id = $1', [final.variety_id]);
    expect(v.rows[0].status).toBe('approved');
  });
});

describe('recalls', () => {
  it('traces dealers, holds lots on approval, notifies, flags the pack tag, and tracks acknowledgement', async () => {
    const lot = await createTestSeedLot({ crop: 'Paddy', variety: `RCL-${randomUUID().slice(0, 4)}`, quantityTotal: 1000 });
    expect((await W(sup).post('/lot-tests', { seedLotId: lot.id, testedOn: inDays(-3), germinationPct: 91, minGerminationPct: 80, laboratory: 'STL', reportNumber: `S-${randomUUID().slice(0, 4)}` })).status).toBe(201);
    expect((await W(sup).post('/receipts', { seedLotId: lot.id, locationId: binA, quantityKg: 1000, sourceType: 'processing' })).status).toBe(201);
    const tags = await R(plantMgr).post('/tags', { seedLotId: lot.id, count: 5, packSizeKg: 10 });
    const tagCode = tags.body.data.tagCodes[0];
    const d = await W(sup).post('/dispatches', { dealerId: dealer.id, warehouseId, requestedDate: inDays(1), lines: [{ seedLotId: lot.id, locationId: binA, quantityKg: 200 }] });
    await W(sup).post(`/dispatches/${d.body.data.id}/submit`);
    await approve(whMgr, 'dispatch_order', d.body.data.id);
    expect((await W(sup).post(`/dispatches/${d.body.data.id}/ship`, { vehicleNumber: 'AP07TB1111' })).status).toBe(200);
    const pub = (c: string) => request(app).get(`/api/v1/public/verify/${c}`);
    expect((await pub(tagCode)).body.data.verdict).toBe('genuine');

    const trace = await A(qOff).post('/recalls/trace', { lotIds: [lot.id] });
    expect(trace.body.data).toHaveLength(1);
    expect(trace.body.data[0].dispatched_kg).toBe(200);

    expect((await A(exec).post('/recalls', {})).status).toBe(403);
    const rc = await A(qOff).post('/recalls', { title: 'Off-type plants', reason: 'Multiple field reports of off-types', recallClass: 'II', actionRequired: 'Stop sale and return unsold stock.', lotIds: [lot.id] });
    expect(rc.status, JSON.stringify(rc.body)).toBe(201);
    const id = rc.body.data.id;
    expect((await A(qOff).post(`/recalls/${id}/submit`)).status).toBe(200);
    expect((await approve(qOff, 'recall', id)).status).toBe(403);
    expect((await approve(qMgr, 'recall', id)).status).toBe(200);

    const rec = (await A(qOff).get(`/recalls/${id}`)).body.data;
    expect(rec.status).toBe('in_progress');
    expect(rec.recipients).toHaveLength(1);
    expect(rec.recipients[0].notified_at).toBeTruthy();
    const hold = await pool.query('SELECT 1 FROM quality_lot_holds WHERE seed_lot_id = $1 AND released_at IS NULL', [lot.id]);
    expect(hold.rowCount).toBe(1);
    const msg = await pool.query(`SELECT body FROM msg_outbox WHERE related_type = 'recall' AND related_id = $1`, [id]);
    expect(msg.rowCount).toBe(1);
    expect(msg.rows[0].body).toContain('SAFETY NOTICE');
    expect((await pub(tagCode)).body.data.verdict).toBe('recalled');

    // closing before the dealer acknowledges is refused
    expect((await A(qOff).post(`/recalls/${id}/close`, { closureNote: 'done' })).status).toBe(409);
    const mine = await request(app).get('/api/v1/portal/recalls').set('Authorization', `Bearer ${dealerUser.token}`);
    expect(mine.body.data).toHaveLength(1);
    expect((await request(app).post(`/api/v1/portal/recalls/${mine.body.data[0].id}/acknowledge`).set('Authorization', `Bearer ${dealerUser.token}`).send({ note: 'Stock segregated' })).status).toBe(200);
    expect((await A(qOff).get(`/recalls/${id}`)).body.data.effectiveness.acknowledgedPct).toBe(100);
    expect((await A(qOff).post(`/recalls/${id}/close`, { closureNote: 'All dealers confirmed' })).status).toBe(200);
    void PORTAL;
  });
});

describe('audits', () => {
  it('raises an NCR for a major finding and will not close while findings are open', async () => {
    const a = await A(qOff).post('/audits', { auditType: 'dealer', title: 'Dealer premises check', auditee: 'Sri Sai Seeds', scheduledDate: inDays(2), leadAuditor: 'Quality Officer' });
    expect(a.status, JSON.stringify(a.body)).toBe(201);
    const id = a.body.data.id;
    expect((await A(qOff).post(`/audits/${id}/findings`, { severity: 'minor', description: 'x' })).status).toBe(409); // not started
    expect((await A(qOff).post(`/audits/${id}/start`)).status).toBe(200);
    const minor = await A(qOff).post(`/audits/${id}/findings`, { severity: 'minor', description: 'Storage racks not labelled' });
    const major = await A(qOff).post(`/audits/${id}/findings`, { severity: 'major', description: 'Seed stored with pesticides' });
    expect(minor.body.data.ncr_id).toBeNull();
    expect(major.body.data.ncr_id).toBeTruthy();
    expect((await A(qOff).post(`/audits/${id}/complete`, { summary: 'Two findings' })).status).toBe(200);
    expect((await A(qMgr).post(`/audits/${id}/close`)).status).toBe(409);
    expect((await A(qOff).post(`/audits/${id}/findings/${minor.body.data.id}/close`, { closureNote: 'Labelled' })).status).toBe(200);
    expect((await A(qOff).post(`/audits/${id}/findings/${major.body.data.id}/close`, { closureNote: 'Moved' })).status).toBe(409); // NCR still open
    expect((await A(qOff).post(`/audits/${id}/close`)).status).toBe(403); // only a quality manager closes
    await pool.query(`UPDATE non_conformances SET status = 'cancelled' WHERE id = $1`, [major.body.data.ncr_id]);
    expect((await A(qOff).post(`/audits/${id}/findings/${major.body.data.id}/close`, { closureNote: 'Moved' })).status).toBe(200);
    expect((await A(qMgr).post(`/audits/${id}/close`)).status).toBe(200);
  });
});

describe('training, dashboard and SATHI export', () => {
  it('builds a competency matrix from records and course validity', async () => {
    const c = await A(qOff).post('/training/courses', { title: 'Seed sampling', requiredFor: ['plant_supervisor'], validityMonths: 12 });
    expect(c.status, JSON.stringify(c.body)).toBe(201);
    const find = async () => {
      const m = (await A(qOff).get('/training/matrix')).body.data;
      return m.rows.find((r: { userId: string }) => r.userId === plantSup.user.id)?.cells.find((x: { courseId: string }) => x.courseId === c.body.data.id);
    };
    expect((await find()).status).toBe('missing');
    expect((await A(qOff).post('/training/records', { courseId: c.body.data.id, userIds: [plantSup.user.id], completedOn: inDays(-400) })).status).toBe(201);
    expect((await find()).status).toBe('expired');
    expect((await A(qOff).post('/training/records', { courseId: c.body.data.id, userIds: [plantSup.user.id], completedOn: inDays(-10) })).status).toBe(201);
    expect((await find()).status).toBe('compliant');
    expect((await A(qOff).post('/training/records', { courseId: c.body.data.id, userIds: [plantSup.user.id], completedOn: inDays(5) })).status).toBe(400);
  });

  it('gives managers one dashboard and quality officers the SATHI registers', async () => {
    expect((await A(exec).get('/management/dashboard')).status).toBe(403);
    const d = await A(qMgr).get('/management/dashboard');
    expect(d.status, JSON.stringify(d.body)).toBe(200);
    for (const k of ['approvals', 'procurement', 'warehouse', 'quality', 'rd', 'reach', 'training', 'attention']) expect(d.body.data).toHaveProperty(k);
    expect((await A(admin).get('/management/dashboard')).status).toBe(200);

    expect((await A(whMgr).get('/exports/sathi/lots')).status).toBe(403);
    const lots = await request(app).get('/api/v1/assurance/exports/sathi/sales?format=csv').set('Authorization', `Bearer ${qOff.token}`);
    expect(lots.status).toBe(200);
    expect(lots.headers['content-type']).toContain('text/csv');
    expect(lots.text.split('\r\n')[0]).toContain('dealer_licence_number');
    expect(lots.text).toContain('SDL/A/1'); // the dealer shipped to in the recall test
    expect((await A(qOff).get('/exports/sathi/nope')).status).toBe(400);
    const tags = await A(qOff).get('/exports/sathi/tags');
    expect(tags.body.data.rows).toBeGreaterThan(0);
  });
});
