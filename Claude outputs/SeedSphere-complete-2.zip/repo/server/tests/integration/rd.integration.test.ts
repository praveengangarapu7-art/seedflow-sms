import { randomUUID } from 'node:crypto';
import { beforeAll, describe, expect, it } from 'vitest';
import { api, inDays, jobActor, type Actor } from './helpers/actors';
import { approve } from './helpers/flows';

const R = api('/api/v1/rd');
const A = api('/api/v1/assurance');
let exec: Actor, mgr: Actor, buyer: Actor, qMgr: Actor;
const sfx = () => randomUUID().slice(0, 5);

beforeAll(async () => {
  [exec, mgr, buyer, qMgr] = await Promise.all((['rd_executive', 'rd_manager', 'purchase_executive', 'quality_manager'] as const).map((r) => jobActor(r)));
});

describe('germplasm and phenotyping', () => {
  it('catalogues accessions, blocks duplicates and records measurements', async () => {
    const crop = `Cotton-${sfx()}`;
    expect((await R(buyer).post('/accessions', { name: 'x', crop })).status).toBe(403);
    const a = await R(exec).post('/accessions', { name: 'Wagad landrace', crop, accessionType: 'landrace', originState: 'Gujarat' });
    expect(a.status, JSON.stringify(a.body)).toBe(201);
    expect((await R(exec).post('/accessions', { name: 'wagad LANDRACE', crop })).status).toBe(409);
    expect((await R(exec).post('/accessions', { name: 'y', crop, accessionType: 'bogus' })).status).toBe(400);
    const id = a.body.data.id;
    expect((await R(exec).post('/phenotypes', { accessionId: id, trait: 'boll_weight', unit: 'g', valueNum: 4.2, measuredOn: inDays(-2) })).status).toBe(201);
    expect((await R(exec).post('/phenotypes', { accessionId: id, trait: 'boll_weight', measuredOn: inDays(-2) })).status).toBe(400);
    expect((await R(exec).post('/phenotypes', { accessionId: id, trait: 'boll_weight', valueNum: 1, measuredOn: inDays(3) })).status).toBe(400);
    const d = await R(mgr).get(`/accessions/${id}`);
    expect(d.body.data.phenotypes).toHaveLength(1);
    expect((await R(mgr).get(`/phenotypes?crop=${crop}`)).body.data).toHaveLength(1);
    expect((await R(exec).patch(`/accessions/${id}/status`, { status: 'lost' })).body.data.status).toBe('lost');
  });
});

describe('breeding programmes and nurseries', () => {
  it('tracks generations and enforces budget and nursery lifecycle', async () => {
    const crop = `Chilli-${sfx()}`;
    const p = await R(exec).post('/programs', { name: 'Drought tolerant', crop, objective: 'Stress tolerance', leadBreeder: 'Dr. Rao', startDate: inDays(-100), budget: 1000 });
    expect(p.status, JSON.stringify(p.body)).toBe(201);
    const id = p.body.data.id;
    expect((await R(exec).post(`/programs/${id}/generations`, { stage: 'F1', season: 'Kharif 2026', populationSize: 100, selectionsRetained: 150 })).status).toBe(400);
    expect((await R(exec).post(`/programs/${id}/generations`, { stage: 'F1', season: 'Kharif 2026', populationSize: 100, selectionsRetained: 40 })).status).toBe(201);
    expect((await R(exec).post(`/programs/${id}/generations`, { stage: 'F1', season: 'Kharif 2026', populationSize: 100, selectionsRetained: 40 })).status).toBe(409);
    expect((await R(exec).get(`/programs/${id}`)).body.data.status).toBe('active');
    expect((await R(exec).patch(`/programs/${id}`, { spentToDate: 5000 })).status).toBe(409);
    expect((await R(exec).patch(`/programs/${id}`, { spentToDate: 600 })).status).toBe(200);

    const n = await R(exec).post('/nurseries', { name: 'Block A', crop, season: 'Kharif 2026', location: 'Guntur', programId: id, areaAcres: 2 });
    const nid = n.body.data.id;
    expect((await R(exec).post(`/nurseries/${nid}/notes`, { note: 'early' })).status).toBe(409); // not sown
    expect((await R(exec).post(`/nurseries/${nid}/sow`, { sownOn: inDays(2) })).status).toBe(400);
    expect((await R(exec).post(`/nurseries/${nid}/sow`, { sownOn: inDays(-10), expectedHarvest: inDays(80) })).status).toBe(200);
    expect((await R(exec).post(`/nurseries/${nid}/notes`, { note: 'Good emergence', health: 'good', growthStage: 'seedling' })).status).toBe(201);
    expect((await R(exec).get(`/nurseries/${nid}`)).body.data.status).toBe('growing');
    expect((await R(exec).post(`/nurseries/${nid}/harvest`, {})).status).toBe(200);
    expect((await R(exec).post(`/nurseries/${nid}/abandon`, { reason: 'x' })).status).toBe(409);
    expect((await R(exec).get('/dashboard')).body.data.programs.active).toBeGreaterThan(0);
  });
});

describe('registrations', () => {
  it('needs a pre-release candidate and a reference number to file', async () => {
    const crop = `Okra-${sfx()}`;
    const t = (await A(exec).post('/rd/trials', { title: 'T', crop, season: 'K26', location: 'G', replications: 1, traits: [{ name: 'yield' }], entries: [{ name: 'Check', isCheck: true }, { name: 'L1' }] })).body.data;
    await A(exec).post(`/rd/trials/${t.id}/submit`); await approve(mgr, 'trial_protocol', t.id); await A(exec).post(`/rd/trials/${t.id}/start`);
    const det = (await A(exec).get(`/rd/trials/${t.id}`)).body.data;
    await A(exec).post(`/rd/trials/${t.id}/observations`, { observations: det.entries.map((e: { id: string }, i: number) => ({ entryId: e.id, replication: 1, trait: 'yield', value: 10 + i })) });
    await A(exec).post(`/rd/trials/${t.id}/complete`);
    const c = (await A(exec).post('/rd/candidates', { name: `OK-${sfx()}`, sourceTrialId: t.id })).body.data;
    expect((await R(exec).post('/registrations', { candidateId: c.id, authority: 'cvrc' })).status).toBe(409); // still a candidate
    for (const stage of ['multi_location', 'pre_release']) {
      const adv = (await A(exec).post(`/rd/candidates/${c.id}/advance`, { toStage: stage, justification: 'ok' })).body.data;
      await approve(mgr, 'variety_advancement', adv.id);
    }
    const reg = await R(exec).post('/registrations', { candidateId: c.id, authority: 'cvrc' });
    expect(reg.status, JSON.stringify(reg.body)).toBe(201);
    const id = reg.body.data.id;
    expect((await R(exec).post(`/registrations/${id}/grant`, { grantedOn: inDays(-1) })).status).toBe(409); // not filed
    expect((await R(exec).post(`/registrations/${id}/file`, {})).status).toBe(400);
    expect((await R(exec).post(`/registrations/${id}/file`, { referenceNumber: 'CVRC/2026/118' })).body.data.status).toBe('filed');
    expect((await R(exec).post(`/registrations/${id}/review`)).status).toBe(200);
    expect((await R(exec).post(`/registrations/${id}/grant`, { grantedOn: inDays(-1), validUntil: inDays(-5) })).status).toBe(400);
    expect((await R(exec).post(`/registrations/${id}/grant`, { grantedOn: inDays(-1), validUntil: inDays(3000) })).body.data.status).toBe('granted');
    expect((await R(exec).post(`/registrations/${id}/withdraw`, { note: 'x' })).status).toBe(409);
    const v = (await R(mgr).get('/varieties')).body.data.find((x: { candidate_id: string }) => x.candidate_id === c.id);
    expect(v.registrations[0].status).toBe('granted');
    void qMgr;
  });
});

describe('warehouse reports', () => {
  it('returns the report sections to a warehouse user', async () => {
    const wh = await jobActor('warehouse_manager');
    const r = await api('/api/v1/warehouse')(wh).get('/reports?months=6');
    expect(r.status, JSON.stringify(r.body)).toBe(200);
    for (const k of ['monthly', 'byCrop', 'expiry', 'topDealers', 'returnsByReason', 'onHandKg']) expect(r.body.data).toHaveProperty(k);
  });
});

describe('processing planning and certification', () => {
  it('returns the production plan and certification register', async () => {
    const pm = await jobActor('plant_manager');
    const p = await api('/api/v1/processing')(pm).get('/planning?days=14');
    expect(p.status, JSON.stringify(p.body)).toBe(200);
    for (const k of ['plants', 'batches', 'intake', 'maintenance']) expect(p.body.data).toHaveProperty(k);
    const c = await api('/api/v1/processing')(pm).get('/certification');
    expect(c.status, JSON.stringify(c.body)).toBe(200);
    expect(Array.isArray(c.body.data)).toBe(true);
  });
});
