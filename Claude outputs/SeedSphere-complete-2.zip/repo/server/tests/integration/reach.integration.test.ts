import { randomUUID } from 'node:crypto';
import request from 'supertest';
import { beforeAll, describe, expect, it } from 'vitest';
import { pool } from '../../src/db/pool';
import { normalisePhone } from '../../src/modules/reach/messaging.service';
import { createTestSeedLot } from '../factories';
import { api, inDays, jobActor, phone, type Actor } from './helpers/actors';
import { acceptedGrowerDelivery, activeParty, approve } from './helpers/flows';
import { app } from './testApp';

const W = api('/api/v1/warehouse');
const R = api('/api/v1/reach');
const PORTAL = api('/api/v1/portal');
const parties = api('/api/v1/parties');
const P = api('/api/v1/procurement');

let sup: Actor;
let mgr: Actor;
let exec: Actor;
let pmgr: Actor;
let admin: Actor;
let plantMgr: Actor;
let dealerUser: Actor;
let otherDealerUser: Actor;
let growerUser: Actor;
let warehouseId: string;
let binA: string;
let dealer: { id: string; name: string };
let otherDealer: { id: string };

const pub = (path: string) => request(app).get(`/api/v1/public${path}`);

async function testedLot(opts: { germ?: number; testedOn?: string; qty?: number } = {}) {
  const lot = await createTestSeedLot({ crop: 'Paddy', variety: `RC-${randomUUID().slice(0, 5)}`, quantityTotal: opts.qty ?? 2000 });
  const t = await W(sup).post('/lot-tests', { seedLotId: lot.id, testedOn: opts.testedOn ?? inDays(-5), germinationPct: opts.germ ?? 90, minGerminationPct: 80, laboratory: 'STL Guntur', reportNumber: `STL-${randomUUID().slice(0, 4)}` });
  expect(t.status).toBe(201);
  return lot;
}
async function stockIn(lotId: string, kg: number) {
  expect((await W(sup).post('/receipts', { seedLotId: lotId, locationId: binA, quantityKg: kg, sourceType: 'processing' })).status).toBe(201);
}
async function link(party: { id: string }, user: Actor) {
  const r = await parties(pmgr).post(`/${party.id}/portal-user`, { email: user.user.email });
  expect(r.status, JSON.stringify(r.body)).toBe(200);
}
async function shippedDispatch(dealerId: string, lotId: string, kg: number) {
  const d = await W(sup).post('/dispatches', { dealerId, warehouseId, requestedDate: inDays(1), lines: [{ seedLotId: lotId, locationId: binA, quantityKg: kg }] });
  expect(d.status, JSON.stringify(d.body)).toBe(201);
  await W(sup).post(`/dispatches/${d.body.data.id}/submit`);
  await approve(mgr, 'dispatch_order', d.body.data.id);
  expect((await W(sup).post(`/dispatches/${d.body.data.id}/ship`, { vehicleNumber: 'AP07TB2231' })).status).toBe(200);
  return d.body.data.id as string;
}

beforeAll(async () => {
  sup = await jobActor('warehouse_supervisor');
  mgr = await jobActor('warehouse_manager');
  exec = await jobActor('purchase_executive');
  pmgr = await jobActor('purchase_manager');
  admin = await jobActor('system_admin');
  plantMgr = await jobActor('plant_manager');
  dealerUser = await jobActor('dealer');
  otherDealerUser = await jobActor('dealer');
  growerUser = await jobActor('grower');
  const w = await W(mgr).post('/warehouses', { code: `RC${randomUUID().slice(0, 4)}`, name: 'Reach test godown' });
  warehouseId = w.body.data.id;
  binA = (await W(mgr).post('/locations', { warehouseId, code: 'A-01-01', zone: 'A', capacityKg: 50000 })).body.data.id;
  dealer = await activeParty(exec, pmgr, 'dealer', { licenceNumber: 'SDL/R/1', licenceValidUntil: inDays(300), village: 'Tenali', preferredLanguage: 'te' });
  otherDealer = await activeParty(exec, pmgr, 'dealer', { licenceNumber: 'SDL/R/2', licenceValidUntil: inDays(300) });
  await link(dealer, dealerUser);
  await link(otherDealer, otherDealerUser);
});

describe('pack tags and public verification', () => {
  it('issues tags, verifies them without a login, and reflects holds, voids and unknown codes', async () => {
    const lot = await testedLot({ qty: 500 });
    expect((await R(exec).post('/tags', { seedLotId: lot.id, count: 10, packSizeKg: 10 })).status).toBe(403); // not a packaging role
    const made = await R(plantMgr).post('/tags', { seedLotId: lot.id, count: 20, packSizeKg: 10 });
    expect(made.status, JSON.stringify(made.body)).toBe(201);
    const codes: string[] = made.body.data.tagCodes;
    expect(new Set(codes).size).toBe(20);
    expect(codes[0]).toMatch(/^SS-[A-Z2-9]{4}-[A-Z2-9]{4}$/);
    expect((await R(plantMgr).post('/tags', { seedLotId: lot.id, count: 40, packSizeKg: 10 })).status).toBe(409); // 200 + 400 > 500

    const ok = await pub(`/verify/${codes[0]}`);
    expect(ok.status).toBe(200);
    expect(ok.body.data.verdict).toBe('genuine');
    expect(ok.body.data.product.lotCode).toBe(lot.lot_code);
    expect(ok.body.data.product.germinationPct).toBe(90);
    expect(ok.body.data.product.supplier).toBeUndefined();
    // a farmer typing it in lower case without dashes still gets the answer
    const typed = await pub(`/verify/${codes[0].toLowerCase().replace(/-/g, ' ')}`);
    expect(typed.body.data.verdict).toBe('genuine');
    expect(typed.body.data.timesChecked).toBe(2);

    expect((await pub('/verify/SS-ZZZZ-ZZZZ')).body.data.verdict).toBe('not_found');
    expect((await pub('/verify/garbage')).body.data.verdict).toBe('not_found');

    const qi = await jobActor('quality_manager');
    const hold = await request(app).post('/api/v1/quality/holds').set('Authorization', `Bearer ${qi.token}`).send({ seedLotId: lot.id, reason: 'Complaints of poor emergence' });
    expect(hold.status).toBe(201);
    expect((await pub(`/verify/${codes[1]}`)).body.data.verdict).toBe('on_hold');

    expect((await R(plantMgr).post(`/tags/${codes[2]}/void`, {})).status).toBe(400);
    expect((await R(plantMgr).post(`/tags/${codes[2]}/void`, { reason: 'Misprint' })).status).toBe(200);
    expect((await pub(`/verify/${codes[2]}`)).body.data.verdict).toBe('void');

    const untested = await createTestSeedLot({ crop: 'Paddy', variety: 'UNT', quantityTotal: 100 });
    const u = await R(plantMgr).post('/tags', { seedLotId: untested.id, count: 1, packSizeKg: 5 });
    expect((await pub(`/verify/${u.body.data.tagCodes[0]}`)).body.data.verdict).toBe('unverified');

    const act = (await R(plantMgr).get('/tags/activity')).body.data;
    expect(act.last30Days.not_found).toBeGreaterThanOrEqual(2);
  });

  it('warns when one tag is checked from many different phones', async () => {
    const lot = await testedLot();
    const code = (await R(plantMgr).post('/tags', { seedLotId: lot.id, count: 1, packSizeKg: 5 })).body.data.tagCodes[0];
    let last = '';
    for (let i = 0; i < 9; i++) last = (await request(app).get(`/api/v1/public/verify/${code}`).set('User-Agent', `phone-${i}`)).body.data.verdict;
    expect(last).toBe('caution');
  });
});

describe('farmer complaint channel', () => {
  it('files a complaint with no login, escalates a cluster to a lot hold, and tracks it by code + mobile', async () => {
    const lot = await testedLot();
    const code = (await R(plantMgr).post('/tags', { seedLotId: lot.id, count: 5, packSizeKg: 5 })).body.data.tagCodes[0];
    const mobile = phone();
    const file = (n: string, extra: Record<string, unknown> = {}) =>
      request(app).post('/api/v1/public/complaints').send({ name: n, phone: mobile, village: 'Ponnur', tagCode: code, complaintType: 'germination', description: 'Only a few seeds sprouted after 12 days', ...extra });

    expect((await request(app).post('/api/v1/public/complaints').send({ name: 'X', phone: '123', complaintType: 'other', description: 'bad' })).status).toBe(400);
    const first = await file('Venkat');
    expect(first.status, JSON.stringify(first.body)).toBe(201);
    expect(first.body.data.code).toMatch(/^CMP-/);
    expect(first.body.data.escalated).toBe(false);

    const row = await pool.query('SELECT * FROM quality_complaints WHERE complaint_code = $1', [first.body.data.code]);
    expect(row.rows[0]).toMatchObject({ seed_lot_id: lot.id, channel: 'public_form', severity: 'major', complainant_village: 'Ponnur' });
    const ack = await pool.query(`SELECT * FROM msg_outbox WHERE related_id = $1 AND template = 'complaint_received'`, [row.rows[0].id]);
    expect(ack.rows[0].to_phone).toBe(`+91${mobile}`);

    await file('Suresh');
    const third = await file('Ravi');
    expect(third.body.data.escalated).toBe(true);
    const hold = await pool.query('SELECT 1 FROM quality_lot_holds WHERE seed_lot_id = $1 AND released_at IS NULL', [lot.id]);
    expect(hold.rowCount).toBe(1);
    expect((await pub(`/verify/${code}`)).body.data.verdict).toBe('on_hold');

    expect((await pub(`/complaints/${first.body.data.code}?phone=${mobile}`)).body.data.status).toBe('received');
    expect((await pub(`/complaints/${first.body.data.code}?phone=9000000000`)).status).toBe(404);
    expect((await pub('/complaints/CMP-0000-0000?phone=9000000000')).status).toBe(404);

    const fake = await request(app).post('/api/v1/public/complaints').send({ name: 'Lakshmi', phone: phone(), tagCode: 'SS-ZZZZ-ZZZZ', complaintType: 'suspected_fake', description: 'Pack looks different from last year' });
    expect(fake.status).toBe(201);
    const f = await pool.query('SELECT description, severity FROM quality_complaints WHERE complaint_code = $1', [fake.body.data.code]);
    expect(f.rows[0].description).toMatch(/possible counterfeit/);
    expect(f.rows[0].severity).toBe('major');
  });
});

describe('messaging outbox', () => {
  it('queues a dealer message when a dispatch ships (in their language), sends it, and survives a failing provider', async () => {
    const lot = await testedLot();
    await stockIn(lot.id, 600);
    const id = await shippedDispatch(dealer.id, lot.id, 100);
    const q = await pool.query(`SELECT * FROM msg_outbox WHERE related_id = $1 AND template = 'dispatch_shipped'`, [id]);
    expect(q.rows).toHaveLength(1);
    expect(q.rows[0]).toMatchObject({ status: 'queued', language: 'te' });
    expect(q.rows[0].body).toContain('AP07TB2231');
    expect((await R(sup).post('/messages/flush')).status).toBe(403);
    const flushed = await R(admin).post('/messages/flush');
    expect(flushed.body.data.sent).toBeGreaterThanOrEqual(1);
    expect((await pool.query('SELECT status, provider_ref FROM msg_outbox WHERE id = $1', [q.rows[0].id])).rows[0]).toMatchObject({ status: 'sent' });

    expect(normalisePhone('98765 43210')).toBe('+919876543210');
    expect(normalisePhone('12345')).toBeNull();
    expect(normalisePhone(null)).toBeNull();

    const manual = await R(admin).post('/messages/send', { partyId: dealer.id, text: 'Stock review meeting on Friday' });
    expect(manual.status).toBe(201);
    expect((await R(admin).post(`/messages/${manual.body.data.id}/cancel`)).body.data.status).toBe('cancelled');
    expect((await R(admin).post(`/messages/${manual.body.data.id}/retry`)).status).toBe(409);
    expect((await R(admin).get('/messages/summary')).body.data.sent).toBeGreaterThanOrEqual(1);
  });

  it('tells a grower when their payment is released', async () => {
    const fin = await jobActor('finance_manager');
    const fin2 = await jobActor('finance_manager');
    const inspector = await jobActor('procurement_quality_field_inspector');
    const g = await acceptedGrowerDelivery({ exec, manager: pmgr, inspector });
    const st = await P(exec).post('/growers/settlements', { agreementId: g.agreementId });
    expect(st.status, JSON.stringify(st.body)).toBe(201);
    await approve(fin, 'grower_settlement', st.body.data.id);
    const paid = await P(fin2).post(`/growers/settlements/${st.body.data.id}/pay`, { paymentReference: 'UTR9', paymentMode: 'neft' });
    expect(paid.body.data.status).toBe('paid');
    const m = await pool.query(`SELECT body FROM msg_outbox WHERE related_id = $1 AND template = 'settlement_paid'`, [st.body.data.id]);
    expect(m.rows[0].body).toMatch(/UTR9/);
  });
});

describe('dealer portal', () => {
  it('shows a dealer only their own dispatches and lets them confirm receipt', async () => {
    const lot = await testedLot();
    await stockIn(lot.id, 500);
    const id = await shippedDispatch(dealer.id, lot.id, 80);
    const home = (await PORTAL(dealerUser).get('/dealer')).body.data;
    expect(home.party.name).toBe(dealer.name);
    expect(home.dispatches.map((d: { id: string }) => d.id)).toContain(id);
    expect(home.licenceDaysLeft).toBeGreaterThan(200);
    expect((await PORTAL(otherDealerUser).get('/dealer')).body.data.dispatches.map((d: { id: string }) => d.id)).not.toContain(id);
    expect((await PORTAL(otherDealerUser).get(`/dealer/dispatches/${id}`)).status).toBe(404);
    expect((await PORTAL(otherDealerUser).post(`/dealer/dispatches/${id}/confirm-receipt`, {})).status).toBe(404);
    const d = (await PORTAL(dealerUser).get(`/dealer/dispatches/${id}`)).body.data;
    expect(d.lines[0].lot_code).toBe(lot.lot_code);
    expect(d.lines[0].germination_pct).toBe(90);
    expect(d.eway_bill_number).toBeUndefined();
    const done = await PORTAL(dealerUser).post(`/dealer/dispatches/${id}/confirm-receipt`, { receivedByName: 'K. Srinivas' });
    expect(done.body.data.status).toBe('delivered');
    expect((await PORTAL(dealerUser).get(`/dealer/lots/${lot.id}`)).body.data.status).toBe('sellable');
    const stranger = await testedLot();
    expect((await PORTAL(dealerUser).get(`/dealer/lots/${stranger.id}`)).status).toBe(404);
    expect((await PORTAL(dealerUser).post('/dealer/complaints', { seedLotId: stranger.id, title: 'x', description: 'y' })).status).toBe(409);
    const c = await PORTAL(dealerUser).post('/dealer/complaints', { seedLotId: lot.id, title: 'Bags wet on arrival', description: 'Three bags damp', severity: 'critical' });
    expect(c.status, JSON.stringify(c.body)).toBe(201);
    expect(c.body.data.severity).toBe('major'); // a dealer cannot trigger a lot hold by themselves
    expect(c.body.data.channel).toBe('dealer_portal');
  });

  it('takes seed requests and lets the warehouse manager accept or reject them, telling the dealer', async () => {
    const need = inDays(7);
    expect((await PORTAL(dealerUser).post('/dealer/indents', { crop: 'Paddy', quantityKg: 0, neededBy: need })).status).toBe(400);
    expect((await PORTAL(dealerUser).post('/dealer/indents', { crop: 'Paddy', quantityKg: 500, neededBy: inDays(-1) })).status).toBe(400);
    const a = await PORTAL(dealerUser).post('/dealer/indents', { crop: 'Paddy', variety: 'BPT-5204', quantityKg: 500, neededBy: need });
    const b = await PORTAL(dealerUser).post('/dealer/indents', { crop: 'Maize', quantityKg: 200, neededBy: need });
    expect(a.status).toBe(201);
    expect(a.body.data.indent_number).toMatch(/^IND-/);
    expect((await R(sup).post(`/indents/${a.body.data.id}/decide`, { decision: 'accept' })).status).toBe(403);
    expect((await R(mgr).post(`/indents/${b.body.data.id}/decide`, { decision: 'reject' })).status).toBe(400); // reason needed
    expect((await R(mgr).post(`/indents/${a.body.data.id}/decide`, { decision: 'accept', note: 'Ready from Friday' })).body.data.status).toBe('accepted');
    expect((await R(mgr).post(`/indents/${b.body.data.id}/decide`, { decision: 'reject', note: 'No maize stock this season' })).body.data.status).toBe('rejected');
    expect((await R(mgr).post(`/indents/${a.body.data.id}/decide`, { decision: 'accept' })).status).toBe(409);
    expect((await PORTAL(dealerUser).post(`/dealer/indents/${a.body.data.id}/cancel`)).status).toBe(409);
    const msgs = await pool.query(`SELECT body FROM msg_outbox WHERE related_id = $1`, [b.body.data.id]);
    expect(msgs.rows[0].body).toMatch(/No maize stock/);
    const all = (await R(mgr).get('/indents')).body.data;
    expect(all.find((i: { id: string }) => i.id === a.body.data.id).dealer_name).toBe(dealer.name);
    expect((await R(mgr).post(`/indents/${a.body.data.id}/fulfilled`, {})).body.data.status).toBe('fulfilled');
    const c = await PORTAL(dealerUser).post('/dealer/indents', { crop: 'Cotton', quantityKg: 50, neededBy: need });
    expect((await PORTAL(dealerUser).post(`/dealer/indents/${c.body.data.id}/cancel`)).body.data.status).toBe('cancelled');
  });
});

describe('grower portal and access boundaries', () => {
  it('shows a grower their own agreements, deliveries and balance, and keeps portal users out of staff screens', async () => {
    const inspector = await jobActor('procurement_quality_field_inspector');
    const g = await acceptedGrowerDelivery({ exec, manager: pmgr, inspector });
    await link(g.grower, growerUser);
    const home = (await PORTAL(growerUser).get('/grower')).body.data;
    expect(home.party.name).toBe(g.grower.name);
    expect(home.agreements.map((a: { id: string }) => a.id)).toEqual([g.agreementId]);
    expect(home.deliveries).toHaveLength(1);
    expect(Number(home.balance)).toBeGreaterThan(0); // owed to the grower
    expect(JSON.stringify(home)).not.toMatch(/bank_account_number/);

    expect((await PORTAL(growerUser).get('/dealer')).status).toBe(403);
    expect((await PORTAL(dealerUser).get('/grower')).status).toBe(403);
    expect((await PORTAL(exec).get('/grower')).status).toBe(403);
    expect((await P(growerUser).get('/dashboard')).status).toBe(403);
    expect((await W(dealerUser).get('/stock')).status).toBe(403);
    const unlinked = await jobActor('grower');
    expect((await PORTAL(unlinked).get('/grower')).status).toBe(403);
  });
});
