import { randomUUID } from 'node:crypto';
import { beforeAll, describe, expect, it } from 'vitest';
import { pool } from '../../src/db/pool';
import { api, jobActor, type Actor } from './helpers/actors';
import { acceptedGrowerDelivery, approve, runInspection } from './helpers/flows';

const PR = api('/api/v1/processing');

let exec: Actor;
let manager: Actor;
let gateInspector: Actor;
let plantSup: Actor;
let plantMgr: Actor;
let procInspector: Actor;
let plantId: string;
let recipeId: string;

async function approvedRecipe(withTreatment = true) {
  const name = `Paddy standard line ${randomUUID().slice(0, 6)}`;
  const r = await PR(plantSup).post('/recipes', {
    name,
    crop: 'Paddy',
    targetMoisturePct: 12,
    stages: [
      { stage: 'pre_cleaning', machineType: 'pre_cleaner', maxLossPct: 3 },
      { stage: 'drying', machineType: 'dryer', parameters: 'Air 42 °C max', maxLossPct: 4 },
      { stage: 'cleaning_grading', machineType: 'cleaner_grader', parameters: 'Top screen 2.8 mm slotted', maxLossPct: 8 },
      ...(withTreatment ? [{ stage: 'treatment', machineType: 'treater', maxLossPct: 1 }] : []),
    ],
    chemicals: withTreatment ? [{ chemicalName: 'Carbendazim 50% WP', dosePerKg: 2, doseUnit: 'g', purpose: 'Seed-borne fungi' }] : [],
  });
  expect(r.status, JSON.stringify(r.body)).toBe(201);
  expect((await PR(plantSup).post(`/recipes/${r.body.data.id}/submit`)).status).toBe(200);
  expect((await approve(plantMgr, 'processing_recipe', r.body.data.id)).body.data.status).toBe('approved');
  return r.body.data.id as string;
}

async function readyIntake(netKg = 2000) {
  const g = await acceptedGrowerDelivery({ exec, manager, inspector: gateInspector }, { netKg });
  const x = await PR(plantSup).post('/intake', { sourceType: 'grower_delivery', sourceId: g.deliveryId, plantId });
  expect(x.status, JSON.stringify(x.body)).toBe(201);
  expect(x.body.data.status).toBe('awaiting_check');
  const pre = await runInspection(procInspector, { type: 'processing_pre', subjectType: 'raw_intake', subjectId: x.body.data.id }, {}, 'accept');
  expect(pre.status, JSON.stringify(pre.body)).toBe(200);
  return { ...g, intakeId: x.body.data.id as string };
}

beforeAll(async () => {
  exec = await jobActor('purchase_executive');
  manager = await jobActor('purchase_manager');
  gateInspector = await jobActor('procurement_quality_field_inspector');
  plantSup = await jobActor('plant_supervisor');
  plantMgr = await jobActor('plant_manager');
  procInspector = await jobActor('processing_quality_field_inspector');
  const plant = await PR(plantMgr).post('/plants', { code: `GNT${randomUUID().slice(0, 4)}`, name: 'Guntur seed plant', capacityKgPerDay: 20000 });
  expect(plant.status).toBe(201);
  plantId = plant.body.data.id;
  recipeId = await approvedRecipe();
});

describe('processing', () => {
  it('turns grower deliveries into a treated, certified lot whose genealogy runs back to the grower', async () => {
    const src = await readyIntake(2000);
    // an unapproved recipe cannot run
    const draft = await PR(plantSup).post('/recipes', { name: `Draft ${randomUUID().slice(0, 6)}`, crop: 'Paddy', stages: [{ stage: 'pre_cleaning', maxLossPct: 3 }] });
    expect((await PR(plantSup).post('/batches', { recipeId: draft.body.data.id, plantId, inputs: [{ rawIntakeId: src.intakeId, quantityKg: 100 }] })).status).toBe(409);
    expect((await PR(plantSup).post('/batches', { recipeId, plantId, inputs: [{ rawIntakeId: src.intakeId, quantityKg: 2500 }] })).status).toBe(409);

    const batch = await PR(plantSup).post('/batches', { recipeId, plantId, inputs: [{ rawIntakeId: src.intakeId, quantityKg: 2000 }] });
    expect(batch.status, JSON.stringify(batch.body)).toBe(201);
    const id = batch.body.data.id;
    expect(batch.body.data.stages).toHaveLength(4);
    expect(batch.body.data.parent_lot_id).toBe(src.foundation.id);
    expect((await PR(plantSup).post(`/batches/${id}/stages/1`, { outputKg: 1950 })).status).toBe(409); // not started
    await PR(plantSup).post(`/batches/${id}/start`);

    expect((await PR(plantSup).post(`/batches/${id}/stages/2`, { outputKg: 1900 })).status).toBe(409); // out of order
    expect(Number((await PR(plantSup).post(`/batches/${id}/stages/1`, { outputKg: 1950 })).body.data.stages[0].loss_pct)).toBe(2.5);
    expect((await PR(plantSup).post(`/batches/${id}/stages/2`, { outputKg: 1880 })).status).toBe(200); // 3.59%
    // grading loss of 10% is above the 8% limit: needs a reason and raises an NCR
    expect((await PR(plantSup).post(`/batches/${id}/stages/3`, { outputKg: 1692 })).status).toBe(400);
    const graded = await PR(plantSup).post(`/batches/${id}/stages/3`, { outputKg: 1692, lossReason: 'High chaffy grain in this delivery' });
    expect(graded.body.data.stages[2].ncr_code).toMatch(/^NCR-/);

    // treatment: expected 2 g/kg × 1692 kg = 3384 g; 3000 g needs a reason
    expect((await PR(plantSup).post(`/batches/${id}/stages/4`, { outputKg: 1690 })).status).toBe(409); // treatment not recorded
    expect((await PR(plantSup).post(`/batches/${id}/treatments`, { chemicalName: 'Carbendazim 50% WP', quantityUsed: 3000, supplierLot: 'CBZ-0925' })).status).toBe(400);
    expect((await PR(plantSup).post(`/batches/${id}/treatments`, { chemicalName: 'Carbendazim 50% WP', quantityUsed: 3390, supplierLot: 'CBZ-0925' })).status).toBe(200);
    expect((await PR(plantSup).post(`/batches/${id}/stages/4`, { outputKg: 1688 })).status).toBe(200);

    expect((await PR(plantMgr).post(`/batches/${id}/complete`)).status).toBe(409); // no final inspection
    const fin = await runInspection(procInspector, { type: 'processing_final', subjectType: 'processing_batch', subjectId: id }, { Moisture: 11.2, 'Physical purity': 98.8, 'Germination (quick test)': 88 }, 'accept');
    expect(fin.status, JSON.stringify(fin.body)).toBe(200);
    const done = await PR(plantMgr).post(`/batches/${id}/complete`);
    expect(done.status, JSON.stringify(done.body)).toBe(200);
    const lot = done.body.data.lot;
    expect(lot.lot_code).toMatch(/^LOT-PAD-\d{4}-\d{4}$/);
    expect(Number(lot.quantity_total)).toBe(1688);
    expect(lot.stage).toBe('Certified');
    expect(lot.parent_lot_id).toBe(src.foundation.id);
    expect(lot.notes).toMatch(/TREATED SEED: Carbendazim/);

    const trace = await PR(plantSup).get(`/trace/${lot.id}`);
    expect(trace.body.data.batch.batch_number).toBe(batch.body.data.batch_number);
    expect(trace.body.data.sources[0].grower_name).toBe(src.grower.name);
    expect(trace.body.data.sources[0].plot_survey_number).toBe('112/3');
    expect(trace.body.data.parent.id).toBe(src.foundation.id);

    const intake = await pool.query('SELECT status FROM prc_raw_intakes WHERE id = $1', [src.intakeId]);
    expect(intake.rows[0].status).toBe('consumed');
  });

  it('blocks mixing varieties, reserves intake weight and releases it on cancel', async () => {
    const a = await readyIntake(1000);
    const b = await readyIntake(1000); // different variety (random)
    expect((await PR(plantSup).post('/batches', { recipeId, plantId, inputs: [{ rawIntakeId: a.intakeId, quantityKg: 500 }, { rawIntakeId: b.intakeId, quantityKg: 500 }] })).status).toBe(400);
    const first = await PR(plantSup).post('/batches', { recipeId, plantId, inputs: [{ rawIntakeId: a.intakeId, quantityKg: 800 }] });
    expect(first.status).toBe(201);
    expect((await PR(plantSup).post('/batches', { recipeId, plantId, inputs: [{ rawIntakeId: a.intakeId, quantityKg: 300 }] })).status).toBe(409); // only 200 left
    expect((await PR(plantSup).post(`/batches/${first.body.data.id}/cancel`, { reason: 'Line down' })).status).toBe(403); // supervisors cannot cancel
    expect((await PR(plantMgr).post(`/batches/${first.body.data.id}/cancel`, { reason: 'Line down' })).body.data.status).toBe('cancelled');
    expect((await PR(plantSup).post('/batches', { recipeId, plantId, inputs: [{ rawIntakeId: a.intakeId, quantityKg: 1000 }] })).status).toBe(201);
  });

  it('records machine breakdowns as maintenance with downtime, and a recipe needs the plant manager', async () => {
    const m = await PR(plantMgr).post('/machines', { plantId, code: `DRY${randomUUID().slice(0, 4)}`, name: 'LSU dryer 5 t', machineType: 'dryer', capacityKgPerHour: 1500, serviceIntervalDays: 60 });
    expect(m.status).toBe(201);
    expect((await PR(plantSup).post(`/machines/${m.body.data.id}/status`, { status: 'breakdown' })).status).toBe(400);
    expect((await PR(plantSup).post(`/machines/${m.body.data.id}/status`, { status: 'breakdown', reason: 'Burner fault' })).body.data.status).toBe('breakdown');
    const jobs = (await PR(plantMgr).get('/maintenance?status=scheduled')).body.data.filter((j: { machine_id: string }) => j.machine_id === m.body.data.id);
    expect(jobs).toHaveLength(1);
    const done = await PR(plantMgr).post(`/maintenance/${jobs[0].id}/complete`, { downtimeHours: 6.5, notes: 'Igniter replaced' });
    expect(done.body.data.status).toBe('done');
    const machine = (await PR(plantMgr).get(`/machines?plantId=${plantId}`)).body.data.find((x: { id: string }) => x.id === m.body.data.id);
    expect(machine.status).toBe('available');
    expect(Number(machine.downtime_90d)).toBe(6.5);

    const r = await PR(plantSup).post('/recipes', { name: `Maize ${randomUUID().slice(0, 6)}`, crop: 'Maize', stages: [{ stage: 'treatment', maxLossPct: 1 }] });
    expect(r.status).toBe(400); // treatment with no chemical
  });
});
