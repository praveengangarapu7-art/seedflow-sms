import { Router } from 'express';
import { pool } from '../../db/pool';
import { asyncHandler as h } from '../../middleware/asyncHandler';
import { requireAuth, requireStaff } from '../../middleware/requireAuth';
import { ok, str } from '../shared/http';

/** Small pickers used across the live modules (search-as-you-type). */
export const lookupsRouter = Router();
lookupsRouter.use(requireAuth, requireStaff);

lookupsRouter.get(
  '/lots',
  h(async (req, res) => {
    const q = str(req.query.q);
    const crop = str(req.query.crop);
    const values: unknown[] = [];
    const where = [`l.status = 'active'`];
    if (q) {
      values.push(`%${q.toLowerCase()}%`);
      where.push(`(LOWER(l.lot_code) LIKE $${values.length} OR LOWER(l.variety) LIKE $${values.length} OR LOWER(l.crop) LIKE $${values.length})`);
    }
    if (crop) {
      values.push(crop);
      where.push(`l.crop = $${values.length}`);
    }
    const r = await pool.query(
      `SELECT l.id, l.lot_code, l.crop, l.variety, l.stage, l.quantity_total, l.quantity_allocated, l.unit, l.production_date,
              EXISTS (SELECT 1 FROM quality_lot_holds h WHERE h.seed_lot_id = l.id AND h.released_at IS NULL) AS on_hold
         FROM seed_lots l WHERE ${where.join(' AND ')}
        ORDER BY l.created_at DESC LIMIT 50`,
      values,
    );
    ok(res, r.rows);
  }),
);

lookupsRouter.get(
  '/varieties',
  h(async (req, res) => {
    const crop = str(req.query.crop);
    const r = await pool.query(
      `SELECT DISTINCT crop, variety FROM seed_lots ${crop ? 'WHERE crop = $1' : ''} ORDER BY crop, variety LIMIT 500`,
      crop ? [crop] : [],
    );
    ok(res, r.rows);
  }),
);
