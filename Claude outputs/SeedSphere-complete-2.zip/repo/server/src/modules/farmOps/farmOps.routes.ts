import { Router } from 'express';
import { asyncHandler as h } from '../../middleware/asyncHandler';
import { requireAuth } from '../../middleware/requireAuth';
import { body, ok } from '../shared/http';
import * as s from './farmOps.service';

/** Production-planning reads and writes the screens use: farms, crop plans, inspections, harvests. */
export const farmOpsRouter = Router();
farmOpsRouter.use(['/master-data/farms', '/master-data/varieties', '/production/crop-plans', '/production/farm-inspections', '/production/inspections', '/production/harvests', '/analytics/production-dashboard'], requireAuth);

// master data
farmOpsRouter.get('/master-data/farms', h(async (_q, res) => ok(res, await s.listFarms())));
farmOpsRouter.get('/master-data/farms/:id', h(async (q, res) => ok(res, await s.getFarm(q.params.id))));
farmOpsRouter.post('/master-data/farms', h(async (q, res) => ok(res, await s.createFarm(body(q), q.user!), 'Farm registered', 201)));
farmOpsRouter.put('/master-data/farms/:id', h(async (q, res) => ok(res, await s.updateFarm(q.params.id, body(q), q.user!))));
farmOpsRouter.get('/master-data/varieties', h(async (_q, res) => ok(res, await s.listVarieties())));

// crop plans
farmOpsRouter.get('/production/crop-plans', h(async (_q, res) => ok(res, await s.listCropPlans())));
farmOpsRouter.get('/production/crop-plans/:id', h(async (q, res) => ok(res, await s.getCropPlan(q.params.id))));
farmOpsRouter.post('/production/crop-plans', h(async (q, res) => ok(res, await s.createCropPlan(body(q), q.user!), 'Crop plan created', 201)));
farmOpsRouter.put('/production/crop-plans/:id', h(async (q, res) => ok(res, await s.updateCropPlan(q.params.id, body(q)))));

// farm visits
farmOpsRouter.get('/production/farm-inspections', h(async (_q, res) => ok(res, await s.listFieldInspections())));
farmOpsRouter.get('/production/farm-inspections/:id', h(async (q, res) => ok(res, await s.getFieldInspection(q.params.id))));
farmOpsRouter.post('/production/farm-inspections', h(async (q, res) => ok(res, await s.createFieldInspection(body(q), q.user!), 'Inspection recorded', 201)));
farmOpsRouter.get('/production/inspections', h(async (_q, res) => ok(res, await s.listInspectionRecords())));
farmOpsRouter.get('/production/inspections/:id', h(async (q, res) => ok(res, await s.getInspectionRecord(q.params.id))));
farmOpsRouter.post('/production/inspections', h(async (q, res) => ok(res, await s.createInspectionRecord(body(q), q.user!), 'Inspection scheduled', 201)));
farmOpsRouter.put('/production/inspections/:id', h(async (q, res) => ok(res, await s.updateInspectionRecord(q.params.id, body(q)))));
farmOpsRouter.patch('/production/inspections/:id/approve', h(async (q, res) => ok(res, await s.approveInspectionRecord(q.params.id, q.user!))));

// harvest requests
farmOpsRouter.get('/production/harvests', h(async (_q, res) => ok(res, await s.listHarvests())));
farmOpsRouter.get('/production/harvests/:id', h(async (q, res) => ok(res, await s.getHarvest(q.params.id))));
farmOpsRouter.post('/production/harvests', h(async (q, res) => ok(res, await s.createHarvest(body(q), q.user!), 'Harvest request raised', 201)));
farmOpsRouter.post('/production/harvests/:id/approve', h(async (q, res) => ok(res, await s.reviewHarvest(q.params.id, 'approve', body(q), q.user!))));
farmOpsRouter.post('/production/harvests/:id/reject', h(async (q, res) => ok(res, await s.reviewHarvest(q.params.id, 'reject', body(q), q.user!))));
farmOpsRouter.post('/production/harvests/:id/request-changes', h(async (q, res) => ok(res, await s.reviewHarvest(q.params.id, 'changes', body(q), q.user!))));
farmOpsRouter.post('/production/harvests/:id/complete', h(async (q, res) => ok(res, await s.completeHarvest(q.params.id, body(q), q.user!))));
farmOpsRouter.post('/production/harvests/:id/transport', h(async (q, res) => ok(res, await s.authorizeHarvestTransport(q.params.id, body(q), q.user!))));
farmOpsRouter.post('/production/harvests/:id/deliver', h(async (q, res) => ok(res, await s.deliverHarvest(q.params.id, q.user!))));

farmOpsRouter.get('/analytics/production-dashboard', h(async (_q, res) => ok(res, await s.planningDashboard())));
