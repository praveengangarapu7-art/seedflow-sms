import { pool } from '../../db/pool';
import { withTransaction } from '../../db/transaction';
import { ConflictError, NotFoundError, ValidationError } from '../../errors';
import type { AuthenticatedUser } from '../../middleware/requireAuth';
import { insertAuditLog } from '../auditLogs/auditLogs.service';
import { nextCode, optionalDate, optionalNumber, optionalText, optionalUuid, requireDate, requireNumber, requireText, requireUuid } from '../shared/validate';

const rows = async (sql: string, p: unknown[] = []) => (await pool.query(sql, p)).rows;
const SOILS = ['loamy', 'clay', 'sandy', 'black', 'red', 'alluvial'];
const IRRIGATION = ['canal', 'borewell', 'rainfed', 'drip', 'sprinkler'];
const pick = (v: unknown, allowed: string[]) => (typeof v === 'string' && allowed.includes(v.toLowerCase()) ? v.toLowerCase() : null);
const dateOnly = (d: unknown) => (d instanceof Date ? d.toISOString().slice(0, 10) : (d as string | null) ?? undefined);

async function actorName(user: AuthenticatedUser): Promise<string> {
  const r = (await pool.query(`SELECT name FROM users WHERE id = $1`, [user.id])).rows[0];
  return r?.name ?? user.email;
}

// ---------------------------------------------------------------------- farms
const farmSql = `SELECT f.*, fr.location AS farmer_location FROM farms f JOIN farmers fr ON fr.id = f.farmer_id`;
const farmOut = (r: any) => ({
  id: r.id, farmerId: r.farmer_id, name: r.name, location: r.location ?? r.farmer_location ?? '', gpsCoordinates: r.gps_coordinates ?? undefined,
  area: Number(r.area_acres), cropHistory: r.crop_history ?? [], currentCrop: r.current_crop ?? undefined, soilType: r.soil_type, irrigationType: r.irrigation_type ?? undefined,
});

export const listFarms = async () => (await rows(`${farmSql} ORDER BY f.name`)).map(farmOut);
export async function getFarm(id: string) {
  const r = (await rows(`${farmSql} WHERE f.id = $1`, [requireUuid(id, 'id')]))[0];
  if (!r) throw new NotFoundError('Farm not found');
  return farmOut(r);
}
export async function createFarm(b: Record<string, unknown>, user: AuthenticatedUser) {
  const farmerId = requireUuid(b.farmerId, 'farmerId');
  if (!(await rows(`SELECT 1 FROM farmers WHERE id = $1`, [farmerId]))[0]) throw new ValidationError('Farmer not found');
  const name = requireText(b.name, 'name', 100);
  if ((await rows(`SELECT 1 FROM farms WHERE farmer_id = $1 AND lower(name) = lower($2)`, [farmerId, name]))[0]) throw new ConflictError('This farmer already has a farm with that name');
  const r = (await rows(
    `INSERT INTO farms (farmer_id, name, soil_type, area_acres, irrigation_type, location, gps_coordinates, current_crop, crop_history) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING id`,
    [farmerId, name, pick(b.soilType, SOILS) ?? 'loamy', requireNumber(b.area, 'area', { positive: true }), pick(b.irrigationType, IRRIGATION), optionalText(b.location, 'location', 150), optionalText(b.gpsCoordinates, 'gpsCoordinates', 60), optionalText(b.currentCrop, 'currentCrop', 100), Array.isArray(b.cropHistory) ? b.cropHistory.map(String) : []],
  ))[0];
  await insertAuditLog(pool as never, { entityType: 'farm', entityId: r.id, action: 'CREATE', performedBy: user.email, afterState: b }).catch(() => undefined);
  return getFarm(r.id);
}
export async function updateFarm(id: string, b: Record<string, unknown>, user: AuthenticatedUser) {
  const cur = await getFarm(id);
  await rows(
    `UPDATE farms SET name=$2, soil_type=$3, area_acres=$4, irrigation_type=$5, location=$6, gps_coordinates=$7, current_crop=$8, crop_history=$9, updated_at=now() WHERE id=$1`,
    [id, b.name === undefined ? cur.name : requireText(b.name, 'name', 100), pick(b.soilType, SOILS) ?? cur.soilType, b.area === undefined ? cur.area : requireNumber(b.area, 'area', { positive: true }),
      b.irrigationType === undefined ? cur.irrigationType ?? null : pick(b.irrigationType, IRRIGATION), b.location === undefined ? cur.location : optionalText(b.location, 'location', 150), b.gpsCoordinates === undefined ? cur.gpsCoordinates ?? null : optionalText(b.gpsCoordinates, 'gpsCoordinates', 60),
      b.currentCrop === undefined ? cur.currentCrop ?? null : optionalText(b.currentCrop, 'currentCrop', 100), Array.isArray(b.cropHistory) ? b.cropHistory.map(String) : cur.cropHistory],
  );
  void user;
  return getFarm(id);
}

// ------------------------------------------------------------------- varieties
export async function listVarieties() {
  return (await rows(`SELECT v.*, o.name AS org_name FROM varieties v LEFT JOIN organizations o ON o.id = v.organization_id ORDER BY v.crop, v.variety_name`)).map((v) => ({
    id: v.id, name: v.variety_name, crop: v.crop, description: v.botanical_name, status: v.status === 'pending_review' ? 'pending' : v.status === 'deprecated' ? 'archived' : v.status, breederOrganization: v.org_name ?? undefined, createdAt: v.created_at,
  }));
}

// ------------------------------------------------------------------ crop plans
const planSql = `SELECT c.*, a.quantity AS allocated_qty FROM crop_plans c LEFT JOIN seed_lot_allocations a ON a.id = c.allocation_id`;
const planOut = (r: any) => ({
  id: r.id, planCode: r.plan_code, farmerId: r.farmer_id, farmId: r.farm_id, varietyId: r.variety_id, crop: r.crop, season: r.season ?? '', targetArea: Number(r.target_area_acres),
  targetProduction: r.target_production === null ? undefined : Number(r.target_production), targetYield: r.target_production === null ? undefined : Number(r.target_production),
  sowingDate: dateOnly(r.sowing_date), harvestDate: dateOnly(r.harvest_date), status: r.lifecycle, seedLotId: r.seed_lot_id ?? undefined, seedLotAllocatedQty: r.allocated_qty === null || r.allocated_qty === undefined ? undefined : Number(r.allocated_qty),
});
export const listCropPlans = async () => (await rows(`${planSql} ORDER BY c.created_at DESC`)).map(planOut);
export async function getCropPlan(id: string) {
  const r = (await rows(`${planSql} WHERE c.id = $1`, [requireUuid(id, 'id')]))[0];
  if (!r) throw new NotFoundError('Crop plan not found');
  return planOut(r);
}
const LIFECYCLE = ['Planned', 'Sown', 'Growing', 'Harvested', 'Cancelled'];
export async function createCropPlan(b: Record<string, unknown>, user: AuthenticatedUser) {
  const farmId = requireUuid(b.farmId, 'farmId');
  const farm = (await rows(`SELECT farmer_id FROM farms WHERE id = $1`, [farmId]))[0];
  if (!farm) throw new ValidationError('Farm not found');
  const varietyId = requireUuid(b.varietyId, 'varietyId');
  const id = await withTransaction(async (client) => {
    let code = await nextCode(client, 'CRP', 4, true);
    // Plans created before this module existed were numbered by migration; skip any code already taken.
    while ((await client.query(`SELECT 1 FROM crop_plans WHERE plan_code = $1`, [code])).rows[0]) code = await nextCode(client, 'CRP', 4, true);
    return (await client.query(
      `INSERT INTO crop_plans (plan_code, farmer_id, farm_id, crop, variety_id, target_area_acres, calculated_seed_quantity, season, target_production, sowing_date, harvest_date, lifecycle, created_by)
       VALUES ($1,$2,$3,$4,$5,$6,0,$7,$8,$9,$10,$11,$12) RETURNING id`,
      [code, farm.farmer_id, farmId, requireText(b.crop, 'crop', 100), varietyId, requireNumber(b.targetArea, 'targetArea', { positive: true }), optionalText(b.season, 'season', 30), optionalNumber(b.targetProduction ?? b.targetYield, 'targetProduction', { min: 0 }),
        optionalDate(b.sowingDate, 'sowingDate'), optionalDate(b.harvestDate, 'harvestDate'), LIFECYCLE.includes(String(b.status)) ? b.status : 'Planned', user.email],
    )).rows[0].id as string;
  });
  return getCropPlan(id);
}
export async function updateCropPlan(id: string, b: Record<string, unknown>) {
  const cur = await getCropPlan(id);
  if (b.status !== undefined && !LIFECYCLE.includes(String(b.status))) throw new ValidationError('Unknown status');
  await rows(
    `UPDATE crop_plans SET lifecycle=$2, season=$3, target_production=$4, sowing_date=$5, harvest_date=$6, target_area_acres=$7, updated_at=now() WHERE id=$1`,
    [id, b.status ?? cur.status, b.season === undefined ? cur.season : optionalText(b.season, 'season', 30), b.targetProduction === undefined && b.targetYield === undefined ? cur.targetProduction ?? null : optionalNumber(b.targetProduction ?? b.targetYield, 'targetProduction', { min: 0 }),
      b.sowingDate === undefined ? cur.sowingDate ?? null : optionalDate(b.sowingDate, 'sowingDate'), b.harvestDate === undefined ? cur.harvestDate ?? null : optionalDate(b.harvestDate, 'harvestDate'), b.targetArea === undefined ? cur.targetArea : requireNumber(b.targetArea, 'targetArea', { positive: true })],
  );
  return getCropPlan(id);
}

// --------------------------------------------------------- field inspections
const fiOut = (r: any) => ({
  id: r.id, inspectionCode: r.inspection_code, farmId: r.farm_id, cropStage: r.crop_stage, inspectorName: r.inspector_name, healthScore: Number(r.health_score), diseaseDetected: r.disease_detected,
  diseaseName: r.disease_name ?? undefined, notes: r.notes ?? undefined, photos: r.photos ?? [], inspectionDate: dateOnly(r.inspection_date), aiPrediction: r.ai_prediction ?? undefined,
});
export const listFieldInspections = async () => (await rows(`SELECT * FROM farm_field_inspections ORDER BY inspection_date DESC, created_at DESC`)).map(fiOut);
export async function getFieldInspection(id: string) {
  const r = (await rows(`SELECT * FROM farm_field_inspections WHERE id = $1`, [requireUuid(id, 'id')]))[0];
  if (!r) throw new NotFoundError('Inspection not found');
  return fiOut(r);
}
export async function createFieldInspection(b: Record<string, unknown>, user: AuthenticatedUser) {
  const farmId = requireUuid(b.farmId, 'farmId');
  if (!(await rows(`SELECT 1 FROM farms WHERE id = $1`, [farmId]))[0]) throw new ValidationError('Farm not found');
  const id = await withTransaction(async (client) => {
    const code = await nextCode(client, 'FI', 4, true);
    return (await client.query(
      `INSERT INTO farm_field_inspections (inspection_code, farm_id, crop_stage, inspector_name, health_score, disease_detected, disease_name, notes, photos, inspection_date, ai_prediction, created_by)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) RETURNING id`,
      [code, farmId, requireText(b.cropStage, 'cropStage', 40), optionalText(b.inspectorName, 'inspectorName', 150) ?? (await actorName(user)), requireNumber(b.healthScore, 'healthScore', { min: 0, max: 100 }), b.diseaseDetected === true, b.diseaseDetected === true ? optionalText(b.diseaseName, 'diseaseName', 150) : null,
        optionalText(b.notes, 'notes', 2000), JSON.stringify(Array.isArray(b.photos) ? b.photos : []), optionalDate(b.inspectionDate, 'inspectionDate') ?? new Date().toISOString().slice(0, 10), b.aiPrediction ? JSON.stringify(b.aiPrediction) : null, user.email],
    )).rows[0].id as string;
  });
  return getFieldInspection(id);
}

// --------------------------------------------------------- inspection records
const irOut = (r: any) => ({ id: r.id, inspectionCode: r.inspection_code, farmId: r.farm_id, status: r.status, crop: r.crop, inspectionDate: dateOnly(r.inspection_date) });
export const listInspectionRecords = async () => (await rows(`SELECT * FROM farm_inspection_records ORDER BY inspection_date DESC NULLS LAST, created_at DESC`)).map(irOut);
export async function getInspectionRecord(id: string) {
  const r = (await rows(`SELECT * FROM farm_inspection_records WHERE id = $1`, [requireUuid(id, 'id')]))[0];
  if (!r) throw new NotFoundError('Inspection not found');
  return irOut(r);
}
export async function createInspectionRecord(b: Record<string, unknown>, user: AuthenticatedUser) {
  const farmId = requireUuid(b.farmId, 'farmId');
  if (!(await rows(`SELECT 1 FROM farms WHERE id = $1`, [farmId]))[0]) throw new ValidationError('Farm not found');
  const id = await withTransaction(async (client) => {
    const code = await nextCode(client, 'INS', 4, true);
    return (await client.query(`INSERT INTO farm_inspection_records (inspection_code, farm_id, crop, status, inspection_date, created_by) VALUES ($1,$2,$3,$4,$5,$6) RETURNING id`,
      [code, farmId, requireText(b.crop, 'crop', 100), ['Scheduled', 'Completed'].includes(String(b.status)) ? b.status : 'Scheduled', optionalDate(b.inspectionDate, 'inspectionDate'), user.email])).rows[0].id as string;
  });
  return getInspectionRecord(id);
}
export async function updateInspectionRecord(id: string, b: Record<string, unknown>) {
  const cur = await getInspectionRecord(id);
  if (cur.status === 'Approved') throw new ConflictError('An approved inspection cannot be changed');
  await rows(`UPDATE farm_inspection_records SET status=$2, inspection_date=$3 WHERE id=$1`, [id, ['Scheduled', 'Completed', 'Rejected'].includes(String(b.status)) ? b.status : cur.status, b.inspectionDate === undefined ? cur.inspectionDate ?? null : optionalDate(b.inspectionDate, 'inspectionDate')]);
  return getInspectionRecord(id);
}
export async function approveInspectionRecord(id: string, user: AuthenticatedUser) {
  const cur = await getInspectionRecord(id);
  if (cur.status !== 'Completed') throw new ConflictError('Only a completed inspection can be approved');
  await rows(`UPDATE farm_inspection_records SET status='Approved', approved_by=$2 WHERE id=$1`, [id, user.email]);
  return getInspectionRecord(id);
}

// ------------------------------------------------------------------- harvests
const hrOut = (r: any) => ({
  id: r.id, requestCode: r.request_code, farmId: r.farm_id, farmerId: r.farmer_id, varietyId: r.variety_id ?? '', crop: r.crop, cropPlanId: r.crop_plan_id ?? undefined, estimatedQuantityKg: Number(r.estimated_quantity_kg),
  actualQuantityKg: r.actual_quantity_kg === null ? undefined : Number(r.actual_quantity_kg), requestedHarvestDate: dateOnly(r.requested_harvest_date), harvestedDate: dateOnly(r.harvested_date), notes: r.notes ?? undefined, status: r.status,
  requestedBy: r.requested_by, requestedAt: r.created_at, inspectorName: r.inspector_name ?? undefined, inspectorNotes: r.inspector_notes ?? undefined, reviewedAt: r.reviewed_at ?? undefined, lotId: r.lot_id ?? undefined, transport: r.transport ?? undefined, history: r.history ?? [],
});
export const listHarvests = async () => (await rows(`SELECT * FROM harvest_requests ORDER BY created_at DESC`)).map(hrOut);
export async function getHarvest(id: string) {
  const r = (await rows(`SELECT * FROM harvest_requests WHERE id = $1`, [requireUuid(id, 'id')]))[0];
  if (!r) throw new NotFoundError('Harvest request not found');
  return hrOut(r);
}
const event = (status: string, by: string, note?: string) => ({ status, at: new Date().toISOString(), by, ...(note ? { note } : {}) });
async function pushEvent(id: string, status: string, by: string, note: string | undefined, set = '', params: unknown[] = []) {
  await rows(`UPDATE harvest_requests SET status = $2, history = history || $3::jsonb${set} WHERE id = $1`, [id, status, JSON.stringify([event(status, by, note)]), ...params]);
}

export async function createHarvest(b: Record<string, unknown>, user: AuthenticatedUser) {
  const farmId = requireUuid(b.farmId, 'farmId');
  const farm = (await rows(`SELECT farmer_id FROM farms WHERE id = $1`, [farmId]))[0];
  if (!farm) throw new ValidationError('Farm not found');
  const by = await actorName(user);
  const id = await withTransaction(async (client) => {
    const code = await nextCode(client, 'HR', 3, true);
    return (await client.query(
      `INSERT INTO harvest_requests (request_code, farm_id, farmer_id, variety_id, crop, crop_plan_id, estimated_quantity_kg, requested_harvest_date, notes, requested_by, history)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING id`,
      [code, farmId, farm.farmer_id, optionalUuid(b.varietyId, 'varietyId'), requireText(b.crop, 'crop', 100), optionalUuid(b.cropPlanId, 'cropPlanId'), requireNumber(b.estimatedQuantityKg, 'estimatedQuantityKg', { positive: true }), requireDate(b.requestedHarvestDate, 'requestedHarvestDate'),
        optionalText(b.notes, 'notes', 1000), by, JSON.stringify([event('Pending Approval', by, 'Harvest request raised.')])],
    )).rows[0].id as string;
  });
  return getHarvest(id);
}

export async function reviewHarvest(id: string, action: 'approve' | 'reject' | 'changes', b: Record<string, unknown>, user: AuthenticatedUser) {
  const cur = await getHarvest(id);
  if (!['Pending Approval', 'Changes Requested'].includes(cur.status) && !(action === 'approve' && cur.status === 'Approved')) throw new ConflictError(`A request that is ${cur.status} cannot be reviewed`);
  if (cur.requestedBy === (await actorName(user)) && action === 'approve') throw new ConflictError('You raised this request, so someone else must approve it');
  const notes = optionalText(b.inspectorNotes, 'inspectorNotes', 1000);
  if (action !== 'approve' && !notes) throw new ValidationError('Give a reason');
  const by = await actorName(user);
  if (action === 'approve') {
    const lot = cur.lotId ?? (await withTransaction(async (client) => nextCode(client, 'LOT', 4, true)));
    await pushEvent(id, 'Approved', by, `Readiness verified. Lot ${lot} created.`, ', inspector_name = $4, inspector_notes = COALESCE($5, inspector_notes), reviewed_at = now(), lot_id = $6', [by, notes, lot]);
  } else {
    await pushEvent(id, action === 'reject' ? 'Rejected' : 'Changes Requested', by, notes ?? undefined, ', inspector_name = $4, inspector_notes = $5, reviewed_at = now()', [by, notes]);
  }
  return getHarvest(id);
}
export async function completeHarvest(id: string, b: Record<string, unknown>, user: AuthenticatedUser) {
  const cur = await getHarvest(id);
  if (cur.status !== 'Approved') throw new ConflictError('Only an approved request can be marked harvested');
  const qty = requireNumber(b.actualQuantityKg, 'actualQuantityKg', { positive: true });
  await pushEvent(id, 'Harvested', await actorName(user), `Actual yield ${qty.toLocaleString('en-IN')} kg recorded.`, ', actual_quantity_kg = $4, harvested_date = $5', [qty, optionalDate(b.harvestedDate, 'harvestedDate') ?? new Date().toISOString().slice(0, 10)]);
  return getHarvest(id);
}
export async function authorizeHarvestTransport(id: string, b: Record<string, unknown>, user: AuthenticatedUser) {
  const cur = await getHarvest(id);
  if (cur.status !== 'Harvested') throw new ConflictError('Record the harvest before authorising transport');
  const by = await actorName(user);
  const t = { transporterName: requireText(b.transporterName, 'transporterName', 150), vehicleNumber: requireText(b.vehicleNumber, 'vehicleNumber', 20).toUpperCase(), destination: requireText(b.destination, 'destination', 150), dispatchDate: requireDate(b.dispatchDate, 'dispatchDate'), authorizedBy: by, authorizedAt: new Date().toISOString() };
  await pushEvent(id, 'Transport Authorized', by, `${t.vehicleNumber} authorised to ${t.destination}.`, ', transport = $4::jsonb', [JSON.stringify(t)]);
  return getHarvest(id);
}
export async function deliverHarvest(id: string, user: AuthenticatedUser) {
  const cur = await getHarvest(id);
  if (cur.status !== 'Transport Authorized') throw new ConflictError('Authorise transport first');
  await pushEvent(id, 'Delivered to Processing', await actorName(user), `Lot ${cur.lotId ?? ''} received at raw intake.`.trim());
  return getHarvest(id);
}

// ------------------------------------------------------------------ dashboard
export async function planningDashboard() {
  const [farmers, farms, plans, status, crops, monthly] = await Promise.all([
    rows(`SELECT COUNT(*)::int AS n FROM farmers WHERE NOT anonymized`),
    rows(`SELECT COUNT(*)::int AS n FROM farms`),
    rows(`SELECT COALESCE(SUM(target_area_acres),0)::float AS area, COALESCE(SUM(target_production),0)::float AS prod FROM crop_plans WHERE lifecycle <> 'Cancelled'`),
    rows(`SELECT CASE lifecycle WHEN 'Sown' THEN 'In Progress' WHEN 'Growing' THEN 'In Progress' WHEN 'Harvested' THEN 'Completed' ELSE lifecycle END AS status, COUNT(*)::int AS count FROM crop_plans GROUP BY 1 ORDER BY 1`),
    rows(`SELECT crop, COUNT(*)::int AS count FROM crop_plans WHERE lifecycle <> 'Cancelled' GROUP BY crop ORDER BY count DESC`),
    rows(`SELECT to_char(m, 'Mon') AS month,
            COALESCE((SELECT SUM(target_production) FROM crop_plans WHERE lifecycle <> 'Cancelled' AND date_trunc('month', COALESCE(harvest_date, sowing_date, created_at::date)) = m),0)::float AS target,
            COALESCE((SELECT SUM(actual_quantity_kg) FROM harvest_requests WHERE harvested_date IS NOT NULL AND date_trunc('month', harvested_date) = m),0)::float AS actual
          FROM generate_series(date_trunc('month', now()) - interval '5 months', date_trunc('month', now()), interval '1 month') m ORDER BY m`),
  ]);
  return { totalFarmers: farmers[0].n, activeFarms: farms[0].n, totalPlannedArea: plans[0].area, totalHarvestTarget: plans[0].prod, statusBreakdown: status, cropDistribution: crops, monthlyProgress: monthly };
}
