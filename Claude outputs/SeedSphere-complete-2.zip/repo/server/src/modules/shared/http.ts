import type { Request, Response } from 'express';

export const str = (v: unknown): string | undefined => (typeof v === 'string' && v ? v : undefined);
export const bool = (v: unknown): boolean | undefined => (v === 'true' ? true : v === 'false' ? false : undefined);
export const body = (req: Request): Record<string, unknown> => (req.body && typeof req.body === 'object' && !Buffer.isBuffer(req.body) ? req.body : {});
export const ok = (res: Response, data: unknown, message?: string, status = 200) =>
  res.status(status).json({ success: true, data, ...(message ? { message } : {}) });
