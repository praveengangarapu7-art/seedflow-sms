import { ValidationError } from '../../errors';

export {
  optionalDate,
  optionalEmail,
  optionalText,
  requireDate,
  requireEmail,
  requireEnum,
  requireText,
  nextCode,
  assertSeedLotExists,
  assertLotNotOnHold,
} from '../quality/quality.common';

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export function isUuid(value: unknown): value is string {
  return typeof value === 'string' && UUID.test(value);
}

export function requireUuid(value: unknown, field: string): string {
  if (!isUuid(value)) throw new ValidationError(`${field} must be a valid id`);
  return value;
}

export function optionalUuid(value: unknown, field: string): string | null {
  if (value === undefined || value === null || value === '') return null;
  return requireUuid(value, field);
}

function toNumber(value: unknown): number | null {
  if (typeof value === 'number') return Number.isFinite(value) ? value : null;
  if (typeof value === 'string' && value.trim() !== '') {
    const n = Number(value);
    return Number.isFinite(n) ? n : null;
  }
  return null;
}

export function requireNumber(value: unknown, field: string, opts: { min?: number; max?: number; positive?: boolean } = {}): number {
  const n = toNumber(value);
  if (n === null) throw new ValidationError(`${field} must be a number`);
  if (opts.positive && n <= 0) throw new ValidationError(`${field} must be greater than zero`);
  if (opts.min !== undefined && n < opts.min) throw new ValidationError(`${field} must be at least ${opts.min}`);
  if (opts.max !== undefined && n > opts.max) throw new ValidationError(`${field} must be at most ${opts.max}`);
  return n;
}

export function optionalNumber(value: unknown, field: string, opts: { min?: number; max?: number; positive?: boolean } = {}): number | null {
  if (value === undefined || value === null || value === '') return null;
  return requireNumber(value, field, opts);
}

export function optionalBool(value: unknown, field: string): boolean | null {
  if (value === undefined || value === null || value === '') return null;
  if (typeof value === 'boolean') return value;
  if (value === 'true') return true;
  if (value === 'false') return false;
  throw new ValidationError(`${field} must be true or false`);
}

export function requireArray(value: unknown, field: string, { min = 1, max = 200 } = {}): unknown[] {
  if (!Array.isArray(value)) throw new ValidationError(`${field} must be a list`);
  if (value.length < min) throw new ValidationError(`${field} needs at least ${min} item(s)`);
  if (value.length > max) throw new ValidationError(`${field} can have at most ${max} items`);
  return value;
}

export function asRecord(value: unknown, field: string): Record<string, unknown> {
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw new ValidationError(`${field} must be an object`);
  return value as Record<string, unknown>;
}

/** Postgres NUMERIC comes back as a string; this keeps API payloads numeric. */
export function num(value: unknown): number {
  if (value === null || value === undefined) return 0;
  const n = Number(value);
  return Number.isFinite(n) ? n : 0;
}

/** Rounds money/quantity to 2 dp the way NUMERIC(…,2) stores it. */
export function round2(n: number): number {
  return Math.round((n + Number.EPSILON) * 100) / 100;
}

export function todayIso(): string {
  return new Date().toISOString().slice(0, 10);
}

export function addDaysIso(days: number, from = new Date()): string {
  const d = new Date(from);
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}
