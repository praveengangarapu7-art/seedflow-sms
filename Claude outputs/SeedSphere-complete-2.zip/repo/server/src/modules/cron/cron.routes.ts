import { timingSafeEqual } from 'crypto';
import { Router, type NextFunction, type Request, type Response } from 'express';
import { env } from '../../config/env';
import { asyncHandler as h } from '../../middleware/asyncHandler';
import { flushOutbox } from '../reach/messaging.service';
import { ok } from '../shared/http';

/**
 * Scheduled jobs for hosts with no long-running process (Vercel). Locally the
 * server's own timers do this work; on Vercel, Vercel Cron calls these routes
 * with `Authorization: Bearer <CRON_SECRET>`.
 */
function requireCronSecret(req: Request, res: Response, next: NextFunction): void {
  const secret = env.cronSecret;
  const given = (req.header('authorization') ?? '').replace(/^Bearer\s+/i, '');
  const a = Buffer.from(given);
  const b = Buffer.from(secret);
  if (!secret || a.length !== b.length || !timingSafeEqual(a, b)) {
    res.status(401).json({ success: false, message: 'Not authorised' });
    return;
  }
  next();
}

export const cronRouter = Router();
cronRouter.use(requireCronSecret);
cronRouter.get('/outbox', h(async (_req, res) => ok(res, await flushOutbox(200), 'Outbox processed')));
