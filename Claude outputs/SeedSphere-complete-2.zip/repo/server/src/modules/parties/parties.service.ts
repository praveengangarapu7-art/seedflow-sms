import type { PoolClient } from 'pg';
import { pool } from '../../db/pool';
import { withTransaction } from '../../db/transaction';
import { ConflictError, ForbiddenError, NotFoundError, ValidationError } from '../../errors';
import type { AuthenticatedUser } from '../../middleware/requireAuth';
import { userHasPermission } from '../../middleware/requireAuth';
import { insertAuditLog } from '../auditLogs/auditLogs.service';
import { nextCode, optionalDate, optionalEmail, optionalText, requireEnum, requireText } from '../shared/validate';

export const PARTY_TYPES = [
  'supplier',
  'contract_grower',
  'dealer',
  'distributor',
  'farmer',
  'transporter',
  'customer',
  'service_provider',
] as const;
export type PartyType = (typeof PARTY_TYPES)[number];

const CODE_PREFIX: Record<PartyType, string> = {
  supplier: 'SUP',
  contract_grower: 'GRW',
  dealer: 'DLR',
  distributor: 'DST',
  farmer: 'FRM',
  transporter: 'TRN',
  customer: 'CUS',
  service_provider: 'SRV',
};

/** Seed may only be sold through licensed outlets, so these types must carry a licence. */
const LICENCE_REQUIRED: PartyType[] = ['dealer', 'distributor'];

export const PARTY_STATUSES = ['pending_approval', 'active', 'suspended', 'blacklisted'] as const;

const GSTIN = /^\d{2}[A-Z]{5}\d{4}[A-Z][1-9A-Z]Z[0-9A-Z]$/;
const PAN = /^[A-Z]{5}\d{4}[A-Z]$/;
const IFSC = /^[A-Z]{4}0[A-Z0-9]{6}$/;
const PHONE = /^(\+91)?[6-9]\d{9}$/;
const PINCODE = /^[1-9]\d{5}$/;
const ACCOUNT = /^\d{6,20}$/;

export interface PartyRow {
  id: string;
  party_code: string;
  party_type: PartyType;
  name: string;
  contact_person: string | null;
  phone: string | null;
  email: string | null;
  preferred_language: string;
  address_line: string | null;
  village: string | null;
  district: string | null;
  state: string | null;
  pincode: string | null;
  gstin: string | null;
  pan: string | null;
  bank_account_name: string | null;
  bank_account_number: string | null;
  bank_ifsc: string | null;
  licence_number: string | null;
  licence_valid_until: string | null;
  category: string | null;
  status: string;
  status_reason: string | null;
  approved_by: string | null;
  approved_at: string | null;
  user_id: string | null;
  notes: string | null;
  created_by: string;
  created_at: string;
  updated_at: string;
}

function pattern(value: string | null, re: RegExp, field: string, hint: string): string | null {
  if (value === null) return null;
  const v = value.replace(/\s+/g, '').toUpperCase();
  if (!re.test(v)) throw new ValidationError(`${field} is not valid (${hint})`);
  return v;
}

function normalisePhone(value: string | null): string | null {
  if (value === null) return null;
  const v = value.replace(/[\s-]/g, '');
  if (!PHONE.test(v)) throw new ValidationError('phone must be a 10-digit Indian mobile number, optionally prefixed +91');
  return v.startsWith('+91') ? v : `+91${v}`;
}

interface PartyFields {
  name?: string;
  contact_person?: string | null;
  phone?: string | null;
  email?: string | null;
  preferred_language?: string;
  address_line?: string | null;
  village?: string | null;
  district?: string | null;
  state?: string | null;
  pincode?: string | null;
  gstin?: string | null;
  pan?: string | null;
  bank_account_name?: string | null;
  bank_account_number?: string | null;
  bank_ifsc?: string | null;
  licence_number?: string | null;
  licence_valid_until?: string | null;
  category?: string | null;
  notes?: string | null;
}

const FIELD_MAP: Record<string, keyof PartyFields> = {
  name: 'name',
  contactPerson: 'contact_person',
  phone: 'phone',
  email: 'email',
  preferredLanguage: 'preferred_language',
  addressLine: 'address_line',
  village: 'village',
  district: 'district',
  state: 'state',
  pincode: 'pincode',
  gstin: 'gstin',
  pan: 'pan',
  bankAccountName: 'bank_account_name',
  bankAccountNumber: 'bank_account_number',
  bankIfsc: 'bank_ifsc',
  licenceNumber: 'licence_number',
  licenceValidUntil: 'licence_valid_until',
  category: 'category',
  notes: 'notes',
};

const BANK_FIELDS: (keyof PartyFields)[] = ['bank_account_name', 'bank_account_number', 'bank_ifsc'];

function parseFields(input: Record<string, unknown>, partial: boolean): PartyFields {
  const out: PartyFields = {};
  const has = (k: string) => Object.prototype.hasOwnProperty.call(input, k);
  if (!partial || has('name')) out.name = requireText(input.name, 'name', 200);
  if (has('contactPerson')) out.contact_person = optionalText(input.contactPerson, 'contactPerson', 150);
  if (has('phone')) out.phone = normalisePhone(optionalText(input.phone, 'phone', 20));
  if (has('email')) out.email = optionalEmail(input.email, 'email');
  if (has('preferredLanguage')) {
    out.preferred_language = requireEnum(input.preferredLanguage ?? 'en', ['en', 'hi', 'te', 'ta', 'kn', 'mr', 'gu', 'pa', 'bn', 'or'] as const, 'preferredLanguage');
  }
  if (has('addressLine')) out.address_line = optionalText(input.addressLine, 'addressLine', 500);
  if (has('village')) out.village = optionalText(input.village, 'village', 100);
  if (has('district')) out.district = optionalText(input.district, 'district', 100);
  if (has('state')) out.state = optionalText(input.state, 'state', 100);
  if (has('pincode')) out.pincode = pattern(optionalText(input.pincode, 'pincode', 10), PINCODE, 'pincode', '6 digits');
  if (has('gstin')) out.gstin = pattern(optionalText(input.gstin, 'gstin', 20), GSTIN, 'gstin', '15-character GSTIN');
  if (has('pan')) out.pan = pattern(optionalText(input.pan, 'pan', 12), PAN, 'pan', 'e.g. ABCDE1234F');
  if (has('bankAccountName')) out.bank_account_name = optionalText(input.bankAccountName, 'bankAccountName', 150);
  if (has('bankAccountNumber')) out.bank_account_number = pattern(optionalText(input.bankAccountNumber, 'bankAccountNumber', 30), ACCOUNT, 'bankAccountNumber', '6–20 digits');
  if (has('bankIfsc')) out.bank_ifsc = pattern(optionalText(input.bankIfsc, 'bankIfsc', 15), IFSC, 'bankIfsc', 'e.g. SBIN0001234');
  if (has('licenceNumber')) out.licence_number = optionalText(input.licenceNumber, 'licenceNumber', 60);
  if (has('licenceValidUntil')) out.licence_valid_until = optionalDate(input.licenceValidUntil, 'licenceValidUntil');
  if (has('category')) out.category = optionalText(input.category, 'category', 50);
  if (has('notes')) out.notes = optionalText(input.notes, 'notes', 2000);
  for (const k of Object.keys(input)) {
    if (!(k in FIELD_MAP) && k !== 'partyType') throw new ValidationError(`Unknown field: ${k}`);
  }
  return out;
}

function assertComplete(type: PartyType, row: PartyFields) {
  if (!row.phone && !row.email) throw new ValidationError('A party needs a phone number or an email so it can be contacted');
  if (LICENCE_REQUIRED.includes(type) && (!row.licence_number || !row.licence_valid_until)) {
    throw new ValidationError(`A ${type} must have a seed licence number and its validity date`);
  }
  const bank = BANK_FIELDS.filter((f) => row[f]);
  if (bank.length > 0 && bank.length < BANK_FIELDS.length) {
    throw new ValidationError('Bank details need the account name, account number and IFSC together');
  }
}

/** List views never carry a full bank account number. */
export function maskAccount(account: string | null): string | null {
  if (!account) return null;
  return `${'•'.repeat(Math.max(0, account.length - 4))}${account.slice(-4)}`;
}

function present(row: PartyRow, user: AuthenticatedUser | null) {
  const canSeeBank = !!user && (userHasPermission(user, 'manage_parties') || userHasPermission(user, 'release_payment'));
  const today = new Date().toISOString().slice(0, 10);
  return {
    ...row,
    bank_account_number: canSeeBank ? row.bank_account_number : maskAccount(row.bank_account_number),
    licence_expired: row.licence_valid_until ? row.licence_valid_until < today : null,
  };
}

async function loadForUpdate(client: PoolClient, id: string): Promise<PartyRow> {
  const r = await client.query<PartyRow>('SELECT * FROM parties WHERE id = $1 FOR UPDATE', [id]);
  if (!r.rows[0]) throw new NotFoundError(`Party ${id} not found`);
  return r.rows[0];
}

export async function createParty(input: Record<string, unknown>, user: AuthenticatedUser) {
  const type = requireEnum(input.partyType, PARTY_TYPES, 'partyType');
  const fields = parseFields(input, false);
  assertComplete(type, fields);
  return withTransaction(async (client) => {
    if (fields.gstin) {
      const dup = await client.query('SELECT party_code FROM parties WHERE party_type = $1 AND gstin = $2', [type, fields.gstin]);
      if (dup.rows[0]) throw new ConflictError(`A ${type} with GSTIN ${fields.gstin} already exists (${dup.rows[0].party_code})`);
    }
    const code = await nextCode(client, CODE_PREFIX[type], 4, false);
    const cols = Object.keys(fields) as (keyof PartyFields)[];
    const values = cols.map((c) => fields[c] ?? null);
    const inserted = await client.query<PartyRow>(
      `INSERT INTO parties (party_code, party_type, created_by${cols.map((c) => `, ${c}`).join('')})
       VALUES ($1, $2, $3${cols.map((_, i) => `, $${i + 4}`).join('')}) RETURNING *`,
      [code, type, user.email, ...values],
    );
    const party = inserted.rows[0];
    await insertAuditLog(client, { entityType: 'party', entityId: party.id, action: 'CREATE', performedBy: user.email, afterState: { ...party, bank_account_number: maskAccount(party.bank_account_number) } });
    return present(party, user);
  });
}

export async function updateParty(id: string, input: Record<string, unknown>, user: AuthenticatedUser) {
  const fields = parseFields(input, true);
  return withTransaction(async (client) => {
    const before = await loadForUpdate(client, id);
    if (before.status === 'blacklisted') throw new ConflictError('A blacklisted party cannot be edited');
    const merged = { ...before, ...fields } as PartyFields & PartyRow;
    assertComplete(before.party_type, merged);
    const bankChanged = BANK_FIELDS.some((f) => f in fields && (fields[f] ?? null) !== (before[f as keyof PartyRow] ?? null));
    const cols = Object.keys(fields) as (keyof PartyFields)[];
    if (cols.length === 0) throw new ValidationError('Nothing to update');
    // Changing where money is paid is a classic fraud route, so a bank
    // change on an approved party sends it back for a second person's approval.
    const resetApproval = bankChanged && before.status === 'active';
    const sets = cols.map((c, i) => `${c} = $${i + 2}`);
    if (resetApproval) sets.push(`status = 'pending_approval'`, 'approved_by = NULL', 'approved_at = NULL');
    const updated = await client.query<PartyRow>(`UPDATE parties SET ${sets.join(', ')} WHERE id = $1 RETURNING *`, [id, ...cols.map((c) => fields[c] ?? null)]);
    const after = updated.rows[0];
    await insertAuditLog(client, {
      entityType: 'party',
      entityId: id,
      action: resetApproval ? 'BANK_DETAILS_CHANGED' : 'UPDATE',
      performedBy: user.email,
      beforeState: { ...before, bank_account_number: maskAccount(before.bank_account_number) },
      afterState: { ...after, bank_account_number: maskAccount(after.bank_account_number) },
    });
    return { party: present(after, user), approvalReset: resetApproval };
  });
}

export async function approveParty(id: string, user: AuthenticatedUser) {
  return withTransaction(async (client) => {
    const before = await loadForUpdate(client, id);
    if (before.status !== 'pending_approval') throw new ConflictError(`Only a party awaiting approval can be approved (this one is ${before.status})`);
    if (before.created_by === user.email) throw new ForbiddenError('A party must be approved by someone other than the person who created it');
    const lastEditor = await client.query<{ performed_by: string }>(
      `SELECT performed_by FROM audit_logs WHERE entity_type = 'party' AND entity_id = $1 AND action = 'BANK_DETAILS_CHANGED' ORDER BY created_at DESC LIMIT 1`,
      [id],
    );
    if (lastEditor.rows[0]?.performed_by === user.email) {
      throw new ForbiddenError('The person who changed the bank details cannot approve the change');
    }
    const r = await client.query<PartyRow>(
      `UPDATE parties SET status = 'active', approved_by = $2, approved_at = now(), status_reason = NULL WHERE id = $1 RETURNING *`,
      [id, user.email],
    );
    await insertAuditLog(client, { entityType: 'party', entityId: id, action: 'APPROVE', performedBy: user.email, beforeState: { status: before.status }, afterState: { status: 'active' } });
    return present(r.rows[0], user);
  });
}

export async function suspendParty(id: string, input: Record<string, unknown>, user: AuthenticatedUser) {
  const reason = requireText(input.reason, 'reason', 1000);
  const blacklist = input.blacklist === true;
  return withTransaction(async (client) => {
    const before = await loadForUpdate(client, id);
    if (before.status === 'blacklisted') throw new ConflictError('This party is already blacklisted');
    const status = blacklist ? 'blacklisted' : 'suspended';
    const r = await client.query<PartyRow>(`UPDATE parties SET status = $2, status_reason = $3 WHERE id = $1 RETURNING *`, [id, status, reason]);
    await insertAuditLog(client, { entityType: 'party', entityId: id, action: blacklist ? 'BLACKLIST' : 'SUSPEND', performedBy: user.email, beforeState: { status: before.status }, afterState: { status, reason } });
    return present(r.rows[0], user);
  });
}

export async function reactivateParty(id: string, user: AuthenticatedUser) {
  return withTransaction(async (client) => {
    const before = await loadForUpdate(client, id);
    if (before.status !== 'suspended') throw new ConflictError('Only a suspended party can be reactivated; a blacklisted party stays blacklisted');
    const r = await client.query<PartyRow>(
      `UPDATE parties SET status = 'active', status_reason = NULL, approved_by = $2, approved_at = now() WHERE id = $1 RETURNING *`,
      [id, user.email],
    );
    await insertAuditLog(client, { entityType: 'party', entityId: id, action: 'REACTIVATE', performedBy: user.email, beforeState: { status: before.status }, afterState: { status: 'active' } });
    return present(r.rows[0], user);
  });
}

export async function linkPortalUser(id: string, input: Record<string, unknown>, user: AuthenticatedUser) {
  const email = requireText(input.email, 'email', 150).toLowerCase();
  return withTransaction(async (client) => {
    const party = await loadForUpdate(client, id);
    const expected = party.party_type === 'contract_grower' ? 'grower' : party.party_type === 'dealer' || party.party_type === 'distributor' ? 'dealer' : null;
    if (!expected) throw new ValidationError('Only contract growers, dealers and distributors have portal access');
    const u = await client.query<{ id: string; job_role: string | null }>('SELECT id, job_role FROM users WHERE email = $1', [email]);
    if (!u.rows[0]) throw new NotFoundError(`No user with email ${email}`);
    if (u.rows[0].job_role !== expected) throw new ValidationError(`That user must have the ${expected} job role to be linked to this party`);
    const r = await client.query<PartyRow>('UPDATE parties SET user_id = $2 WHERE id = $1 RETURNING *', [id, u.rows[0].id]);
    await insertAuditLog(client, { entityType: 'party', entityId: id, action: 'LINK_PORTAL_USER', performedBy: user.email, afterState: { email } });
    return present(r.rows[0], user);
  });
}

export interface PartyFilters {
  type?: string;
  status?: string;
  q?: string;
  licenceExpiringWithinDays?: number;
}

export async function listParties(filters: PartyFilters, user: AuthenticatedUser) {
  const where: string[] = [];
  const values: unknown[] = [];
  if (filters.type) {
    values.push(requireEnum(filters.type, PARTY_TYPES, 'type'));
    where.push(`party_type = $${values.length}`);
  }
  if (filters.status) {
    values.push(requireEnum(filters.status, PARTY_STATUSES, 'status'));
    where.push(`status = $${values.length}`);
  }
  if (filters.q) {
    values.push(`%${filters.q.toLowerCase()}%`);
    where.push(`(LOWER(name) LIKE $${values.length} OR LOWER(party_code) LIKE $${values.length} OR LOWER(COALESCE(village,'')) LIKE $${values.length} OR COALESCE(phone,'') LIKE $${values.length})`);
  }
  if (filters.licenceExpiringWithinDays !== undefined) {
    values.push(filters.licenceExpiringWithinDays);
    where.push(`licence_valid_until IS NOT NULL AND licence_valid_until <= CURRENT_DATE + $${values.length}::int`);
  }
  const r = await pool.query<PartyRow>(
    `SELECT * FROM parties ${where.length ? `WHERE ${where.join(' AND ')}` : ''} ORDER BY name LIMIT 1000`,
    values,
  );
  return r.rows.map((row) => ({ ...present(row, user), bank_account_number: maskAccount(row.bank_account_number) }));
}

export async function getParty(id: string, user: AuthenticatedUser) {
  const r = await pool.query<PartyRow>('SELECT * FROM parties WHERE id = $1', [id]);
  if (!r.rows[0]) throw new NotFoundError(`Party ${id} not found`);
  const history = await pool.query(
    `SELECT action, performed_by, created_at FROM audit_logs WHERE entity_type = 'party' AND entity_id = $1 ORDER BY created_at DESC LIMIT 50`,
    [id],
  );
  return { party: present(r.rows[0], user), history: history.rows };
}

/** Licences that have lapsed or lapse within 30 days, and parties waiting for approval. */
export async function getPartyAlerts() {
  const licences = await pool.query(
    `SELECT id, party_code, party_type, name, licence_number, licence_valid_until,
            (licence_valid_until < CURRENT_DATE) AS expired
       FROM parties
      WHERE status IN ('active', 'pending_approval') AND licence_valid_until IS NOT NULL
        AND licence_valid_until <= CURRENT_DATE + 30
      ORDER BY licence_valid_until`,
  );
  const pending = await pool.query(`SELECT COUNT(*)::int AS n FROM parties WHERE status = 'pending_approval'`);
  return { licences: licences.rows, pendingApproval: pending.rows[0].n as number };
}

/** Used by other modules before they transact with a party. */
export async function assertPartyUsable(client: PoolClient, partyId: string, allowed: PartyType[], purpose: string): Promise<PartyRow> {
  const r = await client.query<PartyRow>('SELECT * FROM parties WHERE id = $1', [partyId]);
  const party = r.rows[0];
  if (!party) throw new NotFoundError(`Party ${partyId} not found`);
  if (!allowed.includes(party.party_type)) throw new ValidationError(`${party.name} is a ${party.party_type}; ${purpose} needs a ${allowed.join(' or ')}`);
  if (party.status !== 'active') throw new ConflictError(`${party.name} (${party.party_code}) is ${party.status.replace('_', ' ')} and cannot be used for ${purpose}`);
  if (LICENCE_REQUIRED.includes(party.party_type) && party.licence_valid_until) {
    const today = new Date().toISOString().slice(0, 10);
    if (party.licence_valid_until < today) throw new ConflictError(`${party.name}'s seed licence expired on ${party.licence_valid_until}; renew it before ${purpose}`);
  }
  return party;
}
