import { Router, type Request, type Response } from 'express';
import { asyncHandler as h } from '../../middleware/asyncHandler';
import { requireAuth, requirePermission, requireStaff } from '../../middleware/requireAuth';
import { body, ok, str } from '../shared/http';
import * as s from './parties.service';

export const partiesRouter = Router();
partiesRouter.use(requireAuth, requireStaff);

partiesRouter.get(
  '/',
  h(async (req: Request, res: Response) => {
    const days = str(req.query.licenceExpiringWithinDays);
    ok(res, await s.listParties({ type: str(req.query.type), status: str(req.query.status), q: str(req.query.q), licenceExpiringWithinDays: days ? Number(days) : undefined }, req.user!));
  }),
);
partiesRouter.get('/alerts', h(async (_req, res) => ok(res, await s.getPartyAlerts())));
partiesRouter.get('/:id', h(async (req, res) => ok(res, await s.getParty(req.params.id, req.user!))));
partiesRouter.post(
  '/',
  requirePermission('manage_parties'),
  h(async (req, res) => {
    const party = await s.createParty(body(req), req.user!);
    ok(res, party, `${party.party_code} created — it needs a second person's approval before use`, 201);
  }),
);
partiesRouter.patch(
  '/:id',
  requirePermission('manage_parties'),
  h(async (req, res) => {
    const r = await s.updateParty(req.params.id, body(req), req.user!);
    ok(res, r.party, r.approvalReset ? 'Bank details changed — the party is back awaiting approval' : 'Party updated');
  }),
);
partiesRouter.post('/:id/approve', requirePermission('approve_parties'), h(async (req, res) => ok(res, await s.approveParty(req.params.id, req.user!), 'Party approved')));
partiesRouter.post('/:id/suspend', requirePermission('approve_parties'), h(async (req, res) => ok(res, await s.suspendParty(req.params.id, body(req), req.user!), 'Party status changed')));
partiesRouter.post('/:id/reactivate', requirePermission('approve_parties'), h(async (req, res) => ok(res, await s.reactivateParty(req.params.id, req.user!), 'Party reactivated')));
partiesRouter.post('/:id/portal-user', requirePermission('approve_parties'), h(async (req, res) => ok(res, await s.linkPortalUser(req.params.id, body(req), req.user!), 'Portal user linked')));
