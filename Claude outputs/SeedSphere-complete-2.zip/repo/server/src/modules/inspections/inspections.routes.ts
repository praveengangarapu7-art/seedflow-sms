import { Router } from 'express';
import { asyncHandler as h } from '../../middleware/asyncHandler';
import { requireAuth, requirePermission, requireStaff } from '../../middleware/requireAuth';
import { body, ok, str } from '../shared/http';
import * as s from './inspections.service';

export const inspectionsRouter = Router();
inspectionsRouter.use(requireAuth, requireStaff);

// Templates (specifications)
inspectionsRouter.get('/templates', h(async (req, res) => ok(res, await s.listTemplates({ type: str(req.query.type), status: str(req.query.status) }))));
inspectionsRouter.get('/templates/:id', h(async (req, res) => ok(res, await s.getTemplate(req.params.id))));
inspectionsRouter.post('/templates', requirePermission('manage_inspection_templates'), h(async (req, res) => {
  const t = await s.createTemplate(body(req), req.user!);
  ok(res, t, `${t.template_code} created as a draft`, 201);
}));
inspectionsRouter.post('/templates/:id/revise', requirePermission('manage_inspection_templates'), h(async (req, res) => {
  const t = await s.reviseTemplate(req.params.id, body(req), req.user!);
  ok(res, t, `Version ${t.version} drafted`, 201);
}));
inspectionsRouter.post('/templates/:id/activate', requirePermission('manage_inspection_templates'), h(async (req, res) => ok(res, await s.activateTemplate(req.params.id, req.user!), 'Template activated')));
inspectionsRouter.post('/templates/:id/retire', requirePermission('manage_inspection_templates'), h(async (req, res) => ok(res, await s.retireTemplate(req.params.id, req.user!), 'Template retired')));

// Inspections
inspectionsRouter.get('/stats', h(async (_req, res) => ok(res, await s.getInspectionStats())));
inspectionsRouter.get('/', h(async (req, res) =>
  ok(res, await s.listInspections({
    type: str(req.query.type),
    status: str(req.query.status),
    result: str(req.query.result),
    subjectType: str(req.query.subjectType),
    subjectId: str(req.query.subjectId),
    seedLotId: str(req.query.seedLotId),
    mine: req.query.mine === 'true',
  }, req.user!))));
inspectionsRouter.get('/:id', h(async (req, res) => ok(res, await s.getInspection(req.params.id))));
inspectionsRouter.post('/', requirePermission('conduct_inspection'), h(async (req, res) => {
  const i = await s.startInspection(body(req), req.user!);
  ok(res, i, `${i.inspection_code} started`, 201);
}));
inspectionsRouter.put('/:id/results', requirePermission('conduct_inspection'), h(async (req, res) => ok(res, await s.recordResults(req.params.id, body(req), req.user!), 'Results saved')));
inspectionsRouter.post('/:id/submit', requirePermission('conduct_inspection'), h(async (req, res) => {
  const i = await s.submitInspection(req.params.id, body(req), req.user!);
  ok(res, i, `${i.inspection_code} submitted — result: ${i.result}${i.ncr_code ? `, ${i.ncr_code} raised` : ''}`);
}));
