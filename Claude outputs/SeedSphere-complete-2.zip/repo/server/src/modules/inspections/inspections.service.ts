import type { PoolClient } from 'pg';
import { pool } from '../../db/pool';
import { withTransaction } from '../../db/transaction';
import { ConflictError, ForbiddenError, NotFoundError, ValidationError } from '../../errors';
import type { AuthenticatedUser } from '../../middleware/requireAuth';
import { insertAuditLog } from '../auditLogs/auditLogs.service';
import { placeHoldTx } from '../quality/holds.service';
import { insertNcrTx } from '../quality/ncr.service';
import type { Department } from '../quality/quality.common';
import {
  assertSeedLotExists,
  asRecord,
  nextCode,
  num,
  optionalBool,
  optionalNumber,
  optionalText,
  optionalUuid,
  requireArray,
  requireEnum,
  requireText,
  requireUuid,
} from '../shared/validate';

export const INSPECTION_TYPES = [
  'procurement_receipt',
  'warehouse_receipt',
  'warehouse_return',
  'storage_condition',
  'processing_pre',
  'processing_in_process',
  'processing_final',
  'field',
  'trial_integrity',
  'dealer_audit',
  'other',
] as const;
export type InspectionType = (typeof INSPECTION_TYPES)[number];

export const ITEM_TYPES = ['numeric', 'pass_fail', 'text'] as const;
export const DECISIONS = ['accept', 'partial_accept', 'reject', 'hold', 'rework'] as const;
export type Decision = (typeof DECISIONS)[number];

const DEPARTMENT_FOR_TYPE: Record<InspectionType, Department> = {
  procurement_receipt: 'procurement',
  warehouse_receipt: 'warehouse',
  warehouse_return: 'warehouse',
  storage_condition: 'warehouse',
  processing_pre: 'production',
  processing_in_process: 'production',
  processing_final: 'production',
  field: 'production',
  trial_integrity: 'rd',
  dealer_audit: 'operations',
  other: 'quality',
};

export interface InspectionRow {
  id: string;
  inspection_code: string;
  template_id: string;
  inspection_type: InspectionType;
  subject_type: string;
  subject_id: string | null;
  subject_label: string;
  seed_lot_id: string | null;
  location_text: string | null;
  latitude: string | null;
  longitude: string | null;
  inspector_email: string;
  status: 'in_progress' | 'submitted';
  result: 'pass' | 'conditional' | 'fail' | null;
  decision: Decision | null;
  accepted_quantity: string | null;
  decision_notes: string | null;
  ncr_id: string | null;
  created_at: string;
  submitted_at: string | null;
}

export interface ResultRow {
  id: string;
  inspection_id: string;
  template_item_id: string;
  label: string;
  item_type: 'numeric' | 'pass_fail' | 'text';
  unit: string | null;
  min_value: string | null;
  max_value: string | null;
  is_critical: boolean;
  numeric_value: string | null;
  bool_value: boolean | null;
  text_value: string | null;
  passed: boolean | null;
  notes: string | null;
}

/**
 * Modules that own the thing being inspected (a goods receipt, a processing
 * batch, a return) register here: resolveSubject proves the subject exists
 * and supplies its label and lot; onSubmitted applies the decision to it
 * inside the same transaction (e.g. sets the accepted quantity on a receipt).
 */
export interface InspectionSubjectHandler {
  resolveSubject?: (client: PoolClient, subjectId: string) => Promise<{ label: string; seedLotId: string | null }>;
  onSubmitted?: (client: PoolClient, inspection: InspectionRow, user: AuthenticatedUser) => Promise<void>;
}

const subjectHandlers = new Map<string, InspectionSubjectHandler>();

export function registerInspectionSubject(subjectType: string, handler: InspectionSubjectHandler): void {
  subjectHandlers.set(subjectType, handler);
}

const SUBJECT_TYPE = /^[a-z][a-z_]{1,39}$/;

// ---------------------------------------------------------------- templates

interface ItemInput {
  label: string;
  itemType: (typeof ITEM_TYPES)[number];
  unit: string | null;
  minValue: number | null;
  maxValue: number | null;
  isRequired: boolean;
  isCritical: boolean;
  guidance: string | null;
}

function parseItems(value: unknown): ItemInput[] {
  const items = requireArray(value, 'items', { min: 1, max: 60 });
  return items.map((raw, i) => {
    const r = asRecord(raw, `items[${i}]`);
    const itemType = requireEnum(r.itemType, ITEM_TYPES, `items[${i}].itemType`);
    const minValue = optionalNumber(r.minValue, `items[${i}].minValue`);
    const maxValue = optionalNumber(r.maxValue, `items[${i}].maxValue`);
    if (itemType !== 'numeric' && (minValue !== null || maxValue !== null)) {
      throw new ValidationError(`items[${i}]: only numeric checks have limits`);
    }
    if (minValue !== null && maxValue !== null && minValue > maxValue) throw new ValidationError(`items[${i}]: minValue is above maxValue`);
    return {
      label: requireText(r.label, `items[${i}].label`, 200),
      itemType,
      unit: optionalText(r.unit, `items[${i}].unit`, 20),
      minValue,
      maxValue,
      isRequired: r.isRequired !== false,
      isCritical: r.isCritical === true,
      guidance: optionalText(r.guidance, `items[${i}].guidance`, 1000),
    };
  });
}

async function insertItems(client: PoolClient, templateId: string, items: ItemInput[]) {
  for (const [i, it] of items.entries()) {
    await client.query(
      `INSERT INTO inspection_template_items (template_id, seq, label, item_type, unit, min_value, max_value, is_required, is_critical, guidance)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)`,
      [templateId, i + 1, it.label, it.itemType, it.unit, it.minValue, it.maxValue, it.isRequired, it.isCritical, it.guidance],
    );
  }
}

export async function listTemplates(filters: { type?: string; status?: string }) {
  const where: string[] = [];
  const values: unknown[] = [];
  if (filters.type) {
    values.push(requireEnum(filters.type, INSPECTION_TYPES, 'type'));
    where.push(`t.inspection_type = $${values.length}`);
  }
  if (filters.status) {
    values.push(filters.status);
    where.push(`t.status = $${values.length}`);
  }
  const r = await pool.query(
    `SELECT t.*, (SELECT COUNT(*)::int FROM inspection_template_items i WHERE i.template_id = t.id) AS item_count,
            (SELECT COUNT(*)::int FROM inspection_template_items i WHERE i.template_id = t.id AND i.is_critical) AS critical_count
       FROM inspection_templates t ${where.length ? `WHERE ${where.join(' AND ')}` : ''}
      ORDER BY t.inspection_type, t.name, t.version DESC`,
    values,
  );
  return r.rows;
}

export async function getTemplate(id: string) {
  const t = await pool.query('SELECT * FROM inspection_templates WHERE id = $1', [id]);
  if (!t.rows[0]) throw new NotFoundError('Inspection template not found');
  const items = await pool.query('SELECT * FROM inspection_template_items WHERE template_id = $1 ORDER BY seq', [id]);
  return { ...t.rows[0], items: items.rows };
}

export async function createTemplate(input: Record<string, unknown>, user: AuthenticatedUser) {
  const name = requireText(input.name, 'name', 150);
  const inspectionType = requireEnum(input.inspectionType, INSPECTION_TYPES, 'inspectionType');
  const crop = optionalText(input.crop, 'crop', 100);
  const description = optionalText(input.description, 'description', 2000);
  const items = parseItems(input.items);
  return withTransaction(async (client) => {
    const dup = await client.query('SELECT 1 FROM inspection_templates WHERE name = $1', [name]);
    if (dup.rows[0]) throw new ConflictError(`A template called "${name}" already exists — revise it instead`);
    const code = await nextCode(client, 'ITP', 3, false);
    const t = await client.query(
      `INSERT INTO inspection_templates (template_code, name, inspection_type, crop, description, created_by) VALUES ($1, $2, $3, $4, $5, $6) RETURNING *`,
      [code, name, inspectionType, crop, description, user.email],
    );
    await insertItems(client, t.rows[0].id, items);
    await insertAuditLog(client, { entityType: 'inspection_template', entityId: t.rows[0].id, action: 'CREATE', performedBy: user.email, afterState: { ...t.rows[0], items } });
    return t.rows[0];
  });
}

/** A new draft version; the active version keeps being used until the draft is activated. */
export async function reviseTemplate(id: string, input: Record<string, unknown>, user: AuthenticatedUser) {
  return withTransaction(async (client) => {
    const src = await client.query('SELECT * FROM inspection_templates WHERE id = $1', [id]);
    if (!src.rows[0]) throw new NotFoundError('Inspection template not found');
    const draft = await client.query(`SELECT 1 FROM inspection_templates WHERE name = $1 AND status = 'draft'`, [src.rows[0].name]);
    if (draft.rows[0]) throw new ConflictError('A draft revision of this template already exists');
    const max = await client.query<{ v: number }>('SELECT MAX(version)::int AS v FROM inspection_templates WHERE name = $1', [src.rows[0].name]);
    let items: ItemInput[];
    if (input.items !== undefined) items = parseItems(input.items);
    else {
      const old = await client.query('SELECT * FROM inspection_template_items WHERE template_id = $1 ORDER BY seq', [id]);
      items = old.rows.map((o) => ({
        label: o.label,
        itemType: o.item_type,
        unit: o.unit,
        minValue: o.min_value === null ? null : Number(o.min_value),
        maxValue: o.max_value === null ? null : Number(o.max_value),
        isRequired: o.is_required,
        isCritical: o.is_critical,
        guidance: o.guidance,
      }));
    }
    const code = await nextCode(client, 'ITP', 3, false);
    const t = await client.query(
      `INSERT INTO inspection_templates (template_code, name, inspection_type, crop, description, version, created_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *`,
      [code, src.rows[0].name, src.rows[0].inspection_type, src.rows[0].crop, optionalText(input.description, 'description', 2000) ?? src.rows[0].description, max.rows[0].v + 1, user.email],
    );
    await insertItems(client, t.rows[0].id, items);
    await insertAuditLog(client, { entityType: 'inspection_template', entityId: t.rows[0].id, action: 'REVISE', performedBy: user.email, metadata: { from: id } });
    return t.rows[0];
  });
}

export async function activateTemplate(id: string, user: AuthenticatedUser) {
  return withTransaction(async (client) => {
    const t = await client.query('SELECT * FROM inspection_templates WHERE id = $1 FOR UPDATE', [id]);
    const row = t.rows[0];
    if (!row) throw new NotFoundError('Inspection template not found');
    if (row.status !== 'draft') throw new ConflictError(`Only a draft can be activated (this one is ${row.status})`);
    // A specification is a controlled document: whoever wrote the limits
    // does not also put them into force.
    if (row.created_by === user.email) throw new ForbiddenError('A template must be activated by someone other than its author');
    await client.query(`UPDATE inspection_templates SET status = 'retired' WHERE name = $1 AND status = 'active'`, [row.name]);
    const r = await client.query(`UPDATE inspection_templates SET status = 'active', activated_by = $2, activated_at = now() WHERE id = $1 RETURNING *`, [id, user.email]);
    await insertAuditLog(client, { entityType: 'inspection_template', entityId: id, action: 'ACTIVATE', performedBy: user.email });
    return r.rows[0];
  });
}

export async function retireTemplate(id: string, user: AuthenticatedUser) {
  return withTransaction(async (client) => {
    const r = await client.query(`UPDATE inspection_templates SET status = 'retired' WHERE id = $1 AND status <> 'retired' RETURNING *`, [id]);
    if (!r.rows[0]) throw new ConflictError('Template not found or already retired');
    await insertAuditLog(client, { entityType: 'inspection_template', entityId: id, action: 'RETIRE', performedBy: user.email });
    return r.rows[0];
  });
}

// -------------------------------------------------------------- inspections

export function evaluateItem(r: Pick<ResultRow, 'item_type' | 'min_value' | 'max_value' | 'numeric_value' | 'bool_value'>): boolean | null {
  if (r.item_type === 'numeric') {
    if (r.numeric_value === null || r.numeric_value === undefined) return null;
    const v = Number(r.numeric_value);
    if (r.min_value !== null && v < Number(r.min_value)) return false;
    if (r.max_value !== null && v > Number(r.max_value)) return false;
    return true;
  }
  if (r.item_type === 'pass_fail') return r.bool_value === null || r.bool_value === undefined ? null : r.bool_value === true;
  return null;
}

export function overallResult(results: Pick<ResultRow, 'passed' | 'is_critical'>[]): 'pass' | 'conditional' | 'fail' {
  if (results.some((r) => r.passed === false && r.is_critical)) return 'fail';
  if (results.some((r) => r.passed === false)) return 'conditional';
  return 'pass';
}

export interface StartInspectionParams {
  templateId: string;
  subjectType: string;
  subjectId?: string | null;
  subjectLabel?: string | null;
  seedLotId?: string | null;
  locationText?: string | null;
  latitude?: number | null;
  longitude?: number | null;
}

export function parseStartInput(input: Record<string, unknown>): StartInspectionParams {
  const subjectType = requireText(input.subjectType, 'subjectType', 40);
  if (!SUBJECT_TYPE.test(subjectType)) throw new ValidationError('subjectType must be lowercase letters and underscores');
  return {
    templateId: requireUuid(input.templateId, 'templateId'),
    subjectType,
    subjectId: optionalText(input.subjectId, 'subjectId', 64),
    subjectLabel: optionalText(input.subjectLabel, 'subjectLabel', 200),
    seedLotId: optionalUuid(input.seedLotId, 'seedLotId'),
    locationText: optionalText(input.locationText, 'locationText', 200),
    latitude: optionalNumber(input.latitude, 'latitude', { min: -90, max: 90 }),
    longitude: optionalNumber(input.longitude, 'longitude', { min: -180, max: 180 }),
  };
}

/** Starts an inspection inside the caller's transaction (also used by modules that open one automatically). */
export async function startInspectionTx(client: PoolClient, p: StartInspectionParams, user: AuthenticatedUser): Promise<InspectionRow> {
  const t = await client.query('SELECT * FROM inspection_templates WHERE id = $1', [p.templateId]);
  const template = t.rows[0];
  if (!template) throw new NotFoundError('Inspection template not found');
  if (template.status !== 'active') throw new ConflictError(`Template ${template.template_code} is ${template.status}; inspections use an active template`);

  let label = p.subjectLabel ?? null;
  let seedLotId = p.seedLotId ?? null;
  const handler = subjectHandlers.get(p.subjectType);
  if (handler?.resolveSubject) {
    if (!p.subjectId) throw new ValidationError(`subjectId is required for a ${p.subjectType} inspection`);
    const resolved = await handler.resolveSubject(client, p.subjectId);
    label = label ?? resolved.label;
    seedLotId = seedLotId ?? resolved.seedLotId;
  }
  if (!label) throw new ValidationError('subjectLabel is required — say what is being inspected');
  if (seedLotId) await assertSeedLotExists(client, seedLotId);

  const code = await nextCode(client, 'INS', 5, true);
  const ins = await client.query<InspectionRow>(
    `INSERT INTO inspections (inspection_code, template_id, inspection_type, subject_type, subject_id, subject_label, seed_lot_id,
                              location_text, latitude, longitude, inspector_email)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11) RETURNING *`,
    [code, template.id, template.inspection_type, p.subjectType, p.subjectId ?? null, label, seedLotId, p.locationText ?? null, p.latitude ?? null, p.longitude ?? null, user.email],
  );
  // Snapshot the specification into the results, so later template
  // revisions never change what this inspection was judged against.
  await client.query(
    `INSERT INTO inspection_results (inspection_id, template_item_id, label, item_type, unit, min_value, max_value, is_critical)
     SELECT $1, id, label, item_type, unit, min_value, max_value, is_critical FROM inspection_template_items WHERE template_id = $2`,
    [ins.rows[0].id, template.id],
  );
  await insertAuditLog(client, { entityType: 'inspection', entityId: ins.rows[0].id, action: 'START', performedBy: user.email, afterState: ins.rows[0] });
  return ins.rows[0];
}

export async function startInspection(input: Record<string, unknown>, user: AuthenticatedUser) {
  const p = parseStartInput(input);
  return withTransaction((client) => startInspectionTx(client, p, user));
}

async function lockInspection(client: PoolClient, id: string): Promise<InspectionRow> {
  const r = await client.query<InspectionRow>('SELECT * FROM inspections WHERE id = $1 FOR UPDATE', [id]);
  if (!r.rows[0]) throw new NotFoundError('Inspection not found');
  return r.rows[0];
}

function assertInspector(ins: InspectionRow, user: AuthenticatedUser) {
  if (ins.inspector_email !== user.email && user.role !== 'Admin') {
    throw new ForbiddenError(`Only the inspector who started ${ins.inspection_code} can record its results`);
  }
}

export async function recordResults(id: string, input: Record<string, unknown>, user: AuthenticatedUser) {
  const entries = requireArray(input.results, 'results', { min: 1, max: 100 });
  return withTransaction(async (client) => {
    const ins = await lockInspection(client, id);
    if (ins.status !== 'in_progress') throw new ConflictError(`${ins.inspection_code} is already submitted`);
    assertInspector(ins, user);
    const rows = await client.query<ResultRow>('SELECT * FROM inspection_results WHERE inspection_id = $1', [id]);
    const byItem = new Map(rows.rows.map((r) => [r.template_item_id, r]));
    for (const [i, raw] of entries.entries()) {
      const e = asRecord(raw, `results[${i}]`);
      const itemId = requireUuid(e.itemId, `results[${i}].itemId`);
      const row = byItem.get(itemId);
      if (!row) throw new ValidationError(`results[${i}]: that check is not part of this inspection`);
      const numeric = row.item_type === 'numeric' ? optionalNumber(e.numericValue, `${row.label}`) : null;
      const boolValue = row.item_type === 'pass_fail' ? optionalBool(e.boolValue, `${row.label}`) : null;
      const text = row.item_type === 'text' ? optionalText(e.textValue, `${row.label}`, 2000) : null;
      const notes = optionalText(e.notes, `${row.label} notes`, 1000);
      const passed = evaluateItem({ ...row, numeric_value: numeric === null ? null : String(numeric), bool_value: boolValue });
      await client.query(
        `UPDATE inspection_results SET numeric_value = $2, bool_value = $3, text_value = $4, notes = $5, passed = $6 WHERE id = $1`,
        [row.id, numeric, boolValue, text, notes, passed],
      );
    }
    return getInspection(id, client);
  });
}

export async function submitInspection(id: string, input: Record<string, unknown>, user: AuthenticatedUser) {
  const decision = requireEnum(input.decision, DECISIONS, 'decision');
  const acceptedQuantity = optionalNumber(input.acceptedQuantity, 'acceptedQuantity', { min: 0 });
  const decisionNotes = optionalText(input.decisionNotes, 'decisionNotes', 2000);

  return withTransaction(async (client) => {
    const ins = await lockInspection(client, id);
    if (ins.status !== 'in_progress') throw new ConflictError(`${ins.inspection_code} is already submitted`);
    assertInspector(ins, user);

    const items = await client.query<ResultRow & { is_required: boolean }>(
      `SELECT r.*, i.is_required FROM inspection_results r JOIN inspection_template_items i ON i.id = r.template_item_id
        WHERE r.inspection_id = $1 ORDER BY i.seq`,
      [id],
    );
    const missing = items.rows.filter(
      (r) => r.is_required && r.numeric_value === null && r.bool_value === null && (r.text_value === null || r.text_value === ''),
    );
    if (missing.length) throw new ValidationError(`Record every required check before submitting. Missing: ${missing.map((m) => m.label).join(', ')}`);

    const result = overallResult(items.rows);
    if (result === 'fail' && decision === 'accept') {
      throw new ValidationError('A critical check failed, so the lot cannot simply be accepted — choose reject, hold, rework or partial accept');
    }
    if (result !== 'pass' && !decisionNotes) throw new ValidationError('Explain the decision in decisionNotes when any check has failed');
    if (decision === 'partial_accept' && acceptedQuantity === null) throw new ValidationError('acceptedQuantity is required for a partial accept');
    if (decision === 'hold' && !ins.seed_lot_id) throw new ValidationError('A hold needs the inspection to be linked to a seed lot');

    let ncrId: string | null = null;
    const failed = items.rows.filter((r) => r.passed === false);
    // A failed inspection, or any rejection or hold, becomes a tracked
    // non-conformance — the failure is corrected, not just recorded.
    if (result === 'fail' || decision === 'reject' || decision === 'hold') {
      const { ncr } = await insertNcrTx(
        client,
        {
          title: `Inspection ${ins.inspection_code} ${result === 'fail' ? 'failed' : decision === 'hold' ? 'placed on hold' : 'rejected'}: ${ins.subject_label}`.slice(0, 200),
          description: [
            `Inspection ${ins.inspection_code} (${ins.inspection_type.replace(/_/g, ' ')}) of ${ins.subject_label}.`,
            failed.length ? `Failed checks: ${failed.map((f) => `${f.label}${f.numeric_value !== null ? ` = ${num(f.numeric_value)}${f.unit ? ` ${f.unit}` : ''}` : ''}`).join('; ')}.` : 'No individual check failed.',
            `Decision: ${decision.replace('_', ' ')}.`,
            decisionNotes ? `Inspector notes: ${decisionNotes}` : '',
          ]
            .filter(Boolean)
            .join(' '),
          department: DEPARTMENT_FOR_TYPE[ins.inspection_type] ?? 'quality',
          source: 'inspection',
          severity: result === 'fail' ? 'major' : 'minor',
          seedLotId: ins.seed_lot_id,
          assignedTo: null,
          dueDate: null,
        },
        user,
      );
      ncrId = ncr.id;
      if (decision === 'hold' && ins.seed_lot_id) {
        await placeHoldTx(
          client,
          { seedLotId: ins.seed_lot_id, reason: `Inspection ${ins.inspection_code}: ${decisionNotes ?? 'held by inspector'}`, sourceType: 'ncr', sourceId: ncr.id },
          user,
          true,
        );
      }
    }

    const updated = await client.query<InspectionRow>(
      `UPDATE inspections SET status = 'submitted', result = $2, decision = $3, accepted_quantity = $4, decision_notes = $5, ncr_id = $6, submitted_at = now()
        WHERE id = $1 RETURNING *`,
      [id, result, decision, acceptedQuantity, decisionNotes, ncrId],
    );
    await insertAuditLog(client, {
      entityType: 'inspection',
      entityId: id,
      action: 'SUBMIT',
      performedBy: user.email,
      afterState: { result, decision, acceptedQuantity, ncrId, failed: failed.map((f) => f.label) },
    });

    const handler = subjectHandlers.get(ins.subject_type);
    if (handler?.onSubmitted) await handler.onSubmitted(client, updated.rows[0], user);
    return getInspection(id, client);
  });
}

export interface InspectionFilters {
  type?: string;
  status?: string;
  result?: string;
  subjectType?: string;
  subjectId?: string;
  seedLotId?: string;
  mine?: boolean;
}

export async function listInspections(filters: InspectionFilters, user: AuthenticatedUser) {
  const where: string[] = [];
  const values: unknown[] = [];
  const add = (sql: string, v: unknown) => {
    values.push(v);
    where.push(sql.replace('?', `$${values.length}`));
  };
  if (filters.type) add('i.inspection_type = ?', requireEnum(filters.type, INSPECTION_TYPES, 'type'));
  if (filters.status) add('i.status = ?', filters.status);
  if (filters.result) add('i.result = ?', filters.result);
  if (filters.subjectType) add('i.subject_type = ?', filters.subjectType);
  if (filters.subjectId) add('i.subject_id = ?', filters.subjectId);
  if (filters.seedLotId) add('i.seed_lot_id = ?', filters.seedLotId);
  if (filters.mine) add('i.inspector_email = ?', user.email);
  const r = await pool.query(
    `SELECT i.*, t.name AS template_name, t.version AS template_version, l.lot_code, n.ncr_code,
            (SELECT COUNT(*)::int FROM inspection_results x WHERE x.inspection_id = i.id AND x.passed = FALSE) AS failed_checks
       FROM inspections i
       JOIN inspection_templates t ON t.id = i.template_id
       LEFT JOIN seed_lots l ON l.id = i.seed_lot_id
       LEFT JOIN non_conformances n ON n.id = i.ncr_id
       ${where.length ? `WHERE ${where.join(' AND ')}` : ''}
      ORDER BY i.created_at DESC LIMIT 500`,
    values,
  );
  return r.rows;
}

export async function getInspection(id: string, client?: PoolClient) {
  const db = client ?? pool;
  const r = await db.query(
    `SELECT i.*, t.name AS template_name, t.template_code, t.version AS template_version, l.lot_code, n.ncr_code, n.status AS ncr_status
       FROM inspections i
       JOIN inspection_templates t ON t.id = i.template_id
       LEFT JOIN seed_lots l ON l.id = i.seed_lot_id
       LEFT JOIN non_conformances n ON n.id = i.ncr_id
      WHERE i.id = $1`,
    [id],
  );
  if (!r.rows[0]) throw new NotFoundError('Inspection not found');
  const results = await db.query(
    `SELECT r.*, i.seq, i.is_required, i.guidance FROM inspection_results r JOIN inspection_template_items i ON i.id = r.template_item_id
      WHERE r.inspection_id = $1 ORDER BY i.seq`,
    [id],
  );
  const photos = await db.query<{ n: number }>(
    `SELECT COUNT(*)::int AS n FROM attachments WHERE entity_type = 'inspection' AND entity_id = $1 AND deleted_at IS NULL`,
    [id],
  );
  return { ...r.rows[0], results: results.rows, attachment_count: photos.rows[0].n };
}

export async function getInspectionStats() {
  const r = await pool.query(
    `SELECT inspection_type,
            COUNT(*) FILTER (WHERE status = 'in_progress')::int AS in_progress,
            COUNT(*) FILTER (WHERE result = 'pass')::int AS passed,
            COUNT(*) FILTER (WHERE result = 'conditional')::int AS conditional,
            COUNT(*) FILTER (WHERE result = 'fail')::int AS failed
       FROM inspections
      WHERE created_at >= now() - interval '90 days'
      GROUP BY inspection_type ORDER BY inspection_type`,
  );
  return r.rows;
}
