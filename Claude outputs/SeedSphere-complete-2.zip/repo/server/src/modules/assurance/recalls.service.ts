import type { PoolClient } from 'pg';
import { pool } from '../../db/pool';
import { withTransaction } from '../../db/transaction';
import { ConflictError, ForbiddenError, NotFoundError, ValidationError } from '../../errors';
import type { AuthenticatedUser } from '../../middleware/requireAuth';
import { insertAuditLog } from '../auditLogs/auditLogs.service';
import { registerApprovalHandler, submitForApprovalTx } from '../approvals/approvals.service';
import { placeHoldTx } from '../quality/holds.service';
import { queueMessageTx } from '../reach/messaging.service';
import { nextCode, optionalText, requireArray, requireEnum, requireText, requireUuid, round2 } from '../shared/validate';

registerApprovalHandler('recall', {
  onApproved: async (client, id, user) => {
    const recall = (await client.query(`SELECT * FROM recalls WHERE id = $1 FOR UPDATE`, [id])).rows[0];
    await client.query(`UPDATE recalls SET status = 'in_progress', started_at = now() WHERE id = $1`, [id]);
    const lots = (await client.query(`SELECT l.id, l.lot_code, l.crop, l.variety FROM recall_lots rl JOIN seed_lots l ON l.id = rl.seed_lot_id WHERE rl.recall_id = $1`, [id])).rows;
    // Contain first: every recalled lot goes on quality hold so nothing more can be dispatched.
    for (const l of lots) await placeHoldTx(client, { seedLotId: l.id, reason: `Recall ${recall.recall_number}: ${recall.title}`, sourceType: 'manual' }, user, true);
    // Then tell every dealer who received any of them.
    const recips = (await client.query(`SELECT r.id, r.dealer_id, r.seed_lot_id FROM recall_recipients r WHERE r.recall_id = $1`, [id])).rows;
    for (const r of recips) {
      const lot = lots.find((l) => l.id === r.seed_lot_id)!;
      await queueMessageTx(client, { partyId: r.dealer_id, template: 'recall_notice', vars: { lot: lot.lot_code, crop: lot.crop, variety: lot.variety, action: recall.action_required }, relatedType: 'recall', relatedId: id, createdBy: user.email });
      await client.query(`UPDATE recall_recipients SET notified_at = now() WHERE id = $1`, [r.id]);
    }
    await insertAuditLog(client, { entityType: 'recall', entityId: id, action: 'START', performedBy: user.email, metadata: { lots: lots.length, dealers: recips.length } });
  },
  onRejected: async (client, id, _u, comment) => void (await client.query(`UPDATE recalls SET status = 'rejected', rejection_reason = $2 WHERE id = $1`, [id, comment])),
});

export async function createRecall(input: Record<string, unknown>, user: AuthenticatedUser) {
  const lotIds = [...new Set(requireArray(input.lotIds, 'lotIds', { min: 1, max: 50 }).map((v, i) => requireUuid(v, `lotIds[${i}]`)))];
  return withTransaction(async (client) => {
    const found = await client.query(`SELECT id FROM seed_lots WHERE id = ANY($1::uuid[])`, [lotIds]);
    if (found.rowCount !== lotIds.length) throw new ValidationError('One or more seed lots were not found');
    const complaintId = input.complaintId ? requireUuid(input.complaintId, 'complaintId') : null;
    const code = await nextCode(client, 'RCL', 4, true);
    const r = (await client.query(
      `INSERT INTO recalls (recall_number, title, reason, recall_class, action_required, complaint_id, created_by) VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
      [code, requireText(input.title, 'title', 200), requireText(input.reason, 'reason', 3000), requireEnum(input.recallClass, ['I', 'II', 'III'] as const, 'recallClass'), requireText(input.actionRequired, 'actionRequired', 500), complaintId, user.email],
    )).rows[0];
    for (const id of lotIds) await client.query(`INSERT INTO recall_lots (recall_id, seed_lot_id) VALUES ($1,$2)`, [r.id, id]);
    await insertAuditLog(client, { entityType: 'recall', entityId: r.id, action: 'CREATE', performedBy: user.email, afterState: r });
    return r;
  });
}

/** Everyone who was sent a recalled lot — from the shipped dispatch lines, not from memory. */
export async function trace(lotIds: string[], db: Pick<PoolClient, 'query'> = pool) {
  const r = await db.query(
    `SELECT d.dealer_id, p.name AS dealer_name, p.phone, dl.seed_lot_id, l.lot_code, SUM(dl.quantity_kg)::float AS dispatched_kg, MIN(d.dispatched_at) AS first_shipped
       FROM wh_dispatch_lines dl JOIN wh_dispatches d ON d.id = dl.dispatch_id JOIN parties p ON p.id = d.dealer_id JOIN seed_lots l ON l.id = dl.seed_lot_id
      WHERE dl.seed_lot_id = ANY($1::uuid[]) AND d.status IN ('dispatched', 'delivered')
      GROUP BY d.dealer_id, p.name, p.phone, dl.seed_lot_id, l.lot_code ORDER BY p.name`,
    [lotIds],
  );
  return r.rows;
}

export async function traceForRecall(id: string) {
  const lots = (await pool.query(`SELECT seed_lot_id FROM recall_lots WHERE recall_id = $1`, [id])).rows.map((r) => r.seed_lot_id);
  return trace(lots);
}

export async function submitRecall(id: string, user: AuthenticatedUser) {
  return withTransaction(async (client) => {
    const r = (await client.query(`SELECT * FROM recalls WHERE id = $1 FOR UPDATE`, [id])).rows[0];
    if (!r) throw new NotFoundError('Recall not found');
    if (!['draft', 'rejected'].includes(r.status)) throw new ConflictError(`${r.recall_number} is ${r.status}`);
    const lots = (await client.query(`SELECT seed_lot_id FROM recall_lots WHERE recall_id = $1`, [id])).rows.map((x) => x.seed_lot_id);
    await client.query(`DELETE FROM recall_recipients WHERE recall_id = $1`, [id]);
    for (const t of await trace(lots, client)) {
      await client.query(`INSERT INTO recall_recipients (recall_id, dealer_id, seed_lot_id, dispatched_kg) VALUES ($1,$2,$3,$4)`, [id, t.dealer_id, t.seed_lot_id, t.dispatched_kg]);
    }
    await client.query(`UPDATE recalls SET status = 'pending_approval', rejection_reason = NULL WHERE id = $1`, [id]);
    await submitForApprovalTx(client, { entityType: 'recall', entityId: id, entityCode: r.recall_number, title: `Recall ${r.recall_number} (class ${r.recall_class}): ${r.title}` }, user);
    return (await client.query(`SELECT * FROM recalls WHERE id = $1`, [id])).rows[0];
  });
}

async function effectiveness(id: string) {
  const r = await pool.query(
    `SELECT COALESCE(SUM(rr.dispatched_kg),0)::float AS dispatched_kg,
            COUNT(*)::int AS recipients, COUNT(rr.acknowledged_at)::int AS acknowledged,
            COALESCE((SELECT SUM(w.quantity_kg) FROM wh_returns w JOIN recalls rc ON rc.id = $1 WHERE w.seed_lot_id IN (SELECT seed_lot_id FROM recall_lots WHERE recall_id = $1)
                       AND w.created_at >= COALESCE(rc.started_at, rc.created_at)),0)::float AS returned_kg
       FROM recall_recipients rr WHERE rr.recall_id = $1`,
    [id],
  );
  const e = r.rows[0];
  return { ...e, returnedPct: e.dispatched_kg ? round2((e.returned_kg / e.dispatched_kg) * 100) : null, acknowledgedPct: e.recipients ? round2((e.acknowledged / e.recipients) * 100) : null };
}

export async function listRecalls() {
  const rows = (await pool.query(
    `SELECT r.*, (SELECT COUNT(*)::int FROM recall_lots WHERE recall_id = r.id) AS lot_count,
            (SELECT COUNT(*)::int FROM recall_recipients WHERE recall_id = r.id) AS recipient_count,
            (SELECT COUNT(*)::int FROM recall_recipients WHERE recall_id = r.id AND acknowledged_at IS NOT NULL) AS acknowledged_count
       FROM recalls r ORDER BY r.created_at DESC LIMIT 200`,
  )).rows;
  return rows;
}

export async function getRecall(id: string) {
  const r = (await pool.query(`SELECT * FROM recalls WHERE id = $1`, [id])).rows[0];
  if (!r) throw new NotFoundError('Recall not found');
  const [lots, recipients, eff] = await Promise.all([
    pool.query(`SELECT l.id, l.lot_code, l.crop, l.variety, l.quantity_total::float AS quantity_total FROM recall_lots rl JOIN seed_lots l ON l.id = rl.seed_lot_id WHERE rl.recall_id = $1`, [id]),
    pool.query(`SELECT rr.*, p.name AS dealer_name, l.lot_code, rr.dispatched_kg::float AS dispatched_kg FROM recall_recipients rr JOIN parties p ON p.id = rr.dealer_id JOIN seed_lots l ON l.id = rr.seed_lot_id WHERE rr.recall_id = $1 ORDER BY p.name`, [id]),
    effectiveness(id),
  ]);
  return { ...r, lots: lots.rows, recipients: recipients.rows, effectiveness: eff };
}

export async function acknowledge(recipientId: string, input: Record<string, unknown>, user: AuthenticatedUser, asDealer: boolean) {
  return withTransaction(async (client) => {
    const rr = (await client.query(`SELECT rr.*, r.status FROM recall_recipients rr JOIN recalls r ON r.id = rr.recall_id WHERE rr.id = $1 FOR UPDATE OF rr`, [recipientId])).rows[0];
    if (!rr) throw new NotFoundError('Recall notice not found');
    if (asDealer) {
      const p = (await client.query(`SELECT id FROM parties WHERE user_id = $1`, [user.id])).rows[0];
      if (!p || p.id !== rr.dealer_id) throw new ForbiddenError('This recall notice is not addressed to you');
    }
    if (rr.status !== 'in_progress') throw new ConflictError('This recall is not active');
    if (rr.acknowledged_at) return rr;
    const r = await client.query(
      `UPDATE recall_recipients SET acknowledged_at = now(), acknowledged_by = $2, ack_note = $3 WHERE id = $1 RETURNING *`,
      [recipientId, user.email, optionalText(input.note, 'note', 500)],
    );
    await insertAuditLog(client, { entityType: 'recall', entityId: rr.recall_id, action: 'ACKNOWLEDGE', performedBy: user.email, metadata: { recipientId, onBehalf: !asDealer } });
    return r.rows[0];
  });
}

export async function dealerRecalls(user: AuthenticatedUser) {
  const p = (await pool.query(`SELECT id FROM parties WHERE user_id = $1`, [user.id])).rows[0];
  if (!p) return [];
  const r = await pool.query(
    `SELECT rr.id, rr.acknowledged_at, rr.dispatched_kg::float AS dispatched_kg, l.lot_code, l.crop, l.variety, r.recall_number, r.title, r.action_required, r.recall_class, r.started_at
       FROM recall_recipients rr JOIN recalls r ON r.id = rr.recall_id JOIN seed_lots l ON l.id = rr.seed_lot_id
      WHERE rr.dealer_id = $1 AND r.status IN ('in_progress', 'closed') ORDER BY r.started_at DESC`,
    [p.id],
  );
  return r.rows;
}

export async function closeRecall(id: string, input: Record<string, unknown>, user: AuthenticatedUser) {
  const note = requireText(input.closureNote, 'closureNote', 2000);
  return withTransaction(async (client) => {
    const r = (await client.query(`SELECT * FROM recalls WHERE id = $1 FOR UPDATE`, [id])).rows[0];
    if (!r) throw new NotFoundError('Recall not found');
    if (r.status !== 'in_progress') throw new ConflictError('Only a recall in progress can be closed');
    const open = await client.query(`SELECT p.name, l.lot_code FROM recall_recipients rr JOIN parties p ON p.id = rr.dealer_id JOIN seed_lots l ON l.id = rr.seed_lot_id WHERE rr.recall_id = $1 AND rr.acknowledged_at IS NULL`, [id]);
    if (open.rowCount && input.acceptUnacknowledged !== true) {
      throw new ConflictError(`${open.rowCount} dealer(s) have not acknowledged: ${open.rows.slice(0, 5).map((o) => `${o.name} (${o.lot_code})`).join(', ')}. Chase them, or close with acceptUnacknowledged.`);
    }
    const u = await client.query(`UPDATE recalls SET status = 'closed', closure_note = $2, closed_at = now() WHERE id = $1 RETURNING *`, [id, note]);
    await insertAuditLog(client, { entityType: 'recall', entityId: id, action: 'CLOSE', performedBy: user.email, metadata: { unacknowledged: open.rowCount } });
    return u.rows[0];
  });
}
