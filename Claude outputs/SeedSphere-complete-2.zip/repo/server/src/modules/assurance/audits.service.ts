import { pool } from '../../db/pool';
import { withTransaction } from '../../db/transaction';
import { ConflictError, NotFoundError } from '../../errors';
import type { AuthenticatedUser } from '../../middleware/requireAuth';
import { insertAuditLog } from '../auditLogs/auditLogs.service';
import { insertNcrTx } from '../quality/ncr.service';
import { nextCode, optionalDate, optionalText, optionalUuid, requireDate, requireEnum, requireText } from '../shared/validate';

const TYPES = ['internal', 'dealer', 'supplier', 'grower_field', 'certification', 'regulatory'] as const;
const FINDING_SEVERITY = ['observation', 'minor', 'major', 'critical'] as const;

export async function createAudit(input: Record<string, unknown>, user: AuthenticatedUser) {
  return withTransaction(async (client) => {
    const r = (await client.query(
      `INSERT INTO audits (audit_number, audit_type, title, auditee, party_id, scheduled_date, lead_auditor, created_by) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
      [await nextCode(client, 'AUD', 4, true), requireEnum(input.auditType, TYPES, 'auditType'), requireText(input.title, 'title', 200), requireText(input.auditee, 'auditee', 200), optionalUuid(input.partyId, 'partyId'),
        requireDate(input.scheduledDate, 'scheduledDate'), requireText(input.leadAuditor, 'leadAuditor', 150), user.email],
    )).rows[0];
    await insertAuditLog(client, { entityType: 'audit', entityId: r.id, action: 'CREATE', performedBy: user.email, afterState: r });
    return r;
  });
}

export async function listAudits() {
  return (await pool.query(
    `SELECT a.*, (SELECT COUNT(*)::int FROM audit_findings f WHERE f.audit_id = a.id) AS finding_count,
            (SELECT COUNT(*)::int FROM audit_findings f WHERE f.audit_id = a.id AND f.status = 'open') AS open_findings
       FROM audits a ORDER BY a.scheduled_date DESC LIMIT 300`,
  )).rows;
}

export async function getAudit(id: string) {
  const a = (await pool.query(`SELECT * FROM audits WHERE id = $1`, [id])).rows[0];
  if (!a) throw new NotFoundError('Audit not found');
  const f = await pool.query(`SELECT f.*, n.ncr_code, n.status AS ncr_status FROM audit_findings f LEFT JOIN non_conformances n ON n.id = f.ncr_id WHERE f.audit_id = $1 ORDER BY f.finding_no`, [id]);
  return { ...a, findings: f.rows };
}

async function lock(client: import('pg').PoolClient, id: string) {
  const a = (await client.query(`SELECT * FROM audits WHERE id = $1 FOR UPDATE`, [id])).rows[0];
  if (!a) throw new NotFoundError('Audit not found');
  return a;
}

export async function startAudit(id: string, user: AuthenticatedUser) {
  return withTransaction(async (client) => {
    const a = await lock(client, id);
    if (a.status !== 'planned') throw new ConflictError(`${a.audit_number} is ${a.status}`);
    const r = await client.query(`UPDATE audits SET status = 'in_progress' WHERE id = $1 RETURNING *`, [id]);
    await insertAuditLog(client, { entityType: 'audit', entityId: id, action: 'START', performedBy: user.email });
    return r.rows[0];
  });
}

/** A major or critical finding opens an NCR straight away, so it enters the normal corrective-action pipeline. */
export async function addFinding(id: string, input: Record<string, unknown>, user: AuthenticatedUser) {
  const severity = requireEnum(input.severity, FINDING_SEVERITY, 'severity');
  const description = requireText(input.description, 'description', 3000);
  return withTransaction(async (client) => {
    const a = await lock(client, id);
    if (a.status !== 'in_progress') throw new ConflictError('Findings can be added only while the audit is in progress');
    const no = (await client.query(`SELECT COALESCE(MAX(finding_no),0)+1 AS n FROM audit_findings WHERE audit_id = $1`, [id])).rows[0].n;
    let ncrId: string | null = null;
    if (severity === 'major' || severity === 'critical') {
      const { ncr } = await insertNcrTx(client, { title: `${a.audit_number} finding ${no}: ${description.slice(0, 80)}`, description: `Raised from ${a.audit_number} (${a.title}, ${a.auditee}).\n\n${description}`, department: 'quality', source: 'internal_audit', severity, seedLotId: null, assignedTo: null, dueDate: null, complaintId: null }, user);
      ncrId = ncr.id;
    }
    const r = await client.query(`INSERT INTO audit_findings (audit_id, finding_no, description, severity, ncr_id) VALUES ($1,$2,$3,$4,$5) RETURNING *`, [id, no, description, severity, ncrId]);
    return r.rows[0];
  });
}

export async function closeFinding(auditId: string, findingId: string, input: Record<string, unknown>, user: AuthenticatedUser) {
  const note = requireText(input.closureNote, 'closureNote', 2000);
  return withTransaction(async (client) => {
    const f = (await client.query(`SELECT f.*, n.status AS ncr_status, n.ncr_code FROM audit_findings f LEFT JOIN non_conformances n ON n.id = f.ncr_id WHERE f.id = $1 AND f.audit_id = $2 FOR UPDATE OF f`, [findingId, auditId])).rows[0];
    if (!f) throw new NotFoundError('Finding not found');
    if (f.status === 'closed') throw new ConflictError('Finding already closed');
    if (f.ncr_id && !['closed', 'cancelled'].includes(f.ncr_status)) throw new ConflictError(`Close ${f.ncr_code} (raised from this finding) first`);
    return (await client.query(`UPDATE audit_findings SET status = 'closed', closure_note = $2, closed_by = $3, closed_at = now() WHERE id = $1 RETURNING *`, [findingId, note, user.email])).rows[0];
  });
}

export async function completeAudit(id: string, input: Record<string, unknown>, user: AuthenticatedUser) {
  const summary = requireText(input.summary, 'summary', 3000);
  return withTransaction(async (client) => {
    const a = await lock(client, id);
    if (a.status !== 'in_progress') throw new ConflictError('Only an audit in progress can be completed');
    const r = await client.query(`UPDATE audits SET status = 'completed', summary = $2, completed_at = now() WHERE id = $1 RETURNING *`, [id, summary]);
    await insertAuditLog(client, { entityType: 'audit', entityId: id, action: 'COMPLETE', performedBy: user.email });
    return r.rows[0];
  });
}

export async function closeAudit(id: string, user: AuthenticatedUser) {
  return withTransaction(async (client) => {
    const a = await lock(client, id);
    if (a.status !== 'completed') throw new ConflictError('Complete the audit before closing it');
    const open = (await client.query(`SELECT COUNT(*)::int AS n FROM audit_findings WHERE audit_id = $1 AND status = 'open'`, [id])).rows[0].n;
    if (open) throw new ConflictError(`${open} finding(s) are still open`);
    const r = await client.query(`UPDATE audits SET status = 'closed', closed_at = now() WHERE id = $1 RETURNING *`, [id]);
    await insertAuditLog(client, { entityType: 'audit', entityId: id, action: 'CLOSE', performedBy: user.email });
    return r.rows[0];
  });
}
void optionalDate; void optionalText;
