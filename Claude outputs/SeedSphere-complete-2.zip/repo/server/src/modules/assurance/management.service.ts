import { pool } from '../../db/pool';
import { ValidationError } from '../../errors';
import { matrix } from './training.service';

const one = async (sql: string, params: unknown[] = []) => (await pool.query(sql, params)).rows[0];

/** One read across every module — the numbers a manager looks at on Monday morning. */
export async function dashboard() {
  const [approvals, procurement, grower, processing, stock, holds, breaches, dispatch, ncr, complaints, recalls, audits, rd, tags, msgs, training] = await Promise.all([
    one(`SELECT COUNT(*)::int AS pending, COUNT(*) FILTER (WHERE requested_at < now() - interval '3 days')::int AS stale FROM approval_requests WHERE status = 'pending'`),
    one(`SELECT (SELECT COUNT(*)::int FROM proc_requisitions WHERE status = 'pending_approval') AS requisitions_pending,
                (SELECT COUNT(*)::int FROM proc_purchase_orders WHERE status = 'pending_approval') AS orders_pending,
                (SELECT COUNT(*)::int FROM proc_invoices WHERE status IN ('received','pending_approval','approved')) AS invoices_open`),
    one(`SELECT (SELECT COUNT(*)::int FROM grw_agreements WHERE status = 'active') AS active_agreements,
                (SELECT COUNT(*)::int FROM grw_deliveries WHERE status = 'awaiting_inspection') AS deliveries_awaiting_inspection`),
    one(`SELECT (SELECT COUNT(*)::int FROM prc_batches WHERE status = 'in_progress') AS batches_running,
                (SELECT COUNT(*)::int FROM prc_batches WHERE status = 'completed' AND completed_at > now() - interval '30 days') AS batches_completed_30d,
                (SELECT COALESCE(SUM(output_kg),0)::float FROM prc_batches WHERE status = 'completed' AND completed_at > now() - interval '30 days') AS output_kg_30d`),
    one(`SELECT COALESCE(SUM(quantity_kg),0)::float AS on_hand_kg, COUNT(DISTINCT seed_lot_id)::int AS lots FROM wh_stock_moves`),
    one(`SELECT COUNT(*)::int AS active FROM quality_lot_holds WHERE released_at IS NULL`),
    one(`SELECT COUNT(*)::int AS open FROM wh_sensor_breaches WHERE ended_at IS NULL`),
    one(`SELECT COUNT(*) FILTER (WHERE status = 'pending_approval')::int AS awaiting_approval, COUNT(*) FILTER (WHERE status IN ('dispatched','delivered') AND dispatched_at > now() - interval '30 days')::int AS shipped_30d FROM wh_dispatches`),
    one(`SELECT COUNT(*) FILTER (WHERE status IN ('open','investigating'))::int AS open, COUNT(*) FILTER (WHERE status IN ('open','investigating') AND severity = 'critical')::int AS critical FROM non_conformances`),
    one(`SELECT COUNT(*) FILTER (WHERE status IN ('received','investigating'))::int AS open, COUNT(*) FILTER (WHERE received_date > CURRENT_DATE - 30)::int AS last_30d, COUNT(*) FILTER (WHERE channel = 'public_form' AND received_date > CURRENT_DATE - 30)::int AS farmer_form_30d FROM quality_complaints`),
    one(`SELECT COUNT(*) FILTER (WHERE status = 'in_progress')::int AS active, COUNT(*) FILTER (WHERE status = 'pending_approval')::int AS awaiting_approval FROM recalls`),
    one(`SELECT COUNT(*) FILTER (WHERE status IN ('planned','in_progress','completed'))::int AS open, (SELECT COUNT(*)::int FROM audit_findings WHERE status = 'open') AS open_findings FROM audits`),
    one(`SELECT (SELECT COUNT(*)::int FROM rd_trials WHERE status = 'running') AS trials_running, (SELECT COUNT(*)::int FROM rd_candidates WHERE stage NOT IN ('released','dropped')) AS candidates_active, (SELECT COUNT(*)::int FROM rd_candidates WHERE stage = 'released') AS released`),
    one(`SELECT COUNT(*)::int AS scans_30d, COUNT(*) FILTER (WHERE result IN ('caution','not_found','void'))::int AS suspicious_30d FROM seed_tag_scans WHERE scanned_at > now() - interval '30 days'`),
    one(`SELECT COUNT(*) FILTER (WHERE status = 'queued')::int AS queued, COUNT(*) FILTER (WHERE status = 'failed')::int AS failed FROM msg_outbox`),
    matrix(),
  ]);
  const attention: { level: 'critical' | 'warning'; text: string; link: string }[] = [];
  if (ncr.critical) attention.push({ level: 'critical', text: `${ncr.critical} critical non-conformance(s) open`, link: '/quality/ncrs' });
  if (recalls.active) attention.push({ level: 'critical', text: `${recalls.active} recall(s) in progress`, link: '/quality/recalls' });
  if (breaches.open) attention.push({ level: 'critical', text: `${breaches.open} storage sensor(s) out of range`, link: '/warehouse/iot' });
  if (approvals.stale) attention.push({ level: 'warning', text: `${approvals.stale} approval(s) waiting more than 3 days`, link: '/approvals' });
  if (holds.active) attention.push({ level: 'warning', text: `${holds.active} seed lot(s) on quality hold`, link: '/quality/holds' });
  if (tags.suspicious_30d) attention.push({ level: 'warning', text: `${tags.suspicious_30d} suspicious pack-tag scan(s) in 30 days`, link: '/warehouse/tags' });
  if (msgs.failed) attention.push({ level: 'warning', text: `${msgs.failed} message(s) failed to send`, link: '/admin/messages' });
  if (training.counts.expired) attention.push({ level: 'warning', text: `${training.counts.expired} training certificate(s) expired`, link: '/quality/training' });
  return {
    generatedAt: new Date().toISOString(), attention,
    approvals, procurement, grower, processing, warehouse: { ...stock, holds: holds.active, sensorBreaches: breaches.open, ...dispatch },
    quality: { ncr, complaints, recalls, audits }, rd, reach: { tags, messages: msgs }, training: { compliancePct: training.compliancePct, counts: training.counts },
  };
}

// ---------------------------------------------------------------- SATHI exports
const esc = (v: unknown) => {
  if (v === null || v === undefined) return '';
  const s = v instanceof Date ? v.toISOString().slice(0, 10) : String(v);
  const safe = /^[=+\-@]/.test(s) ? `'${s}` : s; // stop spreadsheet formula injection
  return /[",\n]/.test(safe) ? `"${safe.replace(/"/g, '""')}"` : safe;
};
const toCsv = (cols: string[], rows: Record<string, unknown>[]) => [cols.join(','), ...rows.map((r) => cols.map((c) => esc(r[c])).join(','))].join('\r\n');

/**
 * Registers kept in the layout a seed company needs for the national SATHI seed
 * traceability portal. NOTE: the column set follows our reading of SATHI's
 * traceability fields and must be checked against the portal's current upload
 * template before the first real submission.
 */
export async function sathiExport(kind: string, range: { from?: string; to?: string }) {
  const from = range.from ?? '1900-01-01';
  const to = range.to ?? '2999-12-31';
  if (!/^\d{4}-\d{2}-\d{2}$/.test(from) || !/^\d{4}-\d{2}-\d{2}$/.test(to)) throw new ValidationError('from/to must be YYYY-MM-DD');
  if (kind === 'lots') {
    const cols = ['lot_number', 'crop', 'variety', 'seed_class', 'production_date', 'quantity_kg', 'germination_pct', 'test_date', 'test_valid_until', 'lab_report_number', 'quality_status'];
    const r = await pool.query(
      `SELECT l.lot_code AS lot_number, l.crop, l.variety, l.stage AS seed_class, l.production_date, l.quantity_total AS quantity_kg,
              t.germination_pct, t.tested_on AS test_date, t.valid_until AS test_valid_until, t.report_number AS lab_report_number,
              CASE WHEN h.id IS NOT NULL THEN 'on_hold' ELSE 'released' END AS quality_status
         FROM seed_lots l
         LEFT JOIN LATERAL (SELECT * FROM wh_lot_tests WHERE seed_lot_id = l.id ORDER BY tested_on DESC, recorded_at DESC LIMIT 1) t ON TRUE
         LEFT JOIN quality_lot_holds h ON h.seed_lot_id = l.id AND h.released_at IS NULL
        WHERE COALESCE(l.production_date, l.created_at::date) BETWEEN $1 AND $2 ORDER BY l.lot_code`, [from, to]);
    return { filename: 'sathi_lot_register.csv', csv: toCsv(cols, r.rows), rows: r.rowCount };
  }
  if (kind === 'sales') {
    const cols = ['dispatch_number', 'dispatch_date', 'lot_number', 'crop', 'variety', 'quantity_kg', 'dealer_name', 'dealer_licence_number', 'dealer_village', 'dealer_district', 'dealer_state', 'vehicle_number', 'invoice_reference'];
    const r = await pool.query(
      `SELECT d.dispatch_number, d.dispatched_at::date AS dispatch_date, l.lot_code AS lot_number, l.crop, l.variety, dl.quantity_kg,
              p.name AS dealer_name, p.licence_number AS dealer_licence_number, p.village AS dealer_village, p.district AS dealer_district, p.state AS dealer_state, d.vehicle_number, d.invoice_reference
         FROM wh_dispatch_lines dl JOIN wh_dispatches d ON d.id = dl.dispatch_id JOIN seed_lots l ON l.id = dl.seed_lot_id JOIN parties p ON p.id = d.dealer_id
        WHERE d.status IN ('dispatched','delivered') AND d.dispatched_at::date BETWEEN $1 AND $2 ORDER BY d.dispatched_at, d.dispatch_number`, [from, to]);
    return { filename: 'sathi_sales_register.csv', csv: toCsv(cols, r.rows), rows: r.rowCount };
  }
  if (kind === 'tags') {
    const cols = ['tag_code', 'lot_number', 'crop', 'variety', 'pack_size_kg', 'status', 'created_on', 'dispatch_number'];
    const r = await pool.query(
      `SELECT t.tag_code, l.lot_code AS lot_number, l.crop, l.variety, t.pack_size_kg, t.status, t.created_at::date AS created_on, d.dispatch_number
         FROM seed_tags t JOIN seed_lots l ON l.id = t.seed_lot_id LEFT JOIN wh_dispatches d ON d.id = t.dispatch_id
        WHERE t.created_at::date BETWEEN $1 AND $2 ORDER BY t.created_at, t.tag_code`, [from, to]);
    return { filename: 'sathi_tag_register.csv', csv: toCsv(cols, r.rows), rows: r.rowCount };
  }
  throw new ValidationError('kind must be lots, sales or tags');
}
