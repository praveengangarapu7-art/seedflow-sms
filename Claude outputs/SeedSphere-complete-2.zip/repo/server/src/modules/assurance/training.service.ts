import { pool } from '../../db/pool';
import { withTransaction } from '../../db/transaction';
import { ConflictError, NotFoundError, ValidationError } from '../../errors';
import type { AuthenticatedUser } from '../../middleware/requireAuth';
import { nextCode, optionalNumber, optionalText, requireArray, requireDate, requireText, requireUuid, optionalBool } from '../shared/validate';

export async function createCourse(input: Record<string, unknown>, user: AuthenticatedUser) {
  const roles = requireArray(input.requiredFor ?? [], 'requiredFor', { min: 0, max: 30 }).map((r) => requireText(r, 'requiredFor', 50));
  const months = optionalNumber(input.validityMonths, 'validityMonths', { min: 1, max: 120 });
  return withTransaction(async (client) => {
    return (await client.query(
      `INSERT INTO training_courses (course_code, title, required_for, validity_months, created_by) VALUES ($1,$2,$3,$4,$5) RETURNING *`,
      [await nextCode(client, 'TRN', 3, false), requireText(input.title, 'title', 200), roles, months, user.email],
    )).rows[0];
  });
}

export async function listCourses() {
  return (await pool.query(`SELECT * FROM training_courses WHERE is_active ORDER BY course_code`)).rows;
}

export async function recordTraining(input: Record<string, unknown>, user: AuthenticatedUser) {
  const courseId = requireUuid(input.courseId, 'courseId');
  const userIds = requireArray(input.userIds, 'userIds', { min: 1, max: 200 }).map((v, i) => requireUuid(v, `userIds[${i}]`));
  const completedOn = requireDate(input.completedOn, 'completedOn');
  if (completedOn > new Date().toISOString().slice(0, 10)) throw new ValidationError('completedOn cannot be in the future');
  const passed = optionalBool(input.passed, 'passed') ?? true;
  return withTransaction(async (client) => {
    if (!(await client.query(`SELECT 1 FROM training_courses WHERE id = $1`, [courseId])).rows[0]) throw new NotFoundError('Course not found');
    const users = await client.query(`SELECT id FROM users WHERE id = ANY($1::uuid[]) AND is_active`, [userIds]);
    if (users.rowCount !== userIds.length) throw new ValidationError('One or more staff members were not found');
    for (const uid of userIds) {
      await client.query(
        `INSERT INTO training_records (course_id, user_id, completed_on, trainer, score, passed, note, recorded_by) VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`,
        [courseId, uid, completedOn, optionalText(input.trainer, 'trainer', 150), optionalNumber(input.score, 'score', { min: 0, max: 100 }), passed, optionalText(input.note, 'note', 500), user.email],
      );
    }
    return { recorded: userIds.length };
  });
}

export async function updateCourse(id: string, input: Record<string, unknown>) {
  const r = await pool.query(`UPDATE training_courses SET is_active = COALESCE($2, is_active) WHERE id = $1 RETURNING *`, [id, optionalBool(input.isActive, 'isActive')]);
  if (!r.rows[0]) throw new NotFoundError('Course not found');
  return r.rows[0];
}

/** Competency matrix: for each staff member and each course required for their job role, whether they are current. */
export async function matrix() {
  const courses = (await pool.query(`SELECT * FROM training_courses WHERE is_active ORDER BY course_code`)).rows;
  const staff = (await pool.query(`SELECT id, name, email, job_role FROM users WHERE is_active AND job_role IS NOT NULL AND job_role NOT IN ('grower','dealer') ORDER BY name`)).rows;
  const recs = (await pool.query(`SELECT user_id, course_id, MAX(completed_on) AS last FROM training_records WHERE passed GROUP BY user_id, course_id`)).rows;
  const today = new Date();
  const rows = staff.map((u) => ({
    userId: u.id, name: u.name, jobRole: u.job_role,
    cells: courses.filter((c) => c.required_for.includes(u.job_role) || c.required_for.includes('*')).map((c) => {
      const rec = recs.find((x) => x.user_id === u.id && x.course_id === c.id);
      let status: 'compliant' | 'expiring' | 'expired' | 'missing' = 'missing';
      let dueOn: string | null = null;
      if (rec) {
        const last = new Date(rec.last);
        if (c.validity_months) {
          const due = new Date(last); due.setMonth(due.getMonth() + c.validity_months);
          dueOn = due.toISOString().slice(0, 10);
          const days = Math.floor((due.getTime() - today.getTime()) / 86400000);
          status = days < 0 ? 'expired' : days <= 30 ? 'expiring' : 'compliant';
        } else status = 'compliant';
      }
      return { courseId: c.id, courseCode: c.course_code, status, lastCompleted: rec ? new Date(rec.last).toISOString().slice(0, 10) : null, dueOn };
    }),
  })).filter((r) => r.cells.length);
  const all = rows.flatMap((r) => r.cells);
  const ok = all.filter((c) => c.status === 'compliant' || c.status === 'expiring').length;
  return { courses, rows, compliancePct: all.length ? Math.round((ok / all.length) * 100) : null, counts: { compliant: all.filter((c) => c.status === 'compliant').length, expiring: all.filter((c) => c.status === 'expiring').length, expired: all.filter((c) => c.status === 'expired').length, missing: all.filter((c) => c.status === 'missing').length } };
}
void ConflictError;
