import type { PoolClient } from 'pg';
import { pool } from '../../db/pool';
import { withTransaction } from '../../db/transaction';
import { ConflictError, NotFoundError, ValidationError } from '../../errors';
import type { AuthenticatedUser } from '../../middleware/requireAuth';
import { insertAuditLog } from '../auditLogs/auditLogs.service';
import { registerApprovalHandler, submitForApprovalTx } from '../approvals/approvals.service';
import { asRecord, nextCode, num, optionalNumber, optionalText, requireArray, requireEnum, requireNumber, requireText, requireUuid, round2 } from '../shared/validate';

const STAGES = ['candidate', 'multi_location', 'pre_release', 'released'] as const;

// ------------------------------------------------------------------ approval handlers
registerApprovalHandler('trial_protocol', {
  onApproved: async (client, id) => void (await client.query(`UPDATE rd_trials SET status = 'approved' WHERE id = $1`, [id])),
  onRejected: async (client, id, _u, comment) => void (await client.query(`UPDATE rd_trials SET status = 'rejected', rejection_reason = $2 WHERE id = $1`, [id, comment])),
});

async function applyAdvancement(client: PoolClient, advId: string, user: AuthenticatedUser) {
  const adv = (await client.query(`SELECT * FROM rd_advancements WHERE id = $1 FOR UPDATE`, [advId])).rows[0];
  const cand = (await client.query(`SELECT * FROM rd_candidates WHERE id = $1 FOR UPDATE`, [adv.candidate_id])).rows[0];
  await client.query(`UPDATE rd_advancements SET status = 'approved' WHERE id = $1`, [advId]);
  let varietyId = cand.variety_id;
  if (adv.to_stage === 'released') {
    const existing = await client.query(`SELECT id FROM varieties WHERE crop = $1 AND variety_name = $2`, [cand.crop, cand.name]);
    varietyId = existing.rows[0]?.id;
    if (!varietyId) {
      const ins = await client.query(
        `INSERT INTO varieties (crop, variety_name, botanical_name, status, created_by) VALUES ($1, $2, $3, 'approved', $4) RETURNING id`,
        [cand.crop, cand.name, cand.botanical_name, user.email],
      );
      varietyId = ins.rows[0].id;
    }
    await client.query(`UPDATE rd_variety_specs SET status = 'handed_over', handed_over_at = now(), handed_over_by = $2 WHERE candidate_id = $1`, [cand.id, user.email]);
  }
  await client.query(`UPDATE rd_candidates SET stage = $2, variety_id = $3 WHERE id = $1`, [cand.id, adv.to_stage, varietyId]);
  await insertAuditLog(client, { entityType: 'rd_candidate', entityId: cand.id, action: 'ADVANCE', performedBy: user.email, metadata: { from: adv.from_stage, to: adv.to_stage } });
}
const advHandler = {
  onApproved: applyAdvancement,
  onRejected: async (client: PoolClient, id: string, _u: AuthenticatedUser, comment: string) =>
    void (await client.query(`UPDATE rd_advancements SET status = 'rejected', rejection_reason = $2 WHERE id = $1`, [id, comment])),
};
registerApprovalHandler('variety_advancement', advHandler);
registerApprovalHandler('variety_release', advHandler);

// ------------------------------------------------------------------ trials
interface TraitDef { name: string; unit: string | null; higherIsBetter: boolean }

function parseTraits(v: unknown): TraitDef[] {
  return requireArray(v, 'traits', { min: 1, max: 30 }).map((raw, i) => {
    const r = asRecord(raw, `traits[${i}]`);
    return { name: requireText(r.name, `traits[${i}].name`, 60), unit: optionalText(r.unit, `traits[${i}].unit`, 20), higherIsBetter: r.higherIsBetter !== false };
  });
}

export async function createTrial(input: Record<string, unknown>, user: AuthenticatedUser) {
  const traits = parseTraits(input.traits);
  const entries = requireArray(input.entries, 'entries', { min: 2, max: 200 }).map((raw, i) => {
    const r = asRecord(raw, `entries[${i}]`);
    return { name: requireText(r.name, `entries[${i}].name`, 150), isCheck: r.isCheck === true };
  });
  if (!entries.some((e) => e.isCheck)) throw new ValidationError('Mark at least one entry as the check (control) variety');
  if (new Set(entries.map((e) => e.name.toLowerCase())).size !== entries.length) throw new ValidationError('Entry names must be unique');
  return withTransaction(async (client) => {
    const code = await nextCode(client, 'TRL', 4, true);
    const t = (await client.query(
      `INSERT INTO rd_trials (trial_code, title, crop, season, location, design, replications, traits, protocol_note, created_by)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING *`,
      [code, requireText(input.title, 'title', 200), requireText(input.crop, 'crop', 100), requireText(input.season, 'season', 30), requireText(input.location, 'location', 150),
        input.design === undefined ? 'rcbd' : requireEnum(input.design, ['rcbd', 'crd', 'augmented', 'observational'] as const, 'design'),
        input.replications === undefined ? 3 : requireNumber(input.replications, 'replications', { min: 1, max: 12 }), JSON.stringify(traits), optionalText(input.protocolNote, 'protocolNote', 3000), user.email],
    )).rows[0];
    for (const [i, e] of entries.entries()) {
      await client.query(`INSERT INTO rd_trial_entries (trial_id, entry_code, name, is_check) VALUES ($1,$2,$3,$4)`, [t.id, `E${String(i + 1).padStart(2, '0')}`, e.name, e.isCheck]);
    }
    await insertAuditLog(client, { entityType: 'rd_trial', entityId: t.id, action: 'CREATE', performedBy: user.email, afterState: t });
    return t;
  });
}

export async function listTrials(filters: { status?: string }) {
  const r = await pool.query(
    `SELECT t.*, (SELECT COUNT(*)::int FROM rd_trial_entries e WHERE e.trial_id = t.id) AS entry_count,
            (SELECT COUNT(*)::int FROM rd_trial_observations o WHERE o.trial_id = t.id) AS observation_count
       FROM rd_trials t WHERE ($1::text IS NULL OR t.status = $1) ORDER BY t.created_at DESC LIMIT 300`,
    [filters.status ?? null],
  );
  return r.rows;
}

export async function getTrial(id: string) {
  const t = (await pool.query(`SELECT * FROM rd_trials WHERE id = $1`, [id])).rows[0];
  if (!t) throw new NotFoundError('Trial not found');
  const entries = (await pool.query(`SELECT * FROM rd_trial_entries WHERE trial_id = $1 ORDER BY entry_code`, [id])).rows;
  const obs = (await pool.query(`SELECT entry_id, replication, trait, value::float AS value FROM rd_trial_observations WHERE trial_id = $1`, [id])).rows;
  return { ...t, entries, observations: obs, analysis: analyse(t.traits, entries, obs) };
}

function analyse(traits: TraitDef[], entries: { id: string; entry_code: string; name: string; is_check: boolean }[], obs: { entry_id: string; trait: string; value: number }[]) {
  const perTrait = traits.map((tr) => {
    const rows = entries.map((e) => {
      const vals = obs.filter((o) => o.entry_id === e.id && o.trait === tr.name).map((o) => o.value);
      const n = vals.length;
      const mean = n ? vals.reduce((a, b) => a + b, 0) / n : null;
      const sd = n > 1 && mean !== null ? Math.sqrt(vals.reduce((a, b) => a + (b - mean) ** 2, 0) / (n - 1)) : null;
      return { entryId: e.id, entryCode: e.entry_code, name: e.name, isCheck: e.is_check, n, mean: mean === null ? null : round2(mean), cv: sd !== null && mean ? round2((sd / Math.abs(mean)) * 100) : null, overCheckPct: null as number | null, rank: null as number | null };
    });
    const checks = rows.filter((r) => r.isCheck && r.mean !== null);
    const bestCheck = checks.length ? (tr.higherIsBetter ? Math.max(...checks.map((c) => c.mean!)) : Math.min(...checks.map((c) => c.mean!))) : null;
    for (const r of rows) {
      if (r.mean !== null && bestCheck) r.overCheckPct = round2(((tr.higherIsBetter ? r.mean - bestCheck : bestCheck - r.mean) / Math.abs(bestCheck)) * 100);
    }
    [...rows].filter((r) => r.mean !== null).sort((a, b) => (tr.higherIsBetter ? b.mean! - a.mean! : a.mean! - b.mean!)).forEach((r, i) => { r.rank = i + 1; });
    return { trait: tr.name, unit: tr.unit, higherIsBetter: tr.higherIsBetter, bestCheckMean: bestCheck, rows };
  });
  const overall = entries.map((e) => {
    const ranks = perTrait.map((p) => p.rows.find((r) => r.entryId === e.id)!.rank).filter((r): r is number => r !== null);
    return { entryId: e.id, entryCode: e.entry_code, name: e.name, isCheck: e.is_check, traitsScored: ranks.length, meanRank: ranks.length ? round2(ranks.reduce((a, b) => a + b, 0) / ranks.length) : null };
  }).sort((a, b) => (a.meanRank ?? 1e9) - (b.meanRank ?? 1e9));
  return { perTrait, overall };
}

async function lockTrial(client: PoolClient, id: string) {
  const t = (await client.query(`SELECT * FROM rd_trials WHERE id = $1 FOR UPDATE`, [id])).rows[0];
  if (!t) throw new NotFoundError('Trial not found');
  return t;
}

export async function submitTrial(id: string, user: AuthenticatedUser) {
  return withTransaction(async (client) => {
    const t = await lockTrial(client, id);
    if (!['draft', 'rejected'].includes(t.status)) throw new ConflictError(`${t.trial_code} is ${t.status}; only draft or rejected protocols can be submitted`);
    await client.query(`UPDATE rd_trials SET status = 'pending_approval', rejection_reason = NULL WHERE id = $1`, [id]);
    await submitForApprovalTx(client, { entityType: 'trial_protocol', entityId: id, entityCode: t.trial_code, title: `Trial protocol ${t.trial_code}: ${t.title}` }, user);
    return (await client.query(`SELECT * FROM rd_trials WHERE id = $1`, [id])).rows[0];
  });
}

export async function startTrial(id: string, user: AuthenticatedUser) {
  return withTransaction(async (client) => {
    const t = await lockTrial(client, id);
    if (t.status !== 'approved') throw new ConflictError('Only an approved protocol can be started');
    const r = await client.query(`UPDATE rd_trials SET status = 'running' WHERE id = $1 RETURNING *`, [id]);
    await insertAuditLog(client, { entityType: 'rd_trial', entityId: id, action: 'START', performedBy: user.email });
    return r.rows[0];
  });
}

export async function recordObservations(id: string, input: Record<string, unknown>, user: AuthenticatedUser) {
  const list = requireArray(input.observations, 'observations', { min: 1, max: 1000 }).map((raw, i) => {
    const r = asRecord(raw, `observations[${i}]`);
    return { entryId: requireUuid(r.entryId, `observations[${i}].entryId`), replication: requireNumber(r.replication, `observations[${i}].replication`, { min: 1 }), trait: requireText(r.trait, `observations[${i}].trait`, 60), value: requireNumber(r.value, `observations[${i}].value`) };
  });
  return withTransaction(async (client) => {
    const t = await lockTrial(client, id);
    if (t.status !== 'running') throw new ConflictError('Observations can be recorded only while the trial is running');
    const traitNames = new Set((t.traits as TraitDef[]).map((x) => x.name));
    const entryIds = new Set((await client.query(`SELECT id FROM rd_trial_entries WHERE trial_id = $1`, [id])).rows.map((r) => r.id));
    for (const o of list) {
      if (!traitNames.has(o.trait)) throw new ValidationError(`"${o.trait}" is not a trait of this trial`);
      if (!entryIds.has(o.entryId)) throw new ValidationError('An entry does not belong to this trial');
      if (o.replication > t.replications) throw new ValidationError(`Replication ${o.replication} exceeds the ${t.replications} planned`);
      await client.query(
        `INSERT INTO rd_trial_observations (trial_id, entry_id, replication, trait, value, recorded_by) VALUES ($1,$2,$3,$4,$5,$6)
         ON CONFLICT (entry_id, replication, trait) DO UPDATE SET value = EXCLUDED.value, recorded_by = EXCLUDED.recorded_by, recorded_at = now()`,
        [id, o.entryId, o.replication, o.trait, o.value, user.email],
      );
    }
    return { saved: list.length };
  });
}

export async function completeTrial(id: string, user: AuthenticatedUser) {
  return withTransaction(async (client) => {
    const t = await lockTrial(client, id);
    if (t.status !== 'running') throw new ConflictError('Only a running trial can be completed');
    const n = (await client.query(`SELECT COUNT(*)::int AS n FROM rd_trial_observations WHERE trial_id = $1`, [id])).rows[0].n;
    if (n === 0) throw new ConflictError('Record observations before completing the trial');
    const r = await client.query(`UPDATE rd_trials SET status = 'completed' WHERE id = $1 RETURNING *`, [id]);
    await insertAuditLog(client, { entityType: 'rd_trial', entityId: id, action: 'COMPLETE', performedBy: user.email });
    return r.rows[0];
  });
}

// ------------------------------------------------------------------ candidates, advancement, spec
export async function createCandidate(input: Record<string, unknown>, user: AuthenticatedUser) {
  return withTransaction(async (client) => {
    let crop = input.crop === undefined ? null : requireText(input.crop, 'crop', 100);
    const trialId = input.sourceTrialId ? requireUuid(input.sourceTrialId, 'sourceTrialId') : null;
    if (trialId) {
      const t = await lockTrial(client, trialId);
      if (t.status !== 'completed') throw new ConflictError('A candidate can be taken only from a completed trial');
      crop = crop ?? t.crop;
    }
    if (!crop) throw new ValidationError('crop is required');
    const name = requireText(input.name, 'name', 150);
    const dup = await client.query(`SELECT 1 FROM rd_candidates WHERE crop = $1 AND name = $2`, [crop, name]);
    if (dup.rows[0]) throw new ConflictError(`${name} is already a candidate for ${crop}`);
    const code = await nextCode(client, 'CND', 4, true);
    const r = await client.query(
      `INSERT INTO rd_candidates (candidate_code, name, crop, botanical_name, source_trial_id, created_by) VALUES ($1,$2,$3,$4,$5,$6) RETURNING *`,
      [code, name, crop, optionalText(input.botanicalName, 'botanicalName', 150) ?? crop, trialId, user.email],
    );
    await insertAuditLog(client, { entityType: 'rd_candidate', entityId: r.rows[0].id, action: 'CREATE', performedBy: user.email, afterState: r.rows[0] });
    return r.rows[0];
  });
}

export async function listCandidates() {
  const r = await pool.query(
    `SELECT c.*, t.trial_code, s.status AS spec_status,
            (SELECT row_to_json(a) FROM (SELECT id, adv_number, to_stage, status FROM rd_advancements WHERE candidate_id = c.id AND status = 'pending_approval' LIMIT 1) a) AS pending_advancement
       FROM rd_candidates c LEFT JOIN rd_trials t ON t.id = c.source_trial_id LEFT JOIN rd_variety_specs s ON s.candidate_id = c.id
      ORDER BY c.created_at DESC LIMIT 300`,
  );
  return r.rows;
}

export async function getCandidate(id: string) {
  const c = (await pool.query(`SELECT c.*, t.trial_code FROM rd_candidates c LEFT JOIN rd_trials t ON t.id = c.source_trial_id WHERE c.id = $1`, [id])).rows[0];
  if (!c) throw new NotFoundError('Candidate not found');
  const [adv, spec] = await Promise.all([
    pool.query(`SELECT * FROM rd_advancements WHERE candidate_id = $1 ORDER BY proposed_at DESC`, [id]),
    pool.query(`SELECT * FROM rd_variety_specs WHERE candidate_id = $1`, [id]),
  ]);
  return { ...c, advancements: adv.rows, spec: spec.rows[0] ?? null };
}

export async function proposeAdvancement(candidateId: string, input: Record<string, unknown>, user: AuthenticatedUser) {
  const to = requireEnum(input.toStage, ['multi_location', 'pre_release', 'released', 'dropped'] as const, 'toStage');
  const justification = requireText(input.justification, 'justification', 3000);
  return withTransaction(async (client) => {
    const c = (await client.query(`SELECT * FROM rd_candidates WHERE id = $1 FOR UPDATE`, [candidateId])).rows[0];
    if (!c) throw new NotFoundError('Candidate not found');
    if (['released', 'dropped'].includes(c.stage)) throw new ConflictError(`${c.candidate_code} is already ${c.stage}`);
    if ((await client.query(`SELECT 1 FROM rd_advancements WHERE candidate_id = $1 AND status = 'pending_approval'`, [candidateId])).rows[0]) throw new ConflictError('An advancement is already waiting for approval');
    if (to !== 'dropped') {
      const from = STAGES.indexOf(c.stage);
      if (STAGES.indexOf(to as (typeof STAGES)[number]) !== from + 1) throw new ConflictError(`From ${c.stage} the next stage is ${STAGES[from + 1]}`);
    }
    if (to === 'released') {
      const spec = (await client.query(`SELECT status FROM rd_variety_specs WHERE candidate_id = $1`, [candidateId])).rows[0];
      if (!spec || spec.status === 'draft') throw new ConflictError('Prepare the variety specification (mark it ready) before proposing release');
    }
    const adv = (await client.query(
      `INSERT INTO rd_advancements (adv_number, candidate_id, from_stage, to_stage, justification, proposed_by) VALUES ($1,$2,$3,$4,$5,$6) RETURNING *`,
      [await nextCode(client, 'ADV', 4, true), candidateId, c.stage, to, justification, user.email],
    )).rows[0];
    await submitForApprovalTx(client, { entityType: to === 'released' ? 'variety_release' : 'variety_advancement', entityId: adv.id, entityCode: adv.adv_number, title: `${c.name} (${c.crop}): ${c.stage} → ${to}` }, user);
    return adv;
  });
}

export async function upsertSpec(candidateId: string, input: Record<string, unknown>, user: AuthenticatedUser) {
  const ready = input.ready === true;
  const descriptors = input.descriptors && typeof input.descriptors === 'object' && !Array.isArray(input.descriptors) ? (input.descriptors as Record<string, unknown>) : {};
  const germ = optionalNumber(input.minGerminationPct, 'minGerminationPct', { min: 0, max: 100 });
  const purity = optionalNumber(input.minPurityPct, 'minPurityPct', { min: 0, max: 100 });
  const moisture = optionalNumber(input.maxMoisturePct, 'maxMoisturePct', { min: 0, max: 100 });
  if (ready && (!Object.keys(descriptors).length || germ === null || purity === null || moisture === null)) {
    throw new ValidationError('To mark the specification ready, give descriptors plus minimum germination, minimum purity and maximum moisture');
  }
  return withTransaction(async (client) => {
    const c = (await client.query(`SELECT id FROM rd_candidates WHERE id = $1`, [candidateId])).rows[0];
    if (!c) throw new NotFoundError('Candidate not found');
    const cur = (await client.query(`SELECT status FROM rd_variety_specs WHERE candidate_id = $1 FOR UPDATE`, [candidateId])).rows[0];
    if (cur?.status === 'handed_over') throw new ConflictError('The specification has been handed over to production and is locked');
    const r = await client.query(
      `INSERT INTO rd_variety_specs (candidate_id, descriptors, min_germination_pct, min_purity_pct, max_moisture_pct, recommended_regions, maintenance_notes, status, updated_by)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
       ON CONFLICT (candidate_id) DO UPDATE SET descriptors = EXCLUDED.descriptors, min_germination_pct = EXCLUDED.min_germination_pct, min_purity_pct = EXCLUDED.min_purity_pct,
         max_moisture_pct = EXCLUDED.max_moisture_pct, recommended_regions = EXCLUDED.recommended_regions, maintenance_notes = EXCLUDED.maintenance_notes,
         status = EXCLUDED.status, updated_by = EXCLUDED.updated_by, updated_at = now() RETURNING *`,
      [candidateId, JSON.stringify(descriptors), germ, purity, moisture, optionalText(input.recommendedRegions, 'recommendedRegions', 1000), optionalText(input.maintenanceNotes, 'maintenanceNotes', 3000), ready ? 'ready' : 'draft', user.email],
    );
    return r.rows[0];
  });
}

export async function pipelineSummary() {
  const stages = await pool.query(`SELECT stage, COUNT(*)::int AS n FROM rd_candidates GROUP BY stage`);
  const trials = await pool.query(`SELECT status, COUNT(*)::int AS n FROM rd_trials GROUP BY status`);
  return { stages: stages.rows, trials: trials.rows, num };
}
