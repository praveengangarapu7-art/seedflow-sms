import { Router } from 'express';
import { asyncHandler as h } from '../../middleware/asyncHandler';
import { requireAuth, requirePermission as can, requireStaff } from '../../middleware/requireAuth';
import { pool } from '../../db/pool';
import { body, ok, str } from '../shared/http';
import * as audits from './audits.service';
import * as mgmt from './management.service';
import * as rd from './rd.service';
import * as recalls from './recalls.service';
import * as training from './training.service';

const RD_VIEW = ['design_trial', 'execute_trial', 'record_phenotyping', 'analyze_trial_data', 'propose_variety_advancement', 'approve_trial_protocol', 'approve_variety_advancement', 'approve_variety_release', 'sign_off_variety_release', 'manage_variety_specs'];

export const assuranceRouter = Router();
assuranceRouter.use(requireAuth, requireStaff);

// R&D
assuranceRouter.get('/rd/trials', can(...RD_VIEW), h(async (req, res) => ok(res, await rd.listTrials({ status: str(req.query.status) }))));
assuranceRouter.post('/rd/trials', can('design_trial'), h(async (req, res) => ok(res, await rd.createTrial(body(req), req.user!), 'Trial created', 201)));
assuranceRouter.get('/rd/trials/:id', can(...RD_VIEW), h(async (req, res) => ok(res, await rd.getTrial(req.params.id))));
assuranceRouter.post('/rd/trials/:id/submit', can('design_trial'), h(async (req, res) => ok(res, await rd.submitTrial(req.params.id, req.user!), 'Sent for approval')));
assuranceRouter.post('/rd/trials/:id/start', can('execute_trial'), h(async (req, res) => ok(res, await rd.startTrial(req.params.id, req.user!), 'Trial started')));
assuranceRouter.post('/rd/trials/:id/observations', can('record_phenotyping', 'execute_trial'), h(async (req, res) => ok(res, await rd.recordObservations(req.params.id, body(req), req.user!), 'Observations saved')));
assuranceRouter.post('/rd/trials/:id/complete', can('analyze_trial_data', 'execute_trial'), h(async (req, res) => ok(res, await rd.completeTrial(req.params.id, req.user!), 'Trial completed')));
assuranceRouter.get('/rd/candidates', can(...RD_VIEW), h(async (_req, res) => ok(res, await rd.listCandidates())));
assuranceRouter.post('/rd/candidates', can('propose_variety_advancement'), h(async (req, res) => ok(res, await rd.createCandidate(body(req), req.user!), 'Candidate created', 201)));
assuranceRouter.get('/rd/candidates/:id', can(...RD_VIEW), h(async (req, res) => ok(res, await rd.getCandidate(req.params.id))));
assuranceRouter.post('/rd/candidates/:id/advance', can('propose_variety_advancement'), h(async (req, res) => ok(res, await rd.proposeAdvancement(req.params.id, body(req), req.user!), 'Sent for approval', 201)));
assuranceRouter.put('/rd/candidates/:id/spec', can('manage_variety_specs', 'propose_variety_advancement'), h(async (req, res) => ok(res, await rd.upsertSpec(req.params.id, body(req), req.user!), 'Specification saved')));

// Recalls
const RECALL_VIEW = ['manage_recalls', 'approve_recall', 'view_management_dashboard'];
assuranceRouter.get('/recalls', can(...RECALL_VIEW), h(async (_req, res) => ok(res, await recalls.listRecalls())));
assuranceRouter.post('/recalls', can('manage_recalls'), h(async (req, res) => ok(res, await recalls.createRecall(body(req), req.user!), 'Recall drafted', 201)));
assuranceRouter.post('/recalls/trace', can(...RECALL_VIEW), h(async (req, res) => ok(res, await recalls.trace(Array.isArray(body(req).lotIds) ? (body(req).lotIds as string[]) : []))));
assuranceRouter.get('/recalls/:id', can(...RECALL_VIEW), h(async (req, res) => ok(res, await recalls.getRecall(req.params.id))));
assuranceRouter.post('/recalls/:id/submit', can('manage_recalls'), h(async (req, res) => ok(res, await recalls.submitRecall(req.params.id, req.user!), 'Sent for approval')));
assuranceRouter.post('/recalls/recipients/:rid/acknowledge', can('manage_recalls'), h(async (req, res) => ok(res, await recalls.acknowledge(req.params.rid, body(req), req.user!, false), 'Acknowledged')));
assuranceRouter.post('/recalls/:id/close', can('manage_recalls'), h(async (req, res) => ok(res, await recalls.closeRecall(req.params.id, body(req), req.user!), 'Recall closed')));

// Audits
assuranceRouter.get('/audits', can('manage_audits', 'close_audit', 'view_management_dashboard'), h(async (_req, res) => ok(res, await audits.listAudits())));
assuranceRouter.post('/audits', can('manage_audits'), h(async (req, res) => ok(res, await audits.createAudit(body(req), req.user!), 'Audit planned', 201)));
assuranceRouter.get('/audits/:id', can('manage_audits', 'close_audit', 'view_management_dashboard'), h(async (req, res) => ok(res, await audits.getAudit(req.params.id))));
assuranceRouter.post('/audits/:id/start', can('manage_audits'), h(async (req, res) => ok(res, await audits.startAudit(req.params.id, req.user!), 'Audit started')));
assuranceRouter.post('/audits/:id/findings', can('manage_audits'), h(async (req, res) => ok(res, await audits.addFinding(req.params.id, body(req), req.user!), 'Finding recorded', 201)));
assuranceRouter.post('/audits/:id/findings/:fid/close', can('manage_audits'), h(async (req, res) => ok(res, await audits.closeFinding(req.params.id, req.params.fid, body(req), req.user!), 'Finding closed')));
assuranceRouter.post('/audits/:id/complete', can('manage_audits'), h(async (req, res) => ok(res, await audits.completeAudit(req.params.id, body(req), req.user!), 'Audit completed')));
assuranceRouter.post('/audits/:id/close', can('close_audit'), h(async (req, res) => ok(res, await audits.closeAudit(req.params.id, req.user!), 'Audit closed')));

// Training
assuranceRouter.get('/training/matrix', can('manage_training', 'view_management_dashboard'), h(async (_req, res) => ok(res, await training.matrix())));
assuranceRouter.get('/training/courses', can('manage_training', 'view_management_dashboard'), h(async (_req, res) => ok(res, await training.listCourses())));
assuranceRouter.get('/training/staff', can('manage_training'), h(async (_req, res) => ok(res, (await pool.query(`SELECT id, name, job_role FROM users WHERE is_active AND job_role IS NOT NULL AND job_role NOT IN ('grower','dealer') ORDER BY name`)).rows)));
assuranceRouter.post('/training/courses', can('manage_training'), h(async (req, res) => ok(res, await training.createCourse(body(req), req.user!), 'Course created', 201)));
assuranceRouter.patch('/training/courses/:id', can('manage_training'), h(async (req, res) => ok(res, await training.updateCourse(req.params.id, body(req)))));
assuranceRouter.post('/training/records', can('manage_training'), h(async (req, res) => ok(res, await training.recordTraining(body(req), req.user!), 'Training recorded', 201)));

// Management + SATHI
assuranceRouter.get('/management/dashboard', can('view_management_dashboard'), h(async (_req, res) => ok(res, await mgmt.dashboard())));
assuranceRouter.get('/exports/sathi/:kind', can('export_sathi'), h(async (req, res) => {
  const out = await mgmt.sathiExport(req.params.kind, { from: str(req.query.from), to: str(req.query.to) });
  if (req.query.format === 'csv') {
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="${out.filename}"`);
    return void res.send(out.csv);
  }
  ok(res, out);
}));

// Dealer portal: recall notices
export const recallPortalRouter = Router();
recallPortalRouter.use(requireAuth);
recallPortalRouter.get('/', can('portal_dealer'), h(async (req, res) => ok(res, await recalls.dealerRecalls(req.user!))));
recallPortalRouter.post('/:rid/acknowledge', can('portal_dealer'), h(async (req, res) => ok(res, await recalls.acknowledge(req.params.rid, body(req), req.user!, true), 'Thank you — acknowledged')));
