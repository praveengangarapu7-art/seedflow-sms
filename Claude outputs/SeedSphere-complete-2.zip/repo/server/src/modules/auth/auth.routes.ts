import { Router } from 'express';
import rateLimit from 'express-rate-limit';
import { env } from '../../config/env';
import { asyncHandler } from '../../middleware/asyncHandler';
import { requireAuth, requireRole } from '../../middleware/requireAuth';
import * as authController from './auth.controller';

export const authRouter = Router();

// Login is the one credential-guessing surface in this app, so failed
// attempts are throttled per IP. Successful sign-ins are not counted: the
// screens sign in once and then renew through the refresh cookie, and a whole
// office behind one address must still be able to start the day.
// Skipped in the test env, where the suite signs in many times from one address.
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 20,
  skipSuccessfulRequests: true,
  standardHeaders: true,
  legacyHeaders: false,
  skip: () => env.nodeEnv === 'test',
  message: { success: false, message: 'Too many failed sign-in attempts. Please wait 15 minutes and try again.' },
});

authRouter.post('/login', loginLimiter, asyncHandler(authController.login));
authRouter.post('/refresh', asyncHandler(authController.refresh));
authRouter.post('/logout', asyncHandler(authController.logout));
authRouter.get('/me', requireAuth, asyncHandler(authController.me));
// Bootstrapping the very first Admin happens via `npm run seed:auth`; this
// endpoint is how an existing Admin provisions everyone after that.
authRouter.post('/register', requireAuth, requireRole('Admin'), asyncHandler(authController.register));
