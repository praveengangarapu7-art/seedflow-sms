import { pool } from '../../db/pool';
import { withTransaction } from '../../db/transaction';
import { ConflictError, NotFoundError, ValidationError } from '../../errors';
import type { AuthenticatedUser } from '../../middleware/requireAuth';
import { insertAuditLog } from '../auditLogs/auditLogs.service';
import { insertNcrTx } from '../quality/ncr.service';
import { nextCode, optionalNumber, optionalText, optionalUuid, requireEnum, requireNumber, requireText, requireUuid } from '../shared/validate';

const rows = async (sql: string, p: unknown[] = []) => (await pool.query(sql, p)).rows;
const TYPES = ['injury', 'near_miss', 'chemical_spill', 'fire', 'equipment', 'environmental', 'other'] as const;
const SEVERITIES = ['minor', 'moderate', 'major', 'critical'] as const;
const AREAS = ['warehouse', 'processing', 'laboratory', 'field', 'transport', 'office'] as const;
const DEPARTMENT_FOR_AREA = { warehouse: 'warehouse', processing: 'production', laboratory: 'laboratory', field: 'production', transport: 'logistics', office: 'operations' } as const;

async function actorName(user: AuthenticatedUser): Promise<string> {
  return (await rows(`SELECT name FROM users WHERE id = $1`, [user.id]))[0]?.name ?? user.email;
}

export async function reportIncident(b: Record<string, unknown>, user: AuthenticatedUser) {
  const occurred = new Date(String(b.occurredAt ?? new Date().toISOString()));
  if (Number.isNaN(occurred.getTime())) throw new ValidationError('occurredAt is not a valid date');
  if (occurred.getTime() > Date.now() + 60_000) throw new ValidationError('occurredAt cannot be in the future');
  const type = requireEnum(b.incidentType, TYPES, 'incidentType');
  const severity = requireEnum(b.severity, SEVERITIES, 'severity');
  const area = requireEnum(b.area, AREAS, 'area');
  const by = await actorName(user);
  const batchId = optionalUuid(b.batchId, 'batchId');
  return withTransaction(async (client) => {
    if (batchId && !(await client.query(`SELECT 1 FROM prc_batches WHERE id = $1`, [batchId])).rows[0]) throw new ValidationError('Batch not found');
    const number = await nextCode(client, 'INC', 4, true);
    const description = requireText(b.description, 'description', 4000);
    let ncrId: string | null = null;
    if (severity === 'major' || severity === 'critical') {
      const { ncr } = await insertNcrTx(client, { title: `Safety incident ${number}`, description, department: DEPARTMENT_FOR_AREA[area], source: 'other', severity: severity === 'critical' ? 'critical' : 'major', seedLotId: null, assignedTo: null, dueDate: null } as never, user);
      ncrId = ncr.id;
    }
    const r = (await client.query(
      `INSERT INTO safety_incidents (incident_number, incident_type, severity, area, occurred_at, location, description, persons_involved, lost_time, chemical, quantity, unit, immediate_action, batch_id, ncr_id, reported_by)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16) RETURNING *`,
      [number, type, severity, area, occurred.toISOString(), optionalText(b.location, 'location', 150), description, optionalText(b.personsInvolved, 'personsInvolved', 500), b.lostTime === true, optionalText(b.chemical, 'chemical', 150),
        optionalNumber(b.quantity, 'quantity', { min: 0 }), optionalText(b.unit, 'unit', 10), optionalText(b.immediateAction, 'immediateAction', 2000), batchId, ncrId, by],
    )).rows[0];
    await insertAuditLog(client, { entityType: 'safety_incident', entityId: r.id, action: 'CREATE', performedBy: user.email, afterState: r });
    return r;
  });
}

export async function listIncidents(f: { status?: string; severity?: string }) {
  const where: string[] = [];
  const v: unknown[] = [];
  if (f.status) { v.push(f.status); where.push(`i.status = $${v.length}`); }
  if (f.severity) { v.push(f.severity); where.push(`i.severity = $${v.length}`); }
  return rows(`SELECT i.*, n.ncr_code, b.batch_number FROM safety_incidents i LEFT JOIN non_conformances n ON n.id = i.ncr_id LEFT JOIN prc_batches b ON b.id = i.batch_id ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY i.occurred_at DESC LIMIT 500`, v);
}

export async function getIncident(id: string) {
  const r = (await rows(`SELECT i.*, n.ncr_code, b.batch_number FROM safety_incidents i LEFT JOIN non_conformances n ON n.id = i.ncr_id LEFT JOIN prc_batches b ON b.id = i.batch_id WHERE i.id = $1`, [requireUuid(id, 'id')]))[0];
  if (!r) throw new NotFoundError('Incident not found');
  return r;
}

export async function incidentAction(id: string, action: 'investigate' | 'close', b: Record<string, unknown>, user: AuthenticatedUser) {
  const cur = await getIncident(id);
  const by = await actorName(user);
  if (action === 'investigate') {
    if (cur.status !== 'open') throw new ConflictError('Only an open incident can be put under investigation');
    await rows(`UPDATE safety_incidents SET status = 'investigating', investigated_by = $2, root_cause = COALESCE($3, root_cause) WHERE id = $1`, [id, by, optionalText(b.rootCause, 'rootCause', 3000)]);
  } else {
    if (cur.status === 'closed') throw new ConflictError('This incident is already closed');
    const rootCause = requireText(b.rootCause ?? cur.root_cause, 'rootCause', 3000);
    const corrective = requireText(b.correctiveAction, 'correctiveAction', 3000);
    await rows(`UPDATE safety_incidents SET status = 'closed', root_cause = $2, corrective_action = $3, closed_by = $4, closed_at = now() WHERE id = $1`, [id, rootCause, corrective, by]);
  }
  await insertAuditLog(pool as never, { entityType: 'safety_incident', entityId: id, action: action === 'close' ? 'CLOSE' : 'INVESTIGATE', performedBy: user.email, afterState: b }).catch(() => undefined);
  return getIncident(id);
}

// ------------------------------------------------------------------ chemicals
export async function logChemical(b: Record<string, unknown>, user: AuthenticatedUser) {
  const chemical = requireText(b.chemical, 'chemical', 150);
  const action = requireEnum(b.action, ['received', 'used', 'disposed'] as const, 'action');
  const quantity = requireNumber(b.quantity, 'quantity', { positive: true });
  const unit = optionalText(b.unit, 'unit', 10) ?? 'kg';
  const by = await actorName(user);
  return withTransaction(async (client) => {
    if (action !== 'received') {
      const bal = (await client.query(`SELECT COALESCE(SUM(CASE WHEN action = 'received' THEN quantity ELSE -quantity END),0)::float AS bal FROM safety_chemical_log WHERE lower(chemical) = lower($1) AND unit = $2`, [chemical, unit])).rows[0].bal as number;
      if (quantity > bal + 1e-9) throw new ConflictError(`Only ${bal} ${unit} of ${chemical} is on record — cannot ${action === 'used' ? 'use' : 'dispose of'} ${quantity}`);
    }
    const batchId = optionalUuid(b.batchId, 'batchId');
    if (batchId && !(await client.query(`SELECT 1 FROM prc_batches WHERE id = $1`, [batchId])).rows[0]) throw new ValidationError('Batch not found');
    if (action === 'disposed' && !optionalText(b.disposalMethod, 'disposalMethod', 150)) throw new ValidationError('disposalMethod is required when disposing');
    return (await client.query(
      `INSERT INTO safety_chemical_log (chemical, action, quantity, unit, batch_id, disposal_method, supplier, notes, logged_by) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,
      [chemical, action, quantity, unit, batchId, optionalText(b.disposalMethod, 'disposalMethod', 150), optionalText(b.supplier, 'supplier', 150), optionalText(b.notes, 'notes', 1000), by],
    )).rows[0];
  });
}

export async function chemicalRegister() {
  const [balances, log] = await Promise.all([
    rows(`SELECT chemical, unit, COALESCE(SUM(CASE WHEN action='received' THEN quantity ELSE 0 END),0)::float AS received, COALESCE(SUM(CASE WHEN action='used' THEN quantity ELSE 0 END),0)::float AS used,
                 COALESCE(SUM(CASE WHEN action='disposed' THEN quantity ELSE 0 END),0)::float AS disposed, COALESCE(SUM(CASE WHEN action='received' THEN quantity ELSE -quantity END),0)::float AS on_hand
            FROM safety_chemical_log GROUP BY chemical, unit ORDER BY chemical`),
    rows(`SELECT l.*, b.batch_number FROM safety_chemical_log l LEFT JOIN prc_batches b ON b.id = l.batch_id ORDER BY l.logged_at DESC LIMIT 200`),
  ]);
  return { balances, log };
}

export async function safetyDashboard() {
  const [counts, bySeverity, byArea, lastLost, chemicals] = await Promise.all([
    rows(`SELECT COUNT(*) FILTER (WHERE status <> 'closed')::int AS open, COUNT(*) FILTER (WHERE status = 'investigating')::int AS investigating,
                 COUNT(*) FILTER (WHERE occurred_at > now() - interval '90 days')::int AS last_90_days, COUNT(*) FILTER (WHERE status <> 'closed' AND severity IN ('major','critical'))::int AS open_serious,
                 COUNT(*) FILTER (WHERE incident_type = 'near_miss' AND occurred_at > now() - interval '90 days')::int AS near_misses_90 FROM safety_incidents`),
    rows(`SELECT severity, COUNT(*)::int AS count FROM safety_incidents WHERE occurred_at > now() - interval '12 months' GROUP BY severity`),
    rows(`SELECT area, COUNT(*)::int AS count FROM safety_incidents WHERE occurred_at > now() - interval '12 months' GROUP BY area ORDER BY count DESC`),
    rows(`SELECT MAX(occurred_at) AS at FROM safety_incidents WHERE lost_time`),
    rows(`SELECT COUNT(*)::int AS n FROM (SELECT chemical, unit FROM safety_chemical_log GROUP BY chemical, unit HAVING SUM(CASE WHEN action='received' THEN quantity ELSE -quantity END) > 0) x`),
  ]);
  const last = lastLost[0].at as Date | null;
  return { ...counts[0], bySeverity, byArea, daysSinceLostTime: last ? Math.floor((Date.now() - new Date(last).getTime()) / 86_400_000) : null, chemicalsOnHand: chemicals[0].n };
}
