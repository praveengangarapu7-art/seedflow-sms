import { Router } from 'express';
import { asyncHandler as h } from '../../middleware/asyncHandler';
import { requireAuth, requirePermission as can, requireStaff } from '../../middleware/requireAuth';
import { body, ok, str } from '../shared/http';
import * as s from './safety.service';

export const safetyRouter = Router();
safetyRouter.use(requireAuth, requireStaff);
safetyRouter.get('/dashboard', h(async (_q, res) => ok(res, await s.safetyDashboard())));
// Anyone on the floor can report; only safety staff and managers investigate and close.
safetyRouter.get('/incidents', h(async (q, res) => ok(res, await s.listIncidents({ status: str(q.query.status), severity: str(q.query.severity) }))));
safetyRouter.post('/incidents', h(async (q, res) => ok(res, await s.reportIncident(body(q), q.user!), 'Incident reported', 201)));
safetyRouter.get('/incidents/:id', h(async (q, res) => ok(res, await s.getIncident(q.params.id))));
safetyRouter.post('/incidents/:id/:action(investigate|close)', can('manage_safety_incidents'), h(async (q, res) => ok(res, await s.incidentAction(q.params.id, q.params.action as 'investigate' | 'close', body(q), q.user!))));
safetyRouter.get('/chemicals', h(async (_q, res) => ok(res, await s.chemicalRegister())));
safetyRouter.post('/chemicals', can('manage_safety_incidents', 'update_batch_stage'), h(async (q, res) => ok(res, await s.logChemical(body(q), q.user!), 'Entry recorded', 201)));
