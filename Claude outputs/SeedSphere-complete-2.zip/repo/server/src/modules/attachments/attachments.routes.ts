import express, { Router } from 'express';
import { env } from '../../config/env';
import { asyncHandler as h } from '../../middleware/asyncHandler';
import { requireAuth, requireStaff } from '../../middleware/requireAuth';
import { ok, str } from '../shared/http';
import * as s from './attachments.service';

export const attachmentsRouter = Router();
attachmentsRouter.use(requireAuth, requireStaff);

attachmentsRouter.get('/', h(async (req, res) => ok(res, await s.listAttachments(str(req.query.entityType), str(req.query.entityId)))));

// The file travels as the raw request body (Content-Type = the file's type),
// with the record it belongs to in the query string: no base64 inflation and
// no multipart parser to configure.
attachmentsRouter.post(
  '/',
  express.raw({ type: () => true, limit: env.maxUploadBytes }),
  h(async (req, res) => {
    const row = await s.uploadAttachment(
      {
        entityType: req.query.entityType,
        entityId: req.query.entityId,
        fileName: req.query.fileName,
        description: req.query.description,
        contentType: req.header('content-type'),
      },
      req.body as Buffer,
      req.user!,
    );
    ok(res, row, `${row.file_name} uploaded`, 201);
  }),
);

attachmentsRouter.get(
  '/:id/download',
  h(async (req, res) => {
    const { row, data } = await s.readAttachment(req.params.id);
    res.setHeader('Content-Type', row.content_type);
    res.setHeader('Content-Length', String(data.length));
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Content-Disposition', `attachment; filename="${row.file_name.replace(/"/g, '')}"`);
    res.end(data);
  }),
);

attachmentsRouter.delete('/:id', h(async (req, res) => {
  await s.deleteAttachment(req.params.id, req.user!);
  ok(res, { deleted: true }, 'Attachment removed');
}));
