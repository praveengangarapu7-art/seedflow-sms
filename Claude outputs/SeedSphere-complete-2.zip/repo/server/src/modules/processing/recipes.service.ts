import type { PoolClient } from 'pg';
import { pool } from '../../db/pool';
import { withTransaction } from '../../db/transaction';
import { ConflictError, ForbiddenError, NotFoundError, ValidationError } from '../../errors';
import type { AuthenticatedUser } from '../../middleware/requireAuth';
import { getApprovalsForEntity, registerApprovalHandler, submitForApprovalTx } from '../approvals/approvals.service';
import { insertAuditLog } from '../auditLogs/auditLogs.service';
import { asRecord, nextCode, optionalNumber, optionalText, requireArray, requireEnum, requireNumber, requireText } from '../shared/validate';

export const STAGES = ['pre_cleaning', 'drying', 'cleaning_grading', 'gravity_separation', 'treatment', 'packing'] as const;

registerApprovalHandler('processing_recipe', {
  onApproved: async (client, id) => {
    const r = await client.query<{ name: string }>('SELECT name FROM prc_recipes WHERE id = $1', [id]);
    // One approved version per recipe: the new one supersedes the old.
    await client.query(`UPDATE prc_recipes SET status = 'retired' WHERE name = $1 AND status = 'approved' AND id <> $2`, [r.rows[0].name, id]);
    await client.query(`UPDATE prc_recipes SET status = 'approved', approved_at = now() WHERE id = $1`, [id]);
  },
  onRejected: async (client, id, _user, comment) => {
    await client.query(`UPDATE prc_recipes SET status = 'rejected', rejection_reason = $2 WHERE id = $1`, [id, comment]);
  },
});

interface StageInput {
  stage: (typeof STAGES)[number];
  machineType: string | null;
  parameters: string | null;
  maxLossPct: number;
}
interface ChemicalInput {
  chemicalName: string;
  dosePerKg: number;
  doseUnit: 'g' | 'ml';
  purpose: string | null;
}

function parseStages(value: unknown): StageInput[] {
  const stages = requireArray(value, 'stages', { min: 1, max: 12 }).map((raw, i) => {
    const r = asRecord(raw, `stages[${i}]`);
    return {
      stage: requireEnum(r.stage, STAGES, `stages[${i}].stage`),
      machineType: optionalText(r.machineType, `stages[${i}].machineType`, 30),
      parameters: optionalText(r.parameters, `stages[${i}].parameters`, 1000),
      maxLossPct: requireNumber(r.maxLossPct, `stages[${i}].maxLossPct`, { min: 0, max: 50 }),
    };
  });
  if (new Set(stages.map((s) => s.stage)).size !== stages.length) throw new ValidationError('Each stage may appear once');
  return stages;
}

function parseChemicals(value: unknown): ChemicalInput[] {
  if (value === undefined || value === null) return [];
  return requireArray(value, 'chemicals', { min: 0, max: 10 }).map((raw, i) => {
    const r = asRecord(raw, `chemicals[${i}]`);
    return {
      chemicalName: requireText(r.chemicalName, `chemicals[${i}].chemicalName`, 150),
      dosePerKg: requireNumber(r.dosePerKg, `chemicals[${i}].dosePerKg`, { positive: true }),
      doseUnit: requireEnum(r.doseUnit, ['g', 'ml'] as const, `chemicals[${i}].doseUnit`),
      purpose: optionalText(r.purpose, `chemicals[${i}].purpose`, 150),
    };
  });
}

async function insertParts(client: PoolClient, recipeId: string, stages: StageInput[], chemicals: ChemicalInput[]) {
  for (const [i, s] of stages.entries()) {
    await client.query(`INSERT INTO prc_recipe_stages (recipe_id, seq, stage, machine_type, parameters, max_loss_pct) VALUES ($1, $2, $3, $4, $5, $6)`, [recipeId, i + 1, s.stage, s.machineType, s.parameters, s.maxLossPct]);
  }
  for (const c of chemicals) {
    await client.query(`INSERT INTO prc_recipe_chemicals (recipe_id, chemical_name, dose_per_kg, dose_unit, purpose) VALUES ($1, $2, $3, $4, $5)`, [recipeId, c.chemicalName, c.dosePerKg, c.doseUnit, c.purpose]);
  }
}

function checkTreatment(stages: StageInput[], chemicals: ChemicalInput[]) {
  const hasTreatment = stages.some((s) => s.stage === 'treatment');
  if (hasTreatment && chemicals.length === 0) throw new ValidationError('A treatment stage needs at least one chemical with its dose');
  if (!hasTreatment && chemicals.length > 0) throw new ValidationError('Chemicals are listed but there is no treatment stage');
}

export async function createRecipe(input: Record<string, unknown>, user: AuthenticatedUser) {
  const name = requireText(input.name, 'name', 150);
  const crop = requireText(input.crop, 'crop', 100);
  const stages = parseStages(input.stages);
  const chemicals = parseChemicals(input.chemicals);
  checkTreatment(stages, chemicals);
  return withTransaction(async (client) => {
    const dup = await client.query('SELECT 1 FROM prc_recipes WHERE name = $1', [name]);
    if (dup.rows[0]) throw new ConflictError(`A recipe called "${name}" exists — revise it instead`);
    const code = await nextCode(client, 'RCP', 3, false);
    const r = await client.query(
      `INSERT INTO prc_recipes (recipe_code, name, crop, target_moisture_pct, notes, created_by) VALUES ($1, $2, $3, $4, $5, $6) RETURNING *`,
      [code, name, crop, optionalNumber(input.targetMoisturePct, 'targetMoisturePct', { positive: true, max: 30 }), optionalText(input.notes, 'notes', 2000), user.email],
    );
    await insertParts(client, r.rows[0].id, stages, chemicals);
    await insertAuditLog(client, { entityType: 'processing_recipe', entityId: r.rows[0].id, action: 'CREATE', performedBy: user.email, afterState: { ...r.rows[0], stages, chemicals } });
    return getRecipe(r.rows[0].id, client);
  });
}

export async function reviseRecipe(id: string, input: Record<string, unknown>, user: AuthenticatedUser) {
  return withTransaction(async (client) => {
    const src = await client.query('SELECT * FROM prc_recipes WHERE id = $1', [id]);
    if (!src.rows[0]) throw new NotFoundError('Recipe not found');
    const open = await client.query(`SELECT 1 FROM prc_recipes WHERE name = $1 AND status IN ('draft', 'pending_approval')`, [src.rows[0].name]);
    if (open.rows[0]) throw new ConflictError('A revision of this recipe is already in progress');
    const stages = parseStages(input.stages);
    const chemicals = parseChemicals(input.chemicals);
    checkTreatment(stages, chemicals);
    const max = await client.query<{ v: number }>('SELECT MAX(version)::int AS v FROM prc_recipes WHERE name = $1', [src.rows[0].name]);
    const code = await nextCode(client, 'RCP', 3, false);
    const r = await client.query(
      `INSERT INTO prc_recipes (recipe_code, name, crop, version, target_moisture_pct, notes, created_by) VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *`,
      [code, src.rows[0].name, src.rows[0].crop, max.rows[0].v + 1, optionalNumber(input.targetMoisturePct, 'targetMoisturePct', { positive: true, max: 30 }) ?? src.rows[0].target_moisture_pct, optionalText(input.notes, 'notes', 2000), user.email],
    );
    await insertParts(client, r.rows[0].id, stages, chemicals);
    await insertAuditLog(client, { entityType: 'processing_recipe', entityId: r.rows[0].id, action: 'REVISE', performedBy: user.email, metadata: { from: id } });
    return getRecipe(r.rows[0].id, client);
  });
}

export async function submitRecipe(id: string, user: AuthenticatedUser) {
  return withTransaction(async (client) => {
    const r = await client.query('SELECT * FROM prc_recipes WHERE id = $1 FOR UPDATE', [id]);
    const recipe = r.rows[0];
    if (!recipe) throw new NotFoundError('Recipe not found');
    if (recipe.status !== 'draft' && recipe.status !== 'rejected') throw new ConflictError(`Only a draft recipe can be submitted (this one is ${recipe.status})`);
    if (recipe.created_by !== user.email) throw new ForbiddenError('The author submits the recipe');
    await client.query(`UPDATE prc_recipes SET status = 'pending_approval', rejection_reason = NULL WHERE id = $1`, [id]);
    await submitForApprovalTx(client, { entityType: 'processing_recipe', entityId: id, entityCode: `${recipe.recipe_code} v${recipe.version}`, title: `${recipe.name} (${recipe.crop})` }, user);
    return getRecipe(id, client);
  });
}

export async function retireRecipe(id: string, user: AuthenticatedUser) {
  return withTransaction(async (client) => {
    const r = await client.query(`UPDATE prc_recipes SET status = 'retired' WHERE id = $1 AND status = 'approved' RETURNING id`, [id]);
    if (!r.rows[0]) throw new ConflictError('Only an approved recipe can be retired');
    await insertAuditLog(client, { entityType: 'processing_recipe', entityId: id, action: 'RETIRE', performedBy: user.email });
    return getRecipe(id, client);
  });
}

export async function listRecipes(filters: { crop?: string; status?: string }) {
  const where: string[] = [];
  const values: unknown[] = [];
  if (filters.crop) {
    values.push(filters.crop);
    where.push(`r.crop = $${values.length}`);
  }
  if (filters.status) {
    values.push(filters.status);
    where.push(`r.status = $${values.length}`);
  }
  const q = await pool.query(
    `SELECT r.*, (SELECT string_agg(s.stage, ' → ' ORDER BY s.seq) FROM prc_recipe_stages s WHERE s.recipe_id = r.id) AS stage_path,
            EXISTS (SELECT 1 FROM prc_recipe_chemicals c WHERE c.recipe_id = r.id) AS has_treatment
       FROM prc_recipes r ${where.length ? `WHERE ${where.join(' AND ')}` : ''} ORDER BY r.name, r.version DESC`,
    values,
  );
  return q.rows;
}

export async function getRecipe(id: string, client?: PoolClient) {
  const db = client ?? pool;
  const r = await db.query('SELECT * FROM prc_recipes WHERE id = $1', [id]);
  if (!r.rows[0]) throw new NotFoundError('Recipe not found');
  const stages = await db.query('SELECT * FROM prc_recipe_stages WHERE recipe_id = $1 ORDER BY seq', [id]);
  const chemicals = await db.query('SELECT * FROM prc_recipe_chemicals WHERE recipe_id = $1 ORDER BY chemical_name', [id]);
  const approvals = await getApprovalsForEntity('processing_recipe', id, client);
  return { ...r.rows[0], stages: stages.rows, chemicals: chemicals.rows, approvals };
}
