import type { PoolClient } from 'pg';
import { pool } from '../../db/pool';
import { withTransaction } from '../../db/transaction';
import { ConflictError, NotFoundError, ValidationError } from '../../errors';
import type { AuthenticatedUser } from '../../middleware/requireAuth';
import { insertAuditLog } from '../auditLogs/auditLogs.service';
import { appendHashChainEntry } from '../authenticity/authenticity.service';
import { registerInspectionSubject } from '../inspections/inspections.service';
import { insertNcrTx } from '../quality/ncr.service';
import { refreshGenealogyView } from '../seedLots/genealogy.service';
import {
  asRecord,
  nextCode,
  num,
  optionalDate,
  optionalNumber,
  optionalText,
  optionalUuid,
  requireArray,
  requireEnum,
  requireNumber,
  requireText,
  requireUuid,
  round2,
} from '../shared/validate';

/** Treatment chemical use may differ from dose × weight by this fraction before a reason is required. */
const TREATMENT_TOLERANCE = 0.1;

// ---------------------------------------------------------------- raw intake

registerInspectionSubject('raw_intake', {
  resolveSubject: async (client, id) => {
    const r = await client.query('SELECT intake_number, status, crop, variety, quantity_kg FROM prc_raw_intakes WHERE id = $1', [id]);
    const x = r.rows[0];
    if (!x) throw new NotFoundError('Raw intake not found');
    if (x.status !== 'awaiting_check' && x.status !== 'on_hold') throw new ConflictError(`${x.intake_number} is already ${x.status}`);
    return { label: `${x.intake_number} · ${x.crop} ${x.variety} · ${num(x.quantity_kg)} kg`, seedLotId: null };
  },
  onSubmitted: async (client, ins, user) => {
    const id = ins.subject_id!;
    const r = await client.query('SELECT * FROM prc_raw_intakes WHERE id = $1 FOR UPDATE', [id]);
    const intake = r.rows[0];
    let status: string;
    let qty = num(intake.quantity_kg);
    if (ins.decision === 'accept') status = 'ready';
    else if (ins.decision === 'partial_accept') {
      qty = Math.min(qty, num(ins.accepted_quantity));
      status = qty > 0 ? 'ready' : 'rejected';
    } else if (ins.decision === 'reject') status = 'rejected';
    else status = 'on_hold';
    await client.query('UPDATE prc_raw_intakes SET status = $2, quantity_kg = $3, pre_inspection_id = $4 WHERE id = $1', [id, status, qty, ins.id]);
    await insertAuditLog(client, { entityType: 'raw_intake', entityId: id, action: 'PRE_CHECK', performedBy: user.email, afterState: { status, qty, inspection: ins.inspection_code } });
  },
});

export async function intakeCandidates() {
  const deliveries = await pool.query(
    `SELECT d.id, d.delivery_number AS ref, 'grower_delivery' AS source_type, p.name AS party_name, a.crop, a.variety, a.seed_class,
            COALESCE(CASE WHEN i.decision = 'partial_accept' THEN LEAST(i.accepted_quantity, d.net_weight_kg) END, d.net_weight_kg) AS quantity_kg,
            d.moisture_pct, d.delivered_at AS received_at
       FROM grw_deliveries d JOIN grw_agreements a ON a.id = d.agreement_id JOIN parties p ON p.id = d.grower_id
       LEFT JOIN inspections i ON i.id = d.inspection_id
      WHERE d.status = 'accepted' AND NOT EXISTS (SELECT 1 FROM prc_raw_intakes x WHERE x.grower_delivery_id = d.id)
      ORDER BY d.delivered_at`,
  );
  const receipts = await pool.query(
    `SELECT g.id, g.grn_number AS ref, 'goods_receipt' AS source_type, p.name AS party_name, it.crop, it.variety, 'Certified' AS seed_class,
            SUM(gl.accepted_quantity) AS quantity_kg, NULL::numeric AS moisture_pct, g.received_at
       FROM proc_goods_receipts g JOIN parties p ON p.id = g.supplier_id
       JOIN proc_grn_lines gl ON gl.grn_id = g.id JOIN proc_po_lines l ON l.id = gl.po_line_id JOIN proc_items it ON it.id = l.item_id
      WHERE g.status IN ('accepted', 'partially_accepted') AND it.category = 'seed' AND gl.accepted_quantity > 0
        AND NOT EXISTS (SELECT 1 FROM prc_raw_intakes x WHERE x.goods_receipt_id = g.id)
      GROUP BY g.id, p.name, it.crop, it.variety ORDER BY g.received_at`,
  );
  return [...deliveries.rows, ...receipts.rows].map((r) => ({ ...r, quantity_kg: num(r.quantity_kg) }));
}

export async function createIntake(input: Record<string, unknown>, user: AuthenticatedUser) {
  const sourceType = requireEnum(input.sourceType, ['grower_delivery', 'goods_receipt'] as const, 'sourceType');
  const sourceId = requireUuid(input.sourceId, 'sourceId');
  const plantId = requireUuid(input.plantId, 'plantId');
  return withTransaction(async (client) => {
    const plant = await client.query(`SELECT status FROM prc_plants WHERE id = $1`, [plantId]);
    if (!plant.rows[0]) throw new NotFoundError('Plant not found');
    if (plant.rows[0].status !== 'active') throw new ConflictError('That plant is inactive');
    const candidates = await intakeCandidates();
    const c = candidates.find((x) => x.id === sourceId && x.source_type === sourceType);
    if (!c) throw new ConflictError('That delivery or receipt is not accepted, is not seed, or has already been taken into the plant');
    let growerId: string | null = null;
    let supplierId: string | null = null;
    let parentLotId: string | null = null;
    if (sourceType === 'grower_delivery') {
      const d = await client.query('SELECT d.grower_id, a.parent_lot_id FROM grw_deliveries d JOIN grw_agreements a ON a.id = d.agreement_id WHERE d.id = $1', [sourceId]);
      growerId = d.rows[0].grower_id;
      parentLotId = d.rows[0].parent_lot_id;
    } else {
      const g = await client.query('SELECT supplier_id FROM proc_goods_receipts WHERE id = $1', [sourceId]);
      supplierId = g.rows[0].supplier_id;
    }
    const code = await nextCode(client, 'RI', 5, true);
    const r = await client.query(
      `INSERT INTO prc_raw_intakes (intake_number, source_type, grower_delivery_id, goods_receipt_id, grower_id, supplier_id, plant_id, crop, variety, seed_class, parent_lot_id, quantity_kg, moisture_pct, received_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14) RETURNING *`,
      [code, sourceType, sourceType === 'grower_delivery' ? sourceId : null, sourceType === 'goods_receipt' ? sourceId : null, growerId, supplierId, plantId, c.crop, c.variety, c.seed_class, parentLotId, c.quantity_kg, c.moisture_pct, user.email],
    );
    await insertAuditLog(client, { entityType: 'raw_intake', entityId: r.rows[0].id, action: 'CREATE', performedBy: user.email, afterState: r.rows[0] });
    return r.rows[0];
  });
}

export async function listIntakes(filters: { status?: string }) {
  const values: unknown[] = [];
  let where = '';
  if (filters.status) {
    values.push(filters.status);
    where = 'WHERE x.status = $1';
  }
  const r = await pool.query(
    `SELECT x.*, pl.code AS plant_code, COALESCE(g.name, s.name) AS source_party, d.delivery_number, gr.grn_number, l.lot_code AS parent_lot_code,
            i.inspection_code, i.result AS inspection_result, x.quantity_kg - x.consumed_kg AS available_kg
       FROM prc_raw_intakes x
       JOIN prc_plants pl ON pl.id = x.plant_id
       LEFT JOIN parties g ON g.id = x.grower_id
       LEFT JOIN parties s ON s.id = x.supplier_id
       LEFT JOIN grw_deliveries d ON d.id = x.grower_delivery_id
       LEFT JOIN proc_goods_receipts gr ON gr.id = x.goods_receipt_id
       LEFT JOIN seed_lots l ON l.id = x.parent_lot_id
       LEFT JOIN inspections i ON i.id = x.pre_inspection_id
       ${where} ORDER BY x.created_at DESC LIMIT 500`,
    values,
  );
  return r.rows;
}

// ------------------------------------------------------------------- batches

registerInspectionSubject('processing_batch', {
  resolveSubject: async (client, id) => {
    const r = await client.query('SELECT batch_number, status, crop, variety FROM prc_batches WHERE id = $1', [id]);
    const b = r.rows[0];
    if (!b) throw new NotFoundError('Batch not found');
    if (b.status !== 'in_progress') throw new ConflictError(`${b.batch_number} is ${b.status}; checkpoints are recorded while it is in progress`);
    return { label: `${b.batch_number} · ${b.crop} ${b.variety}`, seedLotId: null };
  },
});

async function lockBatch(client: PoolClient, id: string) {
  const r = await client.query('SELECT * FROM prc_batches WHERE id = $1 FOR UPDATE', [id]);
  if (!r.rows[0]) throw new NotFoundError('Batch not found');
  return r.rows[0];
}

export async function createBatch(input: Record<string, unknown>, user: AuthenticatedUser) {
  const recipeId = requireUuid(input.recipeId, 'recipeId');
  const plantId = requireUuid(input.plantId, 'plantId');
  const plannedDate = optionalDate(input.plannedDate, 'plannedDate');
  const inputs = requireArray(input.inputs, 'inputs', { min: 1, max: 50 }).map((raw, i) => {
    const r = asRecord(raw, `inputs[${i}]`);
    return { rawIntakeId: requireUuid(r.rawIntakeId, `inputs[${i}].rawIntakeId`), quantityKg: requireNumber(r.quantityKg, `inputs[${i}].quantityKg`, { positive: true }) };
  });
  if (new Set(inputs.map((x) => x.rawIntakeId)).size !== inputs.length) throw new ValidationError('Each intake may appear once in a batch');

  return withTransaction(async (client) => {
    const rec = await client.query('SELECT * FROM prc_recipes WHERE id = $1', [recipeId]);
    const recipe = rec.rows[0];
    if (!recipe) throw new NotFoundError('Recipe not found');
    // Only an approved recipe may run on the line.
    if (recipe.status !== 'approved') throw new ConflictError(`Recipe ${recipe.recipe_code} v${recipe.version} is ${recipe.status}; only an approved recipe can start a batch`);
    const plant = await client.query('SELECT status FROM prc_plants WHERE id = $1', [plantId]);
    if (!plant.rows[0] || plant.rows[0].status !== 'active') throw new ConflictError('Choose an active plant');

    const rows = [];
    for (const x of inputs) {
      const r = await client.query('SELECT * FROM prc_raw_intakes WHERE id = $1 FOR UPDATE', [x.rawIntakeId]);
      const intake = r.rows[0];
      if (!intake) throw new NotFoundError('Raw intake not found');
      if (intake.status !== 'ready') throw new ConflictError(`${intake.intake_number} is ${intake.status.replace('_', ' ')} — it needs a passed pre-processing check`);
      if (intake.crop !== recipe.crop) throw new ValidationError(`${intake.intake_number} is ${intake.crop}; the recipe is for ${recipe.crop}`);
      const available = num(intake.quantity_kg) - num(intake.consumed_kg);
      if (x.quantityKg > available + 1e-9) throw new ConflictError(`${intake.intake_number} has ${available} kg available`);
      rows.push({ ...intake, take: x.quantityKg });
    }
    // A batch is one variety and one seed class — mixing would make the lot's identity false.
    if (new Set(rows.map((r) => `${r.variety}|${r.seed_class}`)).size > 1) throw new ValidationError('All inputs of a batch must be the same variety and seed class');
    const withParent = rows.filter((r) => r.parent_lot_id).sort((a, b) => b.take - a.take);
    const parentLotId = withParent[0]?.parent_lot_id ?? null;
    const total = round2(rows.reduce((s, r) => s + r.take, 0));

    const code = await nextCode(client, 'PB', 4, true);
    const chem = await client.query('SELECT 1 FROM prc_recipe_chemicals WHERE recipe_id = $1 LIMIT 1', [recipeId]);
    const b = await client.query(
      `INSERT INTO prc_batches (batch_number, recipe_id, plant_id, crop, variety, seed_class, parent_lot_id, input_kg, planned_date, is_treated, notes, created_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, COALESCE($9::date, CURRENT_DATE), $10, $11, $12) RETURNING *`,
      [code, recipeId, plantId, recipe.crop, rows[0].variety, rows[0].seed_class, parentLotId, total, plannedDate, !!chem.rows[0], optionalText(input.notes, 'notes', 2000), user.email],
    );
    const batch = b.rows[0];
    for (const r of rows) {
      await client.query('INSERT INTO prc_batch_inputs (batch_id, raw_intake_id, quantity_kg) VALUES ($1, $2, $3)', [batch.id, r.id, r.take]);
      // reserve the seed so two batches cannot draw the same kilograms
      await client.query('UPDATE prc_raw_intakes SET consumed_kg = consumed_kg + $2 WHERE id = $1', [r.id, r.take]);
    }
    await client.query(
      `INSERT INTO prc_batch_stages (batch_id, seq, stage, max_loss_pct, parameters) SELECT $1, seq, stage, max_loss_pct, parameters FROM prc_recipe_stages WHERE recipe_id = $2`,
      [batch.id, recipeId],
    );
    await insertAuditLog(client, { entityType: 'processing_batch', entityId: batch.id, action: 'CREATE', performedBy: user.email, afterState: { ...batch, inputs } });
    return getBatch(batch.id, client);
  });
}

export async function startBatch(id: string, user: AuthenticatedUser) {
  return withTransaction(async (client) => {
    const b = await lockBatch(client, id);
    if (b.status !== 'planned') throw new ConflictError(`Only a planned batch can start (this one is ${b.status})`);
    await client.query(`UPDATE prc_batches SET status = 'in_progress', started_at = now() WHERE id = $1`, [id]);
    await insertAuditLog(client, { entityType: 'processing_batch', entityId: id, action: 'START', performedBy: user.email });
    return getBatch(id, client);
  });
}

export async function recordTreatment(id: string, input: Record<string, unknown>, user: AuthenticatedUser) {
  const chemicalName = requireText(input.chemicalName, 'chemicalName', 150);
  const quantityUsed = requireNumber(input.quantityUsed, 'quantityUsed', { positive: true });
  const supplierLot = requireText(input.supplierLot, 'supplierLot (the chemical batch number)', 60);
  const deviationReason = optionalText(input.deviationReason, 'deviationReason', 1000);
  return withTransaction(async (client) => {
    const b = await lockBatch(client, id);
    if (b.status !== 'in_progress') throw new ConflictError('Treatment is recorded while the batch is in progress');
    const chem = await client.query('SELECT * FROM prc_recipe_chemicals WHERE recipe_id = $1 AND chemical_name = $2', [b.recipe_id, chemicalName]);
    if (!chem.rows[0]) throw new ValidationError(`${chemicalName} is not in the approved recipe`);
    const stages = await client.query('SELECT * FROM prc_batch_stages WHERE batch_id = $1 ORDER BY seq', [id]);
    const tIdx = stages.rows.findIndex((s) => s.stage === 'treatment');
    if (tIdx < 0) throw new ValidationError('This recipe has no treatment stage');
    if (stages.rows[tIdx].output_kg !== null) throw new ConflictError('The treatment stage is already recorded');
    const prev = tIdx === 0 ? num(b.input_kg) : stages.rows[tIdx - 1].output_kg;
    if (prev === null) throw new ConflictError('Record the stages before treatment first');
    const kg = num(prev);
    const expected = round2(num(chem.rows[0].dose_per_kg) * kg);
    if (Math.abs(quantityUsed - expected) > expected * TREATMENT_TOLERANCE && !deviationReason) {
      throw new ValidationError(`Expected about ${expected} ${chem.rows[0].dose_unit} for ${kg} kg at ${num(chem.rows[0].dose_per_kg)} ${chem.rows[0].dose_unit}/kg; give a deviationReason for ${quantityUsed}`);
    }
    const already = await client.query('SELECT 1 FROM prc_batch_treatments WHERE batch_id = $1 AND chemical_name = $2', [id, chemicalName]);
    if (already.rows[0]) throw new ConflictError(`${chemicalName} is already recorded for this batch`);
    const r = await client.query(
      `INSERT INTO prc_batch_treatments (batch_id, chemical_name, dose_per_kg, dose_unit, expected_quantity, quantity_used, supplier_lot, deviation_reason, applied_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9) RETURNING *`,
      [id, chemicalName, chem.rows[0].dose_per_kg, chem.rows[0].dose_unit, expected, quantityUsed, supplierLot, deviationReason, user.email],
    );
    await insertAuditLog(client, { entityType: 'processing_batch', entityId: id, action: 'TREATMENT', performedBy: user.email, afterState: r.rows[0] });
    return getBatch(id, client);
  });
}

/**
 * Records one stage. Its input is the previous stage's output, so weights
 * chain through the batch and input = output + every recorded loss holds by
 * construction. A loss above the recipe's limit needs a reason and raises a
 * process-deviation non-conformance.
 */
export async function recordStage(id: string, seq: number, input: Record<string, unknown>, user: AuthenticatedUser) {
  const outputKg = requireNumber(input.outputKg, 'outputKg', { min: 0 });
  const machineId = optionalUuid(input.machineId, 'machineId');
  const lossReason = optionalText(input.lossReason, 'lossReason', 1000);
  const actual = optionalText(input.actualParameters, 'actualParameters', 1000);
  return withTransaction(async (client) => {
    const b = await lockBatch(client, id);
    if (b.status !== 'in_progress') throw new ConflictError(`Stages are recorded while the batch is in progress (this one is ${b.status})`);
    const stages = await client.query('SELECT * FROM prc_batch_stages WHERE batch_id = $1 ORDER BY seq', [id]);
    const idx = stages.rows.findIndex((s) => s.seq === seq);
    if (idx < 0) throw new NotFoundError('Stage not found');
    const stage = stages.rows[idx];
    if (stage.output_kg !== null) throw new ConflictError('This stage is already recorded');
    const firstOpen = stages.rows.findIndex((s) => s.output_kg === null);
    if (firstOpen !== idx) throw new ConflictError(`Record stage ${stages.rows[firstOpen].seq} (${stages.rows[firstOpen].stage.replace('_', ' ')}) first`);
    const inputKg = idx === 0 ? num(b.input_kg) : num(stages.rows[idx - 1].output_kg);
    if (outputKg > inputKg + 1e-9) throw new ValidationError(`Output (${outputKg} kg) cannot exceed the stage input (${inputKg} kg)`);

    if (machineId) {
      const m = await client.query('SELECT status, plant_id, machine_type, code FROM prc_machines WHERE id = $1', [machineId]);
      const machine = m.rows[0];
      if (!machine) throw new NotFoundError('Machine not found');
      if (machine.plant_id !== b.plant_id) throw new ValidationError(`${machine.code} is in a different plant`);
      if (machine.status !== 'available') throw new ConflictError(`${machine.code} is ${machine.status}`);
    }
    if (stage.stage === 'treatment') {
      const chems = await client.query('SELECT chemical_name FROM prc_recipe_chemicals WHERE recipe_id = $1', [b.recipe_id]);
      const done = await client.query('SELECT chemical_name FROM prc_batch_treatments WHERE batch_id = $1', [id]);
      const missing = chems.rows.filter((c) => !done.rows.some((d) => d.chemical_name === c.chemical_name));
      if (missing.length) throw new ConflictError(`Record the treatment applied first: ${missing.map((m) => m.chemical_name).join(', ')}`);
    }
    const loss = round2(inputKg - outputKg);
    const lossPct = inputKg > 0 ? round2((loss / inputKg) * 100) : 0;
    let ncrId: string | null = null;
    if (lossPct > num(stage.max_loss_pct)) {
      if (!lossReason) throw new ValidationError(`Loss of ${lossPct}% is above the recipe limit of ${num(stage.max_loss_pct)}% — give a lossReason`);
      const { ncr } = await insertNcrTx(
        client,
        {
          title: `${b.batch_number}: ${stage.stage.replace('_', ' ')} loss ${lossPct}% above ${num(stage.max_loss_pct)}% limit`,
          description: `Batch ${b.batch_number} (${b.crop} ${b.variety}) lost ${loss} kg of ${inputKg} kg at ${stage.stage.replace('_', ' ')}. Reason given: ${lossReason}`,
          department: 'production',
          source: 'process_deviation',
          severity: lossPct > num(stage.max_loss_pct) * 2 ? 'major' : 'minor',
          seedLotId: null,
          assignedTo: null,
          dueDate: null,
        },
        user,
      );
      ncrId = ncr.id;
    }
    await client.query(
      `UPDATE prc_batch_stages SET input_kg = $2, output_kg = $3, loss_kg = $4, loss_pct = $5, loss_reason = $6, actual_parameters = $7, machine_id = $8,
              operator_email = $9, started_at = COALESCE(started_at, now()), completed_at = now(), ncr_id = $10 WHERE id = $1`,
      [stage.id, inputKg, outputKg, loss, lossPct, lossReason, actual, machineId, user.email, ncrId],
    );
    await insertAuditLog(client, { entityType: 'processing_batch', entityId: id, action: 'STAGE', performedBy: user.email, afterState: { seq, stage: stage.stage, inputKg, outputKg, lossPct, ncrId } });
    return getBatch(id, client);
  });
}

function cropCode(crop: string): string {
  const letters = crop.replace(/[^A-Za-z]/g, '').toUpperCase();
  return (letters.slice(0, 3) || 'SED').padEnd(3, 'X');
}

/**
 * Completes the batch: every stage weighed, a final inspection passed, then
 * the seed lot is created with its parent set to the seed the grower was
 * issued — so the lot's genealogy and this batch record tell the same story.
 */
export async function completeBatch(id: string, input: Record<string, unknown>, user: AuthenticatedUser) {
  const lowStock = optionalNumber(input.lowStockThreshold, 'lowStockThreshold', { min: 0 });
  return withTransaction(async (client) => {
    const b = await lockBatch(client, id);
    if (b.status !== 'in_progress') throw new ConflictError(`Only a batch in progress can be completed (this one is ${b.status})`);
    const stages = await client.query('SELECT * FROM prc_batch_stages WHERE batch_id = $1 ORDER BY seq', [id]);
    const open = stages.rows.filter((s) => s.output_kg === null);
    if (open.length) throw new ConflictError(`Record every stage first: ${open.map((s) => s.stage.replace('_', ' ')).join(', ')}`);
    const final = await client.query(
      `SELECT inspection_code, result, decision, accepted_quantity FROM inspections
        WHERE subject_type = 'processing_batch' AND subject_id = $1 AND inspection_type = 'processing_final' AND status = 'submitted'
        ORDER BY submitted_at DESC LIMIT 1`,
      [id],
    );
    const fi = final.rows[0];
    if (!fi) throw new ConflictError('A final inspection must be submitted before the batch can be completed');
    if (fi.result === 'fail' || !['accept', 'partial_accept'].includes(fi.decision)) {
      throw new ConflictError(`Final inspection ${fi.inspection_code} did not accept the batch (${fi.result}, ${fi.decision}) — rework or cancel it`);
    }
    let output = num(stages.rows[stages.rows.length - 1].output_kg);
    if (fi.decision === 'partial_accept') output = Math.min(output, num(fi.accepted_quantity));
    if (output <= 0) throw new ConflictError('The batch produced no accepted seed');
    // Mass balance check (belt and braces: the stage chain guarantees it).
    const losses = stages.rows.reduce((s, x) => s + num(x.loss_kg), 0);
    if (Math.abs(num(b.input_kg) - num(stages.rows[stages.rows.length - 1].output_kg) - losses) > 0.05) {
      throw new ConflictError('The batch weights do not balance; check the stage records');
    }

    const stage = b.seed_class;
    let parent = b.parent_lot_id;
    const productionDate = new Date().toISOString().slice(0, 10);
    if (parent) {
      const p = await client.query('SELECT stage, production_date FROM seed_lots WHERE id = $1', [parent]);
      const expectedParent = stage === 'Foundation' ? 'Breeder' : 'Foundation';
      if (p.rows[0].stage !== expectedParent) parent = null; // keep the lot valid; the batch record still holds the link
      else if (new Date(p.rows[0].production_date).toISOString().slice(0, 10) >= productionDate) parent = null;
    }
    const treatments = await client.query('SELECT chemical_name, dose_per_kg, dose_unit, supplier_lot FROM prc_batch_treatments WHERE batch_id = $1', [id]);
    const notes = [
      `Processed in batch ${b.batch_number}.`,
      treatments.rows.length ? `TREATED SEED: ${treatments.rows.map((t) => `${t.chemical_name} ${num(t.dose_per_kg)} ${t.dose_unit}/kg (lot ${t.supplier_lot})`).join('; ')}. Do not use for food or feed.` : '',
    ]
      .filter(Boolean)
      .join(' ');
    const lotCode = await nextCode(client, `LOT-${cropCode(b.crop)}`, 4, true);
    const lot = await client.query(
      `INSERT INTO seed_lots (lot_code, crop, variety, parent_lot_id, stage, quantity_total, unit, notes, organization_id, low_stock_threshold, production_date)
       VALUES ($1, $2, $3, $4, $5, $6, 'kg', $7, $8, COALESCE($9::numeric, 100), $10) RETURNING *`,
      [lotCode, b.crop, b.variety, parent, stage, output, notes, user.organizationId, lowStock, productionDate],
    );
    const created = lot.rows[0];
    await insertAuditLog(client, { entityType: 'seed_lot', entityId: created.id, action: 'CREATE', performedBy: user.email, afterState: created, metadata: { batch: b.batch_number } });
    await appendHashChainEntry(client, created.id, 'CREATE', created, user);

    await client.query(`UPDATE prc_batches SET status = 'completed', output_kg = $2, output_lot_id = $3, completed_at = now(), completed_by = $4 WHERE id = $1`, [id, output, created.id, user.email]);
    await client.query(
      `UPDATE prc_raw_intakes x SET status = 'consumed' FROM prc_batch_inputs bi WHERE bi.batch_id = $1 AND bi.raw_intake_id = x.id AND x.consumed_kg >= x.quantity_kg`,
      [id],
    );
    await insertAuditLog(client, { entityType: 'processing_batch', entityId: id, action: 'COMPLETE', performedBy: user.email, afterState: { output, lot: lotCode } });
    return { batch: await getBatch(id, client), lot: created };
  }).then((r) => {
    refreshGenealogyView();
    return r;
  });
}

export async function cancelBatch(id: string, input: Record<string, unknown>, user: AuthenticatedUser) {
  const reason = requireText(input.reason, 'reason', 1000);
  return withTransaction(async (client) => {
    const b = await lockBatch(client, id);
    if (!['planned', 'in_progress'].includes(b.status)) throw new ConflictError(`A ${b.status} batch cannot be cancelled`);
    const done = await client.query('SELECT 1 FROM prc_batch_stages WHERE batch_id = $1 AND output_kg IS NOT NULL LIMIT 1', [id]);
    if (done.rows[0]) throw new ConflictError('Seed has already been processed in this batch — complete it (a failed final inspection keeps the seed out of stock) rather than cancel it');
    const inputs = await client.query('SELECT raw_intake_id, quantity_kg FROM prc_batch_inputs WHERE batch_id = $1', [id]);
    for (const x of inputs.rows) await client.query('UPDATE prc_raw_intakes SET consumed_kg = GREATEST(0, consumed_kg - $2) WHERE id = $1', [x.raw_intake_id, x.quantity_kg]);
    await client.query(`UPDATE prc_batches SET status = 'cancelled', cancel_reason = $2 WHERE id = $1`, [id, reason]);
    await insertAuditLog(client, { entityType: 'processing_batch', entityId: id, action: 'CANCEL', performedBy: user.email, metadata: { reason } });
    return getBatch(id, client);
  });
}

export async function listBatches(filters: { status?: string }) {
  const values: unknown[] = [];
  let where = '';
  if (filters.status) {
    values.push(filters.status);
    where = 'WHERE b.status = $1';
  }
  const r = await pool.query(
    `SELECT b.*, r.recipe_code, r.name AS recipe_name, r.version AS recipe_version, p.code AS plant_code, l.lot_code AS output_lot_code,
            (SELECT COUNT(*)::int FROM prc_batch_stages s WHERE s.batch_id = b.id AND s.output_kg IS NOT NULL) AS stages_done,
            (SELECT COUNT(*)::int FROM prc_batch_stages s WHERE s.batch_id = b.id) AS stages_total,
            (SELECT COALESCE(SUM(loss_kg), 0) FROM prc_batch_stages s WHERE s.batch_id = b.id) AS loss_kg,
            EXISTS (SELECT 1 FROM prc_batch_stages s WHERE s.batch_id = b.id AND s.loss_pct > s.max_loss_pct) AS loss_exceeded
       FROM prc_batches b JOIN prc_recipes r ON r.id = b.recipe_id JOIN prc_plants p ON p.id = b.plant_id LEFT JOIN seed_lots l ON l.id = b.output_lot_id
       ${where} ORDER BY b.created_at DESC LIMIT 500`,
    values,
  );
  return r.rows;
}

export async function getBatch(id: string, client?: PoolClient) {
  const db = client ?? pool;
  const r = await db.query(
    `SELECT b.*, r.recipe_code, r.name AS recipe_name, r.version AS recipe_version, p.code AS plant_code, p.name AS plant_name,
            l.lot_code AS output_lot_code, pl.lot_code AS parent_lot_code
       FROM prc_batches b JOIN prc_recipes r ON r.id = b.recipe_id JOIN prc_plants p ON p.id = b.plant_id
       LEFT JOIN seed_lots l ON l.id = b.output_lot_id LEFT JOIN seed_lots pl ON pl.id = b.parent_lot_id
      WHERE b.id = $1`,
    [id],
  );
  if (!r.rows[0]) throw new NotFoundError('Batch not found');
  const inputs = await db.query(
    `SELECT bi.*, x.intake_number, x.source_type, COALESCE(g.name, s.name) AS source_party, d.delivery_number
       FROM prc_batch_inputs bi JOIN prc_raw_intakes x ON x.id = bi.raw_intake_id
       LEFT JOIN parties g ON g.id = x.grower_id LEFT JOIN parties s ON s.id = x.supplier_id LEFT JOIN grw_deliveries d ON d.id = x.grower_delivery_id
      WHERE bi.batch_id = $1`,
    [id],
  );
  const stages = await db.query(`SELECT s.*, m.code AS machine_code, n.ncr_code FROM prc_batch_stages s LEFT JOIN prc_machines m ON m.id = s.machine_id LEFT JOIN non_conformances n ON n.id = s.ncr_id WHERE s.batch_id = $1 ORDER BY s.seq`, [id]);
  const treatments = await db.query('SELECT * FROM prc_batch_treatments WHERE batch_id = $1 ORDER BY applied_at', [id]);
  const chemicals = await db.query('SELECT * FROM prc_recipe_chemicals WHERE recipe_id = $1', [r.rows[0].recipe_id]);
  const inspections = await db.query(
    `SELECT id, inspection_code, inspection_type, status, result, decision, created_at FROM inspections WHERE subject_type = 'processing_batch' AND subject_id = $1 ORDER BY created_at`,
    [id],
  );
  return { ...r.rows[0], inputs: inputs.rows, stages: stages.rows, treatments: treatments.rows, chemicals: chemicals.rows, inspections: inspections.rows };
}

/** One lot, traced back through its batch to every grower delivery and the seed those growers were given. */
export async function traceLot(lotId: string) {
  const lot = await pool.query('SELECT id, lot_code, crop, variety, stage, quantity_total, production_date, notes, parent_lot_id FROM seed_lots WHERE id = $1', [lotId]);
  if (!lot.rows[0]) throw new NotFoundError('Seed lot not found');
  const batch = await pool.query('SELECT id FROM prc_batches WHERE output_lot_id = $1', [lotId]);
  const parent = lot.rows[0].parent_lot_id ? (await pool.query('SELECT id, lot_code, stage, variety FROM seed_lots WHERE id = $1', [lot.rows[0].parent_lot_id])).rows[0] : null;
  if (!batch.rows[0]) return { lot: lot.rows[0], parent, batch: null, sources: [] };
  const b = await getBatch(batch.rows[0].id);
  const sources = await pool.query(
    `SELECT x.intake_number, x.source_type, bi.quantity_kg,
            d.delivery_number, d.delivered_at, d.net_weight_kg, d.moisture_pct, d.purity_pct,
            a.agreement_number, a.plot_village, a.plot_survey_number, a.area_acres, a.season, a.season_year,
            g.party_code AS grower_code, g.name AS grower_name, g.village AS grower_village,
            pl.lot_code AS issued_lot_code,
            gr.grn_number, s.name AS supplier_name,
            di.inspection_code AS gate_inspection, pi.inspection_code AS pre_inspection
       FROM prc_batch_inputs bi
       JOIN prc_raw_intakes x ON x.id = bi.raw_intake_id
       LEFT JOIN grw_deliveries d ON d.id = x.grower_delivery_id
       LEFT JOIN grw_agreements a ON a.id = d.agreement_id
       LEFT JOIN parties g ON g.id = x.grower_id
       LEFT JOIN seed_lots pl ON pl.id = a.parent_lot_id
       LEFT JOIN proc_goods_receipts gr ON gr.id = x.goods_receipt_id
       LEFT JOIN parties s ON s.id = x.supplier_id
       LEFT JOIN inspections di ON di.id = COALESCE(d.inspection_id, gr.inspection_id)
       LEFT JOIN inspections pi ON pi.id = x.pre_inspection_id
      WHERE bi.batch_id = $1`,
    [b.id],
  );
  return { lot: lot.rows[0], parent, batch: b, sources: sources.rows };
}

export async function yieldReport() {
  const byBatch = await pool.query(
    `SELECT b.id, b.batch_number, b.crop, b.variety, b.status, b.input_kg, b.output_kg, b.completed_at,
            ROUND(100.0 * b.output_kg / NULLIF(b.input_kg, 0), 2) AS yield_pct,
            EXISTS (SELECT 1 FROM prc_batch_stages s WHERE s.batch_id = b.id AND s.loss_pct > s.max_loss_pct) AS loss_exceeded
       FROM prc_batches b WHERE b.status = 'completed' ORDER BY b.completed_at DESC LIMIT 200`,
  );
  const byStage = await pool.query(
    `SELECT s.stage, COUNT(*)::int AS records, ROUND(AVG(s.loss_pct), 2) AS avg_loss_pct, ROUND(AVG(s.max_loss_pct), 2) AS avg_limit_pct,
            COUNT(*) FILTER (WHERE s.loss_pct > s.max_loss_pct)::int AS over_limit
       FROM prc_batch_stages s WHERE s.output_kg IS NOT NULL GROUP BY s.stage ORDER BY MIN(s.seq)`,
  );
  const byVariety = await pool.query(
    `SELECT crop, variety, COUNT(*)::int AS batches, SUM(input_kg) AS input_kg, SUM(output_kg) AS output_kg, ROUND(100.0 * SUM(output_kg) / NULLIF(SUM(input_kg), 0), 2) AS yield_pct
       FROM prc_batches WHERE status = 'completed' GROUP BY crop, variety ORDER BY crop, variety`,
  );
  return { byBatch: byBatch.rows, byStage: byStage.rows, byVariety: byVariety.rows };
}

export async function processingDashboard() {
  const c = await pool.query(`
    SELECT
      (SELECT COUNT(*) FROM prc_raw_intakes WHERE status = 'awaiting_check')::int AS intakes_awaiting_check,
      (SELECT COALESCE(SUM(quantity_kg - consumed_kg), 0) FROM prc_raw_intakes WHERE status = 'ready') AS raw_ready_kg,
      (SELECT COUNT(*) FROM prc_batches WHERE status = 'planned')::int AS batches_planned,
      (SELECT COUNT(*) FROM prc_batches WHERE status = 'in_progress')::int AS batches_running,
      (SELECT COUNT(*) FROM prc_batches WHERE status = 'completed' AND completed_at >= now() - interval '30 days')::int AS batches_completed_30d,
      (SELECT ROUND(100.0 * SUM(output_kg) / NULLIF(SUM(input_kg), 0), 2) FROM prc_batches WHERE status = 'completed' AND completed_at >= now() - interval '90 days') AS yield_pct_90d,
      (SELECT COUNT(*) FROM prc_machines WHERE status IN ('maintenance', 'breakdown'))::int AS machines_down,
      (SELECT COUNT(*) FROM prc_machines WHERE next_service_due < CURRENT_DATE AND status <> 'retired')::int AS machines_service_overdue,
      (SELECT COUNT(*) FROM prc_recipes WHERE status = 'pending_approval')::int AS recipes_pending
  `);
  const candidates = await intakeCandidates();
  return { counts: { ...c.rows[0], raw_ready_kg: num(c.rows[0].raw_ready_kg), yield_pct_90d: c.rows[0].yield_pct_90d === null ? null : num(c.rows[0].yield_pct_90d) }, waitingForIntake: candidates.length };
}
