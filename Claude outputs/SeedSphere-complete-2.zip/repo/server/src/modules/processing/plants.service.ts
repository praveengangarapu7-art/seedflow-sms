import { pool } from '../../db/pool';
import { withTransaction } from '../../db/transaction';
import { ConflictError, NotFoundError } from '../../errors';
import type { AuthenticatedUser } from '../../middleware/requireAuth';
import { insertAuditLog } from '../auditLogs/auditLogs.service';
import { addDaysIso, optionalDate, optionalNumber, optionalText, requireDate, requireEnum, requireText, requireUuid, todayIso } from '../shared/validate';

export const MACHINE_TYPES = ['pre_cleaner', 'dryer', 'cleaner_grader', 'gravity_separator', 'treater', 'packing', 'other'] as const;
export const MACHINE_STATUSES = ['available', 'maintenance', 'breakdown', 'retired'] as const;

export async function listPlants() {
  const r = await pool.query(
    `SELECT p.*,
            (SELECT COUNT(*)::int FROM prc_machines m WHERE m.plant_id = p.id AND m.status <> 'retired') AS machines,
            (SELECT COUNT(*)::int FROM prc_batches b WHERE b.plant_id = p.id AND b.status = 'in_progress') AS batches_running
       FROM prc_plants p ORDER BY p.code`,
  );
  return r.rows;
}

export async function createPlant(input: Record<string, unknown>, user: AuthenticatedUser) {
  const code = requireText(input.code, 'code', 20).toUpperCase();
  const name = requireText(input.name, 'name', 150);
  return withTransaction(async (client) => {
    const dup = await client.query('SELECT 1 FROM prc_plants WHERE code = $1', [code]);
    if (dup.rows[0]) throw new ConflictError(`Plant ${code} already exists`);
    const r = await client.query(
      `INSERT INTO prc_plants (code, name, location, capacity_kg_per_day, created_by) VALUES ($1, $2, $3, $4, $5) RETURNING *`,
      [code, name, optionalText(input.location, 'location', 200), optionalNumber(input.capacityKgPerDay, 'capacityKgPerDay', { positive: true }), user.email],
    );
    await insertAuditLog(client, { entityType: 'plant', entityId: r.rows[0].id, action: 'CREATE', performedBy: user.email, afterState: r.rows[0] });
    return r.rows[0];
  });
}

export async function listMachines(filters: { plantId?: string }) {
  const values: unknown[] = [];
  let where = '';
  if (filters.plantId) {
    values.push(filters.plantId);
    where = 'WHERE m.plant_id = $1';
  }
  const r = await pool.query(
    `SELECT m.*, p.code AS plant_code, p.name AS plant_name,
            (m.next_service_due IS NOT NULL AND m.next_service_due < CURRENT_DATE) AS service_overdue,
            (SELECT COUNT(*)::int FROM prc_maintenance x WHERE x.machine_id = m.id AND x.status = 'scheduled') AS scheduled_jobs,
            (SELECT COALESCE(SUM(downtime_hours), 0) FROM prc_maintenance x WHERE x.machine_id = m.id AND x.status = 'done' AND x.completed_at >= now() - interval '90 days') AS downtime_90d
       FROM prc_machines m JOIN prc_plants p ON p.id = m.plant_id ${where}
      ORDER BY p.code, m.code`,
    values,
  );
  return r.rows;
}

export async function createMachine(input: Record<string, unknown>, user: AuthenticatedUser) {
  const plantId = requireUuid(input.plantId, 'plantId');
  const code = requireText(input.code, 'code', 20).toUpperCase();
  const name = requireText(input.name, 'name', 150);
  const type = requireEnum(input.machineType, MACHINE_TYPES, 'machineType');
  const interval = optionalNumber(input.serviceIntervalDays, 'serviceIntervalDays', { positive: true, max: 730 }) ?? 90;
  const lastService = optionalDate(input.lastServiceDate, 'lastServiceDate');
  return withTransaction(async (client) => {
    const p = await client.query('SELECT 1 FROM prc_plants WHERE id = $1', [plantId]);
    if (!p.rows[0]) throw new NotFoundError('Plant not found');
    const dup = await client.query('SELECT 1 FROM prc_machines WHERE code = $1', [code]);
    if (dup.rows[0]) throw new ConflictError(`Machine ${code} already exists`);
    const r = await client.query(
      `INSERT INTO prc_machines (plant_id, code, name, machine_type, capacity_kg_per_hour, service_interval_days, last_service_date, next_service_due, created_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9) RETURNING *`,
      [plantId, code, name, type, optionalNumber(input.capacityKgPerHour, 'capacityKgPerHour', { positive: true }), interval, lastService, lastService ? addDaysIso(interval, new Date(lastService)) : addDaysIso(interval), user.email],
    );
    await insertAuditLog(client, { entityType: 'machine', entityId: r.rows[0].id, action: 'CREATE', performedBy: user.email, afterState: r.rows[0] });
    return r.rows[0];
  });
}

export async function setMachineStatus(id: string, input: Record<string, unknown>, user: AuthenticatedUser) {
  const status = requireEnum(input.status, MACHINE_STATUSES, 'status');
  const reason = status === 'available' ? optionalText(input.reason, 'reason', 500) : requireText(input.reason, 'reason', 500);
  return withTransaction(async (client) => {
    const r = await client.query('UPDATE prc_machines SET status = $2 WHERE id = $1 RETURNING *', [id, status]);
    if (!r.rows[0]) throw new NotFoundError('Machine not found');
    // A breakdown opens a maintenance job so its downtime is measured.
    if (status === 'breakdown') {
      await client.query(`INSERT INTO prc_maintenance (machine_id, maintenance_type, scheduled_date, notes, created_by) VALUES ($1, 'breakdown', CURRENT_DATE, $2, $3)`, [id, reason, user.email]);
    }
    await insertAuditLog(client, { entityType: 'machine', entityId: id, action: 'STATUS', performedBy: user.email, metadata: { status, reason } });
    return r.rows[0];
  });
}

export async function scheduleMaintenance(input: Record<string, unknown>, user: AuthenticatedUser) {
  const machineId = requireUuid(input.machineId, 'machineId');
  const type = requireEnum(input.maintenanceType, ['preventive', 'breakdown', 'calibration'] as const, 'maintenanceType');
  const date = requireDate(input.scheduledDate, 'scheduledDate');
  return withTransaction(async (client) => {
    const m = await client.query('SELECT 1 FROM prc_machines WHERE id = $1', [machineId]);
    if (!m.rows[0]) throw new NotFoundError('Machine not found');
    const r = await client.query(
      `INSERT INTO prc_maintenance (machine_id, maintenance_type, scheduled_date, notes, created_by) VALUES ($1, $2, $3, $4, $5) RETURNING *`,
      [machineId, type, date, optionalText(input.notes, 'notes', 1000), user.email],
    );
    await insertAuditLog(client, { entityType: 'machine', entityId: machineId, action: 'SCHEDULE_MAINTENANCE', performedBy: user.email, afterState: r.rows[0] });
    return r.rows[0];
  });
}

export async function completeMaintenance(id: string, input: Record<string, unknown>, user: AuthenticatedUser) {
  const downtime = optionalNumber(input.downtimeHours, 'downtimeHours', { min: 0, max: 2000 }) ?? 0;
  return withTransaction(async (client) => {
    const r = await client.query('SELECT * FROM prc_maintenance WHERE id = $1 FOR UPDATE', [id]);
    const job = r.rows[0];
    if (!job) throw new NotFoundError('Maintenance job not found');
    if (job.status !== 'scheduled') throw new ConflictError(`This job is already ${job.status}`);
    await client.query(
      `UPDATE prc_maintenance SET status = 'done', completed_at = now(), completed_by = $2, downtime_hours = $3, notes = COALESCE($4, notes) WHERE id = $1`,
      [id, user.email, downtime, optionalText(input.notes, 'notes', 1000)],
    );
    const m = await client.query<{ service_interval_days: number }>('SELECT service_interval_days FROM prc_machines WHERE id = $1', [job.machine_id]);
    await client.query(
      `UPDATE prc_machines SET status = 'available', last_service_date = $2, next_service_due = $3 WHERE id = $1 AND status <> 'retired'`,
      [job.machine_id, todayIso(), addDaysIso(m.rows[0].service_interval_days)],
    );
    await insertAuditLog(client, { entityType: 'machine', entityId: job.machine_id, action: 'MAINTENANCE_DONE', performedBy: user.email, metadata: { jobId: id, downtime } });
    return (await client.query('SELECT * FROM prc_maintenance WHERE id = $1', [id])).rows[0];
  });
}

export async function listMaintenance(filters: { status?: string }) {
  const values: unknown[] = [];
  let where = '';
  if (filters.status) {
    values.push(filters.status);
    where = 'WHERE x.status = $1';
  }
  const r = await pool.query(
    `SELECT x.*, m.code AS machine_code, m.name AS machine_name, p.code AS plant_code
       FROM prc_maintenance x JOIN prc_machines m ON m.id = x.machine_id JOIN prc_plants p ON p.id = m.plant_id ${where}
      ORDER BY x.status = 'scheduled' DESC, x.scheduled_date`,
    values,
  );
  return r.rows;
}
