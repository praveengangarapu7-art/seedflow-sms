import { certificationRegister, productionPlan } from './planning.service';
import { Router } from 'express';
import { asyncHandler as h } from '../../middleware/asyncHandler';
import { requireAuth, requirePermission as can, requireStaff } from '../../middleware/requireAuth';
import { body, ok, str } from '../shared/http';
import * as batches from './batches.service';
import * as plants from './plants.service';
import * as recipes from './recipes.service';

export const processingRouter = Router();
processingRouter.use(requireAuth, requireStaff);

processingRouter.get('/dashboard', h(async (_req, res) => ok(res, await batches.processingDashboard())));
processingRouter.get('/planning', h(async (req, res) => ok(res, await productionPlan(req.query.days ? Number(req.query.days) : 14))));
processingRouter.get('/certification', h(async (_req, res) => ok(res, await certificationRegister())));
processingRouter.get('/yield', h(async (_req, res) => ok(res, await batches.yieldReport())));
processingRouter.get('/trace/:lotId', h(async (req, res) => ok(res, await batches.traceLot(req.params.lotId))));

// Plants, machines, maintenance
processingRouter.get('/plants', h(async (_req, res) => ok(res, await plants.listPlants())));
processingRouter.post('/plants', can('configure_plant'), h(async (req, res) => ok(res, await plants.createPlant(body(req), req.user!), 'Plant added', 201)));
processingRouter.get('/machines', h(async (req, res) => ok(res, await plants.listMachines({ plantId: str(req.query.plantId) }))));
processingRouter.post('/machines', can('configure_machine'), h(async (req, res) => ok(res, await plants.createMachine(body(req), req.user!), 'Machine added', 201)));
processingRouter.post('/machines/:id/status', can('mark_machine_status', 'configure_machine'), h(async (req, res) => ok(res, await plants.setMachineStatus(req.params.id, body(req), req.user!), 'Machine status updated')));
processingRouter.get('/maintenance', h(async (req, res) => ok(res, await plants.listMaintenance({ status: str(req.query.status) }))));
processingRouter.post('/maintenance', can('schedule_maintenance'), h(async (req, res) => ok(res, await plants.scheduleMaintenance(body(req), req.user!), 'Maintenance scheduled', 201)));
processingRouter.post('/maintenance/:id/complete', can('schedule_maintenance', 'mark_machine_status'), h(async (req, res) => ok(res, await plants.completeMaintenance(req.params.id, body(req), req.user!), 'Maintenance recorded')));

// Raw intake
processingRouter.get('/intake/candidates', h(async (_req, res) => ok(res, await batches.intakeCandidates())));
processingRouter.get('/intake', h(async (req, res) => ok(res, await batches.listIntakes({ status: str(req.query.status) }))));
processingRouter.post('/intake', can('create_raw_intake'), h(async (req, res) => {
  const x = await batches.createIntake(body(req), req.user!);
  ok(res, x, `${x.intake_number} received — needs a pre-processing check`, 201);
}));

// Recipes
processingRouter.get('/recipes', h(async (req, res) => ok(res, await recipes.listRecipes({ crop: str(req.query.crop), status: str(req.query.status) }))));
processingRouter.get('/recipes/:id', h(async (req, res) => ok(res, await recipes.getRecipe(req.params.id))));
processingRouter.post('/recipes', can('create_recipe'), h(async (req, res) => {
  const r = await recipes.createRecipe(body(req), req.user!);
  ok(res, r, `${r.recipe_code} drafted`, 201);
}));
processingRouter.post('/recipes/:id/revise', can('create_recipe'), h(async (req, res) => ok(res, await recipes.reviseRecipe(req.params.id, body(req), req.user!), 'New version drafted', 201)));
processingRouter.post('/recipes/:id/submit', can('create_recipe'), h(async (req, res) => ok(res, await recipes.submitRecipe(req.params.id, req.user!), 'Submitted for approval')));
processingRouter.post('/recipes/:id/retire', can('approve_recipe_system'), h(async (req, res) => ok(res, await recipes.retireRecipe(req.params.id, req.user!), 'Recipe retired')));

// Batches
processingRouter.get('/batches', h(async (req, res) => ok(res, await batches.listBatches({ status: str(req.query.status) }))));
processingRouter.get('/batches/:id', h(async (req, res) => ok(res, await batches.getBatch(req.params.id))));
processingRouter.post('/batches', can('create_processing_batch'), h(async (req, res) => {
  const b = await batches.createBatch(body(req), req.user!);
  ok(res, b, `${b.batch_number} planned`, 201);
}));
processingRouter.post('/batches/:id/start', can('update_batch_stage'), h(async (req, res) => ok(res, await batches.startBatch(req.params.id, req.user!), 'Batch started')));
processingRouter.post('/batches/:id/stages/:seq', can('update_batch_stage'), h(async (req, res) => ok(res, await batches.recordStage(req.params.id, Number(req.params.seq), body(req), req.user!), 'Stage recorded')));
processingRouter.post('/batches/:id/treatments', can('update_batch_stage'), h(async (req, res) => ok(res, await batches.recordTreatment(req.params.id, body(req), req.user!), 'Treatment recorded')));
processingRouter.post('/batches/:id/complete', can('approve_finished_lot_dispatch', 'update_batch_stage'), h(async (req, res) => {
  const r = await batches.completeBatch(req.params.id, body(req), req.user!);
  ok(res, r, `Batch completed — lot ${r.lot.lot_code} created with ${r.lot.quantity_total} kg`);
}));
processingRouter.post('/batches/:id/cancel', can('cancel_batch'), h(async (req, res) => ok(res, await batches.cancelBatch(req.params.id, body(req), req.user!), 'Batch cancelled')));
