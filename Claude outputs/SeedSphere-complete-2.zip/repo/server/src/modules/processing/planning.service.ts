import { pool } from '../../db/pool';
import { lotSaleInfo } from '../warehouse/stock.service';

/** Plant load for the next two weeks: planned batch input against each plant's daily capacity. */
export async function productionPlan(days = 14) {
  const n = Math.min(Math.max(Math.floor(days), 7), 42);
  const [plants, batches, intakes, maintenance] = await Promise.all([
    pool.query(`SELECT id, code, name, capacity_kg_per_day::float AS capacity FROM prc_plants WHERE status = 'active' ORDER BY code`),
    pool.query(
      `SELECT b.id, b.batch_number, b.plant_id, b.crop, b.variety, b.status, b.input_kg::float AS input_kg, b.planned_date::text AS planned_date
         FROM prc_batches b WHERE b.status IN ('planned','in_progress') AND b.planned_date <= CURRENT_DATE + $1::int ORDER BY b.planned_date, b.batch_number`, [n]),
    pool.query(`SELECT COALESCE(SUM(quantity_kg - consumed_kg) FILTER (WHERE status = 'ready'),0)::float AS ready_kg, COUNT(*) FILTER (WHERE status = 'ready')::int AS ready, COUNT(*) FILTER (WHERE status = 'awaiting_check')::int AS awaiting FROM prc_raw_intakes`).catch(() => ({ rows: [{ ready_kg: 0, ready: 0, awaiting: 0 }] })),
    pool.query(`SELECT m.code, m.name, m.status, m.next_service_due::text AS due, p.code AS plant_code FROM prc_machines m JOIN prc_plants p ON p.id = m.plant_id WHERE m.status <> 'retired' AND (m.status <> 'available' OR m.next_service_due <= CURRENT_DATE + $1::int) ORDER BY m.next_service_due NULLS LAST`, [n]),
  ]);
  const dates = Array.from({ length: n }, (_, i) => { const d = new Date(); d.setDate(d.getDate() + i); return d.toISOString().slice(0, 10); });
  const rows = plants.rows.map((p) => {
    const mine = batches.rows.filter((b) => b.plant_id === p.id);
    return {
      ...p,
      days: dates.map((date) => {
        const load = mine.filter((b) => (b.planned_date <= date && date === dates[0] && b.planned_date < dates[0]) || b.planned_date === date).reduce((a, b) => a + b.input_kg, 0);
        return { date, loadKg: load, utilisationPct: p.capacity ? Math.round((load / p.capacity) * 100) : null };
      }),
    };
  });
  return { plants: rows, batches: batches.rows, intake: intakes.rows[0], maintenance: maintenance.rows, from: dates[0], to: dates[n - 1] };
}

/** Finished lots with their certification state: germination test validity, hold, and how much is tagged. */
export async function certificationRegister() {
  const lots = (await pool.query(
    `SELECT l.id, l.lot_code, l.crop, l.variety, l.quantity_total::float AS quantity_kg, b.batch_number, b.completed_at,
            COALESCE((SELECT SUM(pack_size_kg) FROM seed_tags t WHERE t.seed_lot_id = l.id AND t.status = 'active'),0)::float AS tagged_kg,
            (SELECT row_to_json(x) FROM (SELECT germination_pct::float AS germination_pct, min_germination_pct::float AS min_germination_pct, tested_on::text AS tested_on, valid_until::text AS valid_until, laboratory, report_number
                                          FROM wh_lot_tests WHERE seed_lot_id = l.id ORDER BY tested_on DESC, recorded_at DESC LIMIT 1) x) AS test
       FROM prc_batches b JOIN seed_lots l ON l.id = b.output_lot_id WHERE b.status = 'completed' ORDER BY b.completed_at DESC LIMIT 300`)).rows;
  const info = await lotSaleInfo(pool, lots.map((l) => l.id));
  return lots.map((l) => {
    const s = info.get(l.id);
    return { ...l, status: s?.status ?? 'untested', valid_until: s?.valid_until ?? null, days_to_expiry: s?.days_to_expiry ?? null, hold_reason: s?.hold_reason ?? null };
  });
}
