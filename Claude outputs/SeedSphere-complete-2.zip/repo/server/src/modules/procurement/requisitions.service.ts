import type { PoolClient } from 'pg';
import { pool } from '../../db/pool';
import { withTransaction } from '../../db/transaction';
import { ConflictError, ForbiddenError, NotFoundError, ValidationError } from '../../errors';
import type { AuthenticatedUser } from '../../middleware/requireAuth';
import { getApprovalsForEntity, registerApprovalHandler, submitForApprovalTx, withdrawTx } from '../approvals/approvals.service';
import { insertAuditLog } from '../auditLogs/auditLogs.service';
import { DEPARTMENTS } from '../quality/quality.common';
import { nextCode, optionalDate, optionalText, optionalUuid, requireEnum, requireText, requireUuid, round2 } from '../shared/validate';
import { loadItems, parseLines } from './common';

export interface RequisitionRow {
  id: string;
  pr_number: string;
  title: string;
  department: string;
  cost_centre_id: string | null;
  needed_by: string | null;
  justification: string | null;
  status: string;
  estimated_total: string;
  source: string;
  source_ref: string | null;
  rejection_reason: string | null;
  requested_by: string;
  submitted_at: string | null;
  decided_at: string | null;
  created_at: string;
}

registerApprovalHandler('purchase_requisition', {
  onApproved: async (client, id) => {
    await client.query(`UPDATE proc_requisitions SET status = 'approved', decided_at = now() WHERE id = $1`, [id]);
  },
  onRejected: async (client, id, _user, comment) => {
    await client.query(`UPDATE proc_requisitions SET status = 'rejected', decided_at = now(), rejection_reason = $2 WHERE id = $1`, [id, comment]);
  },
});

async function lock(client: PoolClient, id: string): Promise<RequisitionRow> {
  const r = await client.query<RequisitionRow>('SELECT * FROM proc_requisitions WHERE id = $1 FOR UPDATE', [id]);
  if (!r.rows[0]) throw new NotFoundError('Requisition not found');
  return r.rows[0];
}

async function writeLines(client: PoolClient, prId: string, input: unknown): Promise<number> {
  const lines = parseLines(input, { requirePrice: false });
  const items = await loadItems(client, lines.map((l) => l.itemId));
  await client.query('DELETE FROM proc_requisition_lines WHERE requisition_id = $1', [prId]);
  let total = 0;
  for (const [i, l] of lines.entries()) {
    const item = items.get(l.itemId)!;
    await client.query(
      `INSERT INTO proc_requisition_lines (requisition_id, line_no, item_id, description, quantity, unit, estimated_unit_price)
       VALUES ($1, $2, $3, $4, $5, $6, $7)`,
      [prId, i + 1, l.itemId, l.description, l.quantity, item.unit, l.unitPrice],
    );
    total += l.quantity * l.unitPrice;
  }
  return round2(total);
}

export async function createRequisition(input: Record<string, unknown>, user: AuthenticatedUser) {
  const title = requireText(input.title, 'title', 200);
  const department = requireEnum(input.department, DEPARTMENTS, 'department');
  const costCentreId = optionalUuid(input.costCentreId, 'costCentreId');
  const neededBy = optionalDate(input.neededBy, 'neededBy');
  const justification = optionalText(input.justification, 'justification', 2000);
  const source = input.source === 'demand_plan' || input.source === 'low_stock' ? input.source : 'manual';
  const sourceRef = optionalText(input.sourceRef, 'sourceRef', 60);
  return withTransaction(async (client) => {
    const code = await nextCode(client, 'PR', 4, true);
    const r = await client.query<RequisitionRow>(
      `INSERT INTO proc_requisitions (pr_number, title, department, cost_centre_id, needed_by, justification, source, source_ref, requested_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9) RETURNING *`,
      [code, title, department, costCentreId, neededBy, justification, source, sourceRef, user.email],
    );
    const total = await writeLines(client, r.rows[0].id, input.lines);
    await client.query('UPDATE proc_requisitions SET estimated_total = $2 WHERE id = $1', [r.rows[0].id, total]);
    await insertAuditLog(client, { entityType: 'purchase_requisition', entityId: r.rows[0].id, action: 'CREATE', performedBy: user.email, afterState: { ...r.rows[0], estimated_total: total } });
    return getRequisition(r.rows[0].id, client);
  });
}

export async function updateRequisition(id: string, input: Record<string, unknown>, user: AuthenticatedUser) {
  return withTransaction(async (client) => {
    const pr = await lock(client, id);
    if (pr.status !== 'draft' && pr.status !== 'rejected') throw new ConflictError(`Only a draft or rejected requisition can be edited (this one is ${pr.status})`);
    if (pr.requested_by !== user.email) throw new ForbiddenError('Only the requester can edit this requisition');
    const title = input.title === undefined ? pr.title : requireText(input.title, 'title', 200);
    const neededBy = input.neededBy === undefined ? pr.needed_by : optionalDate(input.neededBy, 'neededBy');
    const justification = input.justification === undefined ? pr.justification : optionalText(input.justification, 'justification', 2000);
    const costCentreId = input.costCentreId === undefined ? pr.cost_centre_id : optionalUuid(input.costCentreId, 'costCentreId');
    let total = Number(pr.estimated_total);
    if (input.lines !== undefined) total = await writeLines(client, id, input.lines);
    await client.query(
      `UPDATE proc_requisitions SET title = $2, needed_by = $3, justification = $4, cost_centre_id = $5, estimated_total = $6, status = 'draft', rejection_reason = NULL WHERE id = $1`,
      [id, title, neededBy, justification, costCentreId, total],
    );
    await insertAuditLog(client, { entityType: 'purchase_requisition', entityId: id, action: 'UPDATE', performedBy: user.email });
    return getRequisition(id, client);
  });
}

export async function submitRequisition(id: string, user: AuthenticatedUser) {
  return withTransaction(async (client) => {
    const pr = await lock(client, id);
    if (pr.status !== 'draft') throw new ConflictError(`Only a draft can be submitted (this one is ${pr.status})`);
    if (pr.requested_by !== user.email) throw new ForbiddenError('Only the requester can submit this requisition');
    const lines = await client.query('SELECT COUNT(*)::int AS n FROM proc_requisition_lines WHERE requisition_id = $1', [id]);
    if (lines.rows[0].n === 0) throw new ValidationError('Add at least one line before submitting');
    await client.query(`UPDATE proc_requisitions SET status = 'pending_approval', submitted_at = now() WHERE id = $1`, [id]);
    await submitForApprovalTx(client, { entityType: 'purchase_requisition', entityId: id, entityCode: pr.pr_number, title: pr.title, amount: Number(pr.estimated_total) }, user);
    return getRequisition(id, client);
  });
}

export async function cancelRequisition(id: string, input: Record<string, unknown>, user: AuthenticatedUser) {
  const reason = requireText(input.reason, 'reason', 500);
  return withTransaction(async (client) => {
    const pr = await lock(client, id);
    if (['ordered', 'cancelled'].includes(pr.status)) throw new ConflictError(`A ${pr.status} requisition cannot be cancelled`);
    const ordered = await client.query('SELECT 1 FROM proc_requisition_lines WHERE requisition_id = $1 AND ordered_quantity > 0 LIMIT 1', [id]);
    if (ordered.rows[0]) throw new ConflictError('Part of this requisition is already on a purchase order');
    await withdrawTx(client, 'purchase_requisition', id, user);
    await client.query(`UPDATE proc_requisitions SET status = 'cancelled', rejection_reason = $2 WHERE id = $1`, [id, reason]);
    await insertAuditLog(client, { entityType: 'purchase_requisition', entityId: id, action: 'CANCEL', performedBy: user.email, metadata: { reason } });
    return getRequisition(id, client);
  });
}

/** Called by the order module when PO lines draw on requisition lines. */
export async function recordOrderedTx(client: PoolClient, requisitionLineId: string, quantity: number): Promise<void> {
  const r = await client.query<{ requisition_id: string; quantity: string; ordered_quantity: string; status: string }>(
    `SELECT l.requisition_id, l.quantity, l.ordered_quantity, p.status FROM proc_requisition_lines l JOIN proc_requisitions p ON p.id = l.requisition_id WHERE l.id = $1 FOR UPDATE OF l`,
    [requisitionLineId],
  );
  const line = r.rows[0];
  if (!line) throw new NotFoundError('Requisition line not found');
  if (line.status !== 'approved' && line.status !== 'ordered') throw new ConflictError('Only an approved requisition can be ordered');
  await client.query('UPDATE proc_requisition_lines SET ordered_quantity = ordered_quantity + $2 WHERE id = $1', [requisitionLineId, quantity]);
  const open = await client.query('SELECT 1 FROM proc_requisition_lines WHERE requisition_id = $1 AND ordered_quantity < quantity LIMIT 1', [line.requisition_id]);
  if (!open.rows[0]) await client.query(`UPDATE proc_requisitions SET status = 'ordered' WHERE id = $1`, [line.requisition_id]);
}

export async function releaseOrderedTx(client: PoolClient, requisitionLineId: string, quantity: number): Promise<void> {
  const r = await client.query<{ requisition_id: string }>(
    'UPDATE proc_requisition_lines SET ordered_quantity = GREATEST(0, ordered_quantity - $2) WHERE id = $1 RETURNING requisition_id',
    [requisitionLineId, quantity],
  );
  if (r.rows[0]) await client.query(`UPDATE proc_requisitions SET status = 'approved' WHERE id = $1 AND status = 'ordered'`, [r.rows[0].requisition_id]);
}

export async function listRequisitions(filters: { status?: string; mine?: boolean }, user: AuthenticatedUser) {
  const where: string[] = [];
  const values: unknown[] = [];
  if (filters.status) {
    values.push(filters.status);
    where.push(`p.status = $${values.length}`);
  }
  if (filters.mine) {
    values.push(user.email);
    where.push(`p.requested_by = $${values.length}`);
  }
  const r = await pool.query(
    `SELECT p.*, c.code AS cost_centre_code,
            (SELECT COUNT(*)::int FROM proc_requisition_lines l WHERE l.requisition_id = p.id) AS line_count
       FROM proc_requisitions p LEFT JOIN proc_cost_centres c ON c.id = p.cost_centre_id
       ${where.length ? `WHERE ${where.join(' AND ')}` : ''}
      ORDER BY p.created_at DESC LIMIT 500`,
    values,
  );
  return r.rows;
}

export async function getRequisition(id: string, client?: PoolClient) {
  const db = client ?? pool;
  const r = await db.query(
    `SELECT p.*, c.code AS cost_centre_code, c.name AS cost_centre_name FROM proc_requisitions p LEFT JOIN proc_cost_centres c ON c.id = p.cost_centre_id WHERE p.id = $1`,
    [id],
  );
  if (!r.rows[0]) throw new NotFoundError('Requisition not found');
  const lines = await db.query(
    `SELECT l.*, i.item_code, i.name AS item_name, i.category FROM proc_requisition_lines l JOIN proc_items i ON i.id = l.item_id WHERE l.requisition_id = $1 ORDER BY l.line_no`,
    [id],
  );
  const orders = await db.query(
    `SELECT DISTINCT o.id, o.po_number, o.status, o.grand_total FROM proc_purchase_orders o WHERE o.requisition_id = $1 ORDER BY o.po_number`,
    [id],
  );
  const approvals = await getApprovalsForEntity('purchase_requisition', id, client);
  return { ...r.rows[0], lines: lines.rows, orders: orders.rows, approvals };
}

/**
 * Turns a demand-planning purchase suggestion (the older purchase_orders
 * table, filled by demand planning) into a requisition for the item, so
 * planned shortfalls enter the controlled buying process.
 */
export async function requisitionFromDemandPlan(input: Record<string, unknown>, user: AuthenticatedUser) {
  const suggestionId = requireUuid(input.suggestionId, 'suggestionId');
  const itemId = requireUuid(input.itemId, 'itemId');
  const s = await pool.query('SELECT * FROM purchase_orders WHERE id = $1', [suggestionId]);
  const sug = s.rows[0];
  if (!sug) throw new NotFoundError('Demand-planning suggestion not found');
  const already = await pool.query(`SELECT pr_number FROM proc_requisitions WHERE source = 'demand_plan' AND source_ref = $1 AND status <> 'cancelled'`, [sug.po_number]);
  if (already.rows[0]) throw new ConflictError(`Requisition ${already.rows[0].pr_number} was already raised from ${sug.po_number}`);
  return createRequisition(
    {
      title: `${sug.crop} ${sug.variety} — planned shortfall ${sug.po_number}`,
      department: 'procurement',
      neededBy: sug.expected_delivery_date ? new Date(sug.expected_delivery_date).toISOString().slice(0, 10) : undefined,
      justification: `Raised from demand-planning suggestion ${sug.po_number}${sug.notes ? `: ${sug.notes}` : ''}`,
      source: 'demand_plan',
      sourceRef: sug.po_number,
      costCentreId: input.costCentreId,
      lines: [{ itemId, quantity: Number(sug.quantity_requested), unitPrice: input.estimatedUnitPrice ?? 0 }],
    },
    user,
  );
}

export async function listDemandSuggestions() {
  const r = await pool.query(
    `SELECT s.id, s.po_number, s.crop, s.variety, s.quantity_requested, s.unit, s.status, s.expected_delivery_date, s.created_at,
            (SELECT p.pr_number FROM proc_requisitions p WHERE p.source = 'demand_plan' AND p.source_ref = s.po_number AND p.status <> 'cancelled' LIMIT 1) AS requisition_number
       FROM purchase_orders s WHERE s.status IN ('draft', 'sent') ORDER BY s.created_at DESC LIMIT 100`,
  );
  return r.rows;
}
