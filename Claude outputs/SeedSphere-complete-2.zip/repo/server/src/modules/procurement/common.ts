import type { PoolClient } from 'pg';
import { NotFoundError, ValidationError } from '../../errors';
import { asRecord, optionalText, requireArray, requireNumber, requireUuid, round2 } from '../shared/validate';

export interface LineInput {
  itemId: string;
  description: string | null;
  quantity: number;
  unitPrice: number;
  gstRate: number | null;
  requisitionLineId: string | null;
}

export function parseLines(value: unknown, { requirePrice = true } = {}): LineInput[] {
  const lines = requireArray(value, 'lines', { min: 1, max: 100 });
  return lines.map((raw, i) => {
    const r = asRecord(raw, `lines[${i}]`);
    return {
      itemId: requireUuid(r.itemId, `lines[${i}].itemId`),
      description: optionalText(r.description, `lines[${i}].description`, 500),
      quantity: requireNumber(r.quantity, `lines[${i}].quantity`, { positive: true }),
      unitPrice: requirePrice ? requireNumber(r.unitPrice, `lines[${i}].unitPrice`, { min: 0 }) : r.unitPrice === undefined || r.unitPrice === null || r.unitPrice === '' ? 0 : requireNumber(r.unitPrice, `lines[${i}].unitPrice`, { min: 0 }),
      gstRate: r.gstRate === undefined || r.gstRate === null || r.gstRate === '' ? null : requireNumber(r.gstRate, `lines[${i}].gstRate`, { min: 0, max: 28 }),
      requisitionLineId: r.requisitionLineId ? requireUuid(r.requisitionLineId, `lines[${i}].requisitionLineId`) : null,
    };
  });
}

export interface ItemRow {
  id: string;
  item_code: string;
  name: string;
  category: string;
  unit: string;
  crop: string | null;
  variety: string | null;
  gst_rate: string;
  requires_inspection: boolean;
  is_active: boolean;
}

export async function loadItems(client: PoolClient, ids: string[]): Promise<Map<string, ItemRow>> {
  const r = await client.query<ItemRow>('SELECT * FROM proc_items WHERE id = ANY($1::uuid[])', [ids]);
  const map = new Map(r.rows.map((row) => [row.id, row]));
  for (const id of ids) {
    const item = map.get(id);
    if (!item) throw new NotFoundError(`Item ${id} not found`);
    if (!item.is_active) throw new ValidationError(`Item ${item.name} is inactive`);
  }
  return map;
}

export function lineAmounts(quantity: number, unitPrice: number, gstRate: number) {
  const lineTotal = round2(quantity * unitPrice);
  const tax = round2((lineTotal * gstRate) / 100);
  return { lineTotal, tax };
}

export function totals(lines: { lineTotal: number; tax: number }[]) {
  const subtotal = round2(lines.reduce((s, l) => s + l.lineTotal, 0));
  const taxTotal = round2(lines.reduce((s, l) => s + l.tax, 0));
  return { subtotal, taxTotal, grandTotal: round2(subtotal + taxTotal) };
}

/** Indian fiscal year label for a date: April–March, e.g. 2026-27. */
export function fiscalYear(d = new Date()): string {
  const y = d.getUTCMonth() >= 3 ? d.getUTCFullYear() : d.getUTCFullYear() - 1;
  return `${y}-${String((y + 1) % 100).padStart(2, '0')}`;
}

/** Received over the ordered quantity is accepted up to this tolerance (bags and weighbridge rounding). */
export const RECEIPT_TOLERANCE = 0.05;
/** Invoice unit price may differ from the PO price by at most this fraction and still match. */
export const PRICE_TOLERANCE = 0.01;
