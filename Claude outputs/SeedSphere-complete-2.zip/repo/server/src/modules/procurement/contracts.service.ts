import type { PoolClient } from 'pg';
import { pool } from '../../db/pool';
import { withTransaction } from '../../db/transaction';
import { ConflictError, ForbiddenError, NotFoundError, ValidationError } from '../../errors';
import type { AuthenticatedUser } from '../../middleware/requireAuth';
import { insertAuditLog } from '../auditLogs/auditLogs.service';
import { assertPartyUsable } from '../parties/parties.service';
import { asRecord, nextCode, num, optionalNumber, optionalText, requireArray, requireDate, requireEnum, requireNumber, requireText, requireUuid } from '../shared/validate';

export const CONTRACT_TYPES = ['rate_contract', 'supply_agreement', 'service', 'transport'] as const;

export async function createContract(input: Record<string, unknown>, user: AuthenticatedUser) {
  const contractType = requireEnum(input.contractType, CONTRACT_TYPES, 'contractType');
  const supplierId = requireUuid(input.supplierId, 'supplierId');
  const title = requireText(input.title, 'title', 200);
  const startDate = requireDate(input.startDate, 'startDate');
  const endDate = requireDate(input.endDate, 'endDate');
  if (endDate < startDate) throw new ValidationError('endDate must be on or after startDate');
  const renewal = optionalNumber(input.renewalNoticeDays, 'renewalNoticeDays', { min: 0, max: 365 }) ?? 30;
  const cap = optionalNumber(input.valueCap, 'valueCap', { positive: true });
  const terms = optionalNumber(input.paymentTermsDays, 'paymentTermsDays', { min: 0, max: 365 }) ?? 30;
  const text = optionalText(input.terms, 'terms', 5000);
  const rates = input.rates === undefined ? [] : requireArray(input.rates, 'rates', { min: 0, max: 200 }).map((raw, i) => {
    const r = asRecord(raw, `rates[${i}]`);
    return { itemId: requireUuid(r.itemId, `rates[${i}].itemId`), unitPrice: requireNumber(r.unitPrice, `rates[${i}].unitPrice`, { min: 0 }) };
  });
  if (contractType === 'rate_contract' && rates.length === 0) throw new ValidationError('A rate contract needs at least one item rate');
  if (new Set(rates.map((r) => r.itemId)).size !== rates.length) throw new ValidationError('Each item may appear once in the rate schedule');

  return withTransaction(async (client) => {
    await assertPartyUsable(client, supplierId, ['supplier', 'transporter', 'service_provider'], 'a contract');
    const code = await nextCode(client, 'CTR', 4, true);
    const c = await client.query(
      `INSERT INTO proc_contracts (contract_number, contract_type, supplier_id, title, start_date, end_date, renewal_notice_days, value_cap, payment_terms_days, terms, created_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11) RETURNING *`,
      [code, contractType, supplierId, title, startDate, endDate, renewal, cap, terms, text, user.email],
    );
    for (const r of rates) {
      await client.query('INSERT INTO proc_contract_rates (contract_id, item_id, unit_price) VALUES ($1, $2, $3)', [c.rows[0].id, r.itemId, r.unitPrice]);
    }
    await insertAuditLog(client, { entityType: 'contract', entityId: c.rows[0].id, action: 'CREATE', performedBy: user.email, afterState: { ...c.rows[0], rates } });
    return getContract(c.rows[0].id, client);
  });
}

export async function activateContract(id: string, user: AuthenticatedUser) {
  return withTransaction(async (client) => {
    const r = await client.query('SELECT * FROM proc_contracts WHERE id = $1 FOR UPDATE', [id]);
    const c = r.rows[0];
    if (!c) throw new NotFoundError('Contract not found');
    if (c.status !== 'draft') throw new ConflictError(`Only a draft contract can be activated (this one is ${c.status})`);
    if (c.created_by === user.email) throw new ForbiddenError('A contract must be activated by someone other than the person who drafted it');
    const today = new Date().toISOString().slice(0, 10);
    if (new Date(c.end_date).toISOString().slice(0, 10) < today) throw new ConflictError('This contract has already ended');
    await assertPartyUsable(client, c.supplier_id, ['supplier', 'transporter', 'service_provider'], 'a contract');
    await client.query(`UPDATE proc_contracts SET status = 'active', activated_by = $2, activated_at = now() WHERE id = $1`, [id, user.email]);
    await insertAuditLog(client, { entityType: 'contract', entityId: id, action: 'ACTIVATE', performedBy: user.email });
    return getContract(id, client);
  });
}

export async function terminateContract(id: string, input: Record<string, unknown>, user: AuthenticatedUser) {
  const reason = requireText(input.reason, 'reason', 1000);
  return withTransaction(async (client) => {
    const r = await client.query(`UPDATE proc_contracts SET status = 'terminated', termination_reason = $2 WHERE id = $1 AND status <> 'terminated' RETURNING id`, [id, reason]);
    if (!r.rows[0]) throw new ConflictError('Contract not found or already terminated');
    await insertAuditLog(client, { entityType: 'contract', entityId: id, action: 'TERMINATE', performedBy: user.email, metadata: { reason } });
    return getContract(id, client);
  });
}

function withLifecycle<T extends { status: string; start_date: string | Date; end_date: string | Date; renewal_notice_days: number }>(c: T) {
  const today = new Date().toISOString().slice(0, 10);
  const end = new Date(c.end_date).toISOString().slice(0, 10);
  const start = new Date(c.start_date).toISOString().slice(0, 10);
  const daysLeft = Math.round((Date.parse(end) - Date.parse(today)) / 86400000);
  let lifecycle: string = c.status;
  if (c.status === 'active') lifecycle = end < today ? 'expired' : start > today ? 'not_started' : daysLeft <= c.renewal_notice_days ? 'renewal_due' : 'in_force';
  return { ...c, days_left: daysLeft, lifecycle };
}

export async function listContracts(filters: { supplierId?: string; status?: string }) {
  const where: string[] = [];
  const values: unknown[] = [];
  if (filters.supplierId) {
    values.push(filters.supplierId);
    where.push(`c.supplier_id = $${values.length}`);
  }
  if (filters.status) {
    values.push(filters.status);
    where.push(`c.status = $${values.length}`);
  }
  const r = await pool.query(
    `SELECT c.*, p.name AS supplier_name, p.party_code AS supplier_code,
            COALESCE((SELECT SUM(o.grand_total) FROM proc_purchase_orders o WHERE o.contract_id = c.id AND o.status NOT IN ('draft', 'cancelled', 'rejected')), 0) AS ordered_value
       FROM proc_contracts c JOIN parties p ON p.id = c.supplier_id
       ${where.length ? `WHERE ${where.join(' AND ')}` : ''} ORDER BY c.end_date`,
    values,
  );
  return r.rows.map(withLifecycle);
}

export async function getContract(id: string, client?: PoolClient) {
  const db = client ?? pool;
  const r = await db.query(
    `SELECT c.*, p.name AS supplier_name, p.party_code AS supplier_code,
            COALESCE((SELECT SUM(o.grand_total) FROM proc_purchase_orders o WHERE o.contract_id = c.id AND o.status NOT IN ('draft', 'cancelled', 'rejected')), 0) AS ordered_value
       FROM proc_contracts c JOIN parties p ON p.id = c.supplier_id WHERE c.id = $1`,
    [id],
  );
  if (!r.rows[0]) throw new NotFoundError('Contract not found');
  const rates = await db.query(
    `SELECT r.*, i.item_code, i.name AS item_name, i.unit FROM proc_contract_rates r JOIN proc_items i ON i.id = r.item_id WHERE r.contract_id = $1 ORDER BY i.name`,
    [id],
  );
  const orders = await db.query(`SELECT id, po_number, status, grand_total, order_date FROM proc_purchase_orders WHERE contract_id = $1 ORDER BY order_date DESC`, [id]);
  return { ...withLifecycle(r.rows[0]), rates: rates.rows, orders: orders.rows };
}

/**
 * Used when an order cites a contract: the contract must be active and in
 * force for the supplier, every rated item must be priced at or below the
 * contract rate, and the order must not take the contract over its value cap.
 */
export async function checkOrderAgainstContract(
  client: PoolClient,
  contractId: string,
  supplierId: string,
  lines: { itemId: string; unitPrice: number }[],
  orderTotal: number,
  excludePoId: string | null,
): Promise<{ paymentTermsDays: number }> {
  const r = await client.query('SELECT * FROM proc_contracts WHERE id = $1', [contractId]);
  const c = r.rows[0];
  if (!c) throw new NotFoundError('Contract not found');
  if (c.supplier_id !== supplierId) throw new ValidationError('That contract is with a different supplier');
  const today = new Date().toISOString().slice(0, 10);
  if (c.status !== 'active' || new Date(c.start_date).toISOString().slice(0, 10) > today || new Date(c.end_date).toISOString().slice(0, 10) < today) {
    throw new ConflictError(`Contract ${c.contract_number} is not in force today`);
  }
  const rates = await client.query<{ item_id: string; unit_price: string }>('SELECT item_id, unit_price FROM proc_contract_rates WHERE contract_id = $1', [contractId]);
  const rateMap = new Map(rates.rows.map((x) => [x.item_id, num(x.unit_price)]));
  for (const l of lines) {
    const rate = rateMap.get(l.itemId);
    if (rate !== undefined && l.unitPrice > rate) {
      throw new ConflictError(`A line is priced at ${l.unitPrice} but contract ${c.contract_number} fixes it at ${rate}`);
    }
  }
  if (c.value_cap) {
    const used = await client.query<{ v: string }>(
      `SELECT COALESCE(SUM(grand_total), 0) AS v FROM proc_purchase_orders WHERE contract_id = $1 AND status NOT IN ('draft', 'cancelled', 'rejected') AND ($2::uuid IS NULL OR id <> $2)`,
      [contractId, excludePoId],
    );
    if (num(used.rows[0].v) + orderTotal > num(c.value_cap)) {
      throw new ConflictError(`This order would take contract ${c.contract_number} over its value cap of ${num(c.value_cap)}`);
    }
  }
  return { paymentTermsDays: c.payment_terms_days };
}

export async function contractAlerts() {
  const list = await listContracts({ status: 'active' });
  return list.filter((c) => c.lifecycle === 'renewal_due' || c.lifecycle === 'expired');
}
