import { pool } from '../../db/pool';
import { num, round2 } from '../shared/validate';
import { contractAlerts } from './contracts.service';
import { fiscalYear } from './common';
import { listCostCentres } from './items.service';

/** Monthly spend for the last 12 months: approved order value (committed) and paid invoices (cash out). */
export async function spendAnalysis(filters: { months?: number }) {
  const months = Math.min(Math.max(filters.months ?? 12, 1), 36);
  const byMonth = await pool.query(
    `WITH m AS (SELECT generate_series(date_trunc('month', CURRENT_DATE) - ($1::int - 1) * interval '1 month', date_trunc('month', CURRENT_DATE), interval '1 month') AS month)
     SELECT to_char(m.month, 'YYYY-MM') AS month,
            COALESCE((SELECT SUM(o.grand_total) FROM proc_purchase_orders o WHERE date_trunc('month', o.approved_at) = m.month), 0) AS ordered,
            COALESCE((SELECT SUM(i.total_amount) FROM proc_invoices i WHERE i.status = 'paid' AND date_trunc('month', i.paid_at) = m.month), 0) AS paid,
            COALESCE((SELECT SUM(s.net_payable) FROM grw_settlements s WHERE s.status = 'paid' AND date_trunc('month', s.paid_at) = m.month), 0) AS grower_paid
       FROM m ORDER BY m.month`,
    [months],
  );
  const byCategory = await pool.query(
    `SELECT it.category, SUM(l.line_total + l.tax_amount) AS amount
       FROM proc_po_lines l JOIN proc_purchase_orders o ON o.id = l.po_id JOIN proc_items it ON it.id = l.item_id
      WHERE o.status NOT IN ('draft', 'cancelled', 'rejected', 'pending_approval') AND o.order_date >= CURRENT_DATE - ($1::int * interval '1 month')
      GROUP BY it.category ORDER BY amount DESC`,
    [months],
  );
  const bySupplier = await pool.query(
    `SELECT p.id, p.name, p.party_code, SUM(o.grand_total) AS amount, COUNT(*)::int AS orders
       FROM proc_purchase_orders o JOIN parties p ON p.id = o.supplier_id
      WHERE o.status NOT IN ('draft', 'cancelled', 'rejected', 'pending_approval') AND o.order_date >= CURRENT_DATE - ($1::int * interval '1 month')
      GROUP BY p.id ORDER BY amount DESC LIMIT 10`,
    [months],
  );
  const priceTrend = await pool.query(
    `SELECT it.id AS item_id, it.name, it.unit, to_char(date_trunc('month', o.order_date), 'YYYY-MM') AS month,
            ROUND(SUM(l.line_total) / NULLIF(SUM(l.quantity), 0), 2) AS avg_price, MIN(l.unit_price) AS min_price, MAX(l.unit_price) AS max_price
       FROM proc_po_lines l JOIN proc_purchase_orders o ON o.id = l.po_id JOIN proc_items it ON it.id = l.item_id
      WHERE o.status NOT IN ('draft', 'cancelled', 'rejected') AND o.order_date >= CURRENT_DATE - ($1::int * interval '1 month')
      GROUP BY it.id, it.name, it.unit, date_trunc('month', o.order_date) ORDER BY it.name, month`,
    [months],
  );
  return {
    byMonth: byMonth.rows.map((r) => ({ month: r.month, ordered: num(r.ordered), paid: num(r.paid), growerPaid: num(r.grower_paid) })),
    byCategory: byCategory.rows.map((r) => ({ category: r.category, amount: num(r.amount) })),
    bySupplier: bySupplier.rows.map((r) => ({ ...r, amount: num(r.amount) })),
    priceTrend: priceTrend.rows.map((r) => ({ ...r, avg_price: num(r.avg_price), min_price: num(r.min_price), max_price: num(r.max_price) })),
    costCentres: await listCostCentres({ fiscalYear: fiscalYear() }),
  };
}

/**
 * Scores computed from what actually happened, not entered by hand:
 *   on-time   = receipts on or before the order's expected date ÷ receipts
 *   rejection = rejected + damaged quantity ÷ received quantity
 *   price var = invoice value above order value ÷ invoice value
 *   NCRs      = non-conformances raised by inspections of this supplier's receipts
 */
export async function supplierPerformance() {
  const r = await pool.query(
    `SELECT p.id, p.party_code, p.name, p.party_type, p.status,
            COUNT(DISTINCT o.id) FILTER (WHERE o.status NOT IN ('draft', 'cancelled', 'rejected')) AS orders,
            (SELECT COALESCE(SUM(o2.grand_total), 0) FROM proc_purchase_orders o2 WHERE o2.supplier_id = p.id AND o2.status NOT IN ('draft', 'cancelled', 'rejected')) AS order_value,
            COUNT(DISTINCT g.id) AS receipts,
            COUNT(DISTINCT g.id) FILTER (WHERE g.received_at::date <= o.expected_delivery_date) AS on_time_receipts,
            COALESCE(SUM(gl.received_quantity), 0) AS received_qty,
            COALESCE(SUM(gl.received_quantity - COALESCE(gl.accepted_quantity, gl.received_quantity - gl.damaged_quantity)), 0) AS bad_qty,
            (SELECT COUNT(*) FROM inspections i JOIN proc_goods_receipts g2 ON g2.id::text = i.subject_id
              WHERE i.subject_type = 'goods_receipt' AND g2.supplier_id = p.id AND i.ncr_id IS NOT NULL)::int AS ncrs,
            (SELECT COALESCE(SUM(i.variance_amount), 0) FROM proc_invoices i WHERE i.supplier_id = p.id AND i.status NOT IN ('cancelled', 'rejected')) AS variance,
            (SELECT COALESCE(SUM(i.total_amount), 0) FROM proc_invoices i WHERE i.supplier_id = p.id AND i.status NOT IN ('cancelled', 'rejected')) AS invoiced
       FROM parties p
       LEFT JOIN proc_purchase_orders o ON o.supplier_id = p.id
       LEFT JOIN proc_goods_receipts g ON g.po_id = o.id AND g.status <> 'awaiting_inspection'
       LEFT JOIN proc_grn_lines gl ON gl.grn_id = g.id
      WHERE p.party_type = 'supplier'
      GROUP BY p.id
      ORDER BY order_value DESC`,
  );
  return r.rows.map((x) => {
    const receipts = Number(x.receipts);
    const onTime = receipts ? round2((Number(x.on_time_receipts) / receipts) * 100) : null;
    const rejection = num(x.received_qty) > 0 ? round2((num(x.bad_qty) / num(x.received_qty)) * 100) : null;
    const priceVar = num(x.invoiced) > 0 ? round2((num(x.variance) / num(x.invoiced)) * 100) : null;
    // A simple, explained composite: start at 100, lose points for lateness,
    // rejections, price variance and NCRs. The parts are shown beside it.
    let score: number | null = null;
    if (receipts > 0) {
      score = 100;
      score -= (100 - (onTime ?? 100)) * 0.4;
      score -= Math.min(40, (rejection ?? 0) * 2);
      score -= Math.min(20, Math.max(0, priceVar ?? 0) * 2);
      score -= Math.min(20, x.ncrs * 5);
      score = Math.max(0, round2(score));
    }
    return {
      id: x.id,
      party_code: x.party_code,
      name: x.name,
      status: x.status,
      orders: Number(x.orders),
      order_value: num(x.order_value),
      receipts,
      on_time_pct: onTime,
      rejection_pct: rejection,
      price_variance_pct: priceVar,
      ncrs: x.ncrs,
      score,
    };
  });
}

export async function growerPerformance() {
  const r = await pool.query(
    `SELECT p.id, p.party_code, p.name, p.village,
            COUNT(DISTINCT a.id) AS agreements,
            COALESCE(SUM(a.area_acres) FILTER (WHERE a.status IN ('active', 'completed')), 0) AS acres,
            COUNT(d.id) AS deliveries,
            COUNT(d.id) FILTER (WHERE d.status = 'accepted') AS accepted,
            COUNT(d.id) FILTER (WHERE d.status = 'rejected') AS rejected,
            COALESCE(SUM(d.net_weight_kg) FILTER (WHERE d.status = 'accepted'), 0) AS accepted_kg,
            AVG(d.moisture_pct) AS avg_moisture, AVG(d.purity_pct) AS avg_purity,
            (SELECT COALESCE(SUM(g.amount), 0) FROM grw_ledger g WHERE g.grower_id = p.id) AS balance,
            (SELECT AVG(EXTRACT(EPOCH FROM (s.paid_at - s.first_delivery_at)) / 86400) FROM grw_settlements s
              WHERE s.grower_id = p.id AND s.status = 'paid' AND s.settlement_type = 'final' AND s.first_delivery_at IS NOT NULL) AS avg_days_to_payment
       FROM parties p
       LEFT JOIN grw_agreements a ON a.grower_id = p.id
       LEFT JOIN grw_deliveries d ON d.agreement_id = a.id
      WHERE p.party_type = 'contract_grower'
      GROUP BY p.id ORDER BY accepted_kg DESC`,
  );
  return r.rows.map((x) => ({
    ...x,
    agreements: Number(x.agreements),
    deliveries: Number(x.deliveries),
    accepted: Number(x.accepted),
    rejected: Number(x.rejected),
    acres: num(x.acres),
    accepted_kg: num(x.accepted_kg),
    avg_moisture: x.avg_moisture === null ? null : round2(num(x.avg_moisture)),
    avg_purity: x.avg_purity === null ? null : round2(num(x.avg_purity)),
    balance: num(x.balance),
    avg_days_to_payment: x.avg_days_to_payment === null ? null : round2(num(x.avg_days_to_payment)),
  }));
}

export async function procurementDashboard() {
  const counts = await pool.query(`
    SELECT
      (SELECT COUNT(*) FROM proc_requisitions WHERE status = 'pending_approval')::int AS prs_pending,
      (SELECT COUNT(*) FROM proc_purchase_orders WHERE status = 'pending_approval')::int AS pos_pending,
      (SELECT COUNT(*) FROM proc_purchase_orders WHERE status IN ('approved', 'sent', 'partially_received'))::int AS pos_open,
      (SELECT COUNT(*) FROM proc_purchase_orders WHERE status IN ('approved', 'sent', 'partially_received') AND expected_delivery_date < CURRENT_DATE)::int AS pos_late,
      (SELECT COUNT(*) FROM proc_goods_receipts WHERE status = 'awaiting_inspection')::int AS grns_awaiting_inspection,
      (SELECT COUNT(*) FROM grw_deliveries WHERE status = 'awaiting_inspection')::int AS deliveries_awaiting_inspection,
      (SELECT COUNT(*) FROM proc_invoices WHERE status IN ('received', 'pending_approval', 'approved') AND due_date < CURRENT_DATE)::int AS invoices_overdue,
      (SELECT COALESCE(SUM(total_amount), 0) FROM proc_invoices WHERE status = 'approved') AS payable_now,
      (SELECT COUNT(*) FROM proc_invoices WHERE status = 'received' AND match_status = 'mismatch')::int AS invoices_mismatch,
      (SELECT COUNT(*) FROM grw_agreements WHERE status = 'active')::int AS agreements_active,
      (SELECT COALESCE(SUM(net_payable), 0) FROM grw_settlements WHERE status IN ('pending_approval', 'approved')) AS grower_payments_pending,
      (SELECT COALESCE(SUM(amount), 0) FROM grw_ledger g WHERE g.settled_by_id IS NULL AND g.entry_type = 'delivery') AS grower_unsettled_value,
      (SELECT AVG(EXTRACT(EPOCH FROM (paid_at - first_delivery_at)) / 86400) FROM grw_settlements
        WHERE status = 'paid' AND settlement_type = 'final' AND first_delivery_at IS NOT NULL AND paid_at >= now() - interval '90 days') AS avg_days_to_grower_payment
  `);
  const recentOrders = await pool.query(
    `SELECT o.id, o.po_number, o.status, o.grand_total, o.order_date, p.name AS supplier_name FROM proc_purchase_orders o JOIN parties p ON p.id = o.supplier_id ORDER BY o.created_at DESC LIMIT 8`,
  );
  const statusMix = await pool.query(`SELECT status, COUNT(*)::int AS n FROM proc_purchase_orders GROUP BY status`);
  const c = counts.rows[0];
  return {
    counts: {
      ...c,
      payable_now: num(c.payable_now),
      grower_payments_pending: num(c.grower_payments_pending),
      grower_unsettled_value: num(c.grower_unsettled_value),
      avg_days_to_grower_payment: c.avg_days_to_grower_payment === null ? null : round2(num(c.avg_days_to_grower_payment)),
    },
    recentOrders: recentOrders.rows,
    statusMix: statusMix.rows,
    contractAlerts: await contractAlerts(),
    spend: (await spendAnalysis({ months: 6 })).byMonth,
  };
}
