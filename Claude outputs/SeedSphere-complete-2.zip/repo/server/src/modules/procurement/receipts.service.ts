import type { PoolClient } from 'pg';
import { pool } from '../../db/pool';
import { withTransaction } from '../../db/transaction';
import { ConflictError, NotFoundError, ValidationError } from '../../errors';
import type { AuthenticatedUser } from '../../middleware/requireAuth';
import { insertAuditLog } from '../auditLogs/auditLogs.service';
import { registerInspectionSubject, type InspectionRow } from '../inspections/inspections.service';
import { asRecord, nextCode, num, optionalNumber, optionalText, requireArray, requireNumber, requireUuid, round2 } from '../shared/validate';
import { RECEIPT_TOLERANCE } from './common';
import { refreshReceivingStatusTx } from './orders.service';

interface GrnLine {
  id: string;
  po_line_id: string;
  received_quantity: string;
  damaged_quantity: string;
  accepted_quantity: string | null;
}

/**
 * Applies accepted quantities to a receipt and its order. "Received" on the
 * order line counts only good goods (accepted), so rejected or damaged goods
 * leave the order open for the supplier to replace.
 */
async function applyAcceptance(client: PoolClient, grnId: string, accepted: Map<string, number>, status: string, user: AuthenticatedUser, inspectionId: string | null) {
  const g = await client.query<{ po_id: string; grn_number: string }>('SELECT po_id, grn_number FROM proc_goods_receipts WHERE id = $1', [grnId]);
  for (const [lineId, qty] of accepted.entries()) {
    const l = await client.query<{ po_line_id: string }>('UPDATE proc_grn_lines SET accepted_quantity = $2 WHERE id = $1 RETURNING po_line_id', [lineId, qty]);
    if (qty > 0) {
      await client.query('UPDATE proc_po_lines SET received_quantity = received_quantity + $2, accepted_quantity = accepted_quantity + $2 WHERE id = $1', [l.rows[0].po_line_id, qty]);
    }
  }
  await client.query(`UPDATE proc_goods_receipts SET status = $2, decided_at = now(), inspection_id = COALESCE($3, inspection_id) WHERE id = $1`, [grnId, status, inspectionId]);
  await refreshReceivingStatusTx(client, g.rows[0].po_id);
  await insertAuditLog(client, {
    entityType: 'goods_receipt',
    entityId: grnId,
    action: 'DECIDE',
    performedBy: user.email,
    afterState: { status, accepted: Object.fromEntries(accepted), inspectionId },
  });
}

registerInspectionSubject('goods_receipt', {
  resolveSubject: async (client, subjectId) => {
    const r = await client.query(
      `SELECT g.grn_number, g.status, p.name AS supplier_name,
              (SELECT string_agg(i.name, ', ') FROM proc_grn_lines gl JOIN proc_po_lines l ON l.id = gl.po_line_id JOIN proc_items i ON i.id = l.item_id WHERE gl.grn_id = g.id) AS items
         FROM proc_goods_receipts g JOIN parties p ON p.id = g.supplier_id WHERE g.id = $1`,
      [subjectId],
    );
    const g = r.rows[0];
    if (!g) throw new NotFoundError('Goods receipt not found');
    if (g.status !== 'awaiting_inspection' && g.status !== 'on_hold') throw new ConflictError(`${g.grn_number} is already ${g.status}`);
    const open = await client.query(`SELECT inspection_code FROM inspections WHERE subject_type = 'goods_receipt' AND subject_id = $1 AND status = 'in_progress'`, [subjectId]);
    if (open.rows[0]) throw new ConflictError(`Inspection ${open.rows[0].inspection_code} is already open for ${g.grn_number}`);
    return { label: `${g.grn_number} · ${g.supplier_name} · ${g.items}`, seedLotId: null };
  },
  onSubmitted: async (client, inspection: InspectionRow, user) => {
    const grnId = inspection.subject_id!;
    const lines = await client.query<GrnLine>('SELECT * FROM proc_grn_lines WHERE grn_id = $1 ORDER BY id', [grnId]);
    const good = lines.rows.map((l) => ({ id: l.id, good: num(l.received_quantity) - num(l.damaged_quantity) }));
    const accepted = new Map<string, number>();
    let status: string;
    switch (inspection.decision) {
      case 'accept':
        good.forEach((l) => accepted.set(l.id, l.good));
        status = 'accepted';
        break;
      case 'partial_accept': {
        const totalGood = good.reduce((s, l) => s + l.good, 0);
        const target = Math.min(num(inspection.accepted_quantity), totalGood);
        let left = target;
        good.forEach((l, i) => {
          const share = i === good.length - 1 ? left : round2((l.good / totalGood) * target);
          const q = Math.min(l.good, Math.max(0, share));
          accepted.set(l.id, q);
          left = round2(left - q);
        });
        status = target > 0 ? 'partially_accepted' : 'rejected';
        break;
      }
      case 'reject':
        good.forEach((l) => accepted.set(l.id, 0));
        status = 'rejected';
        break;
      default:
        // hold / rework: nothing is accepted yet; a new inspection decides later
        await client.query(`UPDATE proc_goods_receipts SET status = 'on_hold', inspection_id = $2 WHERE id = $1`, [grnId, inspection.id]);
        await insertAuditLog(client, { entityType: 'goods_receipt', entityId: grnId, action: 'HOLD', performedBy: user.email, metadata: { inspectionId: inspection.id } });
        return;
    }
    await applyAcceptance(client, grnId, accepted, status, user, inspection.id);
  },
});

export async function createReceipt(input: Record<string, unknown>, user: AuthenticatedUser) {
  const poId = requireUuid(input.poId, 'poId');
  const lines = requireArray(input.lines, 'lines', { min: 1, max: 100 }).map((raw, i) => {
    const r = asRecord(raw, `lines[${i}]`);
    const received = requireNumber(r.receivedQuantity, `lines[${i}].receivedQuantity`, { positive: true });
    const damaged = optionalNumber(r.damagedQuantity, `lines[${i}].damagedQuantity`, { min: 0 }) ?? 0;
    if (damaged > received) throw new ValidationError(`lines[${i}]: damaged cannot exceed received`);
    return { poLineId: requireUuid(r.poLineId, `lines[${i}].poLineId`), received, damaged, notes: optionalText(r.notes, `lines[${i}].notes`, 500) };
  });
  const gross = optionalNumber(input.grossWeightKg, 'grossWeightKg', { positive: true });
  const tare = optionalNumber(input.tareWeightKg, 'tareWeightKg', { min: 0 });
  if ((gross === null) !== (tare === null)) throw new ValidationError('Give both gross and tare weight, or neither');
  if (gross !== null && tare !== null && gross <= tare) throw new ValidationError('Gross weight must be more than tare weight');

  return withTransaction(async (client) => {
    const po = await client.query('SELECT * FROM proc_purchase_orders WHERE id = $1 FOR UPDATE', [poId]);
    const order = po.rows[0];
    if (!order) throw new NotFoundError('Purchase order not found');
    if (!['approved', 'sent', 'partially_received'].includes(order.status)) throw new ConflictError(`Goods can only be received against an approved order (this one is ${order.status})`);

    let needsInspection = false;
    for (const [i, l] of lines.entries()) {
      const pl = await client.query(
        `SELECT l.*, i.requires_inspection, i.name AS item_name,
                COALESCE((SELECT SUM(gl.received_quantity - gl.damaged_quantity) FROM proc_grn_lines gl JOIN proc_goods_receipts g ON g.id = gl.grn_id
                           WHERE gl.po_line_id = l.id AND g.status IN ('awaiting_inspection', 'on_hold')), 0) AS pending
           FROM proc_po_lines l JOIN proc_items i ON i.id = l.item_id WHERE l.id = $1 AND l.po_id = $2`,
        [l.poLineId, poId],
      );
      const line = pl.rows[0];
      if (!line) throw new ValidationError(`lines[${i}] is not a line of this order`);
      const open = num(line.quantity) * (1 + RECEIPT_TOLERANCE) - num(line.received_quantity) - num(line.pending);
      if (l.received - l.damaged > open + 1e-9) {
        throw new ConflictError(`${line.item_name}: receiving ${l.received - l.damaged} ${line.unit} would exceed the order (open ${Math.max(0, round2(open))} ${line.unit} including ${RECEIPT_TOLERANCE * 100}% tolerance)`);
      }
      if (line.requires_inspection) needsInspection = true;
    }

    const code = await nextCode(client, 'GRN', 5, true);
    const g = await client.query(
      `INSERT INTO proc_goods_receipts (grn_number, po_id, supplier_id, vehicle_number, driver_name, challan_number, weighbridge_ticket, gross_weight_kg, tare_weight_kg, net_weight_kg, status, storage_location, notes, received_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14) RETURNING *`,
      [
        code,
        poId,
        order.supplier_id,
        optionalText(input.vehicleNumber, 'vehicleNumber', 20),
        optionalText(input.driverName, 'driverName', 100),
        optionalText(input.challanNumber, 'challanNumber', 60),
        optionalText(input.weighbridgeTicket, 'weighbridgeTicket', 60),
        gross,
        tare,
        gross !== null && tare !== null ? round2(gross - tare) : null,
        needsInspection ? 'awaiting_inspection' : 'accepted',
        optionalText(input.storageLocation, 'storageLocation', 100),
        optionalText(input.notes, 'notes', 2000),
        user.email,
      ],
    );
    const grn = g.rows[0];
    const accepted = new Map<string, number>();
    for (const l of lines) {
      const r = await client.query<{ id: string }>(
        'INSERT INTO proc_grn_lines (grn_id, po_line_id, received_quantity, damaged_quantity, notes) VALUES ($1, $2, $3, $4, $5) RETURNING id',
        [grn.id, l.poLineId, l.received, l.damaged, l.notes],
      );
      accepted.set(r.rows[0].id, round2(l.received - l.damaged));
    }
    await insertAuditLog(client, { entityType: 'goods_receipt', entityId: grn.id, action: 'CREATE', performedBy: user.email, afterState: { ...grn, lines } });
    // Items that need no gate inspection (packaging, services) are accepted on receipt, less damage.
    if (!needsInspection) await applyAcceptance(client, grn.id, accepted, 'accepted', user, null);
    return getReceipt(grn.id, client);
  });
}

export async function listReceipts(filters: { status?: string; poId?: string }) {
  const where: string[] = [];
  const values: unknown[] = [];
  if (filters.status) {
    values.push(filters.status);
    where.push(`g.status = $${values.length}`);
  }
  if (filters.poId) {
    values.push(filters.poId);
    where.push(`g.po_id = $${values.length}`);
  }
  const r = await pool.query(
    `SELECT g.*, o.po_number, p.name AS supplier_name, i.inspection_code, i.result AS inspection_result,
            (SELECT SUM(received_quantity) FROM proc_grn_lines WHERE grn_id = g.id) AS received_total,
            (SELECT SUM(accepted_quantity) FROM proc_grn_lines WHERE grn_id = g.id) AS accepted_total
       FROM proc_goods_receipts g
       JOIN proc_purchase_orders o ON o.id = g.po_id
       JOIN parties p ON p.id = g.supplier_id
       LEFT JOIN inspections i ON i.id = g.inspection_id
       ${where.length ? `WHERE ${where.join(' AND ')}` : ''}
      ORDER BY g.received_at DESC LIMIT 500`,
    values,
  );
  return r.rows;
}

export async function getReceipt(id: string, client?: PoolClient) {
  const db = client ?? pool;
  const r = await db.query(
    `SELECT g.*, o.po_number, o.expected_delivery_date, p.name AS supplier_name, p.party_code AS supplier_code,
            i.inspection_code, i.result AS inspection_result, i.decision AS inspection_decision, n.ncr_code, n.id AS ncr_id
       FROM proc_goods_receipts g
       JOIN proc_purchase_orders o ON o.id = g.po_id
       JOIN parties p ON p.id = g.supplier_id
       LEFT JOIN inspections i ON i.id = g.inspection_id
       LEFT JOIN non_conformances n ON n.id = i.ncr_id
      WHERE g.id = $1`,
    [id],
  );
  if (!r.rows[0]) throw new NotFoundError('Goods receipt not found');
  const lines = await db.query(
    `SELECT gl.*, l.line_no, l.quantity AS ordered_quantity, l.unit, l.unit_price, i.item_code, i.name AS item_name, i.requires_inspection
       FROM proc_grn_lines gl JOIN proc_po_lines l ON l.id = gl.po_line_id JOIN proc_items i ON i.id = l.item_id
      WHERE gl.grn_id = $1 ORDER BY l.line_no`,
    [id],
  );
  const inspections = await db.query(
    `SELECT id, inspection_code, status, result, decision, created_at FROM inspections WHERE subject_type = 'goods_receipt' AND subject_id = $1 ORDER BY created_at DESC`,
    [id],
  );
  return { ...r.rows[0], lines: lines.rows, inspections: inspections.rows };
}
