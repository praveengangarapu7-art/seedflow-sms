import type { PoolClient } from 'pg';
import { pool } from '../../db/pool';
import { withTransaction } from '../../db/transaction';
import { ConflictError, ForbiddenError, NotFoundError, ValidationError } from '../../errors';
import type { AuthenticatedUser } from '../../middleware/requireAuth';
import { userHasPermission } from '../../middleware/requireAuth';
import { getApprovalsForEntity, registerApprovalHandler, submitForApprovalTx, withdrawTx } from '../approvals/approvals.service';
import { insertAuditLog } from '../auditLogs/auditLogs.service';
import { assertPartyUsable } from '../parties/parties.service';
import { nextCode, num, optionalNumber, optionalText, optionalUuid, requireDate, requireText, requireUuid } from '../shared/validate';
import { lineAmounts, loadItems, parseLines, totals, type LineInput } from './common';
import { checkOrderAgainstContract } from './contracts.service';
import { remainingBudget } from './items.service';
import { recordOrderedTx, releaseOrderedTx } from './requisitions.service';

export interface PurchaseOrderRow {
  id: string;
  po_number: string;
  supplier_id: string;
  requisition_id: string | null;
  rfq_id: string | null;
  contract_id: string | null;
  cost_centre_id: string | null;
  order_date: string;
  expected_delivery_date: string;
  delivery_address: string;
  payment_terms_days: number;
  status: string;
  subtotal: string;
  tax_total: string;
  grand_total: string;
  budget_override_reason: string | null;
  amendment_no: number;
  notes: string | null;
  rejection_reason: string | null;
  cancel_reason: string | null;
  created_by: string;
  approved_at: string | null;
  sent_at: string | null;
}

registerApprovalHandler('purchase_order', {
  onApproved: async (client, id) => {
    await client.query(`UPDATE proc_purchase_orders SET status = 'approved', approved_at = now(), rejection_reason = NULL WHERE id = $1`, [id]);
  },
  onRejected: async (client, id, _user, comment) => {
    await client.query(`UPDATE proc_purchase_orders SET status = 'rejected', rejection_reason = $2 WHERE id = $1`, [id, comment]);
  },
});

async function lock(client: PoolClient, id: string): Promise<PurchaseOrderRow> {
  const r = await client.query<PurchaseOrderRow>('SELECT * FROM proc_purchase_orders WHERE id = $1 FOR UPDATE', [id]);
  if (!r.rows[0]) throw new NotFoundError('Purchase order not found');
  return r.rows[0];
}

interface Header {
  supplierId: string;
  requisitionId: string | null;
  rfqId: string | null;
  contractId: string | null;
  costCentreId: string | null;
  expectedDeliveryDate: string;
  deliveryAddress: string;
  paymentTermsDays: number | null;
  notes: string | null;
}

function parseHeader(input: Record<string, unknown>): Header {
  return {
    supplierId: requireUuid(input.supplierId, 'supplierId'),
    requisitionId: optionalUuid(input.requisitionId, 'requisitionId'),
    rfqId: optionalUuid(input.rfqId, 'rfqId'),
    contractId: optionalUuid(input.contractId, 'contractId'),
    costCentreId: optionalUuid(input.costCentreId, 'costCentreId'),
    expectedDeliveryDate: requireDate(input.expectedDeliveryDate, 'expectedDeliveryDate'),
    deliveryAddress: requireText(input.deliveryAddress, 'deliveryAddress', 500),
    paymentTermsDays: optionalNumber(input.paymentTermsDays, 'paymentTermsDays', { min: 0, max: 365 }),
    notes: optionalText(input.notes, 'notes', 2000),
  };
}

/** Writes lines (replacing any), reserving requisition quantities; returns the order totals. */
async function writeLines(client: PoolClient, poId: string, lines: LineInput[], requisitionId: string | null) {
  // release what the previous version of this order reserved on the requisition
  const old = await client.query<{ requisition_line_id: string | null; quantity: string }>('SELECT requisition_line_id, quantity FROM proc_po_lines WHERE po_id = $1', [poId]);
  for (const o of old.rows) if (o.requisition_line_id) await releaseOrderedTx(client, o.requisition_line_id, num(o.quantity));
  await client.query('DELETE FROM proc_po_lines WHERE po_id = $1', [poId]);

  const items = await loadItems(client, lines.map((l) => l.itemId));
  const amounts: { lineTotal: number; tax: number }[] = [];
  for (const [i, l] of lines.entries()) {
    const item = items.get(l.itemId)!;
    if (l.requisitionLineId) {
      const rl = await client.query<{ requisition_id: string; item_id: string; quantity: string; ordered_quantity: string }>(
        'SELECT requisition_id, item_id, quantity, ordered_quantity FROM proc_requisition_lines WHERE id = $1',
        [l.requisitionLineId],
      );
      const line = rl.rows[0];
      if (!line) throw new NotFoundError('Requisition line not found');
      if (requisitionId && line.requisition_id !== requisitionId) throw new ValidationError(`Line ${i + 1} belongs to a different requisition`);
      if (line.item_id !== l.itemId) throw new ValidationError(`Line ${i + 1}: the item differs from the requisition line`);
      const remaining = num(line.quantity) - num(line.ordered_quantity);
      if (l.quantity > remaining + 1e-9) throw new ConflictError(`Line ${i + 1}: only ${remaining} ${item.unit} remain to be ordered on the requisition`);
      await recordOrderedTx(client, l.requisitionLineId, l.quantity);
    }
    const gst = l.gstRate ?? num(item.gst_rate);
    const a = lineAmounts(l.quantity, l.unitPrice, gst);
    amounts.push(a);
    await client.query(
      `INSERT INTO proc_po_lines (po_id, line_no, item_id, description, quantity, unit, unit_price, gst_rate, line_total, tax_amount, requisition_line_id)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)`,
      [poId, i + 1, l.itemId, l.description, l.quantity, item.unit, l.unitPrice, gst, a.lineTotal, a.tax, l.requisitionLineId],
    );
  }
  return totals(amounts);
}

export async function createOrderTx(client: PoolClient, input: Record<string, unknown>, user: AuthenticatedUser) {
  const h = parseHeader(input);
  const lines = parseLines(input.lines);
  await assertPartyUsable(client, h.supplierId, ['supplier', 'contract_grower'], 'a purchase order');
  if (h.requisitionId) {
    const pr = await client.query('SELECT status FROM proc_requisitions WHERE id = $1', [h.requisitionId]);
    if (!pr.rows[0]) throw new NotFoundError('Requisition not found');
    if (pr.rows[0].status !== 'approved') throw new ConflictError('Only an approved requisition can be turned into an order');
  }
  const code = await nextCode(client, 'PO', 4, true);
  const r = await client.query<PurchaseOrderRow>(
    `INSERT INTO proc_purchase_orders (po_number, supplier_id, requisition_id, rfq_id, contract_id, cost_centre_id, expected_delivery_date, delivery_address, payment_terms_days, notes, created_by)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11) RETURNING *`,
    [code, h.supplierId, h.requisitionId, h.rfqId, h.contractId, h.costCentreId, h.expectedDeliveryDate, h.deliveryAddress, h.paymentTermsDays ?? 30, h.notes, user.email],
  );
  const t = await writeLines(client, r.rows[0].id, lines, h.requisitionId);
  let terms = h.paymentTermsDays ?? 30;
  if (h.contractId) {
    const c = await checkOrderAgainstContract(client, h.contractId, h.supplierId, lines, t.grandTotal, r.rows[0].id);
    if (h.paymentTermsDays === null) terms = c.paymentTermsDays;
  }
  await client.query('UPDATE proc_purchase_orders SET subtotal = $2, tax_total = $3, grand_total = $4, payment_terms_days = $5 WHERE id = $1', [
    r.rows[0].id,
    t.subtotal,
    t.taxTotal,
    t.grandTotal,
    terms,
  ]);
  await insertAuditLog(client, { entityType: 'purchase_order', entityId: r.rows[0].id, action: 'CREATE', performedBy: user.email, afterState: { ...r.rows[0], ...t } });
  return r.rows[0].id;
}

export async function createOrder(input: Record<string, unknown>, user: AuthenticatedUser) {
  return withTransaction(async (client) => {
    const id = await createOrderTx(client, input, user);
    return getOrder(id, client);
  });
}

export async function updateOrder(id: string, input: Record<string, unknown>, user: AuthenticatedUser) {
  return withTransaction(async (client) => {
    const po = await lock(client, id);
    if (po.status !== 'draft' && po.status !== 'rejected') throw new ConflictError(`Only a draft or rejected order can be edited (this one is ${po.status}); use an amendment instead`);
    const h = parseHeader({ supplierId: po.supplier_id, requisitionId: po.requisition_id, rfqId: po.rfq_id, contractId: po.contract_id, costCentreId: po.cost_centre_id, expectedDeliveryDate: po.expected_delivery_date ? new Date(po.expected_delivery_date).toISOString().slice(0, 10) : undefined, deliveryAddress: po.delivery_address, paymentTermsDays: po.payment_terms_days, notes: po.notes, ...input });
    await assertPartyUsable(client, h.supplierId, ['supplier', 'contract_grower'], 'a purchase order');
    let t = { subtotal: num(po.subtotal), taxTotal: num(po.tax_total), grandTotal: num(po.grand_total) };
    let lines: LineInput[] | null = null;
    if (input.lines !== undefined) {
      lines = parseLines(input.lines);
      t = await writeLines(client, id, lines, h.requisitionId);
    }
    if (h.contractId) {
      const current = lines ?? (await client.query('SELECT item_id, unit_price FROM proc_po_lines WHERE po_id = $1', [id])).rows.map((l) => ({ itemId: l.item_id, unitPrice: num(l.unit_price) }));
      await checkOrderAgainstContract(client, h.contractId, h.supplierId, current, t.grandTotal, id);
    }
    await client.query(
      `UPDATE proc_purchase_orders SET supplier_id = $2, contract_id = $3, cost_centre_id = $4, expected_delivery_date = $5, delivery_address = $6,
              payment_terms_days = $7, notes = $8, subtotal = $9, tax_total = $10, grand_total = $11, status = 'draft' WHERE id = $1`,
      [id, h.supplierId, h.contractId, h.costCentreId, h.expectedDeliveryDate, h.deliveryAddress, h.paymentTermsDays ?? po.payment_terms_days, h.notes, t.subtotal, t.taxTotal, t.grandTotal],
    );
    await insertAuditLog(client, { entityType: 'purchase_order', entityId: id, action: 'UPDATE', performedBy: user.email });
    return getOrder(id, client);
  });
}

async function budgetCheck(po: PurchaseOrderRow, overrideReason: string | null): Promise<string | null> {
  if (!po.cost_centre_id) return null;
  const b = await remainingBudget(po.cost_centre_id);
  const amount = num(po.grand_total);
  if (amount > b.remaining) {
    if (!overrideReason) {
      throw new ConflictError(
        `This order (${amount.toFixed(2)}) exceeds the remaining ${b.code} budget (${b.remaining.toFixed(2)}). Give a budgetOverrideReason to submit it anyway; approvers will see it.`,
      );
    }
    return overrideReason;
  }
  return null;
}

export async function submitOrder(id: string, input: Record<string, unknown>, user: AuthenticatedUser) {
  const overrideReason = optionalText(input.budgetOverrideReason, 'budgetOverrideReason', 1000);
  const before = await pool.query<PurchaseOrderRow>('SELECT * FROM proc_purchase_orders WHERE id = $1', [id]);
  if (!before.rows[0]) throw new NotFoundError('Purchase order not found');
  const override = await budgetCheck(before.rows[0], overrideReason);
  return withTransaction(async (client) => {
    const po = await lock(client, id);
    if (po.status !== 'draft') throw new ConflictError(`Only a draft order can be submitted (this one is ${po.status})`);
    const supplier = await assertPartyUsable(client, po.supplier_id, ['supplier', 'contract_grower'], 'a purchase order');
    await client.query(`UPDATE proc_purchase_orders SET status = 'pending_approval', budget_override_reason = $2 WHERE id = $1`, [id, override]);
    await submitForApprovalTx(
      client,
      {
        entityType: 'purchase_order',
        entityId: id,
        entityCode: po.po_number,
        title: `${supplier.name}${override ? ' — OVER BUDGET' : ''}`,
        amount: num(po.grand_total),
      },
      user,
    );
    return getOrder(id, client);
  });
}

export async function sendOrder(id: string, user: AuthenticatedUser) {
  return withTransaction(async (client) => {
    const po = await lock(client, id);
    if (po.status !== 'approved') throw new ConflictError(`Only an approved order can be sent to the supplier (this one is ${po.status})`);
    await client.query(`UPDATE proc_purchase_orders SET status = 'sent', sent_at = now() WHERE id = $1`, [id]);
    await insertAuditLog(client, { entityType: 'purchase_order', entityId: id, action: 'SEND', performedBy: user.email });
    return getOrder(id, client);
  });
}

/**
 * An approved order changes only through an amendment: the reason and the
 * before/after are recorded and the order goes back through approval. Not
 * allowed once anything has been received against it.
 */
export async function amendOrder(id: string, input: Record<string, unknown>, user: AuthenticatedUser) {
  const reason = requireText(input.reason, 'reason', 1000);
  return withTransaction(async (client) => {
    const po = await lock(client, id);
    if (!['approved', 'sent'].includes(po.status)) throw new ConflictError(`Only an approved or sent order can be amended (this one is ${po.status})`);
    const received = await client.query('SELECT 1 FROM proc_po_lines WHERE po_id = $1 AND received_quantity > 0 LIMIT 1', [id]);
    if (received.rows[0]) throw new ConflictError('Goods have already been received against this order; it can no longer be amended');
    const beforeLines = await client.query('SELECT item_id, quantity, unit_price, gst_rate, line_total FROM proc_po_lines WHERE po_id = $1 ORDER BY line_no', [id]);
    const before = { header: { expected_delivery_date: po.expected_delivery_date, delivery_address: po.delivery_address, payment_terms_days: po.payment_terms_days, grand_total: po.grand_total }, lines: beforeLines.rows };

    const expected = input.expectedDeliveryDate === undefined ? po.expected_delivery_date : requireDate(input.expectedDeliveryDate, 'expectedDeliveryDate');
    const address = input.deliveryAddress === undefined ? po.delivery_address : requireText(input.deliveryAddress, 'deliveryAddress', 500);
    const terms = input.paymentTermsDays === undefined ? po.payment_terms_days : optionalNumber(input.paymentTermsDays, 'paymentTermsDays', { min: 0, max: 365 }) ?? po.payment_terms_days;
    let t = { subtotal: num(po.subtotal), taxTotal: num(po.tax_total), grandTotal: num(po.grand_total) };
    if (input.lines !== undefined) {
      const lines = parseLines(input.lines);
      t = await writeLines(client, id, lines, po.requisition_id);
      if (po.contract_id) await checkOrderAgainstContract(client, po.contract_id, po.supplier_id, lines, t.grandTotal, id);
    }
    const amendmentNo = po.amendment_no + 1;
    await client.query(
      `UPDATE proc_purchase_orders SET expected_delivery_date = $2, delivery_address = $3, payment_terms_days = $4, subtotal = $5, tax_total = $6, grand_total = $7,
              amendment_no = $8, status = 'pending_approval', approved_at = NULL, sent_at = NULL WHERE id = $1`,
      [id, expected, address, terms, t.subtotal, t.taxTotal, t.grandTotal, amendmentNo],
    );
    const afterLines = await client.query('SELECT item_id, quantity, unit_price, gst_rate, line_total FROM proc_po_lines WHERE po_id = $1 ORDER BY line_no', [id]);
    await client.query(
      `INSERT INTO proc_po_amendments (po_id, amendment_no, reason, before_state, after_state, amended_by) VALUES ($1, $2, $3, $4, $5, $6)`,
      [id, amendmentNo, reason, JSON.stringify(before), JSON.stringify({ header: { expected_delivery_date: expected, delivery_address: address, payment_terms_days: terms, grand_total: t.grandTotal }, lines: afterLines.rows }), user.email],
    );
    const supplier = await client.query('SELECT name FROM parties WHERE id = $1', [po.supplier_id]);
    await submitForApprovalTx(client, { entityType: 'purchase_order', entityId: id, entityCode: `${po.po_number}/A${amendmentNo}`, title: `Amendment ${amendmentNo}: ${supplier.rows[0].name} — ${reason}`.slice(0, 250), amount: t.grandTotal }, user);
    await insertAuditLog(client, { entityType: 'purchase_order', entityId: id, action: 'AMEND', performedBy: user.email, metadata: { amendmentNo, reason } });
    return getOrder(id, client);
  });
}

export async function cancelOrder(id: string, input: Record<string, unknown>, user: AuthenticatedUser) {
  const reason = requireText(input.reason, 'reason', 1000);
  return withTransaction(async (client) => {
    const po = await lock(client, id);
    if (['cancelled', 'closed', 'received'].includes(po.status)) throw new ConflictError(`A ${po.status} order cannot be cancelled`);
    const received = await client.query('SELECT 1 FROM proc_po_lines WHERE po_id = $1 AND received_quantity > 0 LIMIT 1', [id]);
    if (received.rows[0]) throw new ConflictError('Goods have been received against this order — short-close it instead');
    if (po.created_by !== user.email && user.role !== 'Admin') {
      // anyone holding the approving permission may also cancel
      if (!userHasPermission(user, 'approve_order')) throw new ForbiddenError('Only the buyer who raised the order or a purchase manager can cancel it');
    }
    await withdrawTx(client, 'purchase_order', id, user);
    const lines = await client.query<{ requisition_line_id: string | null; quantity: string }>('SELECT requisition_line_id, quantity FROM proc_po_lines WHERE po_id = $1', [id]);
    for (const l of lines.rows) if (l.requisition_line_id) await releaseOrderedTx(client, l.requisition_line_id, num(l.quantity));
    await client.query(`UPDATE proc_purchase_orders SET status = 'cancelled', cancel_reason = $2 WHERE id = $1`, [id, reason]);
    await insertAuditLog(client, { entityType: 'purchase_order', entityId: id, action: 'CANCEL', performedBy: user.email, metadata: { reason } });
    return getOrder(id, client);
  });
}

/** Short-close: no more goods are expected; the unreceived balance stops counting as committed spend. */
export async function closeOrder(id: string, input: Record<string, unknown>, user: AuthenticatedUser) {
  return withTransaction(async (client) => {
    const po = await lock(client, id);
    if (!['received', 'partially_received', 'sent', 'approved'].includes(po.status)) throw new ConflictError(`A ${po.status} order cannot be closed`);
    const reason = po.status === 'received' ? optionalText(input.reason, 'reason', 1000) : requireText(input.reason, 'reason (goods are still outstanding)', 1000);
    await client.query(`UPDATE proc_purchase_orders SET status = 'closed', closed_at = now(), notes = COALESCE(notes || E'\\n', '') || $2 WHERE id = $1`, [id, reason ? `Closed: ${reason}` : 'Closed']);
    await insertAuditLog(client, { entityType: 'purchase_order', entityId: id, action: 'CLOSE', performedBy: user.email, metadata: { reason } });
    return getOrder(id, client);
  });
}

export async function listOrders(filters: { status?: string; supplierId?: string; q?: string }) {
  const where: string[] = [];
  const values: unknown[] = [];
  if (filters.status) {
    values.push(filters.status);
    where.push(`o.status = $${values.length}`);
  }
  if (filters.supplierId) {
    values.push(filters.supplierId);
    where.push(`o.supplier_id = $${values.length}`);
  }
  if (filters.q) {
    values.push(`%${filters.q.toLowerCase()}%`);
    where.push(`(LOWER(o.po_number) LIKE $${values.length} OR LOWER(p.name) LIKE $${values.length})`);
  }
  const r = await pool.query(
    `SELECT o.*, p.name AS supplier_name, p.party_code AS supplier_code,
            COALESCE((SELECT SUM(l.received_quantity) / NULLIF(SUM(l.quantity), 0) FROM proc_po_lines l WHERE l.po_id = o.id), 0) AS received_fraction,
            (o.expected_delivery_date < CURRENT_DATE AND o.status IN ('approved', 'sent', 'partially_received')) AS is_late
       FROM proc_purchase_orders o JOIN parties p ON p.id = o.supplier_id
       ${where.length ? `WHERE ${where.join(' AND ')}` : ''}
      ORDER BY o.created_at DESC LIMIT 500`,
    values,
  );
  return r.rows;
}

export async function getOrder(id: string, client?: PoolClient) {
  const db = client ?? pool;
  const r = await db.query(
    `SELECT o.*, p.name AS supplier_name, p.party_code AS supplier_code, p.phone AS supplier_phone, p.email AS supplier_email, p.gstin AS supplier_gstin,
            pr.pr_number, rq.rfq_number, c.contract_number, cc.code AS cost_centre_code, cc.name AS cost_centre_name,
            (o.expected_delivery_date < CURRENT_DATE AND o.status IN ('approved', 'sent', 'partially_received')) AS is_late
       FROM proc_purchase_orders o
       JOIN parties p ON p.id = o.supplier_id
       LEFT JOIN proc_requisitions pr ON pr.id = o.requisition_id
       LEFT JOIN proc_rfqs rq ON rq.id = o.rfq_id
       LEFT JOIN proc_contracts c ON c.id = o.contract_id
       LEFT JOIN proc_cost_centres cc ON cc.id = o.cost_centre_id
      WHERE o.id = $1`,
    [id],
  );
  if (!r.rows[0]) throw new NotFoundError('Purchase order not found');
  const lines = await db.query(
    `SELECT l.*, i.item_code, i.name AS item_name, i.category, i.requires_inspection FROM proc_po_lines l JOIN proc_items i ON i.id = l.item_id WHERE l.po_id = $1 ORDER BY l.line_no`,
    [id],
  );
  const receipts = await db.query(`SELECT id, grn_number, status, received_at, net_weight_kg FROM proc_goods_receipts WHERE po_id = $1 ORDER BY received_at DESC`, [id]);
  const invoices = await db.query(`SELECT id, invoice_number, supplier_invoice_no, status, match_status, total_amount, due_date FROM proc_invoices WHERE po_id = $1 ORDER BY created_at DESC`, [id]);
  const amendments = await db.query(`SELECT * FROM proc_po_amendments WHERE po_id = $1 ORDER BY amendment_no DESC`, [id]);
  const approvals = await getApprovalsForEntity('purchase_order', id, client);
  return { ...r.rows[0], lines: lines.rows, receipts: receipts.rows, invoices: invoices.rows, amendments: amendments.rows, approvals };
}

/** Recomputes an order's receiving status from its lines (called after every receipt decision). */
export async function refreshReceivingStatusTx(client: PoolClient, poId: string): Promise<void> {
  const r = await client.query<{ total: string; received: string }>(
    'SELECT SUM(quantity) AS total, SUM(received_quantity) AS received FROM proc_po_lines WHERE po_id = $1',
    [poId],
  );
  const total = num(r.rows[0].total);
  const received = num(r.rows[0].received);
  const status = received <= 0 ? null : received + 1e-9 >= total ? 'received' : 'partially_received';
  if (status) await client.query(`UPDATE proc_purchase_orders SET status = $2 WHERE id = $1 AND status IN ('approved', 'sent', 'partially_received')`, [poId, status]);
}
