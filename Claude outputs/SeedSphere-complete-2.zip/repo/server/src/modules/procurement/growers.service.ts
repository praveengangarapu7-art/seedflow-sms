import type { PoolClient } from 'pg';
import { pool } from '../../db/pool';
import { withTransaction } from '../../db/transaction';
import { ConflictError, ForbiddenError, NotFoundError, ValidationError } from '../../errors';
import type { AuthenticatedUser } from '../../middleware/requireAuth';
import { getApprovalsForEntity, registerApprovalHandler, submitForApprovalTx, withdrawTx } from '../approvals/approvals.service';
import { queueMessageTx } from '../reach/messaging.service';
import { insertAuditLog } from '../auditLogs/auditLogs.service';
import { registerInspectionSubject, type InspectionRow } from '../inspections/inspections.service';
import { assertPartyUsable } from '../parties/parties.service';
import {
  assertLotNotOnHold,
  nextCode,
  num,
  optionalNumber,
  optionalText,
  optionalUuid,
  requireDate,
  requireEnum,
  requireNumber,
  requireText,
  requireUuid,
  round2,
} from '../shared/validate';
import { PAYMENT_MODES } from './invoices.service';

const SEASONS = ['kharif', 'rabi', 'zaid'] as const;
const STAGE_BEFORE: Record<string, string> = { Foundation: 'Breeder', Certified: 'Foundation' };
/** Buy-back covers deliveries up to this multiple of the agreed expected yield. */
const MAX_DELIVERY_OF_EXPECTED = 1.2;

export interface AgreementRow {
  id: string;
  agreement_number: string;
  grower_id: string;
  season: string;
  season_year: number;
  crop: string;
  variety: string;
  seed_class: string;
  plot_village: string;
  area_acres: string;
  parent_lot_id: string | null;
  parent_qty_issued_kg: string | null;
  expected_yield_kg: string;
  buyback_price_per_kg: string;
  advance_amount: string;
  input_cost_amount: string;
  standard_moisture_pct: string;
  reject_moisture_pct: string;
  min_purity_pct: string;
  purity_deduction_per_point_pct: string;
  reject_purity_pct: string;
  procurement_window_start: string;
  procurement_window_end: string;
  status: string;
  created_by: string;
}

// ------------------------------------------------------------------ pricing

export interface DeliveryPrice {
  payableWeightKg: number;
  grossValue: number;
  qualityDeduction: number;
  netValue: number;
  note: string;
}

/**
 * Prices a delivery under its agreement's written terms:
 *  - wet seed is paid on its dry-weight equivalent:
 *      payable = weight × (100 − moisture) ÷ (100 − standard moisture)
 *  - each point of purity below the minimum deducts a fixed % of the value.
 * Deliveries beyond the reject limits are refused, not discounted.
 */
export function priceDelivery(a: AgreementRow, weightKg: number, moisture: number, purity: number): DeliveryPrice {
  const std = num(a.standard_moisture_pct);
  const price = num(a.buyback_price_per_kg);
  if (moisture > num(a.reject_moisture_pct)) throw new ValidationError(`Moisture ${moisture}% is above the agreement's reject limit of ${num(a.reject_moisture_pct)}% — the delivery must be rejected`);
  if (purity < num(a.reject_purity_pct)) throw new ValidationError(`Purity ${purity}% is below the agreement's reject limit of ${num(a.reject_purity_pct)}% — the delivery must be rejected`);
  const notes: string[] = [];
  let payable = weightKg;
  if (moisture > std) {
    payable = round2((weightKg * (100 - moisture)) / (100 - std));
    notes.push(`moisture ${moisture}% > ${std}%: paid on ${payable} kg of ${weightKg} kg`);
  }
  const grossValue = round2(payable * price);
  let deductionPct = 0;
  if (purity < num(a.min_purity_pct)) {
    deductionPct = round2((num(a.min_purity_pct) - purity) * num(a.purity_deduction_per_point_pct));
    notes.push(`purity ${purity}% < ${num(a.min_purity_pct)}%: ${deductionPct}% deduction`);
  }
  const qualityDeduction = round2((grossValue * deductionPct) / 100);
  return {
    payableWeightKg: payable,
    grossValue,
    qualityDeduction,
    netValue: round2(grossValue - qualityDeduction),
    note: notes.length ? notes.join('; ') : 'within standard — full price',
  };
}

// --------------------------------------------------------------- handlers

registerApprovalHandler('grower_agreement', {
  onApproved: async (client, id, user) => {
    const r = await client.query<AgreementRow>('SELECT * FROM grw_agreements WHERE id = $1 FOR UPDATE', [id]);
    const a = r.rows[0];
    // The foundation seed handed to the grower leaves available stock.
    if (a.parent_lot_id && a.parent_qty_issued_kg) {
      await assertLotNotOnHold(client, a.parent_lot_id);
      const lot = await client.query<{ quantity_total: string; quantity_allocated: string; lot_code: string }>(
        'SELECT quantity_total, quantity_allocated, lot_code FROM seed_lots WHERE id = $1 FOR UPDATE',
        [a.parent_lot_id],
      );
      const available = num(lot.rows[0].quantity_total) - num(lot.rows[0].quantity_allocated);
      if (num(a.parent_qty_issued_kg) > available) throw new ConflictError(`Only ${available} kg of ${lot.rows[0].lot_code} is available to issue`);
      await client.query('UPDATE seed_lots SET quantity_allocated = quantity_allocated + $2 WHERE id = $1', [a.parent_lot_id, a.parent_qty_issued_kg]);
      await insertAuditLog(client, { entityType: 'seed_lot', entityId: a.parent_lot_id, action: 'ISSUED_TO_GROWER', performedBy: user.email, metadata: { agreement: a.agreement_number, kg: a.parent_qty_issued_kg } });
    }
    await client.query(`UPDATE grw_agreements SET status = 'active', approved_at = now() WHERE id = $1`, [id]);
    if (num(a.input_cost_amount) > 0) {
      await client.query(
        `INSERT INTO grw_ledger (grower_id, agreement_id, entry_type, description, amount, created_by) VALUES ($1, $2, 'inputs', $3, $4, $5)`,
        [a.grower_id, id, `Seed and inputs supplied under ${a.agreement_number} (recoverable)`, -num(a.input_cost_amount), user.email],
      );
    }
    if (num(a.advance_amount) > 0) {
      const code = await nextCode(client, 'GSET', 5, true);
      const s = await client.query(
        `INSERT INTO grw_settlements (settlement_number, settlement_type, grower_id, agreement_id, net_payable, created_by) VALUES ($1, 'advance', $2, $3, $4, $5) RETURNING id`,
        [code, a.grower_id, id, a.advance_amount, user.email],
      );
      const g = await client.query('SELECT name FROM parties WHERE id = $1', [a.grower_id]);
      await submitForApprovalTx(client, { entityType: 'grower_settlement', entityId: s.rows[0].id, entityCode: code, title: `Advance to ${g.rows[0].name} (${a.agreement_number})`, amount: num(a.advance_amount) }, user);
    }
  },
  onRejected: async (client, id, _user, comment) => {
    await client.query(`UPDATE grw_agreements SET status = 'rejected', rejection_reason = $2 WHERE id = $1`, [id, comment]);
  },
});

registerApprovalHandler('grower_settlement', {
  onApproved: async (client, id) => {
    await client.query(`UPDATE grw_settlements SET status = 'approved' WHERE id = $1`, [id]);
  },
  onRejected: async (client, id, _user, comment) => {
    await client.query(`UPDATE grw_settlements SET status = 'rejected', rejection_reason = $2 WHERE id = $1`, [id, comment]);
    // Entries the rejected settlement had reserved become payable again.
    await client.query('UPDATE grw_ledger SET settled_by_id = NULL WHERE settled_by_id = $1', [id]);
  },
});

function readResult(results: { label: string; numeric_value: string | null }[], match: RegExp): number | null {
  const r = results.find((x) => match.test(x.label) && x.numeric_value !== null);
  return r ? num(r.numeric_value) : null;
}

registerInspectionSubject('grower_delivery', {
  resolveSubject: async (client, subjectId) => {
    const r = await client.query(
      `SELECT d.delivery_number, d.status, d.net_weight_kg, a.crop, a.variety, p.name FROM grw_deliveries d
         JOIN grw_agreements a ON a.id = d.agreement_id JOIN parties p ON p.id = d.grower_id WHERE d.id = $1`,
      [subjectId],
    );
    const d = r.rows[0];
    if (!d) throw new NotFoundError('Grower delivery not found');
    if (d.status !== 'awaiting_inspection' && d.status !== 'on_hold') throw new ConflictError(`${d.delivery_number} is already ${d.status}`);
    const open = await client.query(`SELECT inspection_code FROM inspections WHERE subject_type = 'grower_delivery' AND subject_id = $1 AND status = 'in_progress'`, [subjectId]);
    if (open.rows[0]) throw new ConflictError(`Inspection ${open.rows[0].inspection_code} is already open for ${d.delivery_number}`);
    return { label: `${d.delivery_number} · ${d.name} · ${d.crop} ${d.variety} · ${num(d.net_weight_kg)} kg`, seedLotId: null };
  },
  onSubmitted: async (client, ins: InspectionRow, user) => {
    const id = ins.subject_id!;
    const d = await client.query('SELECT * FROM grw_deliveries WHERE id = $1 FOR UPDATE', [id]);
    const delivery = d.rows[0];
    const a = await client.query<AgreementRow>('SELECT * FROM grw_agreements WHERE id = $1', [delivery.agreement_id]);
    const results = await client.query<{ label: string; numeric_value: string | null }>('SELECT label, numeric_value FROM inspection_results WHERE inspection_id = $1', [ins.id]);
    const moisture = readResult(results.rows, /moisture/i);
    const purity = readResult(results.rows, /purity/i);

    if (ins.decision === 'reject') {
      await client.query(`UPDATE grw_deliveries SET status = 'rejected', inspection_id = $2, moisture_pct = $3, purity_pct = $4, decided_at = now() WHERE id = $1`, [id, ins.id, moisture, purity]);
      await insertAuditLog(client, { entityType: 'grower_delivery', entityId: id, action: 'REJECT', performedBy: user.email, metadata: { inspection: ins.inspection_code } });
      return;
    }
    if (ins.decision === 'hold' || ins.decision === 'rework') {
      await client.query(`UPDATE grw_deliveries SET status = 'on_hold', inspection_id = $2, moisture_pct = $3, purity_pct = $4 WHERE id = $1`, [id, ins.id, moisture, purity]);
      return;
    }
    if (moisture === null || purity === null) throw new ValidationError('Pricing a grower delivery needs the Moisture and Physical purity checks recorded on the inspection');
    const weight = ins.decision === 'partial_accept' ? Math.min(num(ins.accepted_quantity), num(delivery.net_weight_kg)) : num(delivery.net_weight_kg);
    if (weight <= 0) throw new ValidationError('Accepted quantity must be more than zero');
    const p = priceDelivery(a.rows[0], weight, moisture, purity);
    const note = ins.decision === 'partial_accept' ? `accepted ${weight} kg of ${num(delivery.net_weight_kg)} kg; ${p.note}` : p.note;
    await client.query(
      `UPDATE grw_deliveries SET status = 'accepted', inspection_id = $2, moisture_pct = $3, purity_pct = $4, payable_weight_kg = $5, price_per_kg = $6,
              gross_value = $7, quality_deduction = $8, net_value = $9, pricing_note = $10, decided_at = now() WHERE id = $1`,
      [id, ins.id, moisture, purity, p.payableWeightKg, a.rows[0].buyback_price_per_kg, p.grossValue, p.qualityDeduction, p.netValue, note],
    );
    await client.query(
      `INSERT INTO grw_ledger (grower_id, agreement_id, entry_type, description, amount, delivery_id, created_by) VALUES ($1, $2, 'delivery', $3, $4, $5, $6)`,
      [delivery.grower_id, delivery.agreement_id, `${delivery.delivery_number}: ${p.payableWeightKg} kg × ₹${num(a.rows[0].buyback_price_per_kg)}${p.qualityDeduction ? ` less ₹${p.qualityDeduction}` : ''}`, p.netValue, id, user.email],
    );
    await insertAuditLog(client, { entityType: 'grower_delivery', entityId: id, action: 'ACCEPT', performedBy: user.email, afterState: { ...p, moisture, purity } });
  },
});

// ------------------------------------------------------------- agreements

interface AgreementInput {
  growerId: string;
  season: string;
  seasonYear: number;
  crop: string;
  variety: string;
  seedClass: string;
  plotVillage: string;
  plotSurveyNumber: string | null;
  areaAcres: number;
  latitude: number | null;
  longitude: number | null;
  parentLotId: string | null;
  parentQtyIssuedKg: number | null;
  expectedYieldKg: number;
  buybackPricePerKg: number;
  advanceAmount: number;
  inputCostAmount: number;
  standardMoisturePct: number;
  rejectMoisturePct: number;
  minPurityPct: number;
  purityDeductionPerPointPct: number;
  rejectPurityPct: number;
  windowStart: string;
  windowEnd: string;
}

function parseAgreement(input: Record<string, unknown>): AgreementInput {
  const a: AgreementInput = {
    growerId: requireUuid(input.growerId, 'growerId'),
    season: requireEnum(input.season, SEASONS, 'season'),
    seasonYear: requireNumber(input.seasonYear, 'seasonYear', { min: 2000, max: 2100 }),
    crop: requireText(input.crop, 'crop', 100),
    variety: requireText(input.variety, 'variety', 100),
    seedClass: requireEnum(input.seedClass, ['Foundation', 'Certified'] as const, 'seedClass'),
    plotVillage: requireText(input.plotVillage, 'plotVillage', 100),
    plotSurveyNumber: optionalText(input.plotSurveyNumber, 'plotSurveyNumber', 60),
    areaAcres: requireNumber(input.areaAcres, 'areaAcres', { positive: true, max: 10000 }),
    latitude: optionalNumber(input.latitude, 'latitude', { min: -90, max: 90 }),
    longitude: optionalNumber(input.longitude, 'longitude', { min: -180, max: 180 }),
    parentLotId: optionalUuid(input.parentLotId, 'parentLotId'),
    parentQtyIssuedKg: optionalNumber(input.parentQtyIssuedKg, 'parentQtyIssuedKg', { positive: true }),
    expectedYieldKg: requireNumber(input.expectedYieldKg, 'expectedYieldKg', { positive: true }),
    buybackPricePerKg: requireNumber(input.buybackPricePerKg, 'buybackPricePerKg', { positive: true }),
    advanceAmount: optionalNumber(input.advanceAmount, 'advanceAmount', { min: 0 }) ?? 0,
    inputCostAmount: optionalNumber(input.inputCostAmount, 'inputCostAmount', { min: 0 }) ?? 0,
    standardMoisturePct: optionalNumber(input.standardMoisturePct, 'standardMoisturePct', { positive: true, max: 29 }) ?? 12,
    rejectMoisturePct: optionalNumber(input.rejectMoisturePct, 'rejectMoisturePct', { positive: true, max: 40 }) ?? 18,
    minPurityPct: optionalNumber(input.minPurityPct, 'minPurityPct', { min: 50, max: 100 }) ?? 98,
    purityDeductionPerPointPct: optionalNumber(input.purityDeductionPerPointPct, 'purityDeductionPerPointPct', { min: 0, max: 50 }) ?? 2,
    rejectPurityPct: optionalNumber(input.rejectPurityPct, 'rejectPurityPct', { min: 0, max: 100 }) ?? 95,
    windowStart: requireDate(input.procurementWindowStart, 'procurementWindowStart'),
    windowEnd: requireDate(input.procurementWindowEnd, 'procurementWindowEnd'),
  };
  if (a.windowEnd < a.windowStart) throw new ValidationError('The procurement window ends before it starts');
  if (a.rejectMoisturePct <= a.standardMoisturePct) throw new ValidationError('The reject moisture must be above the standard moisture');
  if (a.rejectPurityPct >= a.minPurityPct) throw new ValidationError('The reject purity must be below the minimum purity');
  if ((a.parentLotId === null) !== (a.parentQtyIssuedKg === null)) throw new ValidationError('Give both the parent seed lot and the quantity issued, or neither');
  // An advance larger than what the crop is expected to earn is unrecoverable.
  if (a.advanceAmount + a.inputCostAmount > a.expectedYieldKg * a.buybackPricePerKg) throw new ValidationError('The advance and input cost exceed the expected value of the crop');
  return a;
}

async function validateParent(client: PoolClient, a: AgreementInput) {
  if (!a.parentLotId) return;
  const lot = await client.query('SELECT lot_code, crop, variety, stage, quantity_total, quantity_allocated, status FROM seed_lots WHERE id = $1', [a.parentLotId]);
  const p = lot.rows[0];
  if (!p) throw new NotFoundError('Parent seed lot not found');
  if (p.crop !== a.crop || p.variety !== a.variety) throw new ValidationError(`Parent lot ${p.lot_code} is ${p.crop} ${p.variety}, not ${a.crop} ${a.variety}`);
  if (p.stage !== STAGE_BEFORE[a.seedClass]) throw new ValidationError(`${a.seedClass} seed is produced from ${STAGE_BEFORE[a.seedClass]} seed; ${p.lot_code} is ${p.stage}`);
  if (p.status !== 'active') throw new ConflictError(`Parent lot ${p.lot_code} is ${p.status}`);
  const available = num(p.quantity_total) - num(p.quantity_allocated);
  if ((a.parentQtyIssuedKg ?? 0) > available) throw new ConflictError(`Only ${available} kg of ${p.lot_code} is available to issue`);
}

const AGREEMENT_COLUMNS = `grower_id, season, season_year, crop, variety, seed_class, plot_village, plot_survey_number, area_acres, latitude, longitude,
  parent_lot_id, parent_qty_issued_kg, expected_yield_kg, buyback_price_per_kg, advance_amount, input_cost_amount, standard_moisture_pct, reject_moisture_pct,
  min_purity_pct, purity_deduction_per_point_pct, reject_purity_pct, procurement_window_start, procurement_window_end`;

function agreementValues(a: AgreementInput) {
  return [
    a.growerId, a.season, a.seasonYear, a.crop, a.variety, a.seedClass, a.plotVillage, a.plotSurveyNumber, a.areaAcres, a.latitude, a.longitude,
    a.parentLotId, a.parentQtyIssuedKg, a.expectedYieldKg, a.buybackPricePerKg, a.advanceAmount, a.inputCostAmount, a.standardMoisturePct, a.rejectMoisturePct,
    a.minPurityPct, a.purityDeductionPerPointPct, a.rejectPurityPct, a.windowStart, a.windowEnd,
  ];
}

export async function createAgreement(input: Record<string, unknown>, user: AuthenticatedUser) {
  const a = parseAgreement(input);
  return withTransaction(async (client) => {
    await assertPartyUsable(client, a.growerId, ['contract_grower'], 'a grower agreement');
    await validateParent(client, a);
    const code = await nextCode(client, 'GA', 4, true);
    const values = agreementValues(a);
    const r = await client.query<AgreementRow>(
      `INSERT INTO grw_agreements (agreement_number, created_by, ${AGREEMENT_COLUMNS}) VALUES ($1, $2, ${values.map((_, i) => `$${i + 3}`).join(', ')}) RETURNING *`,
      [code, user.email, ...values],
    );
    await insertAuditLog(client, { entityType: 'grower_agreement', entityId: r.rows[0].id, action: 'CREATE', performedBy: user.email, afterState: r.rows[0] });
    return getAgreement(r.rows[0].id, client);
  });
}

export async function updateAgreement(id: string, input: Record<string, unknown>, user: AuthenticatedUser) {
  return withTransaction(async (client) => {
    const cur = await client.query<AgreementRow>('SELECT * FROM grw_agreements WHERE id = $1 FOR UPDATE', [id]);
    const row = cur.rows[0];
    if (!row) throw new NotFoundError('Agreement not found');
    if (row.status !== 'draft' && row.status !== 'rejected') throw new ConflictError(`Only a draft or rejected agreement can be edited (this one is ${row.status})`);
    const a = parseAgreement({
      growerId: row.grower_id,
      season: row.season,
      seasonYear: row.season_year,
      crop: row.crop,
      variety: row.variety,
      seedClass: row.seed_class,
      plotVillage: row.plot_village,
      areaAcres: row.area_acres,
      parentLotId: row.parent_lot_id,
      parentQtyIssuedKg: row.parent_qty_issued_kg,
      expectedYieldKg: row.expected_yield_kg,
      buybackPricePerKg: row.buyback_price_per_kg,
      advanceAmount: row.advance_amount,
      inputCostAmount: row.input_cost_amount,
      standardMoisturePct: row.standard_moisture_pct,
      rejectMoisturePct: row.reject_moisture_pct,
      minPurityPct: row.min_purity_pct,
      purityDeductionPerPointPct: row.purity_deduction_per_point_pct,
      rejectPurityPct: row.reject_purity_pct,
      procurementWindowStart: new Date(row.procurement_window_start).toISOString().slice(0, 10),
      procurementWindowEnd: new Date(row.procurement_window_end).toISOString().slice(0, 10),
      ...input,
    });
    await assertPartyUsable(client, a.growerId, ['contract_grower'], 'a grower agreement');
    await validateParent(client, a);
    const cols = AGREEMENT_COLUMNS.split(',').map((c) => c.trim());
    const values = agreementValues(a);
    await client.query(`UPDATE grw_agreements SET ${cols.map((c, i) => `${c} = $${i + 2}`).join(', ')}, status = 'draft', rejection_reason = NULL WHERE id = $1`, [id, ...values]);
    await insertAuditLog(client, { entityType: 'grower_agreement', entityId: id, action: 'UPDATE', performedBy: user.email });
    return getAgreement(id, client);
  });
}

export async function submitAgreement(id: string, user: AuthenticatedUser) {
  return withTransaction(async (client) => {
    const r = await client.query<AgreementRow>('SELECT * FROM grw_agreements WHERE id = $1 FOR UPDATE', [id]);
    const a = r.rows[0];
    if (!a) throw new NotFoundError('Agreement not found');
    if (a.status !== 'draft') throw new ConflictError(`Only a draft agreement can be submitted (this one is ${a.status})`);
    const g = await assertPartyUsable(client, a.grower_id, ['contract_grower'], 'a grower agreement');
    await client.query(`UPDATE grw_agreements SET status = 'pending_approval' WHERE id = $1`, [id]);
    await submitForApprovalTx(
      client,
      {
        entityType: 'grower_agreement',
        entityId: id,
        entityCode: a.agreement_number,
        title: `${g.name} · ${a.crop} ${a.variety} · ${num(a.area_acres)} acres`,
        amount: round2(num(a.expected_yield_kg) * num(a.buyback_price_per_kg)),
      },
      user,
    );
    return getAgreement(id, client);
  });
}

export async function cancelAgreement(id: string, input: Record<string, unknown>, user: AuthenticatedUser) {
  const reason = requireText(input.reason, 'reason', 1000);
  return withTransaction(async (client) => {
    const r = await client.query<AgreementRow>('SELECT * FROM grw_agreements WHERE id = $1 FOR UPDATE', [id]);
    const a = r.rows[0];
    if (!a) throw new NotFoundError('Agreement not found');
    if (['completed', 'cancelled'].includes(a.status)) throw new ConflictError(`A ${a.status} agreement cannot be cancelled`);
    const d = await client.query('SELECT 1 FROM grw_deliveries WHERE agreement_id = $1 LIMIT 1', [id]);
    if (d.rows[0]) throw new ConflictError('Deliveries exist under this agreement — complete it instead');
    const paid = await client.query(`SELECT 1 FROM grw_settlements WHERE agreement_id = $1 AND status IN ('approved', 'paid') LIMIT 1`, [id]);
    if (paid.rows[0]) throw new ConflictError('An advance has been approved or paid — recover it before cancelling');
    await withdrawTx(client, 'grower_agreement', id, user);
    if (a.status === 'active' && a.parent_lot_id && a.parent_qty_issued_kg) {
      await client.query('UPDATE seed_lots SET quantity_allocated = GREATEST(0, quantity_allocated - $2) WHERE id = $1', [a.parent_lot_id, a.parent_qty_issued_kg]);
    }
    const pending = await client.query<{ id: string }>(`SELECT id FROM grw_settlements WHERE agreement_id = $1 AND status = 'pending_approval'`, [id]);
    for (const s of pending.rows) {
      await withdrawTx(client, 'grower_settlement', s.id, user);
      await client.query(`UPDATE grw_settlements SET status = 'rejected', rejection_reason = 'Agreement cancelled' WHERE id = $1`, [s.id]);
    }
    await client.query(`DELETE FROM grw_ledger WHERE agreement_id = $1 AND entry_type = 'inputs' AND settled_by_id IS NULL`, [id]);
    await client.query(`UPDATE grw_agreements SET status = 'cancelled', rejection_reason = $2 WHERE id = $1`, [id, reason]);
    await insertAuditLog(client, { entityType: 'grower_agreement', entityId: id, action: 'CANCEL', performedBy: user.email, metadata: { reason } });
    return getAgreement(id, client);
  });
}

export async function completeAgreement(id: string, user: AuthenticatedUser) {
  return withTransaction(async (client) => {
    const r = await client.query<AgreementRow>('SELECT * FROM grw_agreements WHERE id = $1 FOR UPDATE', [id]);
    if (!r.rows[0]) throw new NotFoundError('Agreement not found');
    if (r.rows[0].status !== 'active') throw new ConflictError('Only an active agreement can be completed');
    const open = await client.query(`SELECT delivery_number FROM grw_deliveries WHERE agreement_id = $1 AND status IN ('awaiting_inspection', 'on_hold')`, [id]);
    if (open.rows.length) throw new ConflictError(`Decide pending deliveries first: ${open.rows.map((x) => x.delivery_number).join(', ')}`);
    await client.query(`UPDATE grw_agreements SET status = 'completed' WHERE id = $1`, [id]);
    await insertAuditLog(client, { entityType: 'grower_agreement', entityId: id, action: 'COMPLETE', performedBy: user.email });
    return getAgreement(id, client);
  });
}

export async function listAgreements(filters: { status?: string; growerId?: string; season?: string }) {
  const where: string[] = [];
  const values: unknown[] = [];
  if (filters.status) {
    values.push(filters.status);
    where.push(`a.status = $${values.length}`);
  }
  if (filters.growerId) {
    values.push(filters.growerId);
    where.push(`a.grower_id = $${values.length}`);
  }
  if (filters.season) {
    values.push(filters.season);
    where.push(`a.season = $${values.length}`);
  }
  const r = await pool.query(
    `SELECT a.*, p.name AS grower_name, p.party_code AS grower_code, p.village AS grower_village, l.lot_code AS parent_lot_code,
            COALESCE((SELECT SUM(net_weight_kg) FROM grw_deliveries d WHERE d.agreement_id = a.id AND d.status = 'accepted'), 0) AS delivered_kg,
            COALESCE((SELECT SUM(amount) FROM grw_ledger g WHERE g.agreement_id = a.id), 0) AS balance
       FROM grw_agreements a JOIN parties p ON p.id = a.grower_id LEFT JOIN seed_lots l ON l.id = a.parent_lot_id
       ${where.length ? `WHERE ${where.join(' AND ')}` : ''}
      ORDER BY a.created_at DESC LIMIT 500`,
    values,
  );
  return r.rows;
}

export async function getAgreement(id: string, client?: PoolClient) {
  const db = client ?? pool;
  const r = await db.query(
    `SELECT a.*, p.name AS grower_name, p.party_code AS grower_code, p.phone AS grower_phone, p.village AS grower_village, p.preferred_language,
            l.lot_code AS parent_lot_code, l.stage AS parent_stage
       FROM grw_agreements a JOIN parties p ON p.id = a.grower_id LEFT JOIN seed_lots l ON l.id = a.parent_lot_id WHERE a.id = $1`,
    [id],
  );
  if (!r.rows[0]) throw new NotFoundError('Agreement not found');
  const deliveries = await db.query(
    `SELECT d.*, i.inspection_code, i.result AS inspection_result FROM grw_deliveries d LEFT JOIN inspections i ON i.id = d.inspection_id
      WHERE d.agreement_id = $1 ORDER BY d.delivered_at DESC`,
    [id],
  );
  const ledger = await ledgerRows(db, { agreementId: id });
  const settlements = await db.query(`SELECT * FROM grw_settlements WHERE agreement_id = $1 ORDER BY created_at DESC`, [id]);
  const approvals = await getApprovalsForEntity('grower_agreement', id, client);
  return { ...r.rows[0], deliveries: deliveries.rows, ledger, settlements: settlements.rows, approvals };
}

// ------------------------------------------------------------- deliveries

export async function recordDelivery(input: Record<string, unknown>, user: AuthenticatedUser) {
  const agreementId = requireUuid(input.agreementId, 'agreementId');
  const gross = requireNumber(input.grossWeightKg, 'grossWeightKg', { positive: true });
  const tare = requireNumber(input.tareWeightKg, 'tareWeightKg', { min: 0 });
  if (gross <= tare) throw new ValidationError('Gross weight must be more than tare weight');
  const net = round2(gross - tare);
  return withTransaction(async (client) => {
    const r = await client.query<AgreementRow>('SELECT * FROM grw_agreements WHERE id = $1 FOR UPDATE', [agreementId]);
    const a = r.rows[0];
    if (!a) throw new NotFoundError('Agreement not found');
    if (a.status !== 'active') throw new ConflictError(`Deliveries are received only under an active agreement (this one is ${a.status})`);
    const today = new Date().toISOString().slice(0, 10);
    const ws = new Date(a.procurement_window_start).toISOString().slice(0, 10);
    const we = new Date(a.procurement_window_end).toISOString().slice(0, 10);
    if (today < ws || today > we) throw new ConflictError(`Today is outside the agreed procurement window (${ws} to ${we})`);
    const sofar = await client.query<{ kg: string }>(`SELECT COALESCE(SUM(net_weight_kg), 0) AS kg FROM grw_deliveries WHERE agreement_id = $1 AND status <> 'rejected'`, [agreementId]);
    const cap = num(a.expected_yield_kg) * MAX_DELIVERY_OF_EXPECTED;
    if (num(sofar.rows[0].kg) + net > cap) throw new ConflictError(`This delivery would exceed the buy-back limit of ${cap} kg (${MAX_DELIVERY_OF_EXPECTED * 100}% of the expected yield)`);
    const code = await nextCode(client, 'GD', 5, true);
    const d = await client.query(
      `INSERT INTO grw_deliveries (delivery_number, agreement_id, grower_id, vehicle_number, weighbridge_ticket, gross_weight_kg, tare_weight_kg, net_weight_kg, bags, received_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10) RETURNING *`,
      [code, agreementId, a.grower_id, optionalText(input.vehicleNumber, 'vehicleNumber', 20), optionalText(input.weighbridgeTicket, 'weighbridgeTicket', 60), gross, tare, net, optionalNumber(input.bags, 'bags', { positive: true }), user.email],
    );
    await insertAuditLog(client, { entityType: 'grower_delivery', entityId: d.rows[0].id, action: 'CREATE', performedBy: user.email, afterState: d.rows[0] });
    return d.rows[0];
  });
}

export async function listDeliveries(filters: { status?: string; growerId?: string }) {
  const where: string[] = [];
  const values: unknown[] = [];
  if (filters.status) {
    values.push(filters.status);
    where.push(`d.status = $${values.length}`);
  }
  if (filters.growerId) {
    values.push(filters.growerId);
    where.push(`d.grower_id = $${values.length}`);
  }
  const r = await pool.query(
    `SELECT d.*, a.agreement_number, a.crop, a.variety, a.seed_class, p.name AS grower_name, i.inspection_code
       FROM grw_deliveries d JOIN grw_agreements a ON a.id = d.agreement_id JOIN parties p ON p.id = d.grower_id
       LEFT JOIN inspections i ON i.id = d.inspection_id
       ${where.length ? `WHERE ${where.join(' AND ')}` : ''}
      ORDER BY d.delivered_at DESC LIMIT 500`,
    values,
  );
  return r.rows;
}

// --------------------------------------------------------- ledger & payment

async function ledgerRows(db: { query: PoolClient['query'] }, f: { agreementId?: string; growerId?: string }) {
  const r = await db.query(
    `SELECT g.*, a.agreement_number, s.settlement_number AS settled_by_number,
            SUM(g.amount) OVER (PARTITION BY ${f.agreementId ? 'g.agreement_id' : 'g.grower_id'} ORDER BY g.entry_date, g.id) AS running_balance
       FROM grw_ledger g JOIN grw_agreements a ON a.id = g.agreement_id LEFT JOIN grw_settlements s ON s.id = g.settled_by_id
      WHERE ${f.agreementId ? 'g.agreement_id = $1' : 'g.grower_id = $1'}
      ORDER BY g.entry_date, g.id`,
    [f.agreementId ?? f.growerId],
  );
  return r.rows;
}

export async function growerAccount(growerId: string) {
  const g = await pool.query('SELECT id, party_code, name, village, district, phone, preferred_language, status FROM parties WHERE id = $1 AND party_type = $2', [growerId, 'contract_grower']);
  if (!g.rows[0]) throw new NotFoundError('Grower not found');
  const ledger = await ledgerRows(pool, { growerId });
  const agreements = await listAgreements({ growerId });
  const deliveries = await listDeliveries({ growerId });
  const settlements = await pool.query('SELECT * FROM grw_settlements WHERE grower_id = $1 ORDER BY created_at DESC', [growerId]);
  const paid = settlements.rows.filter((s) => s.status === 'paid' && s.settlement_type === 'final' && s.first_delivery_at);
  const avgDays = paid.length
    ? Math.round((paid.reduce((sum, s) => sum + (Date.parse(s.paid_at) - Date.parse(s.first_delivery_at)) / 86400000, 0) / paid.length) * 10) / 10
    : null;
  const balance = round2(ledger.reduce((s, e) => s + num(e.amount), 0));
  return { grower: g.rows[0], balance, avgDaysToPayment: avgDays, agreements, deliveries, settlements: settlements.rows, ledger };
}

/**
 * Pays out everything open on an agreement's account: accepted delivery
 * value less recoverable inputs and advances already paid. Reserves those
 * ledger entries so they cannot be paid twice, and routes the payment to
 * finance through the approval engine.
 */
export async function createSettlement(input: Record<string, unknown>, user: AuthenticatedUser) {
  const agreementId = requireUuid(input.agreementId, 'agreementId');
  return withTransaction(async (client) => {
    const a = await client.query<AgreementRow>('SELECT * FROM grw_agreements WHERE id = $1 FOR UPDATE', [agreementId]);
    if (!a.rows[0]) throw new NotFoundError('Agreement not found');
    const open = await client.query<{ id: string; amount: string; entry_type: string; delivery_id: string | null }>(
      `SELECT id, amount, entry_type, delivery_id FROM grw_ledger WHERE agreement_id = $1 AND settled_by_id IS NULL AND entry_type IN ('delivery', 'inputs', 'advance', 'adjustment') FOR UPDATE`,
      [agreementId],
    );
    const deliveryValue = round2(open.rows.filter((e) => num(e.amount) > 0).reduce((s, e) => s + num(e.amount), 0));
    const recoveries = round2(-open.rows.filter((e) => num(e.amount) < 0).reduce((s, e) => s + num(e.amount), 0));
    const net = round2(deliveryValue - recoveries);
    if (deliveryValue <= 0) throw new ConflictError('No accepted deliveries are waiting to be paid on this agreement');
    if (net <= 0) throw new ConflictError(`Nothing is payable: recoveries (₹${recoveries}) cover the delivery value (₹${deliveryValue})`);
    const pendingAdvance = await client.query(`SELECT settlement_number FROM grw_settlements WHERE agreement_id = $1 AND settlement_type = 'advance' AND status IN ('pending_approval', 'approved')`, [agreementId]);
    if (pendingAdvance.rows[0]) throw new ConflictError(`Advance ${pendingAdvance.rows[0].settlement_number} is not yet paid — pay or reject it first so it can be recovered correctly`);
    const deliveryIds = open.rows.filter((e) => e.delivery_id).map((e) => e.delivery_id);
    const first = await client.query<{ first: string | null }>('SELECT MIN(delivered_at) AS first FROM grw_deliveries WHERE id = ANY($1::uuid[])', [deliveryIds]);
    const code = await nextCode(client, 'GSET', 5, true);
    const s = await client.query(
      `INSERT INTO grw_settlements (settlement_number, settlement_type, grower_id, agreement_id, delivery_value, recoveries, net_payable, first_delivery_at, created_by)
       VALUES ($1, 'final', $2, $3, $4, $5, $6, $7, $8) RETURNING *`,
      [code, a.rows[0].grower_id, agreementId, deliveryValue, recoveries, net, first.rows[0].first, user.email],
    );
    await client.query('UPDATE grw_ledger SET settled_by_id = $2 WHERE id = ANY($1::uuid[])', [open.rows.map((e) => e.id), s.rows[0].id]);
    const g = await client.query('SELECT name FROM parties WHERE id = $1', [a.rows[0].grower_id]);
    await submitForApprovalTx(client, { entityType: 'grower_settlement', entityId: s.rows[0].id, entityCode: code, title: `Payment to ${g.rows[0].name} (${a.rows[0].agreement_number})`, amount: net }, user);
    await insertAuditLog(client, { entityType: 'grower_settlement', entityId: s.rows[0].id, action: 'CREATE', performedBy: user.email, afterState: s.rows[0] });
    return getSettlement(s.rows[0].id, client);
  });
}

export async function paySettlement(id: string, input: Record<string, unknown>, user: AuthenticatedUser) {
  const reference = requireText(input.paymentReference, 'paymentReference', 60);
  const mode = requireEnum(input.paymentMode, PAYMENT_MODES, 'paymentMode');
  return withTransaction(async (client) => {
    const r = await client.query('SELECT * FROM grw_settlements WHERE id = $1 FOR UPDATE', [id]);
    const s = r.rows[0];
    if (!s) throw new NotFoundError('Settlement not found');
    if (s.status !== 'approved') throw new ConflictError(`Only an approved payment can be released (this one is ${s.status})`);
    const approvers = await client.query<{ decided_by: string }>(
      `SELECT st.decided_by FROM approval_steps st JOIN approval_requests rq ON rq.id = st.request_id
        WHERE rq.entity_type = 'grower_settlement' AND rq.entity_id = $1 AND st.decided_by IS NOT NULL`,
      [id],
    );
    if (approvers.rows.some((x) => x.decided_by === user.email)) throw new ForbiddenError('You approved this payment; someone else must release it');
    await client.query(`UPDATE grw_settlements SET status = 'paid', payment_reference = $2, payment_mode = $3, paid_at = now(), paid_by = $4 WHERE id = $1`, [id, reference, mode, user.email]);
    const a = await client.query('SELECT agreement_number FROM grw_agreements WHERE id = $1', [s.agreement_id]);
    await client.query(
      `INSERT INTO grw_ledger (grower_id, agreement_id, entry_type, description, amount, settlement_id, settled_by_id, created_by) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
      [
        s.grower_id,
        s.agreement_id,
        s.settlement_type === 'advance' ? 'advance' : 'payment',
        `${s.settlement_type === 'advance' ? 'Advance' : 'Payment'} ${s.settlement_number} (${a.rows[0].agreement_number}) — ${mode.toUpperCase()} ${reference}`,
        -num(s.net_payable),
        id,
        // a final payment closes itself; an advance stays open until recovered
        s.settlement_type === 'final' ? id : null,
        user.email,
      ],
    );
    await insertAuditLog(client, { entityType: 'grower_settlement', entityId: id, action: 'PAY', performedBy: user.email, metadata: { reference, mode, amount: s.net_payable } });
    await queueMessageTx(client, { partyId: s.grower_id, template: 'settlement_paid', vars: { number: s.settlement_number, amount: num(s.net_payable).toLocaleString('en-IN'), reference }, relatedType: 'grower_settlement', relatedId: id, createdBy: user.email });
    return getSettlement(id, client);
  });
}

export async function listSettlements(filters: { status?: string }) {
  const values: unknown[] = [];
  let where = '';
  if (filters.status) {
    values.push(filters.status);
    where = 'WHERE s.status = $1';
  }
  const r = await pool.query(
    `SELECT s.*, p.name AS grower_name, p.party_code AS grower_code, a.agreement_number,
            CASE WHEN s.paid_at IS NOT NULL AND s.first_delivery_at IS NOT NULL THEN ROUND(EXTRACT(EPOCH FROM (s.paid_at - s.first_delivery_at)) / 86400, 1) END AS days_to_payment
       FROM grw_settlements s JOIN parties p ON p.id = s.grower_id JOIN grw_agreements a ON a.id = s.agreement_id ${where}
      ORDER BY s.created_at DESC LIMIT 500`,
    values,
  );
  return r.rows;
}

export async function getSettlement(id: string, client?: PoolClient) {
  const db = client ?? pool;
  const r = await db.query(
    `SELECT s.*, p.name AS grower_name, p.party_code AS grower_code, p.bank_account_name, p.bank_ifsc, RIGHT(p.bank_account_number, 4) AS bank_account_last4,
            a.agreement_number,
            CASE WHEN s.paid_at IS NOT NULL AND s.first_delivery_at IS NOT NULL THEN ROUND(EXTRACT(EPOCH FROM (s.paid_at - s.first_delivery_at)) / 86400, 1) END AS days_to_payment
       FROM grw_settlements s JOIN parties p ON p.id = s.grower_id JOIN grw_agreements a ON a.id = s.agreement_id WHERE s.id = $1`,
    [id],
  );
  if (!r.rows[0]) throw new NotFoundError('Settlement not found');
  const entries = await db.query(`SELECT * FROM grw_ledger WHERE settled_by_id = $1 OR settlement_id = $1 ORDER BY entry_date`, [id]);
  const approvals = await getApprovalsForEntity('grower_settlement', id, client);
  return { ...r.rows[0], entries: entries.rows, approvals };
}
