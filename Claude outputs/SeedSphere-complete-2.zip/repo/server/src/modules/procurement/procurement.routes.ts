import { Router } from 'express';
import { asyncHandler as h } from '../../middleware/asyncHandler';
import { requireAuth, requirePermission as can, requireStaff } from '../../middleware/requireAuth';
import { body, ok, str } from '../shared/http';
import * as analytics from './analytics.service';
import * as contracts from './contracts.service';
import * as growers from './growers.service';
import * as invoices from './invoices.service';
import * as items from './items.service';
import * as orders from './orders.service';
import * as receipts from './receipts.service';
import * as prs from './requisitions.service';
import * as rfqs from './rfq.service';

export const procurementRouter = Router();
procurementRouter.use(requireAuth, requireStaff);

// Dashboard & analytics
procurementRouter.get('/dashboard', h(async (_req, res) => ok(res, await analytics.procurementDashboard())));
procurementRouter.get('/analytics/spend', h(async (req, res) => ok(res, await analytics.spendAnalysis({ months: req.query.months ? Number(req.query.months) : undefined }))));
procurementRouter.get('/analytics/suppliers', h(async (_req, res) => ok(res, await analytics.supplierPerformance())));
procurementRouter.get('/analytics/growers', h(async (_req, res) => ok(res, await analytics.growerPerformance())));

// Items & cost centres
procurementRouter.get('/items', h(async (req, res) => ok(res, await items.listItems({ category: str(req.query.category), q: str(req.query.q), includeInactive: req.query.includeInactive === 'true' }))));
procurementRouter.post('/items', can('create_requisition', 'create_order'), h(async (req, res) => ok(res, await items.createItem(body(req), req.user!), 'Item added', 201)));
procurementRouter.patch('/items/:id', can('create_order'), h(async (req, res) => ok(res, await items.updateItem(req.params.id, body(req), req.user!), 'Item updated')));
procurementRouter.get('/cost-centres', h(async (req, res) => ok(res, await items.listCostCentres({ fiscalYear: str(req.query.fiscalYear) }))));
procurementRouter.post('/cost-centres', can('allocate_budget'), h(async (req, res) => ok(res, await items.createCostCentre(body(req), req.user!), 'Cost centre created', 201)));
procurementRouter.patch('/cost-centres/:id', can('allocate_budget'), h(async (req, res) => ok(res, await items.updateCostCentreBudget(req.params.id, body(req), req.user!), 'Budget changed')));

// Requisitions
procurementRouter.get('/requisitions', h(async (req, res) => ok(res, await prs.listRequisitions({ status: str(req.query.status), mine: req.query.mine === 'true' }, req.user!))));
procurementRouter.get('/requisitions/:id', h(async (req, res) => ok(res, await prs.getRequisition(req.params.id))));
procurementRouter.post('/requisitions', can('create_requisition'), h(async (req, res) => {
  const pr = await prs.createRequisition(body(req), req.user!);
  ok(res, pr, `${pr.pr_number} saved as draft`, 201);
}));
procurementRouter.patch('/requisitions/:id', can('create_requisition'), h(async (req, res) => ok(res, await prs.updateRequisition(req.params.id, body(req), req.user!), 'Requisition updated')));
procurementRouter.post('/requisitions/:id/submit', can('create_requisition'), h(async (req, res) => ok(res, await prs.submitRequisition(req.params.id, req.user!), 'Submitted for approval')));
procurementRouter.post('/requisitions/:id/cancel', can('create_requisition', 'approve_requisition'), h(async (req, res) => ok(res, await prs.cancelRequisition(req.params.id, body(req), req.user!), 'Requisition cancelled')));
procurementRouter.get('/demand-suggestions', h(async (_req, res) => ok(res, await prs.listDemandSuggestions())));
procurementRouter.post('/demand-suggestions/convert', can('create_requisition'), h(async (req, res) => {
  const pr = await prs.requisitionFromDemandPlan(body(req), req.user!);
  ok(res, pr, `${pr.pr_number} raised from the demand plan`, 201);
}));

// RFQs
procurementRouter.get('/rfqs', h(async (req, res) => ok(res, await rfqs.listRfqs({ status: str(req.query.status) }))));
procurementRouter.get('/rfqs/:id', h(async (req, res) => ok(res, await rfqs.getRfq(req.params.id))));
procurementRouter.post('/rfqs', can('create_rfq'), h(async (req, res) => {
  const r = await rfqs.createRfq(body(req), req.user!);
  ok(res, r, `${r.rfq_number} opened`, 201);
}));
procurementRouter.post('/rfqs/:id/quotes', can('create_rfq'), h(async (req, res) => ok(res, await rfqs.recordQuote(req.params.id, body(req), req.user!), 'Quote recorded')));
procurementRouter.post('/rfqs/:id/award', can('award_rfq'), h(async (req, res) => {
  const r = await rfqs.awardRfq(req.params.id, body(req), req.user!);
  ok(res, r, `Awarded — ${r.order.po_number} drafted`);
}));
procurementRouter.post('/rfqs/:id/cancel', can('create_rfq'), h(async (req, res) => ok(res, await rfqs.cancelRfq(req.params.id, body(req), req.user!), 'RFQ cancelled')));

// Purchase orders
procurementRouter.get('/orders', h(async (req, res) => ok(res, await orders.listOrders({ status: str(req.query.status), supplierId: str(req.query.supplierId), q: str(req.query.q) }))));
procurementRouter.get('/orders/:id', h(async (req, res) => ok(res, await orders.getOrder(req.params.id))));
procurementRouter.post('/orders', can('create_order'), h(async (req, res) => {
  const po = await orders.createOrder(body(req), req.user!);
  ok(res, po, `${po.po_number} saved as draft`, 201);
}));
procurementRouter.patch('/orders/:id', can('create_order'), h(async (req, res) => ok(res, await orders.updateOrder(req.params.id, body(req), req.user!), 'Order updated')));
procurementRouter.post('/orders/:id/submit', can('create_order'), h(async (req, res) => ok(res, await orders.submitOrder(req.params.id, body(req), req.user!), 'Submitted for approval')));
procurementRouter.post('/orders/:id/send', can('create_order'), h(async (req, res) => ok(res, await orders.sendOrder(req.params.id, req.user!), 'Marked as sent to the supplier')));
procurementRouter.post('/orders/:id/amend', can('create_order'), h(async (req, res) => ok(res, await orders.amendOrder(req.params.id, body(req), req.user!), 'Amendment submitted for approval')));
procurementRouter.post('/orders/:id/cancel', can('create_order', 'approve_order'), h(async (req, res) => ok(res, await orders.cancelOrder(req.params.id, body(req), req.user!), 'Order cancelled')));
procurementRouter.post('/orders/:id/close', can('create_order', 'approve_order'), h(async (req, res) => ok(res, await orders.closeOrder(req.params.id, body(req), req.user!), 'Order closed')));

// Goods receipts
procurementRouter.get('/receipts', h(async (req, res) => ok(res, await receipts.listReceipts({ status: str(req.query.status), poId: str(req.query.poId) }))));
procurementRouter.get('/receipts/:id', h(async (req, res) => ok(res, await receipts.getReceipt(req.params.id))));
procurementRouter.post('/receipts', can('create_grn', 'receive_incoming_goods'), h(async (req, res) => {
  const g = await receipts.createReceipt(body(req), req.user!);
  ok(res, g, g.status === 'awaiting_inspection' ? `${g.grn_number} recorded — waiting for gate inspection` : `${g.grn_number} recorded and accepted`, 201);
}));

// Invoices
procurementRouter.get('/invoices', h(async (req, res) => ok(res, await invoices.listInvoices({ status: str(req.query.status), supplierId: str(req.query.supplierId), overdue: req.query.overdue === 'true' }))));
procurementRouter.get('/invoices/:id', h(async (req, res) => ok(res, await invoices.getInvoice(req.params.id))));
procurementRouter.post('/invoices', can('create_invoice'), h(async (req, res) => {
  const i = await invoices.createInvoice(body(req), req.user!);
  ok(res, i, i.match_status === 'matched' ? `${i.invoice_number} booked — three-way match passed` : `${i.invoice_number} booked with a mismatch — review before payment`, 201);
}));
procurementRouter.post('/invoices/:id/submit', can('verify_invoice'), h(async (req, res) => ok(res, await invoices.submitInvoice(req.params.id, body(req), req.user!), 'Sent for payment approval')));
procurementRouter.post('/invoices/:id/pay', can('release_payment'), h(async (req, res) => ok(res, await invoices.payInvoice(req.params.id, body(req), req.user!), 'Payment recorded')));
procurementRouter.post('/invoices/:id/cancel', can('create_invoice'), h(async (req, res) => ok(res, await invoices.cancelInvoice(req.params.id, body(req), req.user!), 'Invoice cancelled')));

// Contracts
procurementRouter.get('/contracts', h(async (req, res) => ok(res, await contracts.listContracts({ supplierId: str(req.query.supplierId), status: str(req.query.status) }))));
procurementRouter.get('/contracts/alerts', h(async (_req, res) => ok(res, await contracts.contractAlerts())));
procurementRouter.get('/contracts/:id', h(async (req, res) => ok(res, await contracts.getContract(req.params.id))));
procurementRouter.post('/contracts', can('manage_contracts'), h(async (req, res) => {
  const c = await contracts.createContract(body(req), req.user!);
  ok(res, c, `${c.contract_number} drafted`, 201);
}));
procurementRouter.post('/contracts/:id/activate', can('manage_contracts'), h(async (req, res) => ok(res, await contracts.activateContract(req.params.id, req.user!), 'Contract activated')));
procurementRouter.post('/contracts/:id/terminate', can('manage_contracts'), h(async (req, res) => ok(res, await contracts.terminateContract(req.params.id, body(req), req.user!), 'Contract terminated')));

// Contract growers
procurementRouter.get('/growers/agreements', h(async (req, res) => ok(res, await growers.listAgreements({ status: str(req.query.status), growerId: str(req.query.growerId), season: str(req.query.season) }))));
procurementRouter.get('/growers/agreements/:id', h(async (req, res) => ok(res, await growers.getAgreement(req.params.id))));
procurementRouter.post('/growers/agreements', can('manage_grower_agreements'), h(async (req, res) => {
  const a = await growers.createAgreement(body(req), req.user!);
  ok(res, a, `${a.agreement_number} drafted`, 201);
}));
procurementRouter.patch('/growers/agreements/:id', can('manage_grower_agreements'), h(async (req, res) => ok(res, await growers.updateAgreement(req.params.id, body(req), req.user!), 'Agreement updated')));
procurementRouter.post('/growers/agreements/:id/submit', can('manage_grower_agreements'), h(async (req, res) => ok(res, await growers.submitAgreement(req.params.id, req.user!), 'Submitted for approval')));
procurementRouter.post('/growers/agreements/:id/cancel', can('manage_grower_agreements', 'approve_grower_agreement'), h(async (req, res) => ok(res, await growers.cancelAgreement(req.params.id, body(req), req.user!), 'Agreement cancelled')));
procurementRouter.post('/growers/agreements/:id/complete', can('manage_grower_agreements'), h(async (req, res) => ok(res, await growers.completeAgreement(req.params.id, req.user!), 'Agreement completed')));
procurementRouter.get('/growers/deliveries', h(async (req, res) => ok(res, await growers.listDeliveries({ status: str(req.query.status), growerId: str(req.query.growerId) }))));
procurementRouter.post('/growers/deliveries', can('record_grower_delivery', 'receive_incoming_goods'), h(async (req, res) => {
  const d = await growers.recordDelivery(body(req), req.user!);
  ok(res, d, `${d.delivery_number} weighed in — waiting for gate inspection`, 201);
}));
procurementRouter.get('/growers/settlements', h(async (req, res) => ok(res, await growers.listSettlements({ status: str(req.query.status) }))));
procurementRouter.get('/growers/settlements/:id', h(async (req, res) => ok(res, await growers.getSettlement(req.params.id))));
procurementRouter.post('/growers/settlements', can('manage_grower_agreements'), h(async (req, res) => {
  const s = await growers.createSettlement(body(req), req.user!);
  ok(res, s, `${s.settlement_number} prepared — sent to finance for approval`, 201);
}));
procurementRouter.post('/growers/settlements/:id/pay', can('settle_grower_payment', 'release_payment'), h(async (req, res) => ok(res, await growers.paySettlement(req.params.id, body(req), req.user!), 'Payment released to the grower')));
procurementRouter.get('/growers/:growerId/account', h(async (req, res) => ok(res, await growers.growerAccount(req.params.growerId))));
