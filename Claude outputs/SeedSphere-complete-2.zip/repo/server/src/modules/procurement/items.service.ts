import { pool } from '../../db/pool';
import { withTransaction } from '../../db/transaction';
import { ConflictError, NotFoundError, ValidationError } from '../../errors';
import type { AuthenticatedUser } from '../../middleware/requireAuth';
import { insertAuditLog } from '../auditLogs/auditLogs.service';
import { nextCode, num, optionalEmail, optionalNumber, optionalText, requireEnum, requireNumber, requireText } from '../shared/validate';
import { fiscalYear } from './common';

export const ITEM_CATEGORIES = ['seed', 'packaging', 'chemical', 'fertilizer', 'equipment', 'service', 'other'] as const;

// ------------------------------------------------------------------- items

export async function listItems(filters: { category?: string; q?: string; includeInactive?: boolean }) {
  const where: string[] = [];
  const values: unknown[] = [];
  if (!filters.includeInactive) where.push('is_active');
  if (filters.category) {
    values.push(requireEnum(filters.category, ITEM_CATEGORIES, 'category'));
    where.push(`category = $${values.length}`);
  }
  if (filters.q) {
    values.push(`%${filters.q.toLowerCase()}%`);
    where.push(`(LOWER(name) LIKE $${values.length} OR LOWER(item_code) LIKE $${values.length} OR LOWER(COALESCE(variety,'')) LIKE $${values.length})`);
  }
  const r = await pool.query(
    `SELECT i.*,
            (SELECT l.unit_price FROM proc_po_lines l JOIN proc_purchase_orders o ON o.id = l.po_id
              WHERE l.item_id = i.id AND o.status NOT IN ('draft', 'cancelled', 'rejected') ORDER BY o.order_date DESC LIMIT 1) AS last_price
       FROM proc_items i ${where.length ? `WHERE ${where.join(' AND ')}` : ''} ORDER BY i.category, i.name`,
    values,
  );
  return r.rows;
}

export async function createItem(input: Record<string, unknown>, user: AuthenticatedUser) {
  const category = requireEnum(input.category, ITEM_CATEGORIES, 'category');
  const name = requireText(input.name, 'name', 200);
  const unit = requireText(input.unit, 'unit', 20);
  const crop = optionalText(input.crop, 'crop', 100);
  const variety = optionalText(input.variety, 'variety', 100);
  if (category === 'seed' && (!crop || !variety)) throw new ValidationError('A seed item needs its crop and variety');
  const hsn = optionalText(input.hsnCode, 'hsnCode', 10);
  const gst = optionalNumber(input.gstRate, 'gstRate', { min: 0, max: 28 }) ?? 0;
  const requiresInspection = input.requiresInspection === undefined ? category === 'seed' || category === 'chemical' : input.requiresInspection === true;
  return withTransaction(async (client) => {
    const dup = await client.query('SELECT item_code FROM proc_items WHERE LOWER(name) = LOWER($1)', [name]);
    if (dup.rows[0]) throw new ConflictError(`An item called "${name}" already exists (${dup.rows[0].item_code})`);
    const code = await nextCode(client, 'ITM', 4, false);
    const r = await client.query(
      `INSERT INTO proc_items (item_code, name, category, unit, crop, variety, hsn_code, gst_rate, requires_inspection, created_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10) RETURNING *`,
      [code, name, category, unit, crop, variety, hsn, gst, requiresInspection, user.email],
    );
    await insertAuditLog(client, { entityType: 'proc_item', entityId: r.rows[0].id, action: 'CREATE', performedBy: user.email, afterState: r.rows[0] });
    return r.rows[0];
  });
}

export async function updateItem(id: string, input: Record<string, unknown>, user: AuthenticatedUser) {
  return withTransaction(async (client) => {
    const before = await client.query('SELECT * FROM proc_items WHERE id = $1 FOR UPDATE', [id]);
    if (!before.rows[0]) throw new NotFoundError('Item not found');
    const gst = input.gstRate === undefined ? null : requireNumber(input.gstRate, 'gstRate', { min: 0, max: 28 });
    const active = input.isActive === undefined ? null : input.isActive === true;
    const insp = input.requiresInspection === undefined ? null : input.requiresInspection === true;
    const hsn = input.hsnCode === undefined ? undefined : optionalText(input.hsnCode, 'hsnCode', 10);
    const r = await client.query(
      `UPDATE proc_items SET gst_rate = COALESCE($2, gst_rate), is_active = COALESCE($3, is_active),
              requires_inspection = COALESCE($4, requires_inspection), hsn_code = CASE WHEN $5::boolean THEN $6 ELSE hsn_code END
        WHERE id = $1 RETURNING *`,
      [id, gst, active, insp, hsn !== undefined, hsn ?? null],
    );
    await insertAuditLog(client, { entityType: 'proc_item', entityId: id, action: 'UPDATE', performedBy: user.email, beforeState: before.rows[0], afterState: r.rows[0] });
    return r.rows[0];
  });
}

// ------------------------------------------------------------- cost centres

/**
 * Committed = approved/open purchase orders not yet invoiced; spent = approved
 * or paid invoices. Remaining = budget − committed − spent, which is the
 * figure a new order is checked against.
 */
export async function listCostCentres(filters: { fiscalYear?: string }) {
  const fy = filters.fiscalYear ?? fiscalYear();
  const r = await pool.query(
    `SELECT c.*,
            COALESCE(po.committed, 0) AS committed,
            COALESCE(inv.spent, 0) AS spent
       FROM proc_cost_centres c
       LEFT JOIN LATERAL (
         SELECT SUM(o.grand_total) - COALESCE(SUM(x.invoiced), 0) AS committed
           FROM proc_purchase_orders o
           LEFT JOIN LATERAL (SELECT SUM(i.total_amount) AS invoiced FROM proc_invoices i WHERE i.po_id = o.id AND i.status IN ('approved', 'paid')) x ON TRUE
          WHERE o.cost_centre_id = c.id AND o.status IN ('approved', 'sent', 'partially_received', 'received', 'pending_approval')
       ) po ON TRUE
       LEFT JOIN LATERAL (
         SELECT SUM(i.total_amount) AS spent FROM proc_invoices i JOIN proc_purchase_orders o ON o.id = i.po_id
          WHERE o.cost_centre_id = c.id AND i.status IN ('approved', 'paid')
       ) inv ON TRUE
      WHERE c.fiscal_year = $1
      ORDER BY c.code`,
    [fy],
  );
  return r.rows.map((row) => {
    const budget = num(row.budget_amount);
    const committed = Math.max(0, num(row.committed));
    const spent = num(row.spent);
    return { ...row, committed, spent, remaining: budget - committed - spent, utilisation_pct: budget > 0 ? Math.round(((committed + spent) / budget) * 1000) / 10 : null };
  });
}

export async function remainingBudget(costCentreId: string): Promise<{ code: string; name: string; remaining: number }> {
  const all = await pool.query<{ fiscal_year: string }>('SELECT fiscal_year FROM proc_cost_centres WHERE id = $1', [costCentreId]);
  if (!all.rows[0]) throw new NotFoundError('Cost centre not found');
  const list = await listCostCentres({ fiscalYear: all.rows[0].fiscal_year });
  const cc = list.find((c) => c.id === costCentreId)!;
  return { code: cc.code, name: cc.name, remaining: cc.remaining };
}

export async function createCostCentre(input: Record<string, unknown>, user: AuthenticatedUser) {
  const code = requireText(input.code, 'code', 20).toUpperCase();
  const name = requireText(input.name, 'name', 150);
  const fy = (optionalText(input.fiscalYear, 'fiscalYear', 7) ?? fiscalYear()).trim();
  if (!/^\d{4}-\d{2}$/.test(fy)) throw new ValidationError('fiscalYear must look like 2026-27');
  const budget = requireNumber(input.budgetAmount, 'budgetAmount', { min: 0 });
  const owner = optionalEmail(input.ownerEmail, 'ownerEmail');
  return withTransaction(async (client) => {
    const dup = await client.query('SELECT 1 FROM proc_cost_centres WHERE code = $1 AND fiscal_year = $2', [code, fy]);
    if (dup.rows[0]) throw new ConflictError(`Cost centre ${code} already has a ${fy} budget`);
    const r = await client.query(
      `INSERT INTO proc_cost_centres (code, name, fiscal_year, budget_amount, owner_email, created_by) VALUES ($1, $2, $3, $4, $5, $6) RETURNING *`,
      [code, name, fy, budget, owner, user.email],
    );
    await insertAuditLog(client, { entityType: 'cost_centre', entityId: r.rows[0].id, action: 'CREATE', performedBy: user.email, afterState: r.rows[0] });
    return r.rows[0];
  });
}

export async function updateCostCentreBudget(id: string, input: Record<string, unknown>, user: AuthenticatedUser) {
  const budget = requireNumber(input.budgetAmount, 'budgetAmount', { min: 0 });
  const reason = requireText(input.reason, 'reason', 500);
  return withTransaction(async (client) => {
    const before = await client.query('SELECT * FROM proc_cost_centres WHERE id = $1 FOR UPDATE', [id]);
    if (!before.rows[0]) throw new NotFoundError('Cost centre not found');
    const r = await client.query('UPDATE proc_cost_centres SET budget_amount = $2 WHERE id = $1 RETURNING *', [id, budget]);
    await insertAuditLog(client, {
      entityType: 'cost_centre',
      entityId: id,
      action: 'BUDGET_CHANGED',
      performedBy: user.email,
      beforeState: { budget: before.rows[0].budget_amount },
      afterState: { budget },
      metadata: { reason },
    });
    return r.rows[0];
  });
}
