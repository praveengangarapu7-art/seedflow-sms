import type { PoolClient } from 'pg';
import { pool } from '../../db/pool';
import { withTransaction } from '../../db/transaction';
import { ConflictError, NotFoundError, ValidationError } from '../../errors';
import type { AuthenticatedUser } from '../../middleware/requireAuth';
import { insertAuditLog } from '../auditLogs/auditLogs.service';
import { assertPartyUsable } from '../parties/parties.service';
import { asRecord, nextCode, num, optionalDate, optionalNumber, optionalText, optionalUuid, requireArray, requireDate, requireNumber, requireText, requireUuid, round2 } from '../shared/validate';
import { lineAmounts, loadItems, parseLines } from './common';
import { createOrderTx, getOrder } from './orders.service';

export async function createRfq(input: Record<string, unknown>, user: AuthenticatedUser) {
  const title = requireText(input.title, 'title', 200);
  const dueDate = requireDate(input.dueDate, 'dueDate');
  const requisitionId = optionalUuid(input.requisitionId, 'requisitionId');
  return withTransaction(async (client) => {
    let lines: { itemId: string; quantity: number; requisitionLineId: string | null }[];
    if (requisitionId) {
      const pr = await client.query('SELECT status FROM proc_requisitions WHERE id = $1', [requisitionId]);
      if (!pr.rows[0]) throw new NotFoundError('Requisition not found');
      if (pr.rows[0].status !== 'approved') throw new ConflictError('Quotations are requested only for an approved requisition');
      const rl = await client.query('SELECT id, item_id, quantity - ordered_quantity AS open FROM proc_requisition_lines WHERE requisition_id = $1 AND quantity > ordered_quantity ORDER BY line_no', [requisitionId]);
      if (!rl.rows.length) throw new ConflictError('Everything on this requisition is already ordered');
      lines = rl.rows.map((l) => ({ itemId: l.item_id, quantity: num(l.open), requisitionLineId: l.id }));
    } else {
      lines = parseLines(input.lines, { requirePrice: false }).map((l) => ({ itemId: l.itemId, quantity: l.quantity, requisitionLineId: null }));
    }
    const items = await loadItems(client, lines.map((l) => l.itemId));
    const code = await nextCode(client, 'RFQ', 4, true);
    const r = await client.query(`INSERT INTO proc_rfqs (rfq_number, requisition_id, title, due_date, created_by) VALUES ($1, $2, $3, $4, $5) RETURNING *`, [code, requisitionId, title, dueDate, user.email]);
    for (const [i, l] of lines.entries()) {
      await client.query(`INSERT INTO proc_rfq_lines (rfq_id, line_no, item_id, quantity, unit, requisition_line_id) VALUES ($1, $2, $3, $4, $5, $6)`, [
        r.rows[0].id,
        i + 1,
        l.itemId,
        l.quantity,
        items.get(l.itemId)!.unit,
        l.requisitionLineId,
      ]);
    }
    await insertAuditLog(client, { entityType: 'rfq', entityId: r.rows[0].id, action: 'CREATE', performedBy: user.email, afterState: r.rows[0] });
    return getRfq(r.rows[0].id, client);
  });
}

export async function recordQuote(rfqId: string, input: Record<string, unknown>, user: AuthenticatedUser) {
  const supplierId = requireUuid(input.supplierId, 'supplierId');
  const prices = requireArray(input.lines, 'lines', { min: 1, max: 100 }).map((raw, i) => {
    const r = asRecord(raw, `lines[${i}]`);
    return {
      rfqLineId: requireUuid(r.rfqLineId, `lines[${i}].rfqLineId`),
      unitPrice: requireNumber(r.unitPrice, `lines[${i}].unitPrice`, { min: 0 }),
      gstRate: optionalNumber(r.gstRate, `lines[${i}].gstRate`, { min: 0, max: 28 }),
    };
  });
  return withTransaction(async (client) => {
    const rfq = await client.query('SELECT * FROM proc_rfqs WHERE id = $1 FOR UPDATE', [rfqId]);
    if (!rfq.rows[0]) throw new NotFoundError('RFQ not found');
    if (rfq.rows[0].status !== 'open') throw new ConflictError(`Quotes cannot be added to a ${rfq.rows[0].status} RFQ`);
    await assertPartyUsable(client, supplierId, ['supplier', 'contract_grower'], 'a quotation');
    const lines = await client.query<{ id: string; quantity: string; item_id: string }>('SELECT l.id, l.quantity, l.item_id FROM proc_rfq_lines l WHERE l.rfq_id = $1', [rfqId]);
    const missing = lines.rows.filter((l) => !prices.some((p) => p.rfqLineId === l.id));
    if (missing.length) throw new ValidationError('Quote a price for every RFQ line');
    const items = await loadItems(client, lines.rows.map((l) => l.item_id));
    let subtotal = 0;
    let tax = 0;
    for (const p of prices) {
      const line = lines.rows.find((l) => l.id === p.rfqLineId);
      if (!line) throw new ValidationError('A quoted line is not part of this RFQ');
      const a = lineAmounts(num(line.quantity), p.unitPrice, p.gstRate ?? num(items.get(line.item_id)!.gst_rate));
      subtotal += a.lineTotal;
      tax += a.tax;
    }
    await client.query('DELETE FROM proc_rfq_quotes WHERE rfq_id = $1 AND supplier_id = $2', [rfqId, supplierId]);
    const q = await client.query(
      `INSERT INTO proc_rfq_quotes (rfq_id, supplier_id, quote_ref, valid_until, delivery_days, payment_terms_days, notes, subtotal, tax_total, total_amount, recorded_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11) RETURNING *`,
      [
        rfqId,
        supplierId,
        optionalText(input.quoteRef, 'quoteRef', 60),
        optionalDate(input.validUntil, 'validUntil'),
        optionalNumber(input.deliveryDays, 'deliveryDays', { min: 0 }),
        optionalNumber(input.paymentTermsDays, 'paymentTermsDays', { min: 0 }),
        optionalText(input.notes, 'notes', 2000),
        round2(subtotal),
        round2(tax),
        round2(subtotal + tax),
        user.email,
      ],
    );
    for (const p of prices) {
      const line = lines.rows.find((l) => l.id === p.rfqLineId)!;
      await client.query('INSERT INTO proc_rfq_quote_lines (quote_id, rfq_line_id, unit_price, gst_rate) VALUES ($1, $2, $3, $4)', [
        q.rows[0].id,
        p.rfqLineId,
        p.unitPrice,
        p.gstRate ?? num(items.get(line.item_id)!.gst_rate),
      ]);
    }
    await insertAuditLog(client, { entityType: 'rfq', entityId: rfqId, action: 'QUOTE_RECORDED', performedBy: user.email, metadata: { supplierId, total: round2(subtotal + tax) } });
    return getRfq(rfqId, client);
  });
}

/**
 * Awarding to anyone but the cheapest valid quote needs a written reason
 * (quality, delivery time, past performance) — that reason is what an
 * auditor asks for. The award drafts the purchase order from the quote.
 */
export async function awardRfq(rfqId: string, input: Record<string, unknown>, user: AuthenticatedUser) {
  const quoteId = requireUuid(input.quoteId, 'quoteId');
  const reason = optionalText(input.reason, 'reason', 2000);
  const expectedDeliveryDate = requireDate(input.expectedDeliveryDate, 'expectedDeliveryDate');
  const deliveryAddress = requireText(input.deliveryAddress, 'deliveryAddress', 500);
  const costCentreId = optionalUuid(input.costCentreId, 'costCentreId');
  return withTransaction(async (client) => {
    const rfq = await client.query('SELECT * FROM proc_rfqs WHERE id = $1 FOR UPDATE', [rfqId]);
    const r = rfq.rows[0];
    if (!r) throw new NotFoundError('RFQ not found');
    if (r.status !== 'open') throw new ConflictError(`This RFQ is ${r.status}`);
    const quotes = await client.query('SELECT * FROM proc_rfq_quotes WHERE rfq_id = $1', [rfqId]);
    const chosen = quotes.rows.find((q) => q.id === quoteId);
    if (!chosen) throw new ValidationError('That quote is not part of this RFQ');
    const today = new Date().toISOString().slice(0, 10);
    const valid = quotes.rows.filter((q) => !q.valid_until || new Date(q.valid_until).toISOString().slice(0, 10) >= today);
    if (!valid.some((q) => q.id === quoteId)) throw new ConflictError('The chosen quote has expired');
    const lowest = valid.reduce((m, q) => (num(q.total_amount) < num(m.total_amount) ? q : m), valid[0]);
    if (lowest.id !== quoteId && !reason) {
      throw new ValidationError(`This is not the lowest valid quote (lowest is ${num(lowest.total_amount).toFixed(2)}); give the reason for the award`);
    }
    const qlines = await client.query(
      `SELECT ql.unit_price, ql.gst_rate, l.item_id, l.quantity, l.requisition_line_id FROM proc_rfq_quote_lines ql JOIN proc_rfq_lines l ON l.id = ql.rfq_line_id WHERE ql.quote_id = $1 ORDER BY l.line_no`,
      [quoteId],
    );
    const poId = await createOrderTx(
      client,
      {
        supplierId: chosen.supplier_id,
        requisitionId: r.requisition_id ?? undefined,
        rfqId,
        costCentreId: costCentreId ?? undefined,
        expectedDeliveryDate,
        deliveryAddress,
        paymentTermsDays: chosen.payment_terms_days ?? undefined,
        notes: `Awarded from ${r.rfq_number}${reason ? ` — ${reason}` : ''}`,
        lines: qlines.rows.map((l) => ({ itemId: l.item_id, quantity: num(l.quantity), unitPrice: num(l.unit_price), gstRate: num(l.gst_rate), requisitionLineId: l.requisition_line_id ?? undefined })),
      },
      user,
    );
    await client.query(`UPDATE proc_rfqs SET status = 'awarded', awarded_quote_id = $2, award_reason = $3, awarded_by = $4, awarded_at = now() WHERE id = $1`, [rfqId, quoteId, reason, user.email]);
    await insertAuditLog(client, { entityType: 'rfq', entityId: rfqId, action: 'AWARD', performedBy: user.email, metadata: { quoteId, reason, poId, lowest: lowest.id === quoteId } });
    return { rfq: await getRfq(rfqId, client), order: await getOrder(poId, client) };
  });
}

export async function cancelRfq(rfqId: string, input: Record<string, unknown>, user: AuthenticatedUser) {
  const reason = requireText(input.reason, 'reason', 1000);
  return withTransaction(async (client) => {
    const r = await client.query(`UPDATE proc_rfqs SET status = 'cancelled', award_reason = $2 WHERE id = $1 AND status = 'open' RETURNING id`, [rfqId, reason]);
    if (!r.rows[0]) throw new ConflictError('RFQ not found or not open');
    await insertAuditLog(client, { entityType: 'rfq', entityId: rfqId, action: 'CANCEL', performedBy: user.email, metadata: { reason } });
    return getRfq(rfqId, client);
  });
}

export async function listRfqs(filters: { status?: string }) {
  const values: unknown[] = [];
  let where = '';
  if (filters.status) {
    values.push(filters.status);
    where = 'WHERE r.status = $1';
  }
  const r = await pool.query(
    `SELECT r.*, pr.pr_number,
            (SELECT COUNT(*)::int FROM proc_rfq_quotes q WHERE q.rfq_id = r.id) AS quote_count,
            (SELECT MIN(total_amount) FROM proc_rfq_quotes q WHERE q.rfq_id = r.id) AS lowest_total
       FROM proc_rfqs r LEFT JOIN proc_requisitions pr ON pr.id = r.requisition_id ${where}
      ORDER BY r.created_at DESC LIMIT 500`,
    values,
  );
  return r.rows;
}

export async function getRfq(id: string, client?: PoolClient) {
  const db = client ?? pool;
  const r = await db.query(`SELECT r.*, pr.pr_number FROM proc_rfqs r LEFT JOIN proc_requisitions pr ON pr.id = r.requisition_id WHERE r.id = $1`, [id]);
  if (!r.rows[0]) throw new NotFoundError('RFQ not found');
  const lines = await db.query(`SELECT l.*, i.item_code, i.name AS item_name FROM proc_rfq_lines l JOIN proc_items i ON i.id = l.item_id WHERE l.rfq_id = $1 ORDER BY l.line_no`, [id]);
  const quotes = await db.query(
    `SELECT q.*, p.name AS supplier_name, p.party_code AS supplier_code FROM proc_rfq_quotes q JOIN parties p ON p.id = q.supplier_id WHERE q.rfq_id = $1 ORDER BY q.total_amount`,
    [id],
  );
  const qlines = await db.query(
    `SELECT ql.* FROM proc_rfq_quote_lines ql JOIN proc_rfq_quotes q ON q.id = ql.quote_id WHERE q.rfq_id = $1`,
    [id],
  );
  const order = await db.query('SELECT id, po_number, status FROM proc_purchase_orders WHERE rfq_id = $1 ORDER BY created_at DESC LIMIT 1', [id]);
  return {
    ...r.rows[0],
    lines: lines.rows,
    quotes: quotes.rows.map((q) => ({ ...q, lines: qlines.rows.filter((l) => l.quote_id === q.id) })),
    order: order.rows[0] ?? null,
  };
}
