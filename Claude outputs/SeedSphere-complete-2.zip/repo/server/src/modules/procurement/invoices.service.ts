import type { PoolClient } from 'pg';
import { pool } from '../../db/pool';
import { withTransaction } from '../../db/transaction';
import { ConflictError, ForbiddenError, NotFoundError, ValidationError } from '../../errors';
import type { AuthenticatedUser } from '../../middleware/requireAuth';
import { getApprovalsForEntity, registerApprovalHandler, submitForApprovalTx, withdrawTx } from '../approvals/approvals.service';
import { insertAuditLog } from '../auditLogs/auditLogs.service';
import { asRecord, nextCode, num, optionalNumber, optionalText, requireArray, requireDate, requireEnum, requireNumber, requireText, requireUuid, round2 } from '../shared/validate';
import { lineAmounts, PRICE_TOLERANCE } from './common';

export const PAYMENT_MODES = ['neft', 'rtgs', 'imps', 'upi', 'cheque'] as const;

registerApprovalHandler('invoice_payment', {
  onApproved: async (client, id) => {
    await client.query(`UPDATE proc_invoices SET status = 'approved' WHERE id = $1`, [id]);
  },
  onRejected: async (client, id, _user, comment) => {
    await client.query(`UPDATE proc_invoices SET status = 'rejected', rejection_reason = $2 WHERE id = $1`, [id, comment]);
  },
});

interface MatchLine {
  poLineId: string;
  lineNo: number;
  item: string;
  quantity: number;
  unitPrice: number;
  poUnitPrice: number;
  acceptedQuantity: number;
  previouslyInvoiced: number;
  available: number;
  quantityOk: boolean;
  priceOk: boolean;
  variance: number;
}

/**
 * Three-way match: every invoiced quantity must be covered by goods accepted
 * at the gate and not already invoiced, and every unit price must agree with
 * the order (within PRICE_TOLERANCE). A mismatch is recorded, not refused, so
 * the supplier's document is on file — but it cannot be paid until someone
 * explains the variance, and finance sees that explanation when approving.
 */
async function matchLines(client: PoolClient, poId: string, lines: { poLineId: string; quantity: number; unitPrice: number }[], excludeInvoiceId: string | null) {
  const out: MatchLine[] = [];
  for (const l of lines) {
    const r = await client.query(
      `SELECT l.id, l.line_no, l.unit_price, l.accepted_quantity, l.gst_rate, i.name,
              COALESCE((SELECT SUM(il.quantity) FROM proc_invoice_lines il JOIN proc_invoices inv ON inv.id = il.invoice_id
                         WHERE il.po_line_id = l.id AND inv.status NOT IN ('cancelled', 'rejected') AND ($3::uuid IS NULL OR inv.id <> $3)), 0) AS invoiced
         FROM proc_po_lines l JOIN proc_items i ON i.id = l.item_id WHERE l.id = $1 AND l.po_id = $2`,
      [l.poLineId, poId, excludeInvoiceId],
    );
    const pl = r.rows[0];
    if (!pl) throw new ValidationError('An invoice line does not belong to this order');
    const poPrice = num(pl.unit_price);
    const available = round2(num(pl.accepted_quantity) - num(pl.invoiced));
    const quantityOk = l.quantity <= available + 1e-9;
    const priceOk = Math.abs(l.unitPrice - poPrice) <= poPrice * PRICE_TOLERANCE + 1e-9;
    const variance = round2((l.unitPrice - poPrice) * l.quantity + Math.max(0, l.quantity - available) * poPrice);
    out.push({
      poLineId: l.poLineId,
      lineNo: pl.line_no,
      item: pl.name,
      quantity: l.quantity,
      unitPrice: l.unitPrice,
      poUnitPrice: poPrice,
      acceptedQuantity: num(pl.accepted_quantity),
      previouslyInvoiced: num(pl.invoiced),
      available,
      quantityOk,
      priceOk,
      variance,
    });
  }
  return out;
}

export async function createInvoice(input: Record<string, unknown>, user: AuthenticatedUser) {
  const poId = requireUuid(input.poId, 'poId');
  const supplierInvoiceNo = requireText(input.supplierInvoiceNo, 'supplierInvoiceNo', 60);
  const invoiceDate = requireDate(input.invoiceDate, 'invoiceDate');
  if (invoiceDate > new Date().toISOString().slice(0, 10)) throw new ValidationError('invoiceDate cannot be in the future');
  const statedTotal = optionalNumber(input.statedTotal, 'statedTotal', { positive: true });
  const lines = requireArray(input.lines, 'lines', { min: 1, max: 100 }).map((raw, i) => {
    const r = asRecord(raw, `lines[${i}]`);
    return {
      poLineId: requireUuid(r.poLineId, `lines[${i}].poLineId`),
      quantity: requireNumber(r.quantity, `lines[${i}].quantity`, { positive: true }),
      unitPrice: requireNumber(r.unitPrice, `lines[${i}].unitPrice`, { min: 0 }),
      gstRate: optionalNumber(r.gstRate, `lines[${i}].gstRate`, { min: 0, max: 28 }),
    };
  });
  if (new Set(lines.map((l) => l.poLineId)).size !== lines.length) throw new ValidationError('Each order line may appear once on an invoice');

  return withTransaction(async (client) => {
    const po = await client.query('SELECT * FROM proc_purchase_orders WHERE id = $1', [poId]);
    const order = po.rows[0];
    if (!order) throw new NotFoundError('Purchase order not found');
    if (!['partially_received', 'received', 'closed', 'approved', 'sent'].includes(order.status)) throw new ConflictError(`An invoice cannot be booked against a ${order.status} order`);
    const dup = await client.query('SELECT invoice_number FROM proc_invoices WHERE supplier_id = $1 AND supplier_invoice_no = $2', [order.supplier_id, supplierInvoiceNo]);
    if (dup.rows[0]) throw new ConflictError(`Supplier invoice ${supplierInvoiceNo} is already booked as ${dup.rows[0].invoice_number} — possible duplicate payment`);

    const match = await matchLines(client, poId, lines, null);
    let subtotal = 0;
    let taxTotal = 0;
    const amounts = [];
    for (const l of lines) {
      const gstRow = await client.query<{ gst_rate: string }>('SELECT gst_rate FROM proc_po_lines WHERE id = $1', [l.poLineId]);
      const gst = l.gstRate ?? num(gstRow.rows[0].gst_rate);
      const a = lineAmounts(l.quantity, l.unitPrice, gst);
      subtotal += a.lineTotal;
      taxTotal += a.tax;
      amounts.push({ ...l, gst, ...a });
    }
    subtotal = round2(subtotal);
    taxTotal = round2(taxTotal);
    const total = round2(subtotal + taxTotal);
    const totalOk = statedTotal === null || Math.abs(statedTotal - total) <= 1;
    const matched = match.every((m) => m.quantityOk && m.priceOk) && totalOk;
    const variance = round2(match.reduce((s, m) => s + m.variance, 0));
    const due = new Date(`${invoiceDate}T00:00:00Z`);
    due.setUTCDate(due.getUTCDate() + order.payment_terms_days);

    const code = await nextCode(client, 'INV', 5, true);
    const inv = await client.query(
      `INSERT INTO proc_invoices (invoice_number, supplier_invoice_no, supplier_id, po_id, invoice_date, due_date, subtotal, tax_total, total_amount, match_status, match_details, variance_amount, created_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13) RETURNING *`,
      [code, supplierInvoiceNo, order.supplier_id, poId, invoiceDate, due.toISOString().slice(0, 10), subtotal, taxTotal, total, matched ? 'matched' : 'mismatch', JSON.stringify({ lines: match, statedTotal, computedTotal: total, totalOk }), variance, user.email],
    );
    for (const a of amounts) {
      await client.query(
        `INSERT INTO proc_invoice_lines (invoice_id, po_line_id, quantity, unit_price, gst_rate, line_total, tax_amount) VALUES ($1, $2, $3, $4, $5, $6, $7)`,
        [inv.rows[0].id, a.poLineId, a.quantity, a.unitPrice, a.gst, a.lineTotal, a.tax],
      );
    }
    await insertAuditLog(client, { entityType: 'invoice', entityId: inv.rows[0].id, action: 'CREATE', performedBy: user.email, afterState: { ...inv.rows[0] } });
    return getInvoice(inv.rows[0].id, client);
  });
}

async function lock(client: PoolClient, id: string) {
  const r = await client.query('SELECT * FROM proc_invoices WHERE id = $1 FOR UPDATE', [id]);
  if (!r.rows[0]) throw new NotFoundError('Invoice not found');
  return r.rows[0];
}

export async function submitInvoice(id: string, input: Record<string, unknown>, user: AuthenticatedUser) {
  const varianceReason = optionalText(input.varianceReason, 'varianceReason', 2000);
  return withTransaction(async (client) => {
    const inv = await lock(client, id);
    if (inv.status !== 'received') throw new ConflictError(`Only a received invoice can be sent for payment approval (this one is ${inv.status})`);
    // Re-run the match: goods may have been accepted since the invoice was booked.
    const lines = await client.query('SELECT po_line_id, quantity, unit_price FROM proc_invoice_lines WHERE invoice_id = $1', [id]);
    const match = await matchLines(client, inv.po_id, lines.rows.map((l) => ({ poLineId: l.po_line_id, quantity: num(l.quantity), unitPrice: num(l.unit_price) })), id);
    const details = inv.match_details as { totalOk?: boolean };
    const matched = match.every((m) => m.quantityOk && m.priceOk) && details.totalOk !== false;
    if (!matched && !varianceReason) throw new ValidationError('The invoice does not match the order and the goods accepted — explain the variance in varianceReason before sending it for payment');
    await client.query(
      `UPDATE proc_invoices SET status = 'pending_approval', match_status = $2, match_details = $3, variance_amount = $4, variance_reason = $5 WHERE id = $1`,
      [id, matched ? 'matched' : 'mismatch', JSON.stringify({ ...details, lines: match }), round2(match.reduce((s, m) => s + m.variance, 0)), matched ? null : varianceReason],
    );
    const supplier = await client.query('SELECT name FROM parties WHERE id = $1', [inv.supplier_id]);
    await submitForApprovalTx(
      client,
      { entityType: 'invoice_payment', entityId: id, entityCode: inv.invoice_number, title: `${supplier.rows[0].name} · ${inv.supplier_invoice_no}${matched ? '' : ' — VARIANCE'}`, amount: num(inv.total_amount) },
      user,
    );
    return getInvoice(id, client);
  });
}

export async function payInvoice(id: string, input: Record<string, unknown>, user: AuthenticatedUser) {
  const reference = requireText(input.paymentReference, 'paymentReference', 60);
  const mode = requireEnum(input.paymentMode, PAYMENT_MODES, 'paymentMode');
  return withTransaction(async (client) => {
    const inv = await lock(client, id);
    if (inv.status !== 'approved') throw new ConflictError(`Only an approved invoice can be paid (this one is ${inv.status})`);
    const approvers = await client.query<{ decided_by: string }>(
      `SELECT s.decided_by FROM approval_steps s JOIN approval_requests r ON r.id = s.request_id
        WHERE r.entity_type = 'invoice_payment' AND r.entity_id = $1 AND r.status = 'approved' AND s.decided_by IS NOT NULL`,
      [id],
    );
    // Segregation of duties: whoever approved the payment does not also release it.
    if (approvers.rows.some((a) => a.decided_by === user.email)) throw new ForbiddenError('You approved this payment; someone else must release it');
    await client.query(`UPDATE proc_invoices SET status = 'paid', payment_reference = $2, payment_mode = $3, paid_at = now(), paid_by = $4 WHERE id = $1`, [id, reference, mode, user.email]);
    await insertAuditLog(client, { entityType: 'invoice', entityId: id, action: 'PAY', performedBy: user.email, metadata: { reference, mode, amount: inv.total_amount } });
    return getInvoice(id, client);
  });
}

export async function cancelInvoice(id: string, input: Record<string, unknown>, user: AuthenticatedUser) {
  const reason = requireText(input.reason, 'reason', 1000);
  return withTransaction(async (client) => {
    const inv = await lock(client, id);
    if (!['received', 'rejected', 'pending_approval'].includes(inv.status)) throw new ConflictError(`A ${inv.status} invoice cannot be cancelled`);
    await withdrawTx(client, 'invoice_payment', id, user);
    await client.query(`UPDATE proc_invoices SET status = 'cancelled', rejection_reason = $2 WHERE id = $1`, [id, reason]);
    await insertAuditLog(client, { entityType: 'invoice', entityId: id, action: 'CANCEL', performedBy: user.email, metadata: { reason } });
    return getInvoice(id, client);
  });
}

export async function listInvoices(filters: { status?: string; supplierId?: string; overdue?: boolean }) {
  const where: string[] = [];
  const values: unknown[] = [];
  if (filters.status) {
    values.push(filters.status);
    where.push(`i.status = $${values.length}`);
  }
  if (filters.supplierId) {
    values.push(filters.supplierId);
    where.push(`i.supplier_id = $${values.length}`);
  }
  if (filters.overdue) where.push(`i.status IN ('received', 'pending_approval', 'approved') AND i.due_date < CURRENT_DATE`);
  const r = await pool.query(
    `SELECT i.*, o.po_number, p.name AS supplier_name,
            (i.status IN ('received', 'pending_approval', 'approved') AND i.due_date < CURRENT_DATE) AS is_overdue
       FROM proc_invoices i JOIN proc_purchase_orders o ON o.id = i.po_id JOIN parties p ON p.id = i.supplier_id
       ${where.length ? `WHERE ${where.join(' AND ')}` : ''}
      ORDER BY i.due_date, i.created_at DESC LIMIT 500`,
    values,
  );
  return r.rows;
}

export async function getInvoice(id: string, client?: PoolClient) {
  const db = client ?? pool;
  const r = await db.query(
    `SELECT i.*, o.po_number, o.payment_terms_days, p.name AS supplier_name, p.party_code AS supplier_code, p.bank_account_name, p.bank_ifsc,
            RIGHT(p.bank_account_number, 4) AS bank_account_last4,
            (i.status IN ('received', 'pending_approval', 'approved') AND i.due_date < CURRENT_DATE) AS is_overdue
       FROM proc_invoices i JOIN proc_purchase_orders o ON o.id = i.po_id JOIN parties p ON p.id = i.supplier_id WHERE i.id = $1`,
    [id],
  );
  if (!r.rows[0]) throw new NotFoundError('Invoice not found');
  const lines = await db.query(
    `SELECT il.*, l.line_no, l.unit, it.name AS item_name FROM proc_invoice_lines il JOIN proc_po_lines l ON l.id = il.po_line_id JOIN proc_items it ON it.id = l.item_id
      WHERE il.invoice_id = $1 ORDER BY l.line_no`,
    [id],
  );
  const approvals = await getApprovalsForEntity('invoice_payment', id, client);
  return { ...r.rows[0], lines: lines.rows, approvals };
}
