import { pool } from '../../db/pool';
import type { ModuleInsight, ModuleKey, ModuleMetric } from './moduleInsights';

/**
 * Findings from the operational modules (procurement, warehouse, processing,
 * R&D, approvals, safety). Each is a straight count over stored records; a
 * failing query (older database) simply contributes nothing.
 */
async function one<T extends Record<string, unknown>>(sql: string, params: unknown[] = []): Promise<T | null> {
  try {
    return ((await pool.query(sql, params)).rows[0] as T) ?? null;
  } catch (error) {
    console.warn('[ai] operations insight skipped:', error instanceof Error ? error.message : error);
    return null;
  }
}
const plural = (n: number, one_: string, many = `${one_}s`) => `${n} ${n === 1 ? one_ : many}`;
const mk = (i: Omit<ModuleInsight, 'action' | 'link' | 'aiTab'> & Partial<ModuleInsight>): ModuleInsight => ({ action: null, link: null, aiTab: null, ...i });

export interface OperationsExtra { metrics: ModuleMetric[]; insights: ModuleInsight[] }

const APPROVAL_TYPES: Partial<Record<ModuleKey, string[]>> = {
  procurement: ['purchase_requisition', 'purchase_order', 'invoice_payment', 'grower_agreement', 'grower_settlement'],
  warehouse: ['stock_adjustment', 'dispatch_order'],
  processing: ['processing_recipe'],
  rd: ['trial_protocol', 'variety_advancement', 'variety_release'],
  quality: ['recall', 'variety_release'],
};

async function approvals(module: ModuleKey): Promise<ModuleInsight[]> {
  const types = APPROVAL_TYPES[module];
  if (!types && module !== 'administration') return [];
  const r = await one<{ n: number; old: number }>(
    `SELECT COUNT(*)::int AS n, COUNT(*) FILTER (WHERE requested_at < now() - interval '3 days')::int AS old
       FROM approval_requests WHERE status = 'pending' ${types ? 'AND entity_type = ANY($1::text[])' : ''}`,
    types ? [types] : [],
  );
  if (!r || r.n === 0) return [];
  return [mk({
    id: 'approvals-waiting',
    severity: r.old > 0 ? 'warning' : 'info',
    title: `${plural(r.n, 'approval')} waiting${r.old ? `, ${r.old} for more than 3 days` : ''}`,
    detail: 'Records stay blocked until the next approver decides.',
    action: 'Open the approvals inbox.',
    link: module === 'administration' ? '/admin/approvals' : `/${module === 'laboratory' ? 'lab' : module}/approvals`,
  })];
}

export async function operationsExtras(module: ModuleKey): Promise<OperationsExtra> {
  const insights: ModuleInsight[] = [...(await approvals(module))];
  const metrics: ModuleMetric[] = [];

  if (module === 'procurement') {
    const po = await one<{ open: number; overdue: number; code: string | null; mismatch: number }>(`
      SELECT COUNT(*) FILTER (WHERE status IN ('pending_approval','approved','sent','partially_received'))::int AS open,
             COUNT(*) FILTER (WHERE status IN ('sent','partially_received') AND expected_delivery_date < CURRENT_DATE)::int AS overdue,
             (SELECT po_number FROM proc_purchase_orders WHERE status IN ('sent','partially_received') AND expected_delivery_date < CURRENT_DATE ORDER BY expected_delivery_date LIMIT 1) AS code,
             (SELECT COUNT(*) FROM proc_invoices WHERE match_status = 'mismatch' AND status IN ('received','pending_approval') AND variance_reason IS NULL)::int AS mismatch
        FROM proc_purchase_orders`);
    if (po) {
      metrics.push({ label: 'Open purchase orders', value: String(po.open), tone: 'neutral' }, { label: 'Overdue orders', value: String(po.overdue), tone: po.overdue ? 'warn' : 'good' });
      if (po.overdue) insights.push(mk({ id: 'proc-po-overdue', severity: 'warning', title: `${plural(po.overdue, 'purchase order')} past the expected delivery date`, detail: `${po.code} is the longest overdue.`, action: 'Chase the supplier.', link: '/procurement/orders' }));
      if (po.mismatch) insights.push(mk({ id: 'proc-mismatch', severity: 'warning', title: `${plural(po.mismatch, 'invoice')} with an unexplained three-way-match variance`, detail: 'These cannot be paid until the variance is explained.', action: 'Explain or reject the variance.', link: '/procurement/invoices' }));
    }
  }

  if (module === 'warehouse') {
    const w = await one<{ breaches: number; disp: number; adj: number; ready: number }>(`
      SELECT (SELECT COUNT(*) FROM wh_sensor_breaches WHERE ended_at IS NULL)::int AS breaches,
             (SELECT COUNT(*) FROM wh_dispatches WHERE status = 'pending_approval')::int AS disp,
             (SELECT COUNT(*) FROM wh_adjustments WHERE status = 'pending_approval')::int AS adj,
             (SELECT COUNT(*) FROM wh_dispatches WHERE status = 'approved')::int AS ready`);
    if (w) {
      metrics.push({ label: 'Open storage breaches', value: String(w.breaches), tone: w.breaches ? 'bad' : 'good' });
      if (w.breaches) insights.push(mk({ id: 'wh-breach', severity: 'critical', title: `${plural(w.breaches, 'storage location')} outside its temperature or humidity range now`, detail: 'A non-conformance was raised naming the lots stored there.', action: 'Check the cooling and humidity control.', link: '/warehouse/iot' }));
      if (w.ready) insights.push(mk({ id: 'wh-ready', severity: 'info', title: `${plural(w.ready, 'approved dispatch', 'approved dispatches')} not yet shipped`, detail: 'Approved orders waiting for loading.', link: '/warehouse/outbound' }));
      if (w.adj) insights.push(mk({ id: 'wh-adj', severity: 'info', title: `${plural(w.adj, 'stock adjustment')} waiting for the warehouse manager`, detail: 'Stock is not changed until approved.', link: '/warehouse/adjustments' }));
    }
  }

  if (module === 'processing') {
    const p = await one<{ running: number; late: number; intake: number }>(`
      SELECT (SELECT COUNT(*) FROM prc_batches WHERE status NOT IN ('completed','cancelled'))::int AS running,
             (SELECT COUNT(*) FROM prc_batches WHERE status = 'planned' AND planned_date < CURRENT_DATE)::int AS late,
             (SELECT COUNT(*) FROM prc_raw_intakes WHERE status = 'awaiting_check')::int AS intake`);
    if (p) {
      metrics.push({ label: 'Batches in progress', value: String(p.running), tone: 'neutral' });
      if (p.late) insights.push(mk({ id: 'prc-late', severity: 'warning', title: `${plural(p.late, 'batch', 'batches')} planned for an earlier date and not started`, detail: 'Re-plan them on plant scheduling.', link: '/processing/planning' }));
      if (p.intake) insights.push(mk({ id: 'prc-intake', severity: 'info', title: `${plural(p.intake, 'raw intake')} waiting for the intake check`, detail: 'Seed cannot be processed until it is checked.', link: '/processing/intake' }));
    }
  }

  if (module === 'rd') {
    const r = await one<{ running: number; pending: number }>(`
      SELECT (SELECT COUNT(*) FROM rd_trials WHERE status = 'running')::int AS running,
             (SELECT COUNT(*) FROM rd_advancements WHERE status = 'pending_approval')::int AS pending`);
    if (r) {
      metrics.push({ label: 'Trials running', value: String(r.running), tone: 'neutral' });
      if (r.pending) insights.push(mk({ id: 'rd-adv', severity: 'info', title: `${plural(r.pending, 'variety advancement')} waiting for approval`, detail: 'Candidates move through the pipeline only after approval.', link: '/rd/release' }));
    }
  }

  if (module === 'quality' || module === 'administration') {
    const s = await one<{ serious: number }>(`SELECT COUNT(*)::int AS serious FROM safety_incidents WHERE status <> 'closed' AND severity IN ('major','critical')`);
    if (s?.serious) insights.push(mk({ id: 'safety-serious', severity: 'critical', title: `${plural(s.serious, 'serious safety incident')} still open`, detail: 'Major and critical incidents need a root cause and corrective action.', link: '/quality/safety' }));
  }

  if (module === 'administration') {
    const l = await one<{ n: number }>(`SELECT COUNT(*)::int AS n FROM parties WHERE status = 'active' AND licence_valid_until IS NOT NULL AND licence_valid_until < CURRENT_DATE + 30`);
    if (l?.n) insights.push(mk({ id: 'licences', severity: 'warning', title: `${plural(l.n, 'party licence')} lapsed or lapsing within 30 days`, detail: 'Dealers without a valid licence cannot be supplied.', link: '/admin/parties' }));
  }

  return { metrics, insights };
}
