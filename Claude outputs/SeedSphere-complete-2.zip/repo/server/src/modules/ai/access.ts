import { hasPermission } from '../../auth/permissions';
import type { AuthenticatedUser } from '../../middleware/requireAuth';
import type { ModuleKey } from './moduleInsights';

/**
 * Which AI results a person may read. It follows the screens: a job role sees
 * the AI for its own module. Administrators, the auditor and anyone who holds
 * the management dashboard (the module managers) see every module, as they do
 * on that dashboard. Growers and dealers are refused earlier (requireStaff).
 *
 * Mirrored on the front end in src/utils/aiAccess.ts; keep the two in step.
 */
export const AI_MODULE_ROLES: Record<ModuleKey, string[]> = {
  procurement: ['purchase_executive', 'purchase_manager', 'finance_manager', 'procurement_quality_field_inspector'],
  warehouse: ['warehouse_supervisor', 'warehouse_manager', 'warehouse_quality_field_inspector', 'safety_officer'],
  rd: ['rd_executive', 'rd_manager', 'rd_quality_field_inspector'],
  processing: ['plant_supervisor', 'plant_manager', 'processing_quality_field_inspector'],
  laboratory: ['lab_manager', 'lab_technician', 'lab_quality_analyst', 'quality_manager', 'quality_officer'],
  quality: ['quality_manager', 'quality_officer'],
  administration: ['super_admin', 'system_admin', 'compliance_auditor'],
};

const SEES_EVERY_MODULE = ['super_admin', 'system_admin', 'compliance_auditor'];

type Who = Pick<AuthenticatedUser, 'role' | 'jobRole'>;

export function seesEveryModule(user: Who): boolean {
  if (!user.jobRole) return user.role === 'Admin';
  return SEES_EVERY_MODULE.includes(user.jobRole) || hasPermission(user.jobRole, user.role, 'view_management_dashboard');
}

export function canSeeModule(user: Who, module: ModuleKey): boolean {
  if (seesEveryModule(user)) return true;
  return Boolean(user.jobRole && AI_MODULE_ROLES[module].includes(user.jobRole));
}

/** Lot quality risk and germination forecasts: the people who test, hold, store or process lots. */
export function canSeeLabRisk(user: Who): boolean {
  return (['laboratory', 'quality', 'warehouse', 'processing'] as ModuleKey[]).some((m) => canSeeModule(user, m));
}

/** Stock cover and label-expiry forecasts: the people who buy, store or process stock. */
export function canSeeForecasts(user: Who): boolean {
  return (['warehouse', 'procurement', 'processing'] as ModuleKey[]).some((m) => canSeeModule(user, m));
}
