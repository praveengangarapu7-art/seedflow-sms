import { Router, type Request, type Response } from 'express';
import { asyncHandler } from '../../middleware/asyncHandler';
import { requireAuth, requireRole, requireStaff } from '../../middleware/requireAuth';
import { ForbiddenError, ValidationError } from '../../errors';
import { canSeeForecasts, canSeeLabRisk, canSeeModule } from './access';
import { aiStatus, analyzePhoto, forecastReport, labRiskReport } from './ai.service';
import { ensureKnowledgeIndexed, knowledgeStats, reindexKnowledge, search as searchKnowledge } from './knowledge.service';
import { allModuleInsights, isModuleKey, MODULE_KEYS, moduleInsights } from './moduleInsights';

/**
 * AI Center endpoints. Read-only over existing data; photo analysis stores
 * nothing. Company staff only (growers and dealers have their portals), and
 * each person sees the AI for the modules their job role works in (access.ts).
 */
export const aiRouter = Router();

aiRouter.use(requireAuth, requireStaff);

aiRouter.get(
  '/status',
  asyncHandler(async (_req: Request, res: Response) => {
    res.json({ success: true, data: { ...aiStatus(), knowledge: await knowledgeStats() } });
  }),
);

// Retrieval endpoints behind the assistant, exposed so the AI Center can show
// what the knowledge base holds and re-index it after records change.
aiRouter.get(
  '/knowledge/search',
  asyncHandler(async (req: Request, res: Response) => {
    const q = String(req.query.q ?? '').trim();
    if (!q) throw new ValidationError('q is required');
    await ensureKnowledgeIndexed();
    res.json({ success: true, data: await searchKnowledge(q, 6) });
  }),
);

aiRouter.post(
  '/knowledge/reindex',
  requireRole('Admin'),
  asyncHandler(async (_req: Request, res: Response) => {
    res.json({ success: true, data: await reindexKnowledge(), message: 'Knowledge base re-indexed' });
  }),
);

aiRouter.get(
  '/lab-risk',
  asyncHandler(async (req: Request, res: Response) => {
    if (!canSeeLabRisk(req.user!)) throw new ForbiddenError('Lot quality risk is for the laboratory, quality, warehouse and processing teams');
    res.json({ success: true, data: await labRiskReport() });
  }),
);

aiRouter.get(
  '/forecasts',
  asyncHandler(async (req: Request, res: Response) => {
    if (!canSeeForecasts(req.user!)) throw new ForbiddenError('Stock forecasts are for the procurement, warehouse and processing teams');
    res.json({ success: true, data: await forecastReport() });
  }),
);

aiRouter.get(
  '/insights',
  asyncHandler(async (req: Request, res: Response) => {
    // Only the modules this person works in.
    res.json({ success: true, data: await allModuleInsights(MODULE_KEYS.filter((m) => canSeeModule(req.user!, m))) });
  }),
);

aiRouter.get(
  '/insights/:module',
  asyncHandler(async (req: Request, res: Response) => {
    const key = String(req.params.module);
    if (!isModuleKey(key)) throw new ValidationError(`Unknown module "${key}"`);
    if (!canSeeModule(req.user!, key)) throw new ForbiddenError('Your role does not cover this module');
    res.json({ success: true, data: await moduleInsights(key, { narrate: req.query.briefing === 'true' }) });
  }),
);

aiRouter.post(
  '/photo-analysis',
  asyncHandler(async (req: Request, res: Response) => {
    res.json({ success: true, data: await analyzePhoto(req.body ?? {}) });
  }),
);
