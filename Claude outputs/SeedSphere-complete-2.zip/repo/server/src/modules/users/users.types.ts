export interface AuthUser {
  id: string;
  email: string;
  name: string;
  role: string;
  organizationId: string | null;
  jobRole: string | null;
  permissions: string[] | 'all';
}

export interface RegisterInput {
  email: string;
  password: string;
  name: string;
  role: string;
  organizationId?: string | null;
}

export interface LoginInput {
  email: string;
  password: string;
}
