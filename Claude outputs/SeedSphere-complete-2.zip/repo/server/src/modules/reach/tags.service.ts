import { createHash, randomInt } from 'node:crypto';
import { env } from '../../config/env';
import { pool } from '../../db/pool';
import { withTransaction } from '../../db/transaction';
import { ConflictError, NotFoundError, ValidationError } from '../../errors';
import type { AuthenticatedUser } from '../../middleware/requireAuth';
import { insertAuditLog } from '../auditLogs/auditLogs.service';
import { lotSaleInfo } from '../warehouse/stock.service';
import { num, optionalUuid, requireNumber, requireText, requireUuid } from '../shared/validate';

// No 0/O/1/I so a tag read aloud or typed from a printed pack is not misread.
const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const randomGroup = (n: number) => Array.from({ length: n }, () => ALPHABET[randomInt(ALPHABET.length)]).join('');
const makeTagCode = () => `SS-${randomGroup(4)}-${randomGroup(4)}`;

/** Accepts what a farmer might type: lower case, spaces, missing dashes. */
export function normaliseTagCode(raw: string): string {
  const s = raw.toUpperCase().replace(/[^A-Z0-9]/g, '');
  const body = s.startsWith('SS') ? s.slice(2) : s;
  return body.length === 8 ? `SS-${body.slice(0, 4)}-${body.slice(4)}` : raw.toUpperCase().trim();
}

const MAX_TAGS_PER_CALL = 5000;

export async function generateTags(input: Record<string, unknown>, user: AuthenticatedUser) {
  const lotId = requireUuid(input.seedLotId, 'seedLotId');
  const count = Math.floor(requireNumber(input.count, 'count'));
  const pack = requireNumber(input.packSizeKg, 'packSizeKg');
  const dispatchId = optionalUuid(input.dispatchId, 'dispatchId');
  if (count < 1 || count > MAX_TAGS_PER_CALL) throw new ValidationError(`count must be between 1 and ${MAX_TAGS_PER_CALL}`);
  if (pack <= 0 || pack > 1000) throw new ValidationError('packSizeKg must be above 0 and at most 1000');
  return withTransaction(async (client) => {
    const lot = await client.query('SELECT id, lot_code, quantity_total FROM seed_lots WHERE id = $1 FOR UPDATE', [lotId]);
    if (!lot.rows[0]) throw new NotFoundError('Seed lot not found');
    const existing = await client.query('SELECT COALESCE(SUM(pack_size_kg), 0) AS kg FROM seed_tags WHERE seed_lot_id = $1 AND status = $2', [lotId, 'active']);
    const total = num(existing.rows[0].kg) + count * pack;
    if (total > num(lot.rows[0].quantity_total) + 0.001) {
      throw new ConflictError(`Lot ${lot.rows[0].lot_code} holds ${num(lot.rows[0].quantity_total)} kg; tags for ${total} kg would be more than the lot (void unused tags first)`);
    }
    const codes = new Set<string>();
    while (codes.size < count) codes.add(makeTagCode());
    const list = [...codes];
    const rows = await client.query(
      `INSERT INTO seed_tags (tag_code, seed_lot_id, pack_size_kg, dispatch_id, created_by)
       SELECT c, $2, $3, $4, $5 FROM unnest($1::text[]) AS c
       ON CONFLICT (tag_code) DO NOTHING RETURNING tag_code`,
      [list, lotId, pack, dispatchId, user.email],
    );
    if (rows.rowCount !== count) throw new ConflictError('Tag code collision — please run it again');
    await insertAuditLog(client, { entityType: 'seed_tag', entityId: lotId, action: 'GENERATE', performedBy: user.email, metadata: { count, packSizeKg: pack } });
    return { seedLotId: lotId, lotCode: lot.rows[0].lot_code, count, packSizeKg: pack, tagCodes: rows.rows.map((r) => r.tag_code as string) };
  });
}

export async function listTags(filters: { lotId?: string; status?: string; limit?: number }) {
  const where: string[] = [];
  const values: unknown[] = [];
  if (filters.lotId) {
    values.push(filters.lotId);
    where.push(`t.seed_lot_id = $${values.length}`);
  }
  if (filters.status) {
    values.push(filters.status);
    where.push(`t.status = $${values.length}`);
  }
  values.push(Math.min(filters.limit ?? 300, 2000));
  const r = await pool.query(
    `SELECT t.*, l.lot_code, l.crop, l.variety FROM seed_tags t JOIN seed_lots l ON l.id = t.seed_lot_id
      ${where.length ? `WHERE ${where.join(' AND ')}` : ''} ORDER BY t.created_at DESC, t.tag_code LIMIT $${values.length}`,
    values,
  );
  return r.rows;
}

export async function lotTagSummary() {
  const r = await pool.query(
    `SELECT l.id AS seed_lot_id, l.lot_code, l.crop, l.variety, COUNT(t.id)::int AS tags, COALESCE(SUM(t.pack_size_kg), 0) AS tagged_kg,
            COALESCE(SUM(t.scan_count), 0)::int AS scans, l.quantity_total
       FROM seed_tags t JOIN seed_lots l ON l.id = t.seed_lot_id WHERE t.status = 'active' GROUP BY l.id ORDER BY MAX(t.created_at) DESC LIMIT 200`,
  );
  return r.rows;
}

export async function voidTag(tagCode: string, input: Record<string, unknown>, user: AuthenticatedUser) {
  const reason = requireText(input.reason, 'reason', 500);
  return withTransaction(async (client) => {
    const r = await client.query(`UPDATE seed_tags SET status = 'void', void_reason = $2 WHERE tag_code = $1 AND status = 'active' RETURNING *`, [normaliseTagCode(tagCode), reason]);
    if (!r.rows[0]) throw new ConflictError('No active tag with that code');
    await insertAuditLog(client, { entityType: 'seed_tag', entityId: r.rows[0].id, action: 'VOID', performedBy: user.email, metadata: { reason } });
    return r.rows[0];
  });
}

export async function scanActivity() {
  const [recent, byResult, hot] = await Promise.all([
    pool.query(`SELECT tag_code, result, scanned_at FROM seed_tag_scans ORDER BY scanned_at DESC LIMIT 50`),
    pool.query(`SELECT result, COUNT(*)::int AS n FROM seed_tag_scans WHERE scanned_at > now() - interval '30 days' GROUP BY result`),
    pool.query(
      `SELECT t.tag_code, l.lot_code, t.scan_count, COUNT(DISTINCT s.client_hash)::int AS devices
         FROM seed_tags t JOIN seed_lots l ON l.id = t.seed_lot_id JOIN seed_tag_scans s ON s.seed_tag_id = t.id AND s.scanned_at > now() - interval '30 days'
        GROUP BY t.id, l.lot_code HAVING COUNT(DISTINCT s.client_hash) >= $1 ORDER BY devices DESC LIMIT 50`,
      [SUSPECT_DEVICES],
    ),
  ]);
  return { recent: recent.rows, last30Days: Object.fromEntries(byResult.rows.map((r) => [r.result, r.n])), suspicious: hot.rows };
}

const SUSPECT_DEVICES = 8;

export const clientHash = (ip: string | undefined, ua: string | undefined) =>
  createHash('sha256').update(`${env.jwtAccessSecret}|${ip ?? ''}|${ua ?? ''}`).digest('hex').slice(0, 16);

export type Verdict = 'genuine' | 'caution' | 'on_hold' | 'expired' | 'failed' | 'unverified' | 'void' | 'recalled' | 'not_found';

const MESSAGES: Record<Verdict, string> = {
  genuine: 'This is a genuine SeedSphere seed pack. It is within its tested validity.',
  caution: 'This tag is genuine but has been checked from many different phones. If you have not checked it before, the pack may be a copy — contact us before sowing.',
  on_hold: 'Do not sow. This lot is on a quality hold. Please contact the company or your dealer.',
  expired: 'This lot has passed its tested validity. Do not sow it without a fresh germination test — contact your dealer.',
  failed: 'Do not sow. The latest germination test on this lot did not pass. Please contact the company.',
  unverified: 'The tag is genuine, but this lot has no germination test on record yet. Ask your dealer for the test report.',
  void: 'This tag has been cancelled by the company. Do not trust this pack — contact us.',
  recalled: 'RECALLED. The company has recalled this lot. Do not sow it; return it to your dealer.',
  not_found: 'We could not find this tag. Check the code and try again. If it is correct, the pack may be fake — please report it.',
};

/**
 * Public verification. No login: what comes back is only what is printed on or
 * promised by the pack, never stock, supplier or customer data.
 */
export async function verifyPublic(rawCode: string, client: { ip?: string; ua?: string }) {
  const code = normaliseTagCode(rawCode);
  const hash = clientHash(client.ip, client.ua);
  if (!/^SS-[A-Z2-9]{4}-[A-Z2-9]{4}$/.test(code)) {
    await pool.query(`INSERT INTO seed_tag_scans (tag_code, result, client_hash) VALUES ($1, 'not_found', $2)`, [code.slice(0, 30), hash]);
    return { verdict: 'not_found' as Verdict, message: MESSAGES.not_found, tagCode: code.slice(0, 30) };
  }
  const t = await pool.query(
    `SELECT t.id, t.tag_code, t.status, t.pack_size_kg, t.scan_count, l.id AS lot_id, l.lot_code, l.crop, l.variety, l.stage, l.production_date, o.name AS company
       FROM seed_tags t JOIN seed_lots l ON l.id = t.seed_lot_id LEFT JOIN organizations o ON o.id = l.organization_id WHERE t.tag_code = $1`,
    [code],
  );
  const tag = t.rows[0];
  if (!tag) {
    await pool.query(`INSERT INTO seed_tag_scans (tag_code, result, client_hash) VALUES ($1, 'not_found', $2)`, [code, hash]);
    return { verdict: 'not_found' as Verdict, message: MESSAGES.not_found, tagCode: code };
  }
  const info = (await lotSaleInfo(pool, [tag.lot_id])).get(tag.lot_id)!;
  const recall = await pool.query(`SELECT 1 FROM recall_lots rl JOIN recalls r ON r.id = rl.recall_id WHERE rl.seed_lot_id = $1 AND r.status IN ('approved', 'in_progress')`, [tag.lot_id]).catch(() => ({ rows: [] }));
  const devices = await pool.query(`SELECT COUNT(DISTINCT client_hash)::int AS n FROM seed_tag_scans WHERE seed_tag_id = $1 AND scanned_at > now() - interval '30 days' AND client_hash <> $2`, [tag.id, hash]);

  let verdict: Verdict;
  if (tag.status === 'void') verdict = 'void';
  else if (recall.rows[0]) verdict = 'recalled';
  else if (info.status === 'on_hold') verdict = 'on_hold';
  else if (info.status === 'failed') verdict = 'failed';
  else if (info.status === 'expired') verdict = 'expired';
  else if (info.status === 'untested') verdict = 'unverified';
  else if (devices.rows[0].n + 1 >= SUSPECT_DEVICES) verdict = 'caution';
  else verdict = 'genuine';

  await pool.query(
    `UPDATE seed_tags SET scan_count = scan_count + 1, first_scanned_at = COALESCE(first_scanned_at, now()), last_scanned_at = now() WHERE id = $1`,
    [tag.id],
  );
  await pool.query(`INSERT INTO seed_tag_scans (tag_code, seed_tag_id, result, client_hash) VALUES ($1, $2, $3, $4)`, [code, tag.id, verdict, hash]);

  const showTest = verdict !== 'void' && verdict !== 'recalled';
  return {
    verdict,
    message: MESSAGES[verdict],
    tagCode: code,
    product: {
      company: tag.company,
      crop: tag.crop,
      variety: tag.variety,
      seedClass: tag.stage,
      lotCode: tag.lot_code,
      packSizeKg: num(tag.pack_size_kg),
      productionDate: tag.production_date,
      ...(showTest && info.tested_on ? { germinationPct: info.germination_pct, testedOn: info.tested_on, validUntil: info.valid_until } : {}),
    },
    timesChecked: tag.scan_count + 1,
  };
}
