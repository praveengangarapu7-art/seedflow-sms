import { Router } from 'express';
import rateLimit from 'express-rate-limit';
import { env } from '../../config/env';
import { asyncHandler as h } from '../../middleware/asyncHandler';
import { requireAuth, requirePermission as can, requireStaff } from '../../middleware/requireAuth';
import { body, ok, str } from '../shared/http';
import * as channel from './farmerChannel.service';
import * as msg from './messaging.service';
import * as portal from './portal.service';
import * as tags from './tags.service';

const limiter = (limit: number, windowMin: number, message: string) =>
  rateLimit({ windowMs: windowMin * 60 * 1000, limit: env.nodeEnv === 'test' ? 10_000 : limit, standardHeaders: true, legacyHeaders: false, message: { success: false, message } });

// ---------------------------------------------------------------- public (no login)
export const publicRouter = Router();
publicRouter.get('/verify/:code', limiter(60, 15, 'Too many checks — please try again in a few minutes.'), h(async (req, res) => ok(res, await tags.verifyPublic(req.params.code, { ip: req.ip, ua: req.header('user-agent') }))));
publicRouter.post('/complaints', limiter(10, 60, 'Too many complaints from this connection — please try again later or call us.'), h(async (req, res) => ok(res, await channel.submitPublicComplaint(body(req)), 'Complaint received', 201)));
publicRouter.get('/complaints/:code', limiter(30, 15, 'Too many requests — please try again later.'), h(async (req, res) => {
  const r = await channel.trackComplaint(req.params.code, str(req.query.phone));
  if (!r) return void res.status(404).json({ success: false, message: 'No complaint matches that code and mobile number' });
  ok(res, r);
}));
publicRouter.get('/complaint-types', (_req, res) => ok(res, channel.COMPLAINT_TYPES));

// ---------------------------------------------------------------- portals (growers and dealers see only their own records)
export const portalRouter = Router();
portalRouter.use(requireAuth);
portalRouter.get('/grower', can('portal_grower'), h(async (req, res) => ok(res, await portal.growerHome(req.user!))));
portalRouter.get('/dealer', can('portal_dealer'), h(async (req, res) => ok(res, await portal.dealerHome(req.user!))));
portalRouter.get('/dealer/dispatches/:id', can('portal_dealer'), h(async (req, res) => ok(res, await portal.dealerDispatch(req.user!, req.params.id))));
portalRouter.post('/dealer/dispatches/:id/confirm-receipt', can('portal_dealer'), h(async (req, res) => ok(res, await portal.dealerConfirmReceipt(req.user!, req.params.id, body(req)), 'Receipt confirmed')));
portalRouter.get('/dealer/lots/:lotId', can('portal_dealer'), h(async (req, res) => ok(res, await portal.dealerLotCheck(req.user!, req.params.lotId))));
portalRouter.post('/dealer/indents', can('portal_dealer'), h(async (req, res) => ok(res, await portal.raiseIndent(req.user!, body(req)), 'Request sent', 201)));
portalRouter.post('/dealer/indents/:id/cancel', can('portal_dealer'), h(async (req, res) => ok(res, await portal.cancelIndent(req.user!, req.params.id), 'Request cancelled')));
portalRouter.post('/dealer/complaints', can('portal_dealer'), h(async (req, res) => ok(res, await portal.dealerComplaint(req.user!, body(req)), 'Complaint logged with the quality team', 201)));

// ---------------------------------------------------------------- staff
export const reachRouter = Router();
reachRouter.use(requireAuth, requireStaff);

// pack tags
reachRouter.get('/tags', can('generate_packages', 'prepare_outbound_dispatch', 'manage_recalls', 'manage_farmer_complaints'), h(async (req, res) => ok(res, await tags.listTags({ lotId: str(req.query.lotId), status: str(req.query.status), limit: req.query.limit ? Number(req.query.limit) : undefined }))));
reachRouter.get('/tags/lots', can('generate_packages', 'prepare_outbound_dispatch', 'manage_recalls', 'manage_farmer_complaints'), h(async (_req, res) => ok(res, await tags.lotTagSummary())));
reachRouter.get('/tags/activity', can('manage_recalls', 'manage_farmer_complaints', 'generate_packages', 'prepare_outbound_dispatch'), h(async (_req, res) => ok(res, await tags.scanActivity())));
reachRouter.post('/tags', can('generate_packages', 'prepare_outbound_dispatch'), h(async (req, res) => ok(res, await tags.generateTags(body(req), req.user!), 'Tags created', 201)));
reachRouter.post('/tags/:code/void', can('generate_packages', 'manage_recalls'), h(async (req, res) => ok(res, await tags.voidTag(req.params.code, body(req), req.user!), 'Tag cancelled')));

// dealer requests
reachRouter.get('/indents', can('prepare_outbound_dispatch', 'approve_outbound_dispatch'), h(async (req, res) => ok(res, await portal.listIndents({ status: str(req.query.status) }))));
reachRouter.post('/indents/:id/decide', can('approve_outbound_dispatch'), h(async (req, res) => ok(res, await portal.decideIndent(req.params.id, body(req), req.user!), 'Decision recorded')));
reachRouter.post('/indents/:id/fulfilled', can('prepare_outbound_dispatch', 'approve_outbound_dispatch'), h(async (req, res) => ok(res, await portal.markIndentFulfilled(req.params.id, body(req), req.user!), 'Marked fulfilled')));

// message outbox
reachRouter.get('/messages', can('manage_notifications', 'manage_farmer_complaints', 'manage_recalls'), h(async (req, res) => ok(res, await msg.listMessages({ status: str(req.query.status), partyId: str(req.query.partyId) }))));
reachRouter.get('/messages/summary', can('manage_notifications', 'manage_farmer_complaints', 'manage_recalls'), h(async (_req, res) => ok(res, await msg.outboxSummary())));
reachRouter.post('/messages/flush', can('manage_notifications'), h(async (_req, res) => ok(res, await msg.flushOutbox(), 'Outbox processed')));
reachRouter.post('/messages/send', can('manage_notifications'), h(async (req, res) => ok(res, await msg.sendCustom(body(req), req.user!), 'Message queued', 201)));
reachRouter.post('/messages/:id/retry', can('manage_notifications'), h(async (req, res) => ok(res, await msg.retryMessage(req.params.id, req.user!), 'Queued again')));
reachRouter.post('/messages/:id/cancel', can('manage_notifications'), h(async (req, res) => ok(res, await msg.cancelMessage(req.params.id, req.user!), 'Cancelled')));
