import { pool } from '../../db/pool';
import { ValidationError } from '../../errors';
import type { AuthenticatedUser } from '../../middleware/requireAuth';
import { createComplaint } from '../quality/complaints.service';
import { withTransaction } from '../../db/transaction';
import { optionalText, requireEnum, requireText } from '../shared/validate';
import { normalisePhone, queueMessageTx } from './messaging.service';
import { normaliseTagCode } from './tags.service';

/** The "user" behind a complaint a farmer files themselves. */
const FARMER_CHANNEL: AuthenticatedUser = { id: '00000000-0000-0000-0000-000000000000', email: 'farmer-channel', role: 'Inspector', organizationId: null, jobRole: null };

export const COMPLAINT_TYPES = ['germination', 'purity', 'disease', 'packaging', 'suspected_fake', 'other'] as const;
const TYPE_LABEL: Record<(typeof COMPLAINT_TYPES)[number], string> = {
  germination: 'Poor germination / emergence',
  purity: 'Mixed or impure seed',
  disease: 'Disease or pest in the crop from this seed',
  packaging: 'Damaged or tampered packing',
  suspected_fake: 'Suspected fake seed',
  other: 'Other problem',
};
const CLUSTER_WINDOW_DAYS = 30;
const CLUSTER_THRESHOLD = 3;

/**
 * A complaint from a farmer with no login. A tag code ties it to a lot. Quality
 * problems are filed as "major" so they raise a non-conformance; when the third
 * germination complaint about one lot arrives inside 30 days it is raised as
 * "critical", which places the lot on hold before anyone has met about it.
 */
export async function submitPublicComplaint(input: Record<string, unknown>) {
  const name = requireText(input.name, 'name', 150);
  const phone = normalisePhone(typeof input.phone === 'string' ? input.phone : null);
  if (!phone) throw new ValidationError('Enter a valid 10-digit mobile number');
  const type = requireEnum(input.complaintType, COMPLAINT_TYPES, 'complaintType');
  const description = requireText(input.description, 'description', 2000);
  const village = optionalText(input.village, 'village', 100);
  const rawTag = optionalText(input.tagCode, 'tagCode', 30);

  let lotId: string | null = null;
  let tagCode: string | null = null;
  let tagNote = '';
  if (rawTag) {
    tagCode = normaliseTagCode(rawTag);
    const t = await pool.query('SELECT seed_lot_id FROM seed_tags WHERE tag_code = $1', [tagCode]);
    if (t.rows[0]) lotId = t.rows[0].seed_lot_id;
    else tagNote = `\n\nNOTE: the tag code ${tagCode} given by the farmer does not exist in our records — possible counterfeit pack.`;
  }

  let severity: 'minor' | 'major' | 'critical' = ['packaging', 'other'].includes(type) ? 'minor' : 'major';
  if (tagNote) severity = 'major';
  let cluster = 0;
  if (lotId && type === 'germination') {
    const c = await pool.query(
      `SELECT COUNT(*)::int AS n FROM quality_complaints WHERE seed_lot_id = $1 AND complaint_type = 'germination' AND created_at > now() - ($2 || ' days')::interval`,
      [lotId, String(CLUSTER_WINDOW_DAYS)],
    );
    cluster = c.rows[0].n + 1;
    if (cluster >= CLUSTER_THRESHOLD) severity = 'critical';
  }

  const created = await createComplaint(
    {
      source: 'farmer',
      channel: 'public_form',
      complainantName: name,
      complainantContact: phone,
      complainantVillage: village,
      complaintType: type,
      tagCode,
      seedLotId: lotId,
      title: `${TYPE_LABEL[type]}${village ? ` — ${village}` : ''}`,
      description: `${description}${tagNote}${cluster >= CLUSTER_THRESHOLD ? `\n\nAUTO-ESCALATED: ${cluster} germination complaints about this lot in ${CLUSTER_WINDOW_DAYS} days.` : ''}`,
      severity,
    },
    FARMER_CHANNEL,
  );
  await withTransaction((client) => queueMessageTx(client, { phone, template: 'complaint_received', vars: { code: created.complaint.complaint_code }, relatedType: 'quality_complaint', relatedId: created.complaint.id, createdBy: FARMER_CHANNEL.email }));
  return { code: created.complaint.complaint_code as string, escalated: severity === 'critical', message: 'Your complaint has been received. Keep this code to follow it up.' };
}

/** Status lookup: the code alone is not enough, the mobile number given when filing must match. */
export async function trackComplaint(code: string, phoneRaw: string | undefined) {
  const phone = normalisePhone(phoneRaw ?? null);
  const r = await pool.query(
    `SELECT complaint_code, status, received_date, resolved_at, resolution, complainant_contact FROM quality_complaints WHERE complaint_code = $1 AND channel = 'public_form'`,
    [code.toUpperCase().trim()],
  );
  const c = r.rows[0];
  // Same answer for "no such code" and "wrong number" so codes cannot be probed.
  if (!c || !phone || c.complainant_contact !== phone) return null;
  const label = { received: 'Received — waiting to be looked at', investigating: 'Being investigated by our quality team', resolved: 'Resolved', closed: 'Closed' }[c.status as string] ?? c.status;
  return { code: c.complaint_code, status: c.status, statusLabel: label, receivedOn: c.received_date, resolvedAt: c.resolved_at, outcome: ['resolved', 'closed'].includes(c.status) ? c.resolution : null };
}
