import type { PoolClient } from 'pg';
import { env } from '../../config/env';
import { pool } from '../../db/pool';
import { withTransaction } from '../../db/transaction';
import { ConflictError, NotFoundError, ValidationError } from '../../errors';
import type { AuthenticatedUser } from '../../middleware/requireAuth';
import { insertAuditLog } from '../auditLogs/auditLogs.service';
import { requireEnum, requireText } from '../shared/validate';

/**
 * Outbound SMS / WhatsApp. Business code only ever queues a message in
 * msg_outbox (inside its own transaction, so a message exists only if the
 * event it announces really happened). A worker — or the "Send now" button —
 * delivers queued messages through the configured provider:
 *   MESSAGING_PROVIDER=log      record as sent without calling anyone (default)
 *   MESSAGING_PROVIDER=webhook  POST {to, channel, body, language} to MESSAGING_WEBHOOK_URL
 */
type Lang = 'en' | 'hi' | 'te';

const TEMPLATES: Record<string, Record<Lang, string>> = {
  dispatch_shipped: {
    en: 'SeedSphere: dispatch {number} ({lots}) left our godown on vehicle {vehicle}. Please check the seed tags on arrival.',
    hi: 'SeedSphere: डिस्पैच {number} ({lots}) वाहन {vehicle} से रवाना हुआ। पहुँचने पर बीज टैग जाँच लें।',
    te: 'SeedSphere: డిస్పాచ్ {number} ({lots}) వాహనం {vehicle} లో బయలుదేరింది. చేరగానే విత్తన ట్యాగ్‌లను పరిశీలించండి.',
  },
  settlement_paid: {
    en: 'SeedSphere: payment {number} of Rs {amount} has been released to your bank account (ref {reference}).',
    hi: 'SeedSphere: भुगतान {number} Rs {amount} आपके बैंक खाते में भेज दिया गया है (संदर्भ {reference})।',
    te: 'SeedSphere: చెల్లింపు {number} Rs {amount} మీ బ్యాంకు ఖాతాకు పంపబడింది (రిఫ్ {reference}).',
  },
  complaint_received: {
    en: 'SeedSphere: we have received your complaint {code}. Our quality team will contact you. Track it with this code and your mobile number.',
    hi: 'SeedSphere: आपकी शिकायत {code} मिल गई है। हमारी गुणवत्ता टीम आपसे संपर्क करेगी।',
    te: 'SeedSphere: మీ ఫిర్యాదు {code} అందింది. మా నాణ్యత బృందం మిమ్మల్ని సంప్రదిస్తుంది.',
  },
  complaint_resolved: {
    en: 'SeedSphere: your complaint {code} has been resolved. Thank you for telling us.',
    hi: 'SeedSphere: आपकी शिकायत {code} का समाधान हो गया है।',
    te: 'SeedSphere: మీ ఫిర్యాదు {code} పరిష్కరించబడింది.',
  },
  indent_decision: {
    en: 'SeedSphere: your seed request {number} was {decision}. {note}',
    hi: 'SeedSphere: आपका बीज अनुरोध {number} {decision}। {note}',
    te: 'SeedSphere: మీ విత్తన అభ్యర్థన {number} {decision}. {note}',
  },
  recall_notice: {
    en: 'SeedSphere SAFETY NOTICE: stop selling lot {lot} ({crop} {variety}). {action} Contact us on receipt.',
    hi: 'SeedSphere सूचना: लॉट {lot} ({crop} {variety}) की बिक्री रोकें। {action}',
    te: 'SeedSphere నోటీసు: లాట్ {lot} ({crop} {variety}) అమ్మకం ఆపండి. {action}',
  },
  custom: { en: '{text}', hi: '{text}', te: '{text}' },
};

export const TEMPLATE_NAMES = Object.keys(TEMPLATES);

export function renderTemplate(template: string, language: string, vars: Record<string, unknown>): string {
  const t = TEMPLATES[template];
  if (!t) throw new ValidationError(`Unknown message template ${template}`);
  const lang = (['en', 'hi', 'te'] as const).includes(language as Lang) ? (language as Lang) : 'en';
  return t[lang].replace(/\{(\w+)\}/g, (_m, k: string) => (vars[k] === undefined || vars[k] === null ? '' : String(vars[k]))).replace(/\s+/g, ' ').trim();
}

/** 10-digit Indian mobile numbers become +91…; anything else must already be E.164. */
export function normalisePhone(raw: string | null | undefined): string | null {
  if (!raw) return null;
  const digits = raw.replace(/[\s()-]/g, '');
  if (/^[6-9]\d{9}$/.test(digits)) return `+91${digits}`;
  if (/^\+\d{10,14}$/.test(digits)) return digits;
  if (/^91[6-9]\d{9}$/.test(digits)) return `+${digits}`;
  return null;
}

export interface QueueInput {
  partyId?: string | null;
  phone?: string | null;
  language?: string | null;
  channel?: 'sms' | 'whatsapp';
  template: string;
  vars: Record<string, unknown>;
  relatedType?: string;
  relatedId?: string;
  createdBy: string;
}

/** Queues a message inside the caller's transaction. Returns null when the recipient has no usable phone. */
export async function queueMessageTx(client: PoolClient, input: QueueInput) {
  let phone = input.phone ?? null;
  let language = input.language ?? null;
  if (input.partyId) {
    const p = await client.query<{ phone: string | null; preferred_language: string }>('SELECT phone, preferred_language FROM parties WHERE id = $1', [input.partyId]);
    phone = phone ?? p.rows[0]?.phone ?? null;
    language = language ?? p.rows[0]?.preferred_language ?? null;
  }
  const to = normalisePhone(phone);
  if (!to) return null;
  const body = renderTemplate(input.template, language ?? 'en', input.vars);
  const r = await client.query(
    `INSERT INTO msg_outbox (channel, to_phone, party_id, template, language, body, related_type, related_id, created_by)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9) RETURNING *`,
    [input.channel ?? 'sms', to, input.partyId ?? null, input.template, language ?? 'en', body, input.relatedType ?? null, input.relatedId ?? null, input.createdBy],
  );
  return r.rows[0];
}

async function deliver(row: { id: string; channel: string; to_phone: string; body: string; language: string }): Promise<{ ok: true; ref: string } | { ok: false; error: string }> {
  if (env.messagingProvider === 'webhook') {
    if (!env.messagingWebhookUrl) return { ok: false, error: 'MESSAGING_WEBHOOK_URL is not set' };
    try {
      const res = await fetch(env.messagingWebhookUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...(env.messagingWebhookToken ? { Authorization: `Bearer ${env.messagingWebhookToken}` } : {}) },
        body: JSON.stringify({ id: row.id, to: row.to_phone, channel: row.channel, body: row.body, language: row.language }),
        signal: AbortSignal.timeout(8000),
      });
      if (!res.ok) return { ok: false, error: `Provider answered ${res.status}` };
      const j = (await res.json().catch(() => ({}))) as { id?: string };
      return { ok: true, ref: j.id ?? `webhook:${row.id}` };
    } catch (e) {
      return { ok: false, error: e instanceof Error ? e.message : 'Provider unreachable' };
    }
  }
  return { ok: true, ref: `log:${row.id}` };
}

const MAX_ATTEMPTS = 3;

/** Sends queued messages (and failed ones with attempts left). Safe to run from several places at once. */
export async function flushOutbox(limit = 50) {
  const claimed = await pool.query(
    `UPDATE msg_outbox SET attempts = attempts + 1
      WHERE id IN (SELECT id FROM msg_outbox WHERE status = 'queued' OR (status = 'failed' AND attempts < $2) ORDER BY created_at LIMIT $1 FOR UPDATE SKIP LOCKED)
      RETURNING id, channel, to_phone, body, language, attempts`,
    [limit, MAX_ATTEMPTS],
  );
  let sent = 0;
  let failed = 0;
  for (const row of claimed.rows) {
    const r = await deliver(row);
    if (r.ok) {
      await pool.query(`UPDATE msg_outbox SET status = 'sent', sent_at = now(), provider_ref = $2, last_error = NULL WHERE id = $1`, [row.id, r.ref]);
      sent += 1;
    } else {
      await pool.query(`UPDATE msg_outbox SET status = 'failed', last_error = $2 WHERE id = $1`, [row.id, r.error]);
      failed += 1;
    }
  }
  return { attempted: claimed.rows.length, sent, failed };
}

export function startOutboxWorker(intervalMs = 30_000) {
  const timer = setInterval(() => {
    flushOutbox().catch((e) => console.error('[outbox] flush failed', e));
  }, intervalMs);
  timer.unref();
  return timer;
}

export async function listMessages(filters: { status?: string; partyId?: string; limit?: number }) {
  const where: string[] = [];
  const values: unknown[] = [];
  if (filters.status) {
    values.push(filters.status);
    where.push(`m.status = $${values.length}`);
  }
  if (filters.partyId) {
    values.push(filters.partyId);
    where.push(`m.party_id = $${values.length}`);
  }
  values.push(Math.min(filters.limit ?? 200, 500));
  const r = await pool.query(
    `SELECT m.*, p.name AS party_name, p.party_code FROM msg_outbox m LEFT JOIN parties p ON p.id = m.party_id
      ${where.length ? `WHERE ${where.join(' AND ')}` : ''} ORDER BY m.created_at DESC LIMIT $${values.length}`,
    values,
  );
  return r.rows;
}

export async function outboxSummary() {
  const r = await pool.query(`SELECT status, COUNT(*)::int AS n FROM msg_outbox GROUP BY status`);
  const by = Object.fromEntries(r.rows.map((x) => [x.status, x.n]));
  return { queued: by.queued ?? 0, sent: by.sent ?? 0, failed: by.failed ?? 0, cancelled: by.cancelled ?? 0, provider: env.messagingProvider, templates: TEMPLATE_NAMES };
}

export async function cancelMessage(id: string, user: AuthenticatedUser) {
  return withTransaction(async (client) => {
    const r = await client.query(`UPDATE msg_outbox SET status = 'cancelled' WHERE id = $1 AND status IN ('queued', 'failed') RETURNING *`, [id]);
    if (!r.rows[0]) throw new ConflictError('Only a message that has not been sent can be cancelled');
    await insertAuditLog(client, { entityType: 'message', entityId: id, action: 'CANCEL', performedBy: user.email });
    return r.rows[0];
  });
}

export async function retryMessage(id: string, user: AuthenticatedUser) {
  return withTransaction(async (client) => {
    const r = await client.query(`UPDATE msg_outbox SET status = 'queued', attempts = 0, last_error = NULL WHERE id = $1 AND status = 'failed' RETURNING *`, [id]);
    if (!r.rows[0]) throw new ConflictError('Only a failed message can be retried');
    await insertAuditLog(client, { entityType: 'message', entityId: id, action: 'RETRY', performedBy: user.email });
    return r.rows[0];
  });
}

/** A free-text message to one party (for the rare case no template fits). */
export async function sendCustom(input: Record<string, unknown>, user: AuthenticatedUser) {
  const partyId = requireText(input.partyId, 'partyId', 64);
  const text = requireText(input.text, 'text', 400);
  const channel = input.channel === undefined ? 'sms' : requireEnum(input.channel, ['sms', 'whatsapp'] as const, 'channel');
  return withTransaction(async (client) => {
    const exists = await client.query('SELECT 1 FROM parties WHERE id = $1', [partyId]);
    if (!exists.rows[0]) throw new NotFoundError('Party not found');
    const m = await queueMessageTx(client, { partyId, channel, template: 'custom', vars: { text }, createdBy: user.email });
    if (!m) throw new ConflictError('That party has no valid mobile number on record');
    await insertAuditLog(client, { entityType: 'message', entityId: m.id, action: 'QUEUE', performedBy: user.email });
    return m;
  });
}
