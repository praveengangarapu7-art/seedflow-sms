import { pool } from '../../db/pool';
import { withTransaction } from '../../db/transaction';
import { ConflictError, ForbiddenError, NotFoundError, ValidationError } from '../../errors';
import type { AuthenticatedUser } from '../../middleware/requireAuth';
import { insertAuditLog } from '../auditLogs/auditLogs.service';
import { createComplaint } from '../quality/complaints.service';
import { growerAccount } from '../procurement/growers.service';
import { confirmDelivery, getDispatch, listDispatches } from '../warehouse/dispatch.service';
import { lotSaleInfo } from '../warehouse/stock.service';
import { nextCode, optionalDate, optionalText, optionalUuid, requireDate, requireNumber, requireText } from '../shared/validate';
import { queueMessageTx } from './messaging.service';

async function partyFor(user: AuthenticatedUser, types: string[]) {
  const r = await pool.query('SELECT * FROM parties WHERE user_id = $1', [user.id]);
  const p = r.rows[0];
  if (!p || !types.includes(p.party_type)) throw new ForbiddenError('Your login is not linked to a company record yet — ask the company to link it');
  return p;
}

const strip = (p: Record<string, unknown>) => ({
  id: p.id, party_code: p.party_code, party_type: p.party_type, name: p.name, contact_person: p.contact_person, phone: p.phone, email: p.email,
  village: p.village, district: p.district, state: p.state, status: p.status, licence_number: p.licence_number, licence_valid_until: p.licence_valid_until, preferred_language: p.preferred_language,
});

// ---------------------------------------------------------------- grower

export async function growerHome(user: AuthenticatedUser) {
  const p = await partyFor(user, ['contract_grower']);
  const acct = await growerAccount(p.id);
  const next = await pool.query(
    `SELECT agreement_number, crop, variety, procurement_window_start, procurement_window_end FROM grw_agreements WHERE grower_id = $1 AND status = 'active' ORDER BY procurement_window_end LIMIT 5`,
    [p.id],
  );
  return {
    party: strip(p),
    balance: acct.balance,
    avgDaysToPayment: acct.avgDaysToPayment,
    agreements: acct.agreements.map((a) => ({
      id: a.id, agreement_number: a.agreement_number, status: a.status, season: a.season, season_year: a.season_year, crop: a.crop, variety: a.variety, seed_class: a.seed_class,
      area_acres: a.area_acres, buyback_price_per_kg: a.buyback_price_per_kg, expected_yield_kg: a.expected_yield_kg, delivered_kg: a.delivered_kg, balance: a.balance,
      procurement_window_start: a.procurement_window_start, procurement_window_end: a.procurement_window_end,
    })),
    deliveries: acct.deliveries,
    settlements: acct.settlements.map((s: Record<string, unknown>) => ({ id: s.id, settlement_number: s.settlement_number, settlement_type: s.settlement_type, status: s.status, net_payable: s.net_payable, paid_at: s.paid_at, payment_reference: s.payment_reference })),
    ledger: acct.ledger,
    windows: next.rows,
    messages: (await pool.query(`SELECT id, channel, body, status, created_at FROM msg_outbox WHERE party_id = $1 ORDER BY created_at DESC LIMIT 20`, [p.id])).rows,
  };
}

// ---------------------------------------------------------------- dealer

export async function dealerHome(user: AuthenticatedUser) {
  const p = await partyFor(user, ['dealer', 'distributor']);
  const [dispatches, indents, returns, complaints, messages] = await Promise.all([
    listDispatches({ dealerId: p.id }),
    pool.query('SELECT * FROM dealer_indents WHERE dealer_id = $1 ORDER BY created_at DESC LIMIT 100', [p.id]),
    pool.query(
      `SELECT r.return_number, r.status, r.quantity_kg, r.reason, r.created_at, l.lot_code FROM wh_returns r JOIN seed_lots l ON l.id = r.seed_lot_id WHERE r.dealer_id = $1 ORDER BY r.created_at DESC LIMIT 50`,
      [p.id],
    ),
    pool.query(`SELECT complaint_code, title, status, severity, received_date FROM quality_complaints WHERE channel = 'dealer_portal' AND created_by = $1 ORDER BY created_at DESC LIMIT 50`, [user.email]),
    pool.query(`SELECT id, channel, template, body, status, created_at FROM msg_outbox WHERE party_id = $1 ORDER BY created_at DESC LIMIT 30`, [p.id]),
  ]);
  const licenceDays = p.licence_valid_until ? Math.round((Date.parse(p.licence_valid_until) - Date.now()) / 86400000) : null;
  return {
    party: strip(p),
    licenceDaysLeft: licenceDays,
    dispatches: dispatches.map((d) => ({ id: d.id, dispatch_number: d.dispatch_number, status: d.status, requested_date: d.requested_date, total_kg: d.total_kg, lots: d.lots, vehicle_number: d.vehicle_number, dispatched_at: d.dispatched_at, delivered_at: d.delivered_at })),
    indents: indents.rows,
    returns: returns.rows,
    complaints: complaints.rows,
    notices: messages.rows,
  };
}

export async function dealerDispatch(user: AuthenticatedUser, id: string) {
  const p = await partyFor(user, ['dealer', 'distributor']);
  const d = await getDispatch(id);
  if (d.dealer_id !== p.id) throw new NotFoundError('Dispatch not found');
  const tags = await pool.query(`SELECT COUNT(*)::int AS n FROM seed_tags WHERE dispatch_id = $1`, [id]);
  return {
    id: d.id, dispatch_number: d.dispatch_number, status: d.status, requested_date: d.requested_date, vehicle_number: d.vehicle_number, lr_number: d.lr_number, dispatched_at: d.dispatched_at,
    delivered_at: d.delivered_at, received_by_name: d.received_by_name, transporter_name: d.transporter_name, tag_count: tags.rows[0].n,
    lines: d.lines.map((l: Record<string, any>) => ({ lot_code: l.lot_code, crop: l.crop, variety: l.variety, stage: l.stage, quantity_kg: l.quantity_kg, bags: l.bags, is_treated: l.is_treated, germination_pct: l.sale?.germination_pct ?? null, valid_until: l.sale?.valid_until ?? null })), // eslint-disable-line @typescript-eslint/no-explicit-any
  };
}

export async function dealerConfirmReceipt(user: AuthenticatedUser, id: string, input: Record<string, unknown>) {
  const p = await partyFor(user, ['dealer', 'distributor']);
  const d = await pool.query('SELECT dealer_id FROM wh_dispatches WHERE id = $1', [id]);
  if (!d.rows[0] || d.rows[0].dealer_id !== p.id) throw new NotFoundError('Dispatch not found');
  const by = input.receivedByName ? requireText(input.receivedByName, 'receivedByName', 150) : p.contact_person ?? p.name;
  return confirmDelivery(id, { receivedByName: by }, user);
}

export async function raiseIndent(user: AuthenticatedUser, input: Record<string, unknown>) {
  const p = await partyFor(user, ['dealer', 'distributor']);
  if (p.status !== 'active') throw new ConflictError('Your account is not active, so requests cannot be placed');
  const crop = requireText(input.crop, 'crop', 50);
  const variety = optionalText(input.variety, 'variety', 100);
  const kg = requireNumber(input.quantityKg, 'quantityKg');
  if (kg <= 0 || kg > 1_000_000) throw new ValidationError('quantityKg must be above 0');
  const needed = requireDate(input.neededBy, 'neededBy');
  if (needed < new Date().toISOString().slice(0, 10)) throw new ValidationError('neededBy cannot be in the past');
  return withTransaction(async (client) => {
    const code = await nextCode(client, 'IND', 5, true);
    const r = await client.query(
      `INSERT INTO dealer_indents (indent_number, dealer_id, crop, variety, quantity_kg, needed_by, notes, created_by) VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *`,
      [code, p.id, crop, variety, kg, needed, optionalText(input.notes, 'notes', 1000), user.email],
    );
    await insertAuditLog(client, { entityType: 'dealer_indent', entityId: r.rows[0].id, action: 'CREATE', performedBy: user.email, afterState: r.rows[0] });
    return r.rows[0];
  });
}

export async function cancelIndent(user: AuthenticatedUser, id: string) {
  const p = await partyFor(user, ['dealer', 'distributor']);
  return withTransaction(async (client) => {
    const r = await client.query(`UPDATE dealer_indents SET status = 'cancelled' WHERE id = $1 AND dealer_id = $2 AND status = 'submitted' RETURNING *`, [id, p.id]);
    if (!r.rows[0]) throw new ConflictError('Only a request that is still waiting can be cancelled');
    await insertAuditLog(client, { entityType: 'dealer_indent', entityId: id, action: 'CANCEL', performedBy: user.email });
    return r.rows[0];
  });
}

export async function dealerComplaint(user: AuthenticatedUser, input: Record<string, unknown>) {
  const p = await partyFor(user, ['dealer', 'distributor']);
  const lotId = optionalUuid(input.seedLotId, 'seedLotId');
  if (lotId) {
    // a dealer can only complain about a lot that was actually supplied to them
    const sent = await pool.query(
      `SELECT 1 FROM wh_dispatch_lines dl JOIN wh_dispatches d ON d.id = dl.dispatch_id WHERE d.dealer_id = $1 AND dl.seed_lot_id = $2 AND d.status IN ('dispatched', 'delivered') LIMIT 1`,
      [p.id, lotId],
    );
    if (!sent.rows[0]) throw new ConflictError('That lot was not supplied to you');
  }
  const severity = ['minor', 'major', 'critical'].includes(String(input.severity)) ? String(input.severity) : 'major';
  const created = await createComplaint(
    {
      source: p.party_type === 'distributor' ? 'distributor' : 'dealer',
      channel: 'dealer_portal',
      complainantName: p.name,
      complainantContact: p.phone,
      seedLotId: lotId,
      title: requireText(input.title, 'title', 200),
      description: requireText(input.description, 'description', 3000),
      severity: severity === 'critical' ? 'major' : severity, // only the quality team escalates to a lot hold
    },
    user,
  );
  return created.complaint;
}

export async function dealerLotCheck(user: AuthenticatedUser, lotId: string) {
  const p = await partyFor(user, ['dealer', 'distributor']);
  const sent = await pool.query(
    `SELECT l.lot_code, l.crop, l.variety FROM wh_dispatch_lines dl JOIN wh_dispatches d ON d.id = dl.dispatch_id JOIN seed_lots l ON l.id = dl.seed_lot_id
      WHERE d.dealer_id = $1 AND dl.seed_lot_id = $2 AND d.status IN ('dispatched', 'delivered') LIMIT 1`,
    [p.id, lotId],
  );
  if (!sent.rows[0]) throw new NotFoundError('That lot was not supplied to you');
  const s = (await lotSaleInfo(pool, [lotId])).get(lotId)!;
  return { ...sent.rows[0], status: s.status, germination_pct: s.germination_pct, valid_until: s.valid_until, hold_reason: s.status === 'on_hold' ? s.hold_reason : null };
}

// ------------------------------------------------------- staff (indents)

export async function listIndents(filters: { status?: string }) {
  const values: unknown[] = [];
  let where = '';
  if (filters.status) {
    values.push(filters.status);
    where = 'WHERE i.status = $1';
  }
  const r = await pool.query(
    `SELECT i.*, p.name AS dealer_name, p.party_code AS dealer_code, p.district AS dealer_district, d.dispatch_number
       FROM dealer_indents i JOIN parties p ON p.id = i.dealer_id LEFT JOIN wh_dispatches d ON d.id = i.dispatch_id ${where} ORDER BY (i.status = 'submitted') DESC, i.needed_by LIMIT 500`,
    values,
  );
  return r.rows;
}

export async function decideIndent(id: string, input: Record<string, unknown>, user: AuthenticatedUser) {
  const decision = input.decision === 'accept' ? 'accepted' : input.decision === 'reject' ? 'rejected' : null;
  if (!decision) throw new ValidationError("decision must be 'accept' or 'reject'");
  const note = decision === 'rejected' ? requireText(input.note, 'note', 500) : optionalText(input.note, 'note', 500);
  const dispatchId = optionalUuid(input.dispatchId, 'dispatchId');
  void optionalDate;
  return withTransaction(async (client) => {
    const r = await client.query(
      `UPDATE dealer_indents SET status = $2, decision_note = $3, decided_by = $4, decided_at = now(), dispatch_id = $5 WHERE id = $1 AND status = 'submitted' RETURNING *`,
      [id, decision, note, user.email, dispatchId],
    );
    if (!r.rows[0]) throw new ConflictError('That request has already been decided or cancelled');
    await queueMessageTx(client, { partyId: r.rows[0].dealer_id, template: 'indent_decision', vars: { number: r.rows[0].indent_number, decision, note: note ?? '' }, relatedType: 'dealer_indent', relatedId: id, createdBy: user.email });
    await insertAuditLog(client, { entityType: 'dealer_indent', entityId: id, action: decision.toUpperCase(), performedBy: user.email, metadata: { note } });
    return r.rows[0];
  });
}

export async function markIndentFulfilled(id: string, input: Record<string, unknown>, user: AuthenticatedUser) {
  const dispatchId = optionalUuid(input.dispatchId, 'dispatchId');
  return withTransaction(async (client) => {
    const r = await client.query(`UPDATE dealer_indents SET status = 'fulfilled', dispatch_id = COALESCE($2, dispatch_id) WHERE id = $1 AND status = 'accepted' RETURNING *`, [id, dispatchId]);
    if (!r.rows[0]) throw new ConflictError('Only an accepted request can be marked fulfilled');
    await insertAuditLog(client, { entityType: 'dealer_indent', entityId: id, action: 'FULFILLED', performedBy: user.email });
    return r.rows[0];
  });
}
