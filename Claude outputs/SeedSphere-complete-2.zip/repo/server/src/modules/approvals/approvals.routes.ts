import { Router } from 'express';
import { asyncHandler as h } from '../../middleware/asyncHandler';
import { requireAuth, requirePermission, requireStaff } from '../../middleware/requireAuth';
import { body, ok, str } from '../shared/http';
import * as s from './approvals.service';

export const approvalsRouter = Router();
approvalsRouter.use(requireAuth, requireStaff);

approvalsRouter.get('/inbox', h(async (req, res) => ok(res, await s.inbox(req.user!))));
approvalsRouter.get('/requests', h(async (req, res) => ok(res, await s.listRequests({ status: str(req.query.status), entityType: str(req.query.entityType), mine: req.query.mine === 'true' }, req.user!))));
approvalsRouter.get('/requests/:id', h(async (req, res) => ok(res, await s.getRequest(req.params.id))));
approvalsRouter.get('/entity/:entityType/:entityId', h(async (req, res) => ok(res, await s.getApprovalsForEntity(req.params.entityType, req.params.entityId))));
approvalsRouter.post('/requests/:id/decide', h(async (req, res) => {
  const r = await s.decide(req.params.id, body(req), req.user!);
  ok(res, r, r.status === 'approved' ? `${r.entity_code} approved` : r.status === 'rejected' ? `${r.entity_code} rejected` : 'Step approved — passed to the next approver');
}));
approvalsRouter.get('/rules', h(async (_req, res) => ok(res, await s.listRules())));
approvalsRouter.patch('/rules/:id', requirePermission('manage_approval_rules'), h(async (req, res) => ok(res, await s.updateRule(req.params.id, body(req), req.user!), 'Approval rule updated')));
