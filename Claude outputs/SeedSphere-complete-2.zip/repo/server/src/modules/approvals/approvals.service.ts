import { createHash } from 'node:crypto';
import type { PoolClient } from 'pg';
import { verifyPassword } from '../../auth/password';
import { permissionsFor } from '../../auth/permissions';
import { pool } from '../../db/pool';
import { withTransaction } from '../../db/transaction';
import { ConflictError, ForbiddenError, NotFoundError, ValidationError } from '../../errors';
import type { AuthenticatedUser } from '../../middleware/requireAuth';
import { userHasPermission } from '../../middleware/requireAuth';
import { insertAuditLog } from '../auditLogs/auditLogs.service';
import { optionalText, requireNumber, requireText } from '../shared/validate';

/**
 * One approval engine for every module. A business record is submitted with
 * an amount; the active rules for its type whose threshold the amount reaches
 * become ordered steps, each needing a permission. Rules that hold for every
 * step:
 *   - the requester never approves their own request (four eyes);
 *   - one person decides at most one step of a request;
 *   - only someone holding the step's permission can decide it.
 * When the last step is approved (or any step rejected) the owning module's
 * handler runs inside the same transaction, so the record's status and the
 * approval can never disagree.
 */
export interface ApprovalHandler {
  onApproved: (client: PoolClient, entityId: string, user: AuthenticatedUser) => Promise<void>;
  onRejected: (client: PoolClient, entityId: string, user: AuthenticatedUser, comment: string) => Promise<void>;
}

const handlers = new Map<string, ApprovalHandler>();

export function registerApprovalHandler(entityType: string, handler: ApprovalHandler): void {
  handlers.set(entityType, handler);
}

export interface ApprovalRequestRow {
  id: string;
  entity_type: string;
  entity_id: string;
  entity_code: string;
  title: string;
  amount: string | null;
  status: 'pending' | 'approved' | 'rejected' | 'withdrawn';
  requested_by: string;
  requested_at: string;
  decided_at: string | null;
}

export interface ApprovalStepRow {
  id: string;
  request_id: string;
  step_order: number;
  step_name: string;
  required_permission: string;
  status: 'waiting' | 'pending' | 'approved' | 'rejected' | 'cancelled';
  decided_by: string | null;
  decided_at: string | null;
  comment: string | null;
}

export interface SubmitParams {
  entityType: string;
  entityId: string;
  entityCode: string;
  title: string;
  amount?: number | null;
}

export async function submitForApprovalTx(
  client: PoolClient,
  params: SubmitParams,
  user: AuthenticatedUser,
): Promise<{ request: ApprovalRequestRow; steps: ApprovalStepRow[]; autoApproved: boolean }> {
  const handler = handlers.get(params.entityType);
  if (!handler) throw new Error(`No approval handler registered for ${params.entityType}`);

  const open = await client.query('SELECT id FROM approval_requests WHERE entity_type = $1 AND entity_id = $2 AND status = $3', [
    params.entityType,
    params.entityId,
    'pending',
  ]);
  if (open.rows[0]) throw new ConflictError(`${params.entityCode} is already waiting for approval`);

  const amount = params.amount ?? 0;
  const rules = await client.query<{ step_order: number; step_name: string; required_permission: string }>(
    `SELECT step_order, step_name, required_permission FROM approval_rules
      WHERE entity_type = $1 AND is_active AND min_amount <= $2 ORDER BY step_order`,
    [params.entityType, amount],
  );

  const inserted = await client.query<ApprovalRequestRow>(
    `INSERT INTO approval_requests (entity_type, entity_id, entity_code, title, amount, requested_by, status, decided_at)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *`,
    [
      params.entityType,
      params.entityId,
      params.entityCode,
      params.title,
      params.amount ?? null,
      user.email,
      rules.rows.length === 0 ? 'approved' : 'pending',
      rules.rows.length === 0 ? new Date().toISOString() : null,
    ],
  );
  const request = inserted.rows[0];

  const steps: ApprovalStepRow[] = [];
  for (const [i, rule] of rules.rows.entries()) {
    const s = await client.query<ApprovalStepRow>(
      `INSERT INTO approval_steps (request_id, step_order, step_name, required_permission, status)
       VALUES ($1, $2, $3, $4, $5) RETURNING *`,
      [request.id, rule.step_order, rule.step_name, rule.required_permission, i === 0 ? 'pending' : 'waiting'],
    );
    steps.push(s.rows[0]);
  }

  await insertAuditLog(client, {
    entityType: params.entityType,
    entityId: params.entityId,
    action: 'SUBMIT_FOR_APPROVAL',
    performedBy: user.email,
    metadata: { requestId: request.id, amount: params.amount ?? null, steps: steps.map((s) => s.step_name) },
  });

  // No rule applies (e.g. every rule disabled): the record is approved on
  // submission and the audit row above records that no one was asked.
  if (steps.length === 0) await handler.onApproved(client, params.entityId, user);
  return { request, steps, autoApproved: steps.length === 0 };
}

async function lockRequest(client: PoolClient, id: string): Promise<{ request: ApprovalRequestRow; steps: ApprovalStepRow[] }> {
  const r = await client.query<ApprovalRequestRow>('SELECT * FROM approval_requests WHERE id = $1 FOR UPDATE', [id]);
  if (!r.rows[0]) throw new NotFoundError('Approval request not found');
  const steps = await client.query<ApprovalStepRow>('SELECT * FROM approval_steps WHERE request_id = $1 ORDER BY step_order FOR UPDATE', [id]);
  return { request: r.rows[0], steps: steps.rows };
}

export async function decide(requestId: string, input: Record<string, unknown>, user: AuthenticatedUser) {
  const decision = input.decision;
  if (decision !== 'approve' && decision !== 'reject') throw new ValidationError('decision must be approve or reject');
  const comment = decision === 'reject' ? requireText(input.comment, 'comment (the reason for rejecting)', 2000) : optionalText(input.comment, 'comment', 2000);

  return withTransaction(async (client) => {
    const { request, steps } = await lockRequest(client, requestId);
    if (request.status !== 'pending') throw new ConflictError(`This request is already ${request.status}`);
    const step = steps.find((s) => s.status === 'pending');
    if (!step) throw new ConflictError('This request has no step waiting for a decision');
    if (request.requested_by === user.email) throw new ForbiddenError('You cannot decide on a request you submitted');
    if (!userHasPermission(user, step.required_permission)) {
      throw new ForbiddenError(`"${step.step_name}" needs the ${step.required_permission} permission`);
    }
    if (steps.some((s) => s.decided_by === user.email)) throw new ForbiddenError('You have already decided an earlier step of this request');

    const handler = handlers.get(request.entity_type);
    if (!handler) throw new Error(`No approval handler registered for ${request.entity_type}`);

    if (decision === 'approve') {
      const rule = (await client.query(`SELECT requires_signature, signature_meaning FROM approval_rules WHERE entity_type = $1 AND step_order = $2`, [request.entity_type, step.step_order])).rows[0];
      const signer = rule?.requires_signature ? await checkSignature(client, input.password, user.email) : null;
      await client.query(`UPDATE approval_steps SET status = 'approved', decided_by = $2, decided_at = now(), comment = $3 WHERE id = $1`, [step.id, user.email, comment]);
      if (signer) await recordSignature(client, request, step, signer, rule.signature_meaning ?? `I approve: ${step.step_name}`);
      const next = steps.find((s) => s.step_order > step.step_order && s.status === 'waiting');
      if (next) {
        await client.query(`UPDATE approval_steps SET status = 'pending' WHERE id = $1`, [next.id]);
      } else {
        await client.query(`UPDATE approval_requests SET status = 'approved', decided_at = now() WHERE id = $1`, [request.id]);
        await handler.onApproved(client, request.entity_id, user);
      }
    } else {
      await client.query(`UPDATE approval_steps SET status = 'rejected', decided_by = $2, decided_at = now(), comment = $3 WHERE id = $1`, [step.id, user.email, comment]);
      await client.query(`UPDATE approval_steps SET status = 'cancelled' WHERE request_id = $1 AND status = 'waiting'`, [request.id]);
      await client.query(`UPDATE approval_requests SET status = 'rejected', decided_at = now() WHERE id = $1`, [request.id]);
      await handler.onRejected(client, request.entity_id, user, comment as string);
    }

    await insertAuditLog(client, {
      entityType: request.entity_type,
      entityId: request.entity_id,
      action: decision === 'approve' ? 'APPROVAL_STEP_APPROVED' : 'APPROVAL_REJECTED',
      performedBy: user.email,
      metadata: { requestId: request.id, step: step.step_name, comment },
    });
    return getRequest(request.id, client);
  });
}

/** An electronic signature is the approver proving it is them: their own password, entered again at the moment of approval. */
async function checkSignature(client: PoolClient, password: unknown, email: string): Promise<{ email: string; name: string }> {
  if (typeof password !== 'string' || !password) throw new ValidationError('This step needs your signature — enter your password to sign');
  const u = (await client.query(`SELECT email, name, password_hash FROM users WHERE email = $1`, [email])).rows[0];
  if (!u || !(await verifyPassword(password, u.password_hash))) throw new ValidationError('Password is incorrect — the approval was not signed');
  return { email: u.email, name: u.name };
}

async function recordSignature(client: PoolClient, request: ApprovalRequestRow, step: ApprovalStepRow, signer: { email: string; name: string }, meaning: string) {
  const signedAt = new Date().toISOString();
  const hash = createHash('sha256').update(JSON.stringify({ t: request.entity_type, id: request.entity_id, code: request.entity_code, title: request.title, amount: request.amount, step: step.step_name, signer: signer.email, meaning, signedAt })).digest('hex');
  await client.query(
    `INSERT INTO approval_signatures (request_id, step_id, entity_type, entity_id, entity_code, signer_email, signer_name, meaning, signed_at, record_hash) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`,
    [request.id, step.id, request.entity_type, request.entity_id, request.entity_code, signer.email, signer.name, meaning, signedAt, hash],
  );
  await insertAuditLog(client, { entityType: request.entity_type, entityId: request.entity_id, action: 'APPROVAL_SIGNED', performedBy: signer.email, metadata: { requestId: request.id, step: step.step_name, meaning } });
}

/** Adds what the screens need: which steps want a signature, and the signatures already given. */
async function withSignatures<T extends { id: string; entity_type: string }>(db: { query: PoolClient['query'] }, req: T, steps: ApprovalStepRow[]) {
  const rules = (await db.query(`SELECT step_order, requires_signature, signature_meaning FROM approval_rules WHERE entity_type = $1`, [req.entity_type])).rows as { step_order: number; requires_signature: boolean; signature_meaning: string | null }[];
  const sigs = (await db.query(`SELECT step_id, signer_email, signer_name, meaning, signed_at, record_hash FROM approval_signatures WHERE request_id = $1 ORDER BY signed_at`, [req.id])).rows;
  return {
    ...req,
    steps: steps.map((st) => {
      const rule = rules.find((r) => r.step_order === st.step_order);
      return { ...st, signature_required: !!rule?.requires_signature, signature_meaning: rule?.signature_meaning ?? null, signature: sigs.find((g) => g.step_id === st.id) ?? null };
    }),
  };
}

/** Called by the owning module when the record is cancelled while waiting. */
export async function withdrawTx(client: PoolClient, entityType: string, entityId: string, user: AuthenticatedUser): Promise<boolean> {
  const r = await client.query<{ id: string }>(
    `UPDATE approval_requests SET status = 'withdrawn', decided_at = now() WHERE entity_type = $1 AND entity_id = $2 AND status = 'pending' RETURNING id`,
    [entityType, entityId],
  );
  if (!r.rows[0]) return false;
  await client.query(`UPDATE approval_steps SET status = 'cancelled' WHERE request_id = $1 AND status IN ('pending', 'waiting')`, [r.rows[0].id]);
  await insertAuditLog(client, { entityType, entityId, action: 'APPROVAL_WITHDRAWN', performedBy: user.email, metadata: { requestId: r.rows[0].id } });
  return true;
}

export async function getRequest(id: string, client?: PoolClient) {
  const db = client ?? pool;
  const r = await db.query<ApprovalRequestRow>('SELECT * FROM approval_requests WHERE id = $1', [id]);
  if (!r.rows[0]) throw new NotFoundError('Approval request not found');
  const steps = await db.query<ApprovalStepRow>('SELECT * FROM approval_steps WHERE request_id = $1 ORDER BY step_order', [id]);
  return withSignatures(db, r.rows[0], steps.rows);
}

/** The approval history of one business record, newest request first. */
export async function getApprovalsForEntity(entityType: string, entityId: string, client?: PoolClient) {
  const db = client ?? pool;
  const r = await db.query<ApprovalRequestRow>(
    'SELECT * FROM approval_requests WHERE entity_type = $1 AND entity_id = $2 ORDER BY requested_at DESC',
    [entityType, entityId],
  );
  const out = [];
  for (const req of r.rows) {
    const steps = await db.query<ApprovalStepRow>('SELECT * FROM approval_steps WHERE request_id = $1 ORDER BY step_order', [req.id]);
    out.push(await withSignatures(db, req, steps.rows));
  }
  return out;
}

/** Steps waiting for someone with this user's permissions, excluding their own requests. */
export async function inbox(user: AuthenticatedUser) {
  const held = permissionsFor(user.jobRole, user.role);
  const values: unknown[] = [user.email];
  let permFilter = '';
  if (held !== 'all') {
    if (held.size === 0) return [];
    values.push([...held]);
    permFilter = `AND s.required_permission = ANY($2::text[])`;
  }
  const r = await pool.query(
    `SELECT r.id, r.entity_type, r.entity_id, r.entity_code, r.title, r.amount, r.requested_by, r.requested_at,
            s.step_name, s.required_permission, s.step_order,
            COALESCE((SELECT g.requires_signature FROM approval_rules g WHERE g.entity_type = r.entity_type AND g.step_order = s.step_order), false) AS signature_required,
            (SELECT g.signature_meaning FROM approval_rules g WHERE g.entity_type = r.entity_type AND g.step_order = s.step_order) AS signature_meaning,
            (SELECT COUNT(*)::int FROM approval_steps x WHERE x.request_id = r.id) AS total_steps
       FROM approval_steps s
       JOIN approval_requests r ON r.id = s.request_id
      WHERE s.status = 'pending' AND r.status = 'pending' AND r.requested_by <> $1
        AND NOT EXISTS (SELECT 1 FROM approval_steps d WHERE d.request_id = r.id AND d.decided_by = $1)
        ${permFilter}
      ORDER BY r.requested_at`,
    values,
  );
  return r.rows;
}

export async function listRequests(filters: { status?: string; entityType?: string; mine?: boolean }, user: AuthenticatedUser) {
  const where: string[] = [];
  const values: unknown[] = [];
  if (filters.status) {
    values.push(filters.status);
    where.push(`status = $${values.length}`);
  }
  if (filters.entityType) {
    values.push(filters.entityType);
    where.push(`entity_type = $${values.length}`);
  }
  if (filters.mine) {
    values.push(user.email);
    where.push(`requested_by = $${values.length}`);
  }
  const r = await pool.query<ApprovalRequestRow>(
    `SELECT * FROM approval_requests ${where.length ? `WHERE ${where.join(' AND ')}` : ''} ORDER BY requested_at DESC LIMIT 500`,
    values,
  );
  return r.rows;
}

export async function listRules() {
  const r = await pool.query('SELECT * FROM approval_rules ORDER BY entity_type, step_order');
  return r.rows;
}

export async function updateRule(id: string, input: Record<string, unknown>, user: AuthenticatedUser) {
  return withTransaction(async (client) => {
    const before = await client.query('SELECT * FROM approval_rules WHERE id = $1 FOR UPDATE', [id]);
    if (!before.rows[0]) throw new NotFoundError('Approval rule not found');
    const minAmount = input.minAmount === undefined ? null : requireNumber(input.minAmount, 'minAmount', { min: 0 });
    const isActive = input.isActive === undefined ? null : input.isActive === true;
    const sign = input.requiresSignature === undefined ? null : input.requiresSignature === true;
    if (minAmount === null && isActive === null && sign === null) throw new ValidationError('Nothing to update');
    // A first step must always exist for value-gated types; switching off
    // step 1 would let every record of that type approve itself.
    if (isActive === false && before.rows[0].step_order === 1) throw new ConflictError('The first approval step cannot be switched off');
    const r = await client.query(
      `UPDATE approval_rules SET min_amount = COALESCE($2, min_amount), is_active = COALESCE($3, is_active), requires_signature = COALESCE($5, requires_signature), updated_by = $4, updated_at = now() WHERE id = $1 RETURNING *`,
      [id, minAmount, isActive, user.email, sign],
    );
    await insertAuditLog(client, { entityType: 'approval_rule', entityId: id, action: 'UPDATE', performedBy: user.email, beforeState: before.rows[0], afterState: r.rows[0] });
    return r.rows[0];
  });
}
