import { pool } from '../../db/pool';

/** Warehouse reports: movement volume by month, stock by crop, expiry exposure, top dealers and return reasons. */
export async function warehouseReports(months = 12) {
  const m = Math.min(Math.max(Math.floor(months), 1), 36);
  const [monthly, byCrop, expiry, dealers, returns, turnover] = await Promise.all([
    pool.query(
      `SELECT to_char(date_trunc('month', created_at), 'YYYY-MM') AS month,
              COALESCE(SUM(quantity_kg) FILTER (WHERE move_type = 'receipt'),0)::float AS received,
              COALESCE(-SUM(quantity_kg) FILTER (WHERE move_type = 'dispatch'),0)::float AS dispatched,
              COALESCE(SUM(quantity_kg) FILTER (WHERE move_type = 'return'),0)::float AS returned
         FROM wh_stock_moves WHERE created_at >= date_trunc('month', now()) - ($1 || ' months')::interval GROUP BY 1 ORDER BY 1`, [String(m - 1)]),
    pool.query(`SELECT l.crop, SUM(s.q)::float AS kg, COUNT(*)::int AS lots FROM (SELECT seed_lot_id, SUM(quantity_kg) AS q FROM wh_stock_moves GROUP BY 1 HAVING SUM(quantity_kg) > 0) s JOIN seed_lots l ON l.id = s.seed_lot_id GROUP BY l.crop ORDER BY kg DESC`),
    pool.query(
      `WITH s AS (SELECT seed_lot_id, SUM(quantity_kg) AS q FROM wh_stock_moves GROUP BY 1 HAVING SUM(quantity_kg) > 0),
            t AS (SELECT DISTINCT ON (seed_lot_id) seed_lot_id, valid_until FROM wh_lot_tests ORDER BY seed_lot_id, tested_on DESC, recorded_at DESC)
       SELECT CASE WHEN t.valid_until IS NULL THEN 'untested' WHEN t.valid_until < CURRENT_DATE THEN 'expired' WHEN t.valid_until < CURRENT_DATE + 30 THEN 'within_30_days'
                   WHEN t.valid_until < CURRENT_DATE + 90 THEN 'within_90_days' ELSE 'later' END AS bucket, COUNT(*)::int AS lots, SUM(s.q)::float AS kg
         FROM s LEFT JOIN t ON t.seed_lot_id = s.seed_lot_id GROUP BY 1`),
    pool.query(
      `SELECT p.name, p.district, SUM(dl.quantity_kg)::float AS kg, COUNT(DISTINCT d.id)::int AS dispatches
         FROM wh_dispatch_lines dl JOIN wh_dispatches d ON d.id = dl.dispatch_id JOIN parties p ON p.id = d.dealer_id
        WHERE d.status IN ('dispatched','delivered') AND d.dispatched_at >= now() - ($1 || ' months')::interval GROUP BY p.name, p.district ORDER BY kg DESC LIMIT 10`, [String(m)]),
    pool.query(`SELECT reason, COUNT(*)::int AS n, SUM(quantity_kg)::float AS kg FROM wh_returns WHERE created_at >= now() - ($1 || ' months')::interval GROUP BY reason ORDER BY kg DESC`, [String(m)]),
    pool.query(
      `SELECT COALESCE(-SUM(quantity_kg) FILTER (WHERE move_type = 'dispatch' AND created_at > now() - interval '90 days'),0)::float AS dispatched_90d,
              COALESCE(SUM(quantity_kg),0)::float AS on_hand FROM wh_stock_moves`),
  ]);
  const t = turnover.rows[0];
  return {
    monthly: monthly.rows, byCrop: byCrop.rows, expiry: expiry.rows, topDealers: dealers.rows, returnsByReason: returns.rows,
    coverDays: t.dispatched_90d > 0 ? Math.round((t.on_hand / t.dispatched_90d) * 90) : null, onHandKg: t.on_hand, dispatched90dKg: t.dispatched_90d,
  };
}
