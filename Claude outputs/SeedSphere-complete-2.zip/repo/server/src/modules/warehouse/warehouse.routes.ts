import { warehouseReports } from './reports.service';
import { Router } from 'express';
import { asyncHandler as h } from '../../middleware/asyncHandler';
import { requireAuth, requirePermission as can, requireStaff } from '../../middleware/requireAuth';
import { body, ok, str } from '../shared/http';
import * as dispatch from './dispatch.service';
import * as sensors from './sensors.service';
import * as stock from './stock.service';

export const warehouseDeviceRouter = Router();
// IoT gateways post readings with the sensor's device key (no user session).
warehouseDeviceRouter.post('/sensor-readings', h(async (req, res) => ok(res, await sensors.deviceReading(req.header('x-sensor-code'), req.header('x-device-key'), body(req)), 'Reading stored', 201)));

export const warehouseRouter = Router();
warehouseRouter.use(requireAuth, requireStaff);

warehouseRouter.get('/reports', h(async (req, res) => ok(res, await warehouseReports(req.query.months ? Number(req.query.months) : 12))));
warehouseRouter.get('/dashboard', h(async (_req, res) => ok(res, await sensors.warehouseDashboard())));

// Warehouses & locations
warehouseRouter.get('/warehouses', h(async (_req, res) => ok(res, await stock.listWarehouses())));
warehouseRouter.post('/warehouses', can('define_storage_zones'), h(async (req, res) => ok(res, await stock.createWarehouse(body(req), req.user!), 'Warehouse added (with a quarantine area)', 201)));
warehouseRouter.get('/locations', h(async (req, res) => ok(res, await stock.listLocations({ warehouseId: str(req.query.warehouseId) }))));
warehouseRouter.post('/locations', can('define_storage_zones'), h(async (req, res) => ok(res, await stock.createLocation(body(req), req.user!), 'Location added', 201)));
warehouseRouter.post('/locations/:id/status', can('define_storage_zones'), h(async (req, res) => ok(res, await stock.setLocationStatus(req.params.id, body(req), req.user!), 'Location updated')));

// Stock
warehouseRouter.get('/stock', h(async (req, res) => ok(res, await stock.stockOnHand({ warehouseId: str(req.query.warehouseId), q: str(req.query.q), status: str(req.query.status) }))));
warehouseRouter.get('/stock/lots/:lotId', h(async (req, res) => ok(res, await stock.lotStock(req.params.lotId))));
warehouseRouter.get('/movements', h(async (req, res) => ok(res, await stock.listMovements({ lotId: str(req.query.lotId), type: str(req.query.type), limit: req.query.limit ? Number(req.query.limit) : undefined }))));
warehouseRouter.post('/receipts', can('receive_incoming_goods'), h(async (req, res) => {
  const r = await stock.receiveStock(body(req), req.user!);
  ok(res, r, `${r.receipt_number}: ${r.quantity_kg} kg received`, 201);
}));
warehouseRouter.post('/transfers', can('log_stock_movement', 'assign_storage_location'), h(async (req, res) => ok(res, await stock.transferStock(body(req), req.user!), 'Stock moved')));
warehouseRouter.post('/lot-tests', can('receive_incoming_goods', 'quality_assess_returns'), h(async (req, res) => ok(res, await stock.recordLotTest(body(req), req.user!), 'Test report recorded', 201)));

// Adjustments & counts
warehouseRouter.get('/adjustments', h(async (req, res) => ok(res, await stock.listAdjustments({ status: str(req.query.status) }))));
warehouseRouter.post('/adjustments', can('propose_stock_adjustment'), h(async (req, res) => ok(res, await stock.proposeAdjustment(body(req), req.user!), 'Adjustment sent for approval', 201)));
warehouseRouter.get('/counts', h(async (_req, res) => ok(res, await stock.listCounts())));
warehouseRouter.get('/counts/:id', h(async (req, res) => ok(res, await stock.getCount(req.params.id))));
warehouseRouter.post('/counts', can('schedule_cycle_count'), h(async (req, res) => ok(res, await stock.createCount(body(req), req.user!), 'Count sheet created', 201)));
warehouseRouter.put('/counts/:id/lines', can('execute_cycle_count'), h(async (req, res) => ok(res, await stock.recordCountLines(req.params.id, body(req), req.user!), 'Counts saved')));
warehouseRouter.post('/counts/:id/submit', can('execute_cycle_count'), h(async (req, res) => {
  const r = await stock.submitCount(req.params.id, req.user!);
  ok(res, r, r.adjustments.length ? `${r.adjustments.length} variance(s) sent for approval` : 'Count matched the system — no adjustment needed');
}));

// Dispatch
warehouseRouter.get('/dispatches', h(async (req, res) => ok(res, await dispatch.listDispatches({ status: str(req.query.status), dealerId: str(req.query.dealerId) }))));
warehouseRouter.get('/dispatches/:id', h(async (req, res) => ok(res, await dispatch.getDispatch(req.params.id))));
warehouseRouter.post('/dispatches', can('prepare_outbound_dispatch'), h(async (req, res) => {
  const d = await dispatch.createDispatch(body(req), req.user!);
  ok(res, d, `${d.dispatch_number} drafted${d.warnings.length ? ' — see first-expiry advice' : ''}`, 201);
}));
warehouseRouter.post('/dispatches/:id/submit', can('prepare_outbound_dispatch'), h(async (req, res) => ok(res, await dispatch.submitDispatch(req.params.id, req.user!), 'Sent for approval')));
warehouseRouter.post('/dispatches/:id/ship', can('prepare_outbound_dispatch'), h(async (req, res) => ok(res, await dispatch.shipDispatch(req.params.id, body(req), req.user!), 'Dispatched')));
warehouseRouter.post('/dispatches/:id/deliver', can('prepare_outbound_dispatch'), h(async (req, res) => ok(res, await dispatch.confirmDelivery(req.params.id, body(req), req.user!), 'Delivery confirmed')));
warehouseRouter.post('/dispatches/:id/cancel', can('prepare_outbound_dispatch', 'approve_outbound_dispatch'), h(async (req, res) => ok(res, await dispatch.cancelDispatch(req.params.id, body(req), req.user!), 'Dispatch cancelled')));
warehouseRouter.get('/lots/:lotId/recipients', h(async (req, res) => ok(res, await dispatch.lotRecipients(req.params.lotId))));

// Returns
warehouseRouter.get('/returns', h(async (req, res) => ok(res, await dispatch.listReturns({ status: str(req.query.status) }))));
warehouseRouter.get('/returns/:id', h(async (req, res) => ok(res, await dispatch.getReturn(req.params.id))));
warehouseRouter.post('/returns', can('log_return'), h(async (req, res) => {
  const r = await dispatch.logReturn(body(req), req.user!);
  ok(res, r, `${r.return_number} received into quarantine`, 201);
}));
warehouseRouter.post('/returns/:id/decide', can('approve_return_disposition'), h(async (req, res) => ok(res, await dispatch.decideReturn(req.params.id, body(req), req.user!), 'Disposition recorded')));

// Sensors
warehouseRouter.get('/sensors', h(async (_req, res) => ok(res, await sensors.listSensors())));
warehouseRouter.get('/sensors/:id/history', h(async (req, res) => ok(res, await sensors.sensorHistory(req.params.id, req.query.hours ? Number(req.query.hours) : undefined))));
warehouseRouter.post('/sensors', can('configure_iot_thresholds'), h(async (req, res) => ok(res, await sensors.createSensor(body(req), req.user!), 'Sensor added — copy the device key now, it is shown once', 201)));
warehouseRouter.patch('/sensors/:id', can('configure_iot_thresholds'), h(async (req, res) => ok(res, await sensors.updateThresholds(req.params.id, body(req), req.user!), 'Thresholds updated')));
warehouseRouter.post('/sensors/:id/readings', can('record_sensor_reading'), h(async (req, res) => {
  const r = await sensors.recordReading(req.params.id, body(req), req.user!);
  ok(res, r, r.outOfRange ? 'Reading is out of range — a non-conformance has been raised' : 'Reading stored', 201);
}));
warehouseRouter.post('/breaches/:id/resolve', can('resolve_safety_alerts', 'configure_iot_thresholds'), h(async (req, res) => ok(res, await sensors.resolveBreach(req.params.id, body(req), req.user!), 'Breach resolution recorded')));
