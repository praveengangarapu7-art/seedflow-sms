import { createHash, randomBytes, timingSafeEqual } from 'crypto';
import type { PoolClient } from 'pg';
import { pool } from '../../db/pool';
import { withTransaction } from '../../db/transaction';
import { ConflictError, NotFoundError, UnauthorizedError } from '../../errors';
import type { AuthenticatedUser } from '../../middleware/requireAuth';
import { insertAuditLog } from '../auditLogs/auditLogs.service';
import { insertNcrTx } from '../quality/ncr.service';
import { num, optionalNumber, requireEnum, requireNumber, requireText, requireUuid } from '../shared/validate';
import { lotSaleInfo } from './stock.service';

const hash = (k: string) => createHash('sha256').update(k).digest('hex');

export async function createSensor(input: Record<string, unknown>, user: AuthenticatedUser) {
  const code = requireText(input.code, 'code', 40).toUpperCase();
  const locationId = requireUuid(input.locationId, 'locationId');
  const type = requireEnum(input.sensorType, ['temperature', 'humidity', 'co2', 'phosphine'] as const, 'sensorType');
  const unit = requireText(input.unit, 'unit', 10);
  const min = optionalNumber(input.minValue, 'minValue');
  const max = optionalNumber(input.maxValue, 'maxValue');
  if (min === null && max === null) throw new ConflictError('Set a minimum, a maximum or both');
  if (min !== null && max !== null && min >= max) throw new ConflictError('The minimum must be below the maximum');
  // The device key is shown once; only its hash is stored.
  const deviceKey = randomBytes(24).toString('base64url');
  return withTransaction(async (client) => {
    const dup = await client.query('SELECT 1 FROM wh_sensors WHERE code = $1', [code]);
    if (dup.rows[0]) throw new ConflictError(`Sensor ${code} already exists`);
    const r = await client.query(
      `INSERT INTO wh_sensors (code, location_id, sensor_type, unit, min_value, max_value, device_key_hash, created_by) VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *`,
      [code, locationId, type, unit, min, max, hash(deviceKey), user.email],
    );
    await insertAuditLog(client, { entityType: 'wh_sensor', entityId: r.rows[0].id, action: 'CREATE', performedBy: user.email, afterState: { ...r.rows[0], device_key_hash: undefined } });
    const { device_key_hash: _h, ...sensor } = r.rows[0];
    return { sensor, deviceKey };
  });
}

export async function updateThresholds(id: string, input: Record<string, unknown>, user: AuthenticatedUser) {
  const min = optionalNumber(input.minValue, 'minValue');
  const max = optionalNumber(input.maxValue, 'maxValue');
  if (min === null && max === null) throw new ConflictError('Set a minimum, a maximum or both');
  if (min !== null && max !== null && min >= max) throw new ConflictError('The minimum must be below the maximum');
  return withTransaction(async (client) => {
    const r = await client.query('UPDATE wh_sensors SET min_value = $2, max_value = $3 WHERE id = $1 RETURNING id, code, min_value, max_value', [id, min, max]);
    if (!r.rows[0]) throw new NotFoundError('Sensor not found');
    await insertAuditLog(client, { entityType: 'wh_sensor', entityId: id, action: 'THRESHOLDS', performedBy: user.email, afterState: r.rows[0] });
    return r.rows[0];
  });
}

function outOfRange(s: { min_value: number | null; max_value: number | null }, v: number): boolean {
  return (s.min_value !== null && v < num(s.min_value)) || (s.max_value !== null && v > num(s.max_value));
}

/**
 * Stores a reading. Leaving the allowed range opens a breach and raises a
 * non-conformance naming the lots stored there; the breach closes when a
 * reading is back in range. A storage problem is followed up, not just logged.
 */
async function processReading(client: PoolClient, sensorId: string, value: number, source: 'manual' | 'device', who: string | null, user: AuthenticatedUser) {
  const r = await client.query('SELECT s.*, l.code AS location_code, l.id AS loc_id FROM wh_sensors s JOIN wh_locations l ON l.id = s.location_id WHERE s.id = $1 FOR UPDATE OF s', [sensorId]);
  const s = r.rows[0];
  if (!s) throw new NotFoundError('Sensor not found');
  if (s.status !== 'active') throw new ConflictError('This sensor is inactive');
  await client.query('INSERT INTO wh_sensor_readings (sensor_id, value, source, recorded_by) VALUES ($1, $2, $3, $4)', [sensorId, value, source, who]);
  await client.query('UPDATE wh_sensors SET last_value = $2, last_reading_at = now() WHERE id = $1', [sensorId, value]);
  const open = await client.query('SELECT * FROM wh_sensor_breaches WHERE sensor_id = $1 AND ended_at IS NULL FOR UPDATE', [sensorId]);
  const breach = open.rows[0];
  const bad = outOfRange(s, value);
  if (bad && !breach) {
    const lots = await client.query<{ seed_lot_id: string; lot_code: string; quantity_kg: number }>(
      `SELECT st.seed_lot_id, l.lot_code, st.quantity_kg FROM wh_stock st JOIN seed_lots l ON l.id = st.seed_lot_id WHERE st.location_id = $1`,
      [s.loc_id],
    );
    const range = `${s.min_value ?? '—'} to ${s.max_value ?? '—'} ${s.unit}`;
    const { ncr } = await insertNcrTx(
      client,
      {
        title: `Storage ${s.sensor_type} out of range at ${s.location_code}: ${value} ${s.unit}`.slice(0, 200),
        description: `Sensor ${s.code} read ${value} ${s.unit} (allowed ${range}). Lots stored there: ${lots.rows.length ? lots.rows.map((l) => `${l.lot_code} (${num(l.quantity_kg)} kg)`).join(', ') : 'none'}. Check the seed and retest germination if exposure was prolonged.`,
        department: 'warehouse',
        source: 'process_deviation',
        severity: lots.rows.length ? 'major' : 'minor',
        seedLotId: lots.rows.length === 1 ? lots.rows[0].seed_lot_id : null,
        assignedTo: null,
        dueDate: null,
      },
      user,
    );
    await client.query('INSERT INTO wh_sensor_breaches (sensor_id, started_at, worst_value, ncr_id) VALUES ($1, now(), $2, $3)', [sensorId, value, ncr.id]);
  } else if (bad && breach) {
    const worse = s.max_value !== null && value > num(s.max_value) ? value > num(breach.worst_value) : value < num(breach.worst_value);
    if (worse) await client.query('UPDATE wh_sensor_breaches SET worst_value = $2 WHERE id = $1', [breach.id, value]);
  } else if (!bad && breach) {
    await client.query('UPDATE wh_sensor_breaches SET ended_at = now() WHERE id = $1', [breach.id]);
  }
  return { value, outOfRange: bad };
}

export async function recordReading(sensorId: string, input: Record<string, unknown>, user: AuthenticatedUser) {
  const value = requireNumber(input.value, 'value');
  return withTransaction((client) => processReading(client, sensorId, value, 'manual', user.email, user));
}

/** Ingestion for IoT gateways: authenticated by the sensor's own device key, not a user session. */
export async function deviceReading(code: string | undefined, key: string | undefined, input: Record<string, unknown>) {
  if (!code || !key) throw new UnauthorizedError('Sensor code and device key are required');
  const value = requireNumber(input.value, 'value');
  const r = await pool.query('SELECT id, device_key_hash FROM wh_sensors WHERE code = $1', [code.toUpperCase()]);
  const s = r.rows[0];
  const ok = s?.device_key_hash && timingSafeEqual(Buffer.from(s.device_key_hash, 'hex'), Buffer.from(hash(key), 'hex'));
  if (!ok) throw new UnauthorizedError('Unknown sensor or wrong device key');
  const system: AuthenticatedUser = { id: '00000000-0000-0000-0000-000000000000', email: `sensor:${code.toUpperCase()}`, role: 'Inspector', organizationId: null, jobRole: null };
  return withTransaction((client) => processReading(client, s.id, value, 'device', null, system));
}

export async function resolveBreach(id: string, input: Record<string, unknown>, user: AuthenticatedUser) {
  const note = requireText(input.note, 'note', 1000);
  return withTransaction(async (client) => {
    const r = await client.query('UPDATE wh_sensor_breaches SET resolution_note = $2, resolved_by = $3 WHERE id = $1 RETURNING *', [id, note, user.email]);
    if (!r.rows[0]) throw new NotFoundError('Breach not found');
    await insertAuditLog(client, { entityType: 'wh_sensor_breach', entityId: id, action: 'RESOLVE', performedBy: user.email, metadata: { note } });
    return r.rows[0];
  });
}

export async function listSensors() {
  const r = await pool.query(
    `SELECT s.id, s.code, s.location_id, s.sensor_type, s.unit, s.min_value, s.max_value, s.status, s.last_value, s.last_reading_at, s.created_at,
            l.code AS location_code, l.zone, w.code AS warehouse_code,
            b.id AS open_breach_id, b.started_at AS breach_started_at, b.worst_value AS breach_worst, n.ncr_code AS breach_ncr_code, n.id AS breach_ncr_id,
            (s.last_reading_at IS NULL OR s.last_reading_at < now() - interval '2 hours') AS stale
       FROM wh_sensors s JOIN wh_locations l ON l.id = s.location_id JOIN wh_warehouses w ON w.id = l.warehouse_id
       LEFT JOIN wh_sensor_breaches b ON b.sensor_id = s.id AND b.ended_at IS NULL
       LEFT JOIN non_conformances n ON n.id = b.ncr_id
      ORDER BY w.code, l.code, s.code`,
  );
  return r.rows;
}

export async function sensorHistory(id: string, hours = 72) {
  const readings = await pool.query(
    `SELECT value, recorded_at, source FROM wh_sensor_readings WHERE sensor_id = $1 AND recorded_at >= now() - ($2::int * interval '1 hour') ORDER BY recorded_at`,
    [id, Math.min(Math.max(hours, 1), 24 * 31)],
  );
  const breaches = await pool.query(
    `SELECT b.*, n.ncr_code FROM wh_sensor_breaches b LEFT JOIN non_conformances n ON n.id = b.ncr_id WHERE b.sensor_id = $1 ORDER BY b.started_at DESC LIMIT 50`,
    [id],
  );
  return { readings: readings.rows, breaches: breaches.rows };
}

export async function warehouseDashboard() {
  const stock = await pool.query(`SELECT seed_lot_id, SUM(quantity_kg) AS kg FROM wh_stock GROUP BY seed_lot_id`);
  const info = await lotSaleInfo(pool, stock.rows.map((s) => s.seed_lot_id));
  const byStatus: Record<string, { lots: number; kg: number }> = {};
  for (const s of stock.rows) {
    const st = info.get(s.seed_lot_id)!.status;
    byStatus[st] = byStatus[st] ?? { lots: 0, kg: 0 };
    byStatus[st].lots += 1;
    byStatus[st].kg += num(s.kg);
  }
  const c = await pool.query(`
    SELECT
      (SELECT COALESCE(SUM(quantity_kg), 0) FROM wh_stock) AS stock_kg,
      (SELECT COUNT(*) FROM wh_dispatches WHERE status = 'pending_approval')::int AS dispatches_pending,
      (SELECT COUNT(*) FROM wh_dispatches WHERE status = 'approved')::int AS dispatches_to_ship,
      (SELECT COUNT(*) FROM wh_dispatches WHERE status = 'dispatched')::int AS in_transit,
      (SELECT COUNT(*) FROM wh_returns WHERE status IN ('quarantined', 'inspected', 'retest'))::int AS returns_open,
      (SELECT COUNT(*) FROM wh_adjustments WHERE status = 'pending_approval')::int AS adjustments_pending,
      (SELECT COUNT(*) FROM wh_sensor_breaches WHERE ended_at IS NULL)::int AS open_breaches,
      (SELECT COUNT(*) FROM wh_counts WHERE status = 'open')::int AS counts_open
  `);
  const expiring = (await pool.query(`SELECT seed_lot_id FROM wh_stock GROUP BY seed_lot_id`)).rows
    .map((r) => ({ id: r.seed_lot_id, ...info.get(r.seed_lot_id)! }))
    .filter((x) => x.status === 'retest_due' || x.status === 'expired')
    .sort((a, b) => (a.days_to_expiry ?? 0) - (b.days_to_expiry ?? 0))
    .slice(0, 10);
  const codes = expiring.length ? await pool.query('SELECT id, lot_code, variety FROM seed_lots WHERE id = ANY($1::uuid[])', [expiring.map((e) => e.id)]) : { rows: [] as { id: string; lot_code: string; variety: string }[] };
  return {
    counts: { ...c.rows[0], stock_kg: num(c.rows[0].stock_kg) },
    byStatus,
    expiring: expiring.map((e) => ({ ...e, ...codes.rows.find((x) => x.id === e.id) })),
  };
}
