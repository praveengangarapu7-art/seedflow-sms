import type { PoolClient } from 'pg';
import { pool } from '../../db/pool';
import { withTransaction } from '../../db/transaction';
import { ConflictError, NotFoundError, ValidationError } from '../../errors';
import type { AuthenticatedUser } from '../../middleware/requireAuth';
import { getApprovalsForEntity, registerApprovalHandler, submitForApprovalTx } from '../approvals/approvals.service';
import { insertAuditLog } from '../auditLogs/auditLogs.service';
import {
  asRecord,
  assertSeedLotExists,
  nextCode,
  num,
  optionalDate,
  optionalNumber,
  optionalText,
  requireArray,
  requireDate,
  requireEnum,
  requireNumber,
  requireText,
  requireUuid,
  round2,
} from '../shared/validate';

/** Months a passing germination test from the lab module keeps a lot saleable (Seeds Rules: 9 months for certified seed). */
export const VALIDITY_MONTHS = Number(process.env.LOT_VALIDITY_MONTHS ?? 9);
/** A lot this close to the end of its validity is flagged for retest. */
export const RETEST_WARNING_DAYS = 30;

export type SaleStatus = 'sellable' | 'retest_due' | 'expired' | 'untested' | 'failed' | 'on_hold';

export interface LotSaleInfo {
  status: SaleStatus;
  tested_on: string | null;
  germination_pct: number | null;
  valid_until: string | null;
  days_to_expiry: number | null;
  hold_reason: string | null;
}

function addMonths(iso: string, months: number): string {
  const d = new Date(`${iso}T00:00:00Z`);
  d.setUTCMonth(d.getUTCMonth() + months);
  return d.toISOString().slice(0, 10);
}

/**
 * Whether each lot may be sold today: not on quality hold, its latest
 * germination test passed, and that test is still within validity. Lab-module
 * results and externally recorded test reports both count.
 */
export async function lotSaleInfo(db: { query: PoolClient['query'] }, lotIds: string[]): Promise<Map<string, LotSaleInfo>> {
  const out = new Map<string, LotSaleInfo>();
  if (lotIds.length === 0) return out;
  const tests = await db.query<{ seed_lot_id: string; tested_on: string; germination_pct: number; passed: boolean; valid_until: string | null }>(
    `SELECT s.seed_lot_id, (r.recorded_at AT TIME ZONE 'Asia/Kolkata')::date::text AS tested_on, r.result_value AS germination_pct, r.passed, NULL::text AS valid_until
       FROM lab_test_results r JOIN lab_test_submissions s ON s.id = r.submission_id
      WHERE r.test_type = 'germination' AND s.seed_lot_id = ANY($1::uuid[])
     UNION ALL
     SELECT seed_lot_id, tested_on::text, germination_pct, passed, valid_until::text FROM wh_lot_tests WHERE seed_lot_id = ANY($1::uuid[])
     ORDER BY tested_on DESC`,
    [lotIds],
  );
  const holds = await db.query<{ seed_lot_id: string; reason: string }>(
    'SELECT seed_lot_id, reason FROM quality_lot_holds WHERE released_at IS NULL AND seed_lot_id = ANY($1::uuid[])',
    [lotIds],
  );
  const today = new Date().toISOString().slice(0, 10);
  for (const id of lotIds) {
    const latest = tests.rows.find((t) => t.seed_lot_id === id);
    const hold = holds.rows.find((h) => h.seed_lot_id === id);
    let info: LotSaleInfo = { status: 'untested', tested_on: null, germination_pct: null, valid_until: null, days_to_expiry: null, hold_reason: hold?.reason ?? null };
    if (latest) {
      const validUntil = latest.valid_until ?? addMonths(latest.tested_on, VALIDITY_MONTHS);
      const days = Math.round((Date.parse(validUntil) - Date.parse(today)) / 86400000);
      info = {
        ...info,
        tested_on: latest.tested_on,
        germination_pct: num(latest.germination_pct),
        valid_until: validUntil,
        days_to_expiry: days,
        status: !latest.passed ? 'failed' : days < 0 ? 'expired' : days <= RETEST_WARNING_DAYS ? 'retest_due' : 'sellable',
      };
    }
    if (hold) info.status = 'on_hold';
    out.set(id, info);
  }
  return out;
}

export async function assertLotSaleable(client: PoolClient, lotId: string, lotCode: string): Promise<LotSaleInfo> {
  const info = (await lotSaleInfo(client, [lotId])).get(lotId)!;
  const why: Record<string, string> = {
    on_hold: `is on quality hold (${info.hold_reason})`,
    untested: 'has no germination test on record',
    failed: `failed its latest germination test (${info.germination_pct}%)`,
    expired: `passed its validity on ${info.valid_until} — retest it first`,
  };
  if (why[info.status]) throw new ConflictError(`Lot ${lotCode} ${why[info.status]}`);
  return info;
}

// ------------------------------------------------------- warehouses & bins

export async function listWarehouses() {
  const r = await pool.query(
    `SELECT w.*, (SELECT COUNT(*)::int FROM wh_locations l WHERE l.warehouse_id = w.id AND l.status <> 'inactive') AS locations,
            COALESCE((SELECT SUM(quantity_kg) FROM wh_stock s WHERE s.warehouse_id = w.id), 0) AS stock_kg
       FROM wh_warehouses w ORDER BY w.code`,
  );
  return r.rows;
}

export async function createWarehouse(input: Record<string, unknown>, user: AuthenticatedUser) {
  const code = requireText(input.code, 'code', 20).toUpperCase();
  const name = requireText(input.name, 'name', 150);
  return withTransaction(async (client) => {
    const dup = await client.query('SELECT 1 FROM wh_warehouses WHERE code = $1', [code]);
    if (dup.rows[0]) throw new ConflictError(`Warehouse ${code} already exists`);
    const r = await client.query(
      `INSERT INTO wh_warehouses (code, name, address, licence_number, created_by) VALUES ($1, $2, $3, $4, $5) RETURNING *`,
      [code, name, optionalText(input.address, 'address', 500), optionalText(input.licenceNumber, 'licenceNumber', 60), user.email],
    );
    // every warehouse gets a quarantine area for returns and held stock
    await client.query(`INSERT INTO wh_locations (warehouse_id, code, zone, location_type, created_by) VALUES ($1, 'QRN-01', 'Quarantine', 'quarantine', $2)`, [r.rows[0].id, user.email]);
    await insertAuditLog(client, { entityType: 'warehouse', entityId: r.rows[0].id, action: 'CREATE', performedBy: user.email, afterState: r.rows[0] });
    return r.rows[0];
  });
}

export async function listLocations(filters: { warehouseId?: string }) {
  const values: unknown[] = [];
  let where = '';
  if (filters.warehouseId) {
    values.push(filters.warehouseId);
    where = 'WHERE l.warehouse_id = $1';
  }
  const r = await pool.query(
    `SELECT l.*, w.code AS warehouse_code, COALESCE(s.kg, 0) AS stock_kg, COALESCE(s.lots, 0) AS lots,
            CASE WHEN l.capacity_kg IS NOT NULL THEN ROUND(100.0 * COALESCE(s.kg, 0) / l.capacity_kg, 1) END AS utilisation_pct
       FROM wh_locations l JOIN wh_warehouses w ON w.id = l.warehouse_id
       LEFT JOIN (SELECT location_id, SUM(quantity_kg) AS kg, COUNT(*)::int AS lots FROM wh_stock GROUP BY location_id) s ON s.location_id = l.id
       ${where} ORDER BY w.code, l.zone, l.code`,
    values,
  );
  return r.rows;
}

export async function createLocation(input: Record<string, unknown>, user: AuthenticatedUser) {
  const warehouseId = requireUuid(input.warehouseId, 'warehouseId');
  const code = requireText(input.code, 'code', 40).toUpperCase();
  const zone = requireText(input.zone, 'zone', 60);
  const type = requireEnum(input.locationType ?? 'bin', ['bin', 'floor', 'cold_room', 'quarantine', 'dispatch_bay'] as const, 'locationType');
  return withTransaction(async (client) => {
    const w = await client.query('SELECT 1 FROM wh_warehouses WHERE id = $1', [warehouseId]);
    if (!w.rows[0]) throw new NotFoundError('Warehouse not found');
    const dup = await client.query('SELECT 1 FROM wh_locations WHERE warehouse_id = $1 AND code = $2', [warehouseId, code]);
    if (dup.rows[0]) throw new ConflictError(`Location ${code} already exists in this warehouse`);
    const r = await client.query(
      `INSERT INTO wh_locations (warehouse_id, code, zone, location_type, capacity_kg, created_by) VALUES ($1, $2, $3, $4, $5, $6) RETURNING *`,
      [warehouseId, code, zone, type, optionalNumber(input.capacityKg, 'capacityKg', { positive: true }), user.email],
    );
    await insertAuditLog(client, { entityType: 'wh_location', entityId: r.rows[0].id, action: 'CREATE', performedBy: user.email, afterState: r.rows[0] });
    return r.rows[0];
  });
}

export async function setLocationStatus(id: string, input: Record<string, unknown>, user: AuthenticatedUser) {
  const status = requireEnum(input.status, ['active', 'blocked', 'inactive'] as const, 'status');
  return withTransaction(async (client) => {
    if (status === 'inactive') {
      const s = await client.query('SELECT 1 FROM wh_stock WHERE location_id = $1', [id]);
      if (s.rows[0]) throw new ConflictError('Move the stock out before deactivating this location');
    }
    const r = await client.query('UPDATE wh_locations SET status = $2 WHERE id = $1 RETURNING *', [id, status]);
    if (!r.rows[0]) throw new NotFoundError('Location not found');
    await insertAuditLog(client, { entityType: 'wh_location', entityId: id, action: 'STATUS', performedBy: user.email, metadata: { status } });
    return r.rows[0];
  });
}

// --------------------------------------------------------------- the ledger

export async function stockAt(client: PoolClient, lotId: string, locationId: string): Promise<number> {
  const r = await client.query<{ kg: number | null }>('SELECT SUM(quantity_kg) AS kg FROM wh_stock_moves WHERE seed_lot_id = $1 AND location_id = $2', [lotId, locationId]);
  return round2(num(r.rows[0].kg));
}

/** Quantity at a location already promised to open dispatch orders. */
export async function reservedAt(client: PoolClient, lotId: string, locationId: string, excludeDispatchId: string | null = null): Promise<number> {
  const r = await client.query<{ kg: number | null }>(
    `SELECT SUM(dl.quantity_kg) AS kg FROM wh_dispatch_lines dl JOIN wh_dispatches d ON d.id = dl.dispatch_id
      WHERE dl.seed_lot_id = $1 AND dl.location_id = $2 AND d.status IN ('draft', 'pending_approval', 'approved') AND ($3::uuid IS NULL OR d.id <> $3)`,
    [lotId, locationId, excludeDispatchId],
  );
  return round2(num(r.rows[0].kg));
}

export async function moveTx(
  client: PoolClient,
  m: { lotId: string; locationId: string; kg: number; bags?: number | null; type: string; refType?: string; refId?: string; refCode?: string; reason?: string | null },
  user: AuthenticatedUser,
) {
  // serialise movements of the same lot so two concurrent issues cannot both see the same stock
  await client.query('SELECT id FROM seed_lots WHERE id = $1 FOR UPDATE', [m.lotId]);
  if (m.kg < 0) {
    const have = await stockAt(client, m.lotId, m.locationId);
    if (have + m.kg < -0.005) throw new ConflictError(`Only ${have} kg of this lot is at that location`);
  }
  await client.query(
    `INSERT INTO wh_stock_moves (seed_lot_id, location_id, quantity_kg, bags, move_type, reference_type, reference_id, reference_code, reason, created_by)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)`,
    [m.lotId, m.locationId, round2(m.kg), m.bags ?? null, m.type, m.refType ?? null, m.refId ?? null, m.refCode ?? null, m.reason ?? null, user.email],
  );
}

async function activeLocation(client: PoolClient, id: string, opts: { allowQuarantine?: boolean } = {}) {
  const r = await client.query('SELECT l.*, w.status AS warehouse_status FROM wh_locations l JOIN wh_warehouses w ON w.id = l.warehouse_id WHERE l.id = $1', [id]);
  const loc = r.rows[0];
  if (!loc) throw new NotFoundError('Location not found');
  if (loc.status !== 'active' || loc.warehouse_status !== 'active') throw new ConflictError(`Location ${loc.code} is not active`);
  if (loc.location_type === 'quarantine' && !opts.allowQuarantine) throw new ConflictError(`${loc.code} is a quarantine area — stock enters it only as a return or hold`);
  return loc;
}

export async function receiveStock(input: Record<string, unknown>, user: AuthenticatedUser) {
  const lotId = requireUuid(input.seedLotId, 'seedLotId');
  const locationId = requireUuid(input.locationId, 'locationId');
  const kg = requireNumber(input.quantityKg, 'quantityKg', { positive: true });
  const bags = optionalNumber(input.bags, 'bags', { positive: true });
  const sourceType = requireEnum(input.sourceType, ['processing', 'purchase', 'transfer', 'opening_stock'] as const, 'sourceType');
  return withTransaction(async (client) => {
    const lot = await assertSeedLotExists(client, lotId);
    await activeLocation(client, locationId);
    const lotRow = await client.query<{ quantity_total: number }>('SELECT quantity_total FROM seed_lots WHERE id = $1 FOR UPDATE', [lotId]);
    const received = await client.query<{ kg: number | null }>('SELECT SUM(quantity_kg) AS kg FROM wh_receipts WHERE seed_lot_id = $1', [lotId]);
    // the warehouse cannot hold more of a lot than was produced
    if (num(received.rows[0].kg) + kg > num(lotRow.rows[0].quantity_total) * 1.005) {
      throw new ConflictError(`Lot ${lot.lot_code} has ${num(lotRow.rows[0].quantity_total)} kg in total and ${num(received.rows[0].kg)} kg is already received`);
    }
    const code = await nextCode(client, 'WRC', 5, true);
    const r = await client.query(
      `INSERT INTO wh_receipts (receipt_number, seed_lot_id, location_id, source_type, source_reference, quantity_kg, bags, received_by) VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *`,
      [code, lotId, locationId, sourceType, optionalText(input.sourceReference, 'sourceReference', 60), kg, bags, user.email],
    );
    await moveTx(client, { lotId, locationId, kg, bags, type: 'receipt', refType: 'wh_receipt', refId: r.rows[0].id, refCode: code }, user);
    await insertAuditLog(client, { entityType: 'wh_receipt', entityId: r.rows[0].id, action: 'CREATE', performedBy: user.email, afterState: r.rows[0] });
    return r.rows[0];
  });
}

export async function transferStock(input: Record<string, unknown>, user: AuthenticatedUser) {
  const lotId = requireUuid(input.seedLotId, 'seedLotId');
  const from = requireUuid(input.fromLocationId, 'fromLocationId');
  const to = requireUuid(input.toLocationId, 'toLocationId');
  if (from === to) throw new ValidationError('Choose two different locations');
  const kg = requireNumber(input.quantityKg, 'quantityKg', { positive: true });
  const reason = optionalText(input.reason, 'reason', 500);
  return withTransaction(async (client) => {
    const src = await client.query('SELECT location_type, code FROM wh_locations WHERE id = $1', [from]);
    if (!src.rows[0]) throw new NotFoundError('Source location not found');
    if (src.rows[0].location_type === 'quarantine') throw new ConflictError('Stock leaves quarantine only through a return disposition');
    await activeLocation(client, to, { allowQuarantine: true });
    const free = (await stockAt(client, lotId, from)) - (await reservedAt(client, lotId, from));
    if (kg > free + 0.005) throw new ConflictError(`Only ${round2(free)} kg is free to move (the rest is reserved for dispatch)`);
    const ref = await nextCode(client, 'TRF', 5, true);
    await moveTx(client, { lotId, locationId: from, kg: -kg, type: 'transfer_out', refCode: ref, reason }, user);
    await moveTx(client, { lotId, locationId: to, kg, type: 'transfer_in', refCode: ref, reason }, user);
    await insertAuditLog(client, { entityType: 'seed_lot', entityId: lotId, action: 'TRANSFER', performedBy: user.email, metadata: { from, to, kg, ref } });
    return { reference: ref };
  });
}

// --------------------------------------------------------------- adjustments

registerApprovalHandler('stock_adjustment', {
  onApproved: async (client, id, user) => {
    const r = await client.query('SELECT * FROM wh_adjustments WHERE id = $1 FOR UPDATE', [id]);
    const a = r.rows[0];
    await moveTx(client, { lotId: a.seed_lot_id, locationId: a.location_id, kg: num(a.quantity_change), type: 'adjustment', refType: 'wh_adjustment', refId: id, refCode: a.adjustment_number, reason: `${a.reason}: ${a.details}` }, user);
    await client.query(`UPDATE wh_adjustments SET status = 'approved', decided_at = now() WHERE id = $1`, [id]);
  },
  onRejected: async (client, id, _user, comment) => {
    await client.query(`UPDATE wh_adjustments SET status = 'rejected', decided_at = now(), rejection_reason = $2 WHERE id = $1`, [id, comment]);
  },
});

const ADJUSTMENT_REASONS = ['count_variance', 'damage', 'pest', 'moisture_loss', 'sampling', 'data_correction', 'other'] as const;

export async function proposeAdjustmentTx(
  client: PoolClient,
  p: { lotId: string; locationId: string; change: number; reason: (typeof ADJUSTMENT_REASONS)[number]; details: string; countId?: string | null },
  user: AuthenticatedUser,
) {
  const lot = await assertSeedLotExists(client, p.lotId);
  if (p.change < 0) {
    const have = await stockAt(client, p.lotId, p.locationId);
    if (have + p.change < -0.005) throw new ConflictError(`Only ${have} kg of ${lot.lot_code} is at that location`);
  }
  const code = await nextCode(client, 'ADJ', 5, true);
  const r = await client.query(
    `INSERT INTO wh_adjustments (adjustment_number, seed_lot_id, location_id, quantity_change, reason, details, count_id, created_by) VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *`,
    [code, p.lotId, p.locationId, round2(p.change), p.reason, p.details, p.countId ?? null, user.email],
  );
  await submitForApprovalTx(client, { entityType: 'stock_adjustment', entityId: r.rows[0].id, entityCode: code, title: `${lot.lot_code}: ${p.change > 0 ? '+' : ''}${round2(p.change)} kg (${p.reason.replace('_', ' ')})` }, user);
  return r.rows[0];
}

export async function proposeAdjustment(input: Record<string, unknown>, user: AuthenticatedUser) {
  const change = requireNumber(input.quantityChange, 'quantityChange');
  if (change === 0) throw new ValidationError('quantityChange cannot be zero');
  const p = {
    lotId: requireUuid(input.seedLotId, 'seedLotId'),
    locationId: requireUuid(input.locationId, 'locationId'),
    change,
    reason: requireEnum(input.reason, ADJUSTMENT_REASONS, 'reason'),
    details: requireText(input.details, 'details', 1000),
  };
  return withTransaction((client) => proposeAdjustmentTx(client, p, user));
}

export async function listAdjustments(filters: { status?: string }) {
  const values: unknown[] = [];
  let where = '';
  if (filters.status) {
    values.push(filters.status);
    where = 'WHERE a.status = $1';
  }
  const r = await pool.query(
    `SELECT a.*, l.lot_code, l.variety, loc.code AS location_code, c.count_number
       FROM wh_adjustments a JOIN seed_lots l ON l.id = a.seed_lot_id JOIN wh_locations loc ON loc.id = a.location_id
       LEFT JOIN wh_counts c ON c.id = a.count_id ${where} ORDER BY a.created_at DESC LIMIT 500`,
    values,
  );
  return r.rows;
}

// --------------------------------------------------------------- cycle counts

export async function createCount(input: Record<string, unknown>, user: AuthenticatedUser) {
  const warehouseId = requireUuid(input.warehouseId, 'warehouseId');
  const zone = optionalText(input.zone, 'zone', 60);
  const scheduledFor = optionalDate(input.scheduledFor, 'scheduledFor') ?? new Date().toISOString().slice(0, 10);
  return withTransaction(async (client) => {
    const open = await client.query(`SELECT count_number FROM wh_counts WHERE warehouse_id = $1 AND status = 'open' AND COALESCE(zone, '') = COALESCE($2, '')`, [warehouseId, zone]);
    if (open.rows[0]) throw new ConflictError(`Count ${open.rows[0].count_number} is already open for this area`);
    const code = await nextCode(client, 'CNT', 4, true);
    const c = await client.query(`INSERT INTO wh_counts (count_number, warehouse_id, zone, scheduled_for, created_by) VALUES ($1, $2, $3, $4, $5) RETURNING *`, [code, warehouseId, zone, scheduledFor, user.email]);
    const lines = await client.query(
      `INSERT INTO wh_count_lines (count_id, seed_lot_id, location_id, system_kg)
       SELECT $1, s.seed_lot_id, s.location_id, s.quantity_kg FROM wh_stock s JOIN wh_locations l ON l.id = s.location_id
        WHERE s.warehouse_id = $2 AND ($3::text IS NULL OR l.zone = $3) RETURNING id`,
      [c.rows[0].id, warehouseId, zone],
    );
    if (!lines.rows.length) throw new ConflictError('There is no stock in that area to count');
    await insertAuditLog(client, { entityType: 'wh_count', entityId: c.rows[0].id, action: 'CREATE', performedBy: user.email, metadata: { lines: lines.rows.length } });
    return getCount(c.rows[0].id, client);
  });
}

export async function recordCountLines(id: string, input: Record<string, unknown>, user: AuthenticatedUser) {
  const lines = requireArray(input.lines, 'lines', { min: 1, max: 500 }).map((raw, i) => {
    const r = asRecord(raw, `lines[${i}]`);
    return { lineId: requireUuid(r.lineId, `lines[${i}].lineId`), countedKg: requireNumber(r.countedKg, `lines[${i}].countedKg`, { min: 0 }) };
  });
  return withTransaction(async (client) => {
    const c = await client.query('SELECT status FROM wh_counts WHERE id = $1 FOR UPDATE', [id]);
    if (!c.rows[0]) throw new NotFoundError('Count not found');
    if (c.rows[0].status !== 'open') throw new ConflictError('This count is no longer open');
    for (const l of lines) {
      const r = await client.query('UPDATE wh_count_lines SET counted_kg = $2, counted_by = $3, counted_at = now() WHERE id = $1 AND count_id = $4 RETURNING id', [l.lineId, l.countedKg, user.email, id]);
      if (!r.rows[0]) throw new ValidationError('A line does not belong to this count');
    }
    return getCount(id, client);
  });
}

/**
 * Submitting a count turns each variance into a stock adjustment that waits
 * for the warehouse manager — the counter never writes stock off directly.
 * The variance is against stock at submission, so movements during the
 * count are not double-adjusted.
 */
export async function submitCount(id: string, user: AuthenticatedUser) {
  return withTransaction(async (client) => {
    const c = await client.query('SELECT * FROM wh_counts WHERE id = $1 FOR UPDATE', [id]);
    const count = c.rows[0];
    if (!count) throw new NotFoundError('Count not found');
    if (count.status !== 'open') throw new ConflictError('This count is no longer open');
    const lines = await client.query('SELECT * FROM wh_count_lines WHERE count_id = $1', [id]);
    const uncounted = lines.rows.filter((l) => l.counted_kg === null);
    if (uncounted.length) throw new ConflictError(`${uncounted.length} line(s) are not counted yet`);
    const adjustments = [];
    for (const l of lines.rows) {
      const now = await stockAt(client, l.seed_lot_id, l.location_id);
      const variance = round2(num(l.counted_kg) - now);
      if (Math.abs(variance) >= 0.01) {
        adjustments.push(await proposeAdjustmentTx(client, { lotId: l.seed_lot_id, locationId: l.location_id, change: variance, reason: 'count_variance', details: `Cycle count ${count.count_number}: counted ${num(l.counted_kg)} kg, system ${now} kg`, countId: id }, user));
      }
    }
    await client.query(`UPDATE wh_counts SET status = 'submitted', submitted_by = $2, submitted_at = now() WHERE id = $1`, [id, user.email]);
    await insertAuditLog(client, { entityType: 'wh_count', entityId: id, action: 'SUBMIT', performedBy: user.email, metadata: { variances: adjustments.length } });
    return { count: await getCount(id, client), adjustments };
  });
}

export async function listCounts() {
  const r = await pool.query(
    `SELECT c.*, w.code AS warehouse_code, (SELECT COUNT(*)::int FROM wh_count_lines l WHERE l.count_id = c.id) AS line_count,
            (SELECT COUNT(*)::int FROM wh_count_lines l WHERE l.count_id = c.id AND l.counted_kg IS NOT NULL) AS counted
       FROM wh_counts c JOIN wh_warehouses w ON w.id = c.warehouse_id ORDER BY c.created_at DESC LIMIT 200`,
  );
  return r.rows;
}

export async function getCount(id: string, client?: PoolClient) {
  const db = client ?? pool;
  const c = await db.query('SELECT c.*, w.code AS warehouse_code FROM wh_counts c JOIN wh_warehouses w ON w.id = c.warehouse_id WHERE c.id = $1', [id]);
  if (!c.rows[0]) throw new NotFoundError('Count not found');
  const lines = await db.query(
    `SELECT cl.*, l.lot_code, l.variety, loc.code AS location_code, loc.zone FROM wh_count_lines cl
       JOIN seed_lots l ON l.id = cl.seed_lot_id JOIN wh_locations loc ON loc.id = cl.location_id WHERE cl.count_id = $1 ORDER BY loc.code, l.lot_code`,
    [id],
  );
  const adjustments = await db.query('SELECT id, adjustment_number, status, quantity_change, seed_lot_id FROM wh_adjustments WHERE count_id = $1', [id]);
  return { ...c.rows[0], lines: lines.rows, adjustments: adjustments.rows };
}

// ---------------------------------------------------------------- inquiries

export async function stockOnHand(filters: { warehouseId?: string; q?: string; status?: string }) {
  const where: string[] = [];
  const values: unknown[] = [];
  if (filters.warehouseId) {
    values.push(filters.warehouseId);
    where.push(`s.warehouse_id = $${values.length}`);
  }
  if (filters.q) {
    values.push(`%${filters.q.toLowerCase()}%`);
    where.push(`(LOWER(l.lot_code) LIKE $${values.length} OR LOWER(l.variety) LIKE $${values.length} OR LOWER(l.crop) LIKE $${values.length})`);
  }
  const r = await pool.query(
    `SELECT l.id AS seed_lot_id, l.lot_code, l.crop, l.variety, l.stage, l.production_date, l.notes ILIKE '%TREATED SEED%' AS is_treated,
            SUM(s.quantity_kg) AS quantity_kg, SUM(s.bags) AS bags,
            json_agg(json_build_object('location_id', s.location_id, 'location_code', loc.code, 'zone', loc.zone, 'location_type', loc.location_type, 'warehouse_code', w.code, 'quantity_kg', s.quantity_kg) ORDER BY loc.code) AS locations
       FROM wh_stock s JOIN seed_lots l ON l.id = s.seed_lot_id JOIN wh_locations loc ON loc.id = s.location_id JOIN wh_warehouses w ON w.id = s.warehouse_id
       ${where.length ? `WHERE ${where.join(' AND ')}` : ''}
      GROUP BY l.id ORDER BY l.crop, l.variety, l.lot_code`,
    values,
  );
  const info = await lotSaleInfo(pool, r.rows.map((x) => x.seed_lot_id));
  const rows = r.rows.map((x) => ({ ...x, ...info.get(x.seed_lot_id)! }));
  return filters.status ? rows.filter((x) => x.status === filters.status) : rows;
}

export async function lotStock(lotId: string) {
  const lot = await pool.query('SELECT id, lot_code, crop, variety, stage, quantity_total, production_date, notes FROM seed_lots WHERE id = $1', [lotId]);
  if (!lot.rows[0]) throw new NotFoundError('Seed lot not found');
  const locations = await pool.query(
    `SELECT s.location_id, s.quantity_kg, s.bags, loc.code AS location_code, loc.zone, loc.location_type, w.code AS warehouse_code
       FROM wh_stock s JOIN wh_locations loc ON loc.id = s.location_id JOIN wh_warehouses w ON w.id = s.warehouse_id WHERE s.seed_lot_id = $1`,
    [lotId],
  );
  const moves = await pool.query(
    `SELECT m.*, loc.code AS location_code FROM wh_stock_moves m JOIN wh_locations loc ON loc.id = m.location_id WHERE m.seed_lot_id = $1 ORDER BY m.created_at DESC LIMIT 200`,
    [lotId],
  );
  const tests = await pool.query('SELECT * FROM wh_lot_tests WHERE seed_lot_id = $1 ORDER BY tested_on DESC', [lotId]);
  const info = (await lotSaleInfo(pool, [lotId])).get(lotId)!;
  return { lot: lot.rows[0], sale: info, locations: locations.rows, moves: moves.rows, externalTests: tests.rows };
}

export async function listMovements(filters: { lotId?: string; type?: string; limit?: number }) {
  const where: string[] = [];
  const values: unknown[] = [];
  if (filters.lotId) {
    values.push(filters.lotId);
    where.push(`m.seed_lot_id = $${values.length}`);
  }
  if (filters.type) {
    values.push(filters.type);
    where.push(`m.move_type = $${values.length}`);
  }
  values.push(Math.min(filters.limit ?? 300, 1000));
  const r = await pool.query(
    `SELECT m.*, l.lot_code, l.variety, loc.code AS location_code, w.code AS warehouse_code
       FROM wh_stock_moves m JOIN seed_lots l ON l.id = m.seed_lot_id JOIN wh_locations loc ON loc.id = m.location_id JOIN wh_warehouses w ON w.id = loc.warehouse_id
       ${where.length ? `WHERE ${where.join(' AND ')}` : ''} ORDER BY m.created_at DESC LIMIT $${values.length}`,
    values,
  );
  return r.rows;
}

/** A germination report from outside the lab module (e.g. the state seed testing laboratory). */
export async function recordLotTest(input: Record<string, unknown>, user: AuthenticatedUser) {
  const lotId = requireUuid(input.seedLotId, 'seedLotId');
  const testedOn = requireDate(input.testedOn, 'testedOn');
  if (testedOn > new Date().toISOString().slice(0, 10)) throw new ValidationError('testedOn cannot be in the future');
  const germ = requireNumber(input.germinationPct, 'germinationPct', { min: 0, max: 100 });
  const min = requireNumber(input.minGerminationPct, 'minGerminationPct', { min: 0, max: 100 });
  const months = optionalNumber(input.validityMonths, 'validityMonths', { min: 1, max: 24 }) ?? VALIDITY_MONTHS;
  return withTransaction(async (client) => {
    await assertSeedLotExists(client, lotId);
    const r = await client.query(
      `INSERT INTO wh_lot_tests (seed_lot_id, tested_on, germination_pct, min_germination_pct, passed, laboratory, report_number, valid_until, recorded_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9) RETURNING *`,
      [lotId, testedOn, germ, min, germ >= min, requireText(input.laboratory, 'laboratory', 150), optionalText(input.reportNumber, 'reportNumber', 60), addMonths(testedOn, months), user.email],
    );
    await insertAuditLog(client, { entityType: 'seed_lot', entityId: lotId, action: 'TEST_RECORDED', performedBy: user.email, afterState: r.rows[0] });
    return r.rows[0];
  });
}

export async function adjustmentApprovals(id: string) {
  return getApprovalsForEntity('stock_adjustment', id);
}

