import type { PoolClient } from 'pg';
import { pool } from '../../db/pool';
import { withTransaction } from '../../db/transaction';
import { ConflictError, NotFoundError, ValidationError } from '../../errors';
import type { AuthenticatedUser } from '../../middleware/requireAuth';
import { getApprovalsForEntity, registerApprovalHandler, submitForApprovalTx, withdrawTx } from '../approvals/approvals.service';
import { queueMessageTx } from '../reach/messaging.service';
import { insertAuditLog } from '../auditLogs/auditLogs.service';
import { registerInspectionSubject } from '../inspections/inspections.service';
import { assertPartyUsable } from '../parties/parties.service';
import { createComplaint } from '../quality/complaints.service';
import {
  asRecord,
  assertSeedLotExists,
  nextCode,
  num,
  optionalNumber,
  optionalText,
  optionalUuid,
  requireArray,
  requireDate,
  requireEnum,
  requireNumber,
  requireText,
  requireUuid,
  round2,
} from '../shared/validate';
import { assertLotSaleable, lotSaleInfo, moveTx, reservedAt, stockAt } from './stock.service';

const DEALER_TYPES = ['dealer', 'distributor', 'customer'] as const;

registerApprovalHandler('dispatch_order', {
  onApproved: async (client, id) => {
    await client.query(`UPDATE wh_dispatches SET status = 'approved' WHERE id = $1`, [id]);
  },
  onRejected: async (client, id, _user, comment) => {
    await client.query(`UPDATE wh_dispatches SET status = 'rejected', rejection_reason = $2 WHERE id = $1`, [id, comment]);
  },
});

interface DispatchLineInput {
  seedLotId: string;
  locationId: string;
  quantityKg: number;
  bags: number | null;
}

function parseLines(value: unknown): DispatchLineInput[] {
  return requireArray(value, 'lines', { min: 1, max: 100 }).map((raw, i) => {
    const r = asRecord(raw, `lines[${i}]`);
    return {
      seedLotId: requireUuid(r.seedLotId, `lines[${i}].seedLotId`),
      locationId: requireUuid(r.locationId, `lines[${i}].locationId`),
      quantityKg: requireNumber(r.quantityKg, `lines[${i}].quantityKg`, { positive: true }),
      bags: optionalNumber(r.bags, `lines[${i}].bags`, { positive: true }),
    };
  });
}

/**
 * Every line must be seed that may be sold today, at a location in the
 * dispatching warehouse, with enough free stock. Returns first-expiry-first-out
 * advice: older-expiring saleable lots of the same variety in this warehouse.
 */
async function validateLines(client: PoolClient, warehouseId: string, lines: DispatchLineInput[], excludeDispatchId: string | null) {
  const warnings: string[] = [];
  const perKey = new Map<string, number>();
  for (const l of lines) perKey.set(`${l.seedLotId}|${l.locationId}`, (perKey.get(`${l.seedLotId}|${l.locationId}`) ?? 0) + l.quantityKg);
  for (const [key, kg] of perKey.entries()) {
    const [lotId, locationId] = key.split('|');
    const lot = await assertSeedLotExists(client, lotId);
    const loc = await client.query('SELECT warehouse_id, location_type, code FROM wh_locations WHERE id = $1', [locationId]);
    if (!loc.rows[0]) throw new NotFoundError('Location not found');
    if (loc.rows[0].warehouse_id !== warehouseId) throw new ValidationError(`${loc.rows[0].code} is not in the dispatching warehouse`);
    if (loc.rows[0].location_type === 'quarantine') throw new ConflictError(`${lot.lot_code}: stock in quarantine cannot be dispatched`);
    const info = await assertLotSaleable(client, lotId, lot.lot_code);
    const free = (await stockAt(client, lotId, locationId)) - (await reservedAt(client, lotId, locationId, excludeDispatchId));
    if (kg > free + 0.005) throw new ConflictError(`${lot.lot_code} at ${loc.rows[0].code}: only ${round2(free)} kg is free`);
    const variety = await client.query<{ variety: string }>('SELECT variety FROM seed_lots WHERE id = $1', [lotId]);
    const older = await client.query<{ seed_lot_id: string; lot_code: string }>(
      `SELECT DISTINCT s.seed_lot_id, l.lot_code FROM wh_stock s JOIN seed_lots l ON l.id = s.seed_lot_id JOIN wh_locations loc ON loc.id = s.location_id
        WHERE s.warehouse_id = $1 AND l.variety = $2 AND s.seed_lot_id <> $3 AND loc.location_type <> 'quarantine'`,
      [warehouseId, variety.rows[0].variety, lotId],
    );
    if (older.rows.length && info.valid_until) {
      const others = await lotSaleInfo(client, older.rows.map((o) => o.seed_lot_id));
      for (const o of older.rows) {
        const oi = others.get(o.seed_lot_id)!;
        if ((oi.status === 'sellable' || oi.status === 'retest_due') && oi.valid_until && oi.valid_until < info.valid_until) {
          warnings.push(`First-expiry-first-out: ${o.lot_code} (valid until ${oi.valid_until}) expires before ${lot.lot_code} (${info.valid_until})`);
        }
      }
    }
  }
  return warnings;
}

async function lock(client: PoolClient, id: string) {
  const r = await client.query('SELECT * FROM wh_dispatches WHERE id = $1 FOR UPDATE', [id]);
  if (!r.rows[0]) throw new NotFoundError('Dispatch not found');
  return r.rows[0];
}

export async function createDispatch(input: Record<string, unknown>, user: AuthenticatedUser) {
  const dealerId = requireUuid(input.dealerId, 'dealerId');
  const warehouseId = requireUuid(input.warehouseId, 'warehouseId');
  const requestedDate = requireDate(input.requestedDate, 'requestedDate');
  const transporterId = optionalUuid(input.transporterId, 'transporterId');
  const lines = parseLines(input.lines);
  return withTransaction(async (client) => {
    await assertPartyUsable(client, dealerId, [...DEALER_TYPES], 'a dispatch');
    if (transporterId) await assertPartyUsable(client, transporterId, ['transporter'], 'transport');
    const w = await client.query('SELECT status FROM wh_warehouses WHERE id = $1', [warehouseId]);
    if (!w.rows[0] || w.rows[0].status !== 'active') throw new ConflictError('Choose an active warehouse');
    const warnings = await validateLines(client, warehouseId, lines, null);
    const code = await nextCode(client, 'DSP', 5, true);
    const d = await client.query(
      `INSERT INTO wh_dispatches (dispatch_number, dealer_id, warehouse_id, requested_date, transporter_id, invoice_reference, notes, created_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *`,
      [code, dealerId, warehouseId, requestedDate, transporterId, optionalText(input.invoiceReference, 'invoiceReference', 60), optionalText(input.notes, 'notes', 2000), user.email],
    );
    for (const l of lines) {
      await client.query('INSERT INTO wh_dispatch_lines (dispatch_id, seed_lot_id, location_id, quantity_kg, bags) VALUES ($1, $2, $3, $4, $5)', [d.rows[0].id, l.seedLotId, l.locationId, l.quantityKg, l.bags]);
    }
    await insertAuditLog(client, { entityType: 'dispatch_order', entityId: d.rows[0].id, action: 'CREATE', performedBy: user.email, afterState: { ...d.rows[0], lines } });
    return { ...(await getDispatch(d.rows[0].id, client)), warnings };
  });
}

export async function submitDispatch(id: string, user: AuthenticatedUser) {
  return withTransaction(async (client) => {
    const d = await lock(client, id);
    if (d.status !== 'draft' && d.status !== 'rejected') throw new ConflictError(`Only a draft dispatch can be submitted (this one is ${d.status})`);
    const lines = await client.query('SELECT seed_lot_id, location_id, quantity_kg, bags FROM wh_dispatch_lines WHERE dispatch_id = $1', [id]);
    await validateLines(client, d.warehouse_id, lines.rows.map((l) => ({ seedLotId: l.seed_lot_id, locationId: l.location_id, quantityKg: num(l.quantity_kg), bags: l.bags })), id);
    const dealer = await assertPartyUsable(client, d.dealer_id, [...DEALER_TYPES], 'a dispatch');
    const kg = round2(lines.rows.reduce((s, l) => s + num(l.quantity_kg), 0));
    await client.query(`UPDATE wh_dispatches SET status = 'pending_approval', rejection_reason = NULL WHERE id = $1`, [id]);
    await submitForApprovalTx(client, { entityType: 'dispatch_order', entityId: id, entityCode: d.dispatch_number, title: `${dealer.name} · ${kg} kg` }, user);
    return getDispatch(id, client);
  });
}

/**
 * Shipping re-checks everything: a lot put on hold, or whose validity lapsed,
 * after the order was approved must not leave the gate.
 */
export async function shipDispatch(id: string, input: Record<string, unknown>, user: AuthenticatedUser) {
  const vehicle = requireText(input.vehicleNumber, 'vehicleNumber', 20).toUpperCase().replace(/\s+/g, '');
  return withTransaction(async (client) => {
    const d = await lock(client, id);
    if (d.status !== 'approved') throw new ConflictError(`Only an approved dispatch can be shipped (this one is ${d.status})`);
    await assertPartyUsable(client, d.dealer_id, [...DEALER_TYPES], 'a dispatch');
    const lines = await client.query('SELECT * FROM wh_dispatch_lines WHERE dispatch_id = $1', [id]);
    await validateLines(client, d.warehouse_id, lines.rows.map((l) => ({ seedLotId: l.seed_lot_id, locationId: l.location_id, quantityKg: num(l.quantity_kg), bags: l.bags })), id);
    for (const l of lines.rows) {
      await moveTx(client, { lotId: l.seed_lot_id, locationId: l.location_id, kg: -num(l.quantity_kg), bags: l.bags ? -l.bags : null, type: 'dispatch', refType: 'dispatch_order', refId: id, refCode: d.dispatch_number }, user);
    }
    await client.query(
      `UPDATE wh_dispatches SET status = 'dispatched', vehicle_number = $2, lr_number = $3, eway_bill_number = $4, invoice_reference = COALESCE($5, invoice_reference), dispatched_at = now(), dispatched_by = $6 WHERE id = $1`,
      [id, vehicle, optionalText(input.lrNumber, 'lrNumber', 40), optionalText(input.ewayBillNumber, 'ewayBillNumber', 20), optionalText(input.invoiceReference, 'invoiceReference', 60), user.email],
    );
    await insertAuditLog(client, { entityType: 'dispatch_order', entityId: id, action: 'SHIP', performedBy: user.email, metadata: { vehicle } });
    const lotList = await client.query(`SELECT string_agg(DISTINCT sl.crop || ' ' || sl.variety, ', ') AS lots FROM wh_dispatch_lines l JOIN seed_lots sl ON sl.id = l.seed_lot_id WHERE l.dispatch_id = $1`, [id]);
    await queueMessageTx(client, { partyId: d.dealer_id, template: 'dispatch_shipped', vars: { number: d.dispatch_number, lots: lotList.rows[0].lots, vehicle }, relatedType: 'dispatch_order', relatedId: id, createdBy: user.email });
    return getDispatch(id, client);
  });
}

export async function confirmDelivery(id: string, input: Record<string, unknown>, user: AuthenticatedUser) {
  const receivedBy = requireText(input.receivedByName, 'receivedByName', 150);
  return withTransaction(async (client) => {
    const d = await lock(client, id);
    if (d.status !== 'dispatched') throw new ConflictError('Only a dispatched order can be marked delivered');
    await client.query(`UPDATE wh_dispatches SET status = 'delivered', delivered_at = now(), received_by_name = $2 WHERE id = $1`, [id, receivedBy]);
    await insertAuditLog(client, { entityType: 'dispatch_order', entityId: id, action: 'DELIVERED', performedBy: user.email, metadata: { receivedBy } });
    return getDispatch(id, client);
  });
}

export async function cancelDispatch(id: string, input: Record<string, unknown>, user: AuthenticatedUser) {
  const reason = requireText(input.reason, 'reason', 1000);
  return withTransaction(async (client) => {
    const d = await lock(client, id);
    if (!['draft', 'pending_approval', 'approved', 'rejected'].includes(d.status)) throw new ConflictError(`A ${d.status} dispatch cannot be cancelled`);
    await withdrawTx(client, 'dispatch_order', id, user);
    await client.query(`UPDATE wh_dispatches SET status = 'cancelled', cancel_reason = $2 WHERE id = $1`, [id, reason]);
    await insertAuditLog(client, { entityType: 'dispatch_order', entityId: id, action: 'CANCEL', performedBy: user.email, metadata: { reason } });
    return getDispatch(id, client);
  });
}

export async function listDispatches(filters: { status?: string; dealerId?: string }) {
  const where: string[] = [];
  const values: unknown[] = [];
  if (filters.status) {
    values.push(filters.status);
    where.push(`d.status = $${values.length}`);
  }
  if (filters.dealerId) {
    values.push(filters.dealerId);
    where.push(`d.dealer_id = $${values.length}`);
  }
  const r = await pool.query(
    `SELECT d.*, p.name AS dealer_name, p.party_code AS dealer_code, w.code AS warehouse_code,
            (SELECT SUM(quantity_kg) FROM wh_dispatch_lines l WHERE l.dispatch_id = d.id) AS total_kg,
            (SELECT string_agg(DISTINCT sl.lot_code, ', ') FROM wh_dispatch_lines l JOIN seed_lots sl ON sl.id = l.seed_lot_id WHERE l.dispatch_id = d.id) AS lots
       FROM wh_dispatches d JOIN parties p ON p.id = d.dealer_id JOIN wh_warehouses w ON w.id = d.warehouse_id
       ${where.length ? `WHERE ${where.join(' AND ')}` : ''} ORDER BY d.created_at DESC LIMIT 500`,
    values,
  );
  return r.rows;
}

export async function getDispatch(id: string, client?: PoolClient) {
  const db = client ?? pool;
  const r = await db.query(
    `SELECT d.*, p.name AS dealer_name, p.party_code AS dealer_code, p.licence_number AS dealer_licence, p.licence_valid_until AS dealer_licence_valid_until,
            p.village AS dealer_town, p.district AS dealer_district, p.phone AS dealer_phone, w.code AS warehouse_code, w.name AS warehouse_name, t.name AS transporter_name
       FROM wh_dispatches d JOIN parties p ON p.id = d.dealer_id JOIN wh_warehouses w ON w.id = d.warehouse_id LEFT JOIN parties t ON t.id = d.transporter_id WHERE d.id = $1`,
    [id],
  );
  if (!r.rows[0]) throw new NotFoundError('Dispatch not found');
  const lines = await db.query(
    `SELECT dl.*, sl.lot_code, sl.crop, sl.variety, sl.stage, loc.code AS location_code, sl.notes ILIKE '%TREATED SEED%' AS is_treated
       FROM wh_dispatch_lines dl JOIN seed_lots sl ON sl.id = dl.seed_lot_id JOIN wh_locations loc ON loc.id = dl.location_id WHERE dl.dispatch_id = $1`,
    [id],
  );
  const info = await lotSaleInfo(db, lines.rows.map((l) => l.seed_lot_id));
  const approvals = await getApprovalsForEntity('dispatch_order', id, client);
  return { ...r.rows[0], lines: lines.rows.map((l) => ({ ...l, sale: info.get(l.seed_lot_id) })), approvals };
}

/** Which dealers hold a lot — the recall list. */
export async function lotRecipients(lotId: string) {
  const r = await pool.query(
    `SELECT p.id AS dealer_id, p.party_code, p.name, p.phone, p.village, p.district, p.preferred_language,
            SUM(dl.quantity_kg) AS dispatched_kg, MAX(d.dispatched_at) AS last_dispatched_at,
            COALESCE((SELECT SUM(rt.quantity_kg) FROM wh_returns rt WHERE rt.seed_lot_id = $1 AND rt.dealer_id = p.id), 0) AS returned_kg,
            string_agg(DISTINCT d.dispatch_number, ', ') AS dispatches
       FROM wh_dispatch_lines dl JOIN wh_dispatches d ON d.id = dl.dispatch_id JOIN parties p ON p.id = d.dealer_id
      WHERE dl.seed_lot_id = $1 AND d.status IN ('dispatched', 'delivered')
      GROUP BY p.id ORDER BY p.name`,
    [lotId],
  );
  return r.rows;
}

// --------------------------------------------------------------- returns

registerInspectionSubject('stock_return', {
  resolveSubject: async (client, id) => {
    const r = await client.query(
      `SELECT rt.return_number, rt.status, rt.seed_lot_id, rt.quantity_kg, sl.lot_code, p.name FROM wh_returns rt
         JOIN seed_lots sl ON sl.id = rt.seed_lot_id JOIN parties p ON p.id = rt.dealer_id WHERE rt.id = $1`,
      [id],
    );
    const x = r.rows[0];
    if (!x) throw new NotFoundError('Return not found');
    if (x.status !== 'quarantined' && x.status !== 'retest') throw new ConflictError(`${x.return_number} is already ${x.status}`);
    return { label: `${x.return_number} · ${x.lot_code} · ${num(x.quantity_kg)} kg from ${x.name}`, seedLotId: x.seed_lot_id };
  },
  onSubmitted: async (client, ins) => {
    await client.query(`UPDATE wh_returns SET status = 'inspected', inspection_id = $2 WHERE id = $1`, [ins.subject_id, ins.id]);
  },
});

const RETURN_REASONS = ['damaged', 'expired', 'unsold', 'quality_complaint', 'wrong_supply'] as const;

export async function logReturn(input: Record<string, unknown>, user: AuthenticatedUser) {
  const dealerId = requireUuid(input.dealerId, 'dealerId');
  const dispatchId = optionalUuid(input.dispatchId, 'dispatchId');
  const lotId = requireUuid(input.seedLotId, 'seedLotId');
  const qLoc = requireUuid(input.quarantineLocationId, 'quarantineLocationId');
  const kg = requireNumber(input.quantityKg, 'quantityKg', { positive: true });
  const reason = requireEnum(input.reason, RETURN_REASONS, 'reason');
  const details = reason === 'quality_complaint' ? requireText(input.details, 'details (what the dealer or farmer reported)', 2000) : optionalText(input.details, 'details', 2000);

  const created = await withTransaction(async (client) => {
    const lot = await assertSeedLotExists(client, lotId);
    const loc = await client.query('SELECT location_type FROM wh_locations WHERE id = $1', [qLoc]);
    if (!loc.rows[0] || loc.rows[0].location_type !== 'quarantine') throw new ValidationError('Returned stock goes into a quarantine location');
    const dealer = await client.query('SELECT name FROM parties WHERE id = $1', [dealerId]);
    if (!dealer.rows[0]) throw new NotFoundError('Dealer not found');
    // a return can never exceed what this dealer was sent of this lot
    const sent = await client.query<{ kg: number | null }>(
      `SELECT SUM(dl.quantity_kg) AS kg FROM wh_dispatch_lines dl JOIN wh_dispatches d ON d.id = dl.dispatch_id
        WHERE dl.seed_lot_id = $1 AND d.dealer_id = $2 AND d.status IN ('dispatched', 'delivered') AND ($3::uuid IS NULL OR d.id = $3)`,
      [lotId, dealerId, dispatchId],
    );
    const back = await client.query<{ kg: number | null }>('SELECT SUM(quantity_kg) AS kg FROM wh_returns WHERE seed_lot_id = $1 AND dealer_id = $2 AND ($3::uuid IS NULL OR dispatch_id = $3)', [lotId, dealerId, dispatchId]);
    const open = num(sent.rows[0].kg) - num(back.rows[0].kg);
    if (kg > open + 0.005) throw new ConflictError(`${dealer.rows[0].name} was sent ${num(sent.rows[0].kg)} kg of ${lot.lot_code}; ${round2(open)} kg can still be returned`);
    const code = await nextCode(client, 'RTN', 5, true);
    const r = await client.query(
      `INSERT INTO wh_returns (return_number, dealer_id, dispatch_id, seed_lot_id, quarantine_location_id, quantity_kg, reason, details, created_by) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9) RETURNING *`,
      [code, dealerId, dispatchId, lotId, qLoc, kg, reason, details, user.email],
    );
    await moveTx(client, { lotId, locationId: qLoc, kg, type: 'return', refType: 'stock_return', refId: r.rows[0].id, refCode: code, reason }, user);
    await insertAuditLog(client, { entityType: 'stock_return', entityId: r.rows[0].id, action: 'CREATE', performedBy: user.email, afterState: r.rows[0] });
    return { row: r.rows[0], lotCode: lot.lot_code, dealerName: dealer.rows[0].name };
  });

  // A quality complaint enters the quality module's complaint pipeline
  // (major complaints raise a non-conformance automatically).
  if (reason === 'quality_complaint') {
    const c = await createComplaint(
      {
        source: 'dealer',
        complainantName: created.dealerName,
        title: `Return ${created.row.return_number}: ${created.lotCode}`,
        description: details ?? 'Quality complaint with returned stock',
        severity: input.complaintSeverity === 'critical' || input.complaintSeverity === 'minor' ? input.complaintSeverity : 'major',
        seedLotId: lotId,
      },
      user,
    );
    await pool.query('UPDATE wh_returns SET complaint_id = $2 WHERE id = $1', [created.row.id, c.complaint.id]);
  }
  return getReturn(created.row.id);
}

/**
 * The warehouse manager decides what happens to returned stock after it has
 * been inspected: restock (only if the inspection passed and the lot is
 * still saleable), keep for retest, or destroy.
 */
export async function decideReturn(id: string, input: Record<string, unknown>, user: AuthenticatedUser) {
  const disposition = requireEnum(input.disposition, ['restock', 'retest', 'destroy'] as const, 'disposition');
  const note = requireText(input.note, 'note', 1000);
  const credit = optionalNumber(input.creditNoteAmount, 'creditNoteAmount', { min: 0 });
  return withTransaction(async (client) => {
    const r = await client.query('SELECT * FROM wh_returns WHERE id = $1 FOR UPDATE', [id]);
    const ret = r.rows[0];
    if (!ret) throw new NotFoundError('Return not found');
    if (ret.status !== 'inspected') throw new ConflictError(ret.status === 'quarantined' || ret.status === 'retest' ? 'Inspect the returned stock before deciding' : `This return is already ${ret.status}`);
    const lot = await assertSeedLotExists(client, ret.seed_lot_id);
    const have = await stockAt(client, ret.seed_lot_id, ret.quarantine_location_id);
    const kg = Math.min(num(ret.quantity_kg), have);
    if (disposition === 'restock') {
      const ins = await client.query('SELECT result, decision FROM inspections WHERE id = $1', [ret.inspection_id]);
      if (ins.rows[0]?.result === 'fail' || !['accept', 'partial_accept'].includes(ins.rows[0]?.decision)) throw new ConflictError('The return inspection did not accept this stock; it cannot go back on sale');
      await assertLotSaleable(client, ret.seed_lot_id, lot.lot_code);
      const to = requireUuid(input.toLocationId, 'toLocationId');
      const loc = await client.query('SELECT location_type, status FROM wh_locations WHERE id = $1', [to]);
      if (!loc.rows[0] || loc.rows[0].status !== 'active' || loc.rows[0].location_type === 'quarantine') throw new ValidationError('Restock into an active, non-quarantine location');
      await moveTx(client, { lotId: ret.seed_lot_id, locationId: ret.quarantine_location_id, kg: -kg, type: 'restock_out', refType: 'stock_return', refId: id, refCode: ret.return_number }, user);
      await moveTx(client, { lotId: ret.seed_lot_id, locationId: to, kg, type: 'restock_in', refType: 'stock_return', refId: id, refCode: ret.return_number }, user);
    } else if (disposition === 'destroy') {
      if (kg > 0) await moveTx(client, { lotId: ret.seed_lot_id, locationId: ret.quarantine_location_id, kg: -kg, type: 'disposal', refType: 'stock_return', refId: id, refCode: ret.return_number, reason: note }, user);
    }
    const status = disposition === 'restock' ? 'restocked' : disposition === 'destroy' ? 'destroyed' : 'retest';
    await client.query(`UPDATE wh_returns SET status = $2, disposition_note = $3, credit_note_amount = $4, decided_by = $5, decided_at = now() WHERE id = $1`, [id, status, note, credit, user.email]);
    await insertAuditLog(client, { entityType: 'stock_return', entityId: id, action: 'DISPOSITION', performedBy: user.email, metadata: { disposition, note, kg } });
    return getReturn(id, client);
  });
}

export async function listReturns(filters: { status?: string }) {
  const values: unknown[] = [];
  let where = '';
  if (filters.status) {
    values.push(filters.status);
    where = 'WHERE rt.status = $1';
  }
  const r = await pool.query(
    `SELECT rt.*, sl.lot_code, sl.variety, p.name AS dealer_name, d.dispatch_number, i.inspection_code, i.result AS inspection_result, c.complaint_code
       FROM wh_returns rt JOIN seed_lots sl ON sl.id = rt.seed_lot_id JOIN parties p ON p.id = rt.dealer_id
       LEFT JOIN wh_dispatches d ON d.id = rt.dispatch_id LEFT JOIN inspections i ON i.id = rt.inspection_id LEFT JOIN quality_complaints c ON c.id = rt.complaint_id
       ${where} ORDER BY rt.created_at DESC LIMIT 500`,
    values,
  );
  return r.rows;
}

export async function getReturn(id: string, client?: PoolClient) {
  const db = client ?? pool;
  const r = await db.query(
    `SELECT rt.*, sl.lot_code, sl.crop, sl.variety, p.name AS dealer_name, p.party_code AS dealer_code, d.dispatch_number, loc.code AS quarantine_code,
            i.inspection_code, i.result AS inspection_result, i.decision AS inspection_decision, c.complaint_code, c.id AS complaint_ref
       FROM wh_returns rt JOIN seed_lots sl ON sl.id = rt.seed_lot_id JOIN parties p ON p.id = rt.dealer_id JOIN wh_locations loc ON loc.id = rt.quarantine_location_id
       LEFT JOIN wh_dispatches d ON d.id = rt.dispatch_id LEFT JOIN inspections i ON i.id = rt.inspection_id LEFT JOIN quality_complaints c ON c.id = rt.complaint_id
      WHERE rt.id = $1`,
    [id],
  );
  if (!r.rows[0]) throw new NotFoundError('Return not found');
  return r.rows[0];
}
