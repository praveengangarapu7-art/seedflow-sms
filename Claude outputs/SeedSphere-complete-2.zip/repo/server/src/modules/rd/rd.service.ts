import { pool } from '../../db/pool';
import { withTransaction } from '../../db/transaction';
import { ConflictError, NotFoundError, ValidationError } from '../../errors';
import type { AuthenticatedUser } from '../../middleware/requireAuth';
import { insertAuditLog } from '../auditLogs/auditLogs.service';
import { nextCode, optionalDate, optionalNumber, optionalText, optionalUuid, requireDate, requireEnum, requireNumber, requireText, requireUuid, todayIso } from '../shared/validate';

const one = async (sql: string, p: unknown[] = []) => (await pool.query(sql, p)).rows[0];

// ------------------------------------------------------------------ germplasm
const ACC_TYPES = ['landrace', 'cultivar', 'wild_relative', 'breeding_line', 'mutant'] as const;

export async function createAccession(input: Record<string, unknown>, user: AuthenticatedUser) {
  return withTransaction(async (client) => {
    const crop = requireText(input.crop, 'crop', 100);
    const name = requireText(input.name, 'name', 150);
    if ((await client.query(`SELECT 1 FROM rd_accessions WHERE crop = $1 AND lower(name) = lower($2)`, [crop, name])).rows[0]) throw new ConflictError(`${name} is already catalogued for ${crop}`);
    const r = (await client.query(
      `INSERT INTO rd_accessions (accession_code, accession_number, name, crop, species, accession_type, origin_state, origin_site, donor, custody, notes, created_by)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) RETURNING *`,
      [await nextCode(client, 'GRM', 5, true), optionalText(input.accessionNumber, 'accessionNumber', 60), name, crop, optionalText(input.species, 'species', 150),
        input.accessionType === undefined ? 'cultivar' : requireEnum(input.accessionType, ACC_TYPES, 'accessionType'), optionalText(input.originState, 'originState', 100), optionalText(input.originSite, 'originSite', 150),
        optionalText(input.donor, 'donor', 150), optionalText(input.custody, 'custody', 150), optionalText(input.notes, 'notes', 2000), user.email],
    )).rows[0];
    await insertAuditLog(client, { entityType: 'rd_accession', entityId: r.id, action: 'CREATE', performedBy: user.email, afterState: r });
    return r;
  });
}

export async function listAccessions(f: { crop?: string; q?: string }) {
  return (await pool.query(
    `SELECT a.*, (SELECT COUNT(DISTINCT trait)::int FROM rd_phenotypes p WHERE p.accession_id = a.id) AS trait_count
       FROM rd_accessions a WHERE ($1::text IS NULL OR a.crop = $1) AND ($2::text IS NULL OR a.name ILIKE '%'||$2||'%' OR a.accession_code ILIKE '%'||$2||'%' OR a.accession_number ILIKE '%'||$2||'%')
      ORDER BY a.created_at DESC LIMIT 500`, [f.crop ?? null, f.q ?? null])).rows;
}

export async function getAccession(id: string) {
  const a = await one(`SELECT * FROM rd_accessions WHERE id = $1`, [id]);
  if (!a) throw new NotFoundError('Accession not found');
  const ph = (await pool.query(`SELECT id, trait, category, value_num::float AS value_num, value_text, unit, method, measured_on, recorded_by FROM rd_phenotypes WHERE accession_id = $1 ORDER BY measured_on DESC, recorded_at DESC`, [id])).rows;
  const programs = (await pool.query(`SELECT id, program_code, name, status FROM rd_programs WHERE male_parent_id = $1 OR female_parent_id = $1`, [id])).rows;
  return { ...a, phenotypes: ph, programs };
}

export async function updateAccessionStatus(id: string, input: Record<string, unknown>, user: AuthenticatedUser) {
  const status = requireEnum(input.status, ['active', 'inactive', 'lost'] as const, 'status');
  const r = await pool.query(`UPDATE rd_accessions SET status = $2 WHERE id = $1 RETURNING *`, [id, status]);
  if (!r.rows[0]) throw new NotFoundError('Accession not found');
  await withTransaction((c) => insertAuditLog(c, { entityType: 'rd_accession', entityId: id, action: 'STATUS', performedBy: user.email, metadata: { status } }));
  return r.rows[0];
}

// ------------------------------------------------------------------ phenotyping
export async function recordPhenotype(input: Record<string, unknown>, user: AuthenticatedUser) {
  const accessionId = requireUuid(input.accessionId, 'accessionId');
  const valueNum = optionalNumber(input.valueNum, 'valueNum');
  const valueText = optionalText(input.valueText, 'valueText', 100);
  if (valueNum === null && !valueText) throw new ValidationError('Give a measured value (number or word)');
  const measuredOn = requireDate(input.measuredOn, 'measuredOn');
  if (measuredOn > todayIso()) throw new ValidationError('measuredOn cannot be in the future');
  if (!(await one(`SELECT 1 AS x FROM rd_accessions WHERE id = $1`, [accessionId]))) throw new NotFoundError('Accession not found');
  const r = await pool.query(
    `INSERT INTO rd_phenotypes (accession_id, trait, category, value_num, value_text, unit, method, measured_on, recorded_by) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,
    [accessionId, requireText(input.trait, 'trait', 60), requireEnum(input.category ?? 'agronomic', ['agronomic', 'quality', 'stress', 'disease', 'morphology'] as const, 'category'), valueNum, valueText, optionalText(input.unit, 'unit', 20), optionalText(input.method, 'method', 150), measuredOn, user.email],
  );
  return r.rows[0];
}

export async function listPhenotypes(f: { crop?: string; trait?: string }) {
  return (await pool.query(
    `SELECT p.id, p.trait, p.category, p.value_num::float AS value_num, p.value_text, p.unit, p.method, p.measured_on, p.recorded_by, a.id AS accession_id, a.accession_code, a.name AS accession_name, a.crop
       FROM rd_phenotypes p JOIN rd_accessions a ON a.id = p.accession_id
      WHERE ($1::text IS NULL OR a.crop = $1) AND ($2::text IS NULL OR p.trait = $2) ORDER BY p.measured_on DESC, p.recorded_at DESC LIMIT 500`, [f.crop ?? null, f.trait ?? null])).rows;
}

// ------------------------------------------------------------------ breeding programmes
export async function createProgram(input: Record<string, unknown>, user: AuthenticatedUser) {
  const start = requireDate(input.startDate, 'startDate');
  const end = optionalDate(input.expectedEndDate, 'expectedEndDate');
  if (end && end < start) throw new ValidationError('expectedEndDate is before startDate');
  const male = optionalUuid(input.maleParentId, 'maleParentId');
  const female = optionalUuid(input.femaleParentId, 'femaleParentId');
  return withTransaction(async (client) => {
    const r = (await client.query(
      `INSERT INTO rd_programs (program_code, name, crop, objective, description, status, lead_breeder, start_date, expected_end_date, budget, male_parent_id, female_parent_id, created_by)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13) RETURNING *`,
      [await nextCode(client, 'BP', 3, true), requireText(input.name, 'name', 200), requireText(input.crop, 'crop', 100), requireText(input.objective, 'objective', 40), optionalText(input.description, 'description', 2000),
        input.status === undefined ? 'planning' : requireEnum(input.status, ['planning', 'active'] as const, 'status'), requireText(input.leadBreeder, 'leadBreeder', 150), start, end, optionalNumber(input.budget, 'budget', { min: 0 }), male, female, user.email],
    )).rows[0];
    await insertAuditLog(client, { entityType: 'rd_program', entityId: r.id, action: 'CREATE', performedBy: user.email, afterState: r });
    return r;
  });
}

export async function listPrograms() {
  return (await pool.query(
    `SELECT p.*, p.budget::float AS budget_f, p.spent_to_date::float AS spent_f,
            (SELECT stage FROM rd_generations g WHERE g.program_id = p.id ORDER BY g.recorded_at DESC LIMIT 1) AS current_stage,
            (SELECT COUNT(*)::int FROM rd_generations g WHERE g.program_id = p.id) AS generation_count
       FROM rd_programs p ORDER BY p.created_at DESC LIMIT 300`)).rows;
}

export async function getProgram(id: string) {
  const p = await one(`SELECT p.*, m.name AS male_name, f.name AS female_name FROM rd_programs p LEFT JOIN rd_accessions m ON m.id = p.male_parent_id LEFT JOIN rd_accessions f ON f.id = p.female_parent_id WHERE p.id = $1`, [id]);
  if (!p) throw new NotFoundError('Programme not found');
  const [gens, nurseries] = await Promise.all([
    pool.query(`SELECT * FROM rd_generations WHERE program_id = $1 ORDER BY recorded_at`, [id]),
    pool.query(`SELECT id, nursery_code, name, status, season FROM rd_nurseries WHERE program_id = $1 ORDER BY created_at`, [id]),
  ]);
  return { ...p, generations: gens.rows, nurseries: nurseries.rows };
}

export async function updateProgram(id: string, input: Record<string, unknown>, user: AuthenticatedUser) {
  return withTransaction(async (client) => {
    const p = (await client.query(`SELECT * FROM rd_programs WHERE id = $1 FOR UPDATE`, [id])).rows[0];
    if (!p) throw new NotFoundError('Programme not found');
    const status = input.status === undefined ? p.status : requireEnum(input.status, ['planning', 'active', 'paused', 'completed', 'cancelled'] as const, 'status');
    if (['completed', 'cancelled'].includes(p.status) && status !== p.status) throw new ConflictError(`A ${p.status} programme cannot be reopened`);
    const spent = input.spentToDate === undefined ? p.spent_to_date : requireNumber(input.spentToDate, 'spentToDate', { min: 0 });
    if (p.budget !== null && Number(spent) > Number(p.budget) && input.acceptOverBudget !== true) throw new ConflictError('Spend would exceed the programme budget — confirm with acceptOverBudget');
    const r = await client.query(`UPDATE rd_programs SET status = $2, spent_to_date = $3 WHERE id = $1 RETURNING *`, [id, status, spent]);
    await insertAuditLog(client, { entityType: 'rd_program', entityId: id, action: 'UPDATE', performedBy: user.email, beforeState: p, afterState: r.rows[0] });
    return r.rows[0];
  });
}

export async function recordGeneration(programId: string, input: Record<string, unknown>, user: AuthenticatedUser) {
  const pop = requireNumber(input.populationSize, 'populationSize', { min: 1 });
  const kept = requireNumber(input.selectionsRetained, 'selectionsRetained', { min: 0 });
  if (kept > pop) throw new ValidationError('selectionsRetained cannot exceed populationSize');
  const p = await one(`SELECT status FROM rd_programs WHERE id = $1`, [programId]);
  if (!p) throw new NotFoundError('Programme not found');
  if (!['planning', 'active'].includes(p.status)) throw new ConflictError(`Programme is ${p.status}`);
  try {
    const r = await pool.query(
      `INSERT INTO rd_generations (program_id, stage, season, population_size, selections_retained, criteria, observations, recorded_by) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
      [programId, requireText(input.stage, 'stage', 10), requireText(input.season, 'season', 30), pop, kept, optionalText(input.criteria, 'criteria', 500), optionalText(input.observations, 'observations', 2000), user.email],
    );
    await pool.query(`UPDATE rd_programs SET status = 'active' WHERE id = $1 AND status = 'planning'`, [programId]);
    return r.rows[0];
  } catch (e) {
    if ((e as { code?: string }).code === '23505') throw new ConflictError('That generation is already recorded for this programme');
    throw e;
  }
}

// ------------------------------------------------------------------ nurseries
export async function createNursery(input: Record<string, unknown>, user: AuthenticatedUser) {
  return withTransaction(async (client) => {
    const r = (await client.query(
      `INSERT INTO rd_nurseries (nursery_code, name, program_id, crop, season, location, area_acres, created_by) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
      [await nextCode(client, 'NUR', 4, true), requireText(input.name, 'name', 150), optionalUuid(input.programId, 'programId'), requireText(input.crop, 'crop', 100), requireText(input.season, 'season', 30), requireText(input.location, 'location', 150), optionalNumber(input.areaAcres, 'areaAcres', { positive: true }), user.email],
    )).rows[0];
    return r;
  });
}

export async function listNurseries() {
  return (await pool.query(
    `SELECT n.*, n.area_acres::float AS area_f, p.name AS program_name,
            (SELECT COUNT(*)::int FROM rd_nursery_notes x WHERE x.nursery_id = n.id) AS note_count,
            (SELECT health FROM rd_nursery_notes x WHERE x.nursery_id = n.id ORDER BY note_date DESC, recorded_at DESC LIMIT 1) AS latest_health
       FROM rd_nurseries n LEFT JOIN rd_programs p ON p.id = n.program_id ORDER BY n.created_at DESC LIMIT 300`)).rows;
}

export async function getNursery(id: string) {
  const n = await one(`SELECT n.*, p.name AS program_name FROM rd_nurseries n LEFT JOIN rd_programs p ON p.id = n.program_id WHERE n.id = $1`, [id]);
  if (!n) throw new NotFoundError('Nursery not found');
  const notes = (await pool.query(`SELECT * FROM rd_nursery_notes WHERE nursery_id = $1 ORDER BY note_date DESC, recorded_at DESC`, [id])).rows;
  return { ...n, notes };
}

export async function nurseryAction(id: string, action: string, input: Record<string, unknown>, user: AuthenticatedUser) {
  return withTransaction(async (client) => {
    const n = (await client.query(`SELECT * FROM rd_nurseries WHERE id = $1 FOR UPDATE`, [id])).rows[0];
    if (!n) throw new NotFoundError('Nursery not found');
    let sql: string; let params: unknown[];
    if (action === 'sow') {
      if (n.status !== 'planned') throw new ConflictError(`${n.nursery_code} is ${n.status}`);
      const sown = requireDate(input.sownOn, 'sownOn');
      if (sown > todayIso()) throw new ValidationError('sownOn cannot be in the future');
      sql = `UPDATE rd_nurseries SET status = 'sown', sown_on = $2, expected_harvest = $3 WHERE id = $1 RETURNING *`; params = [id, sown, optionalDate(input.expectedHarvest, 'expectedHarvest')];
    } else if (action === 'harvest') {
      if (!['sown', 'growing'].includes(n.status)) throw new ConflictError('Only a sown or growing nursery can be harvested');
      sql = `UPDATE rd_nurseries SET status = 'harvested', harvested_on = $2 WHERE id = $1 RETURNING *`; params = [id, requireDate(input.harvestedOn ?? todayIso(), 'harvestedOn')];
    } else if (action === 'abandon') {
      if (['harvested', 'abandoned'].includes(n.status)) throw new ConflictError(`${n.nursery_code} is already ${n.status}`);
      requireText(input.reason, 'reason', 500);
      sql = `UPDATE rd_nurseries SET status = 'abandoned' WHERE id = $1 RETURNING *`; params = [id];
    } else throw new ValidationError('Unknown action');
    const r = await client.query(sql, params);
    await insertAuditLog(client, { entityType: 'rd_nursery', entityId: id, action: action.toUpperCase(), performedBy: user.email, metadata: input });
    return r.rows[0];
  });
}

export async function addNurseryNote(id: string, input: Record<string, unknown>, user: AuthenticatedUser) {
  const n = await one(`SELECT status FROM rd_nurseries WHERE id = $1`, [id]);
  if (!n) throw new NotFoundError('Nursery not found');
  if (!['sown', 'growing'].includes(n.status)) throw new ConflictError('Observations can be added while the nursery is sown or growing');
  const date = requireDate(input.noteDate ?? todayIso(), 'noteDate');
  if (date > todayIso()) throw new ValidationError('noteDate cannot be in the future');
  const r = await pool.query(
    `INSERT INTO rd_nursery_notes (nursery_id, note_date, growth_stage, health, note, recorded_by) VALUES ($1,$2,$3,$4,$5,$6) RETURNING *`,
    [id, date, optionalText(input.growthStage, 'growthStage', 40), requireEnum(input.health ?? 'good', ['good', 'fair', 'poor'] as const, 'health'), requireText(input.note, 'note', 2000), user.email],
  );
  await pool.query(`UPDATE rd_nurseries SET status = 'growing' WHERE id = $1 AND status = 'sown'`, [id]);
  return r.rows[0];
}

// ------------------------------------------------------------------ registrations
const AUTH = ['ppvfra', 'cvrc', 'svrc', 'icar', 'other'] as const;

export async function createRegistration(input: Record<string, unknown>, user: AuthenticatedUser) {
  const candidateId = requireUuid(input.candidateId, 'candidateId');
  return withTransaction(async (client) => {
    const c = (await client.query(`SELECT * FROM rd_candidates WHERE id = $1`, [candidateId])).rows[0];
    if (!c) throw new NotFoundError('Candidate not found');
    if (!['pre_release', 'released'].includes(c.stage)) throw new ConflictError('Only a pre-release or released candidate can be filed for registration');
    return (await client.query(
      `INSERT INTO rd_registrations (reg_code, candidate_id, authority, reg_type, created_by) VALUES ($1,$2,$3,$4,$5) RETURNING *`,
      [await nextCode(client, 'REG', 4, true), candidateId, requireEnum(input.authority, AUTH, 'authority'), requireEnum(input.regType ?? 'notification', ['notification', 'ppvfra_protection', 'release', 'other'] as const, 'regType'), user.email],
    )).rows[0];
  });
}

export async function listRegistrations() {
  return (await pool.query(`SELECT r.*, c.name AS candidate_name, c.crop, c.candidate_code, c.stage FROM rd_registrations r JOIN rd_candidates c ON c.id = r.candidate_id ORDER BY r.created_at DESC LIMIT 300`)).rows;
}

export async function registrationAction(id: string, action: string, input: Record<string, unknown>, user: AuthenticatedUser) {
  return withTransaction(async (client) => {
    const r = (await client.query(`SELECT * FROM rd_registrations WHERE id = $1 FOR UPDATE`, [id])).rows[0];
    if (!r) throw new NotFoundError('Registration not found');
    let out;
    if (action === 'file') {
      if (r.status !== 'draft') throw new ConflictError(`${r.reg_code} is ${r.status}`);
      const filed = requireDate(input.filedOn ?? todayIso(), 'filedOn');
      out = await client.query(`UPDATE rd_registrations SET status = 'filed', filed_on = $2, reference_number = $3 WHERE id = $1 RETURNING *`, [id, filed, requireText(input.referenceNumber, 'referenceNumber', 60)]);
    } else if (action === 'review') {
      if (r.status !== 'filed') throw new ConflictError('Only a filed application can go under review');
      out = await client.query(`UPDATE rd_registrations SET status = 'under_review' WHERE id = $1 RETURNING *`, [id]);
    } else if (action === 'grant') {
      if (!['filed', 'under_review'].includes(r.status)) throw new ConflictError('Only a filed application can be granted');
      const granted = requireDate(input.grantedOn, 'grantedOn');
      const until = optionalDate(input.validUntil, 'validUntil');
      if (until && until < granted) throw new ValidationError('validUntil is before grantedOn');
      out = await client.query(`UPDATE rd_registrations SET status = 'granted', granted_on = $2, valid_until = $3, decision_note = $4 WHERE id = $1 RETURNING *`, [id, granted, until, optionalText(input.note, 'note', 1000)]);
    } else if (action === 'reject' || action === 'withdraw') {
      if (['granted', 'rejected', 'withdrawn'].includes(r.status)) throw new ConflictError(`${r.reg_code} is already ${r.status}`);
      out = await client.query(`UPDATE rd_registrations SET status = $2, decision_note = $3 WHERE id = $1 RETURNING *`, [id, action === 'reject' ? 'rejected' : 'withdrawn', requireText(input.note, 'note', 1000)]);
    } else throw new ValidationError('Unknown action');
    await insertAuditLog(client, { entityType: 'rd_registration', entityId: id, action: action.toUpperCase(), performedBy: user.email });
    return out.rows[0];
  });
}

// ------------------------------------------------------------------ varieties + dashboard
export async function listVarieties() {
  return (await pool.query(
    `SELECT c.id AS candidate_id, c.candidate_code, c.name, c.crop, c.stage, v.id AS variety_id, v.status AS variety_status, s.status AS spec_status,
            s.min_germination_pct::float AS min_germination_pct, s.min_purity_pct::float AS min_purity_pct, s.max_moisture_pct::float AS max_moisture_pct, s.recommended_regions,
            (SELECT COUNT(*)::int FROM seed_lots l WHERE l.crop = c.crop AND l.variety = c.name) AS lots,
            (SELECT json_agg(json_build_object('code', r.reg_code, 'authority', r.authority, 'status', r.status)) FROM rd_registrations r WHERE r.candidate_id = c.id) AS registrations
       FROM rd_candidates c LEFT JOIN varieties v ON v.id = c.variety_id LEFT JOIN rd_variety_specs s ON s.candidate_id = c.id
      WHERE c.stage IN ('pre_release', 'released') ORDER BY c.stage DESC, c.created_at DESC LIMIT 300`)).rows;
}

export async function dashboard() {
  const [acc, prog, nur, trials, pipeline, reg, recent] = await Promise.all([
    one(`SELECT COUNT(*)::int AS total, COUNT(DISTINCT crop)::int AS crops FROM rd_accessions WHERE status = 'active'`),
    one(`SELECT COUNT(*) FILTER (WHERE status = 'active')::int AS active, COUNT(*) FILTER (WHERE status = 'planning')::int AS planning, COALESCE(SUM(budget) FILTER (WHERE status IN ('planning','active')),0)::float AS budget, COALESCE(SUM(spent_to_date) FILTER (WHERE status IN ('planning','active')),0)::float AS spent FROM rd_programs`),
    one(`SELECT COUNT(*) FILTER (WHERE status IN ('sown','growing'))::int AS growing, COUNT(*) FILTER (WHERE status IN ('sown','growing') AND expected_harvest < CURRENT_DATE)::int AS overdue FROM rd_nurseries`),
    one(`SELECT COUNT(*) FILTER (WHERE status = 'running')::int AS running, COUNT(*) FILTER (WHERE status = 'pending_approval')::int AS awaiting_approval, COUNT(*) FILTER (WHERE status = 'completed')::int AS completed FROM rd_trials`),
    (await pool.query(`SELECT stage, COUNT(*)::int AS n FROM rd_candidates GROUP BY stage`)).rows,
    one(`SELECT COUNT(*) FILTER (WHERE status IN ('filed','under_review'))::int AS in_process, COUNT(*) FILTER (WHERE status = 'granted')::int AS granted, COUNT(*) FILTER (WHERE status = 'granted' AND valid_until < CURRENT_DATE + 90)::int AS expiring FROM rd_registrations`),
    (await pool.query(`SELECT 'phenotype' AS kind, a.name || ' — ' || p.trait AS text, p.measured_on::text AS on_date FROM rd_phenotypes p JOIN rd_accessions a ON a.id = p.accession_id
                       UNION ALL SELECT 'nursery', n.name || ' — ' || x.note, x.note_date::text FROM rd_nursery_notes x JOIN rd_nurseries n ON n.id = x.nursery_id ORDER BY on_date DESC LIMIT 8`)).rows,
  ]);
  return { accessions: acc, programs: prog, nurseries: nur, trials, pipeline, registrations: reg, recent };
}
