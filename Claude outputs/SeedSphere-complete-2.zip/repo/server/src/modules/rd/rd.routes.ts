import { Router } from 'express';
import { asyncHandler as h } from '../../middleware/asyncHandler';
import { requireAuth, requirePermission as can, requireStaff } from '../../middleware/requireAuth';
import { body, ok, str } from '../shared/http';
import * as rd from './rd.service';

// verify_field_observations: the R&D field inspector reads the records whose field observations they verify.
const VIEW = ['catalog_germplasm', 'verify_field_observations', 'design_trial', 'execute_trial', 'record_phenotyping', 'analyze_trial_data', 'file_variety_registration', 'propose_variety_advancement', 'approve_variety_release', 'sign_off_variety_release', 'view_management_dashboard'];

export const rdRouter = Router();
rdRouter.use(requireAuth, requireStaff);
rdRouter.get('/dashboard', can(...VIEW), h(async (_req, res) => ok(res, await rd.dashboard())));
rdRouter.get('/accessions', can(...VIEW), h(async (req, res) => ok(res, await rd.listAccessions({ crop: str(req.query.crop), q: str(req.query.q) }))));
rdRouter.post('/accessions', can('catalog_germplasm'), h(async (req, res) => ok(res, await rd.createAccession(body(req), req.user!), 'Accession added', 201)));
rdRouter.get('/accessions/:id', can(...VIEW), h(async (req, res) => ok(res, await rd.getAccession(req.params.id))));
rdRouter.patch('/accessions/:id/status', can('catalog_germplasm'), h(async (req, res) => ok(res, await rd.updateAccessionStatus(req.params.id, body(req), req.user!))));
rdRouter.get('/phenotypes', can(...VIEW), h(async (req, res) => ok(res, await rd.listPhenotypes({ crop: str(req.query.crop), trait: str(req.query.trait) }))));
rdRouter.post('/phenotypes', can('record_phenotyping'), h(async (req, res) => ok(res, await rd.recordPhenotype(body(req), req.user!), 'Measurement recorded', 201)));
rdRouter.get('/programs', can(...VIEW), h(async (_req, res) => ok(res, await rd.listPrograms())));
rdRouter.post('/programs', can('design_trial'), h(async (req, res) => ok(res, await rd.createProgram(body(req), req.user!), 'Programme created', 201)));
rdRouter.get('/programs/:id', can(...VIEW), h(async (req, res) => ok(res, await rd.getProgram(req.params.id))));
rdRouter.patch('/programs/:id', can('design_trial'), h(async (req, res) => ok(res, await rd.updateProgram(req.params.id, body(req), req.user!))));
rdRouter.post('/programs/:id/generations', can('design_trial', 'execute_trial'), h(async (req, res) => ok(res, await rd.recordGeneration(req.params.id, body(req), req.user!), 'Generation recorded', 201)));
rdRouter.get('/nurseries', can(...VIEW), h(async (_req, res) => ok(res, await rd.listNurseries())));
rdRouter.post('/nurseries', can('execute_trial', 'design_trial'), h(async (req, res) => ok(res, await rd.createNursery(body(req), req.user!), 'Nursery planned', 201)));
rdRouter.get('/nurseries/:id', can(...VIEW), h(async (req, res) => ok(res, await rd.getNursery(req.params.id))));
rdRouter.post('/nurseries/:id/notes', can('execute_trial', 'record_phenotyping'), h(async (req, res) => ok(res, await rd.addNurseryNote(req.params.id, body(req), req.user!), 'Observation saved', 201)));
rdRouter.post('/nurseries/:id/:action(sow|harvest|abandon)', can('execute_trial'), h(async (req, res) => ok(res, await rd.nurseryAction(req.params.id, req.params.action, body(req), req.user!))));
rdRouter.get('/registrations', can(...VIEW), h(async (_req, res) => ok(res, await rd.listRegistrations())));
rdRouter.post('/registrations', can('file_variety_registration'), h(async (req, res) => ok(res, await rd.createRegistration(body(req), req.user!), 'Registration drafted', 201)));
rdRouter.post('/registrations/:id/:action(file|review|grant|reject|withdraw)', can('file_variety_registration'), h(async (req, res) => ok(res, await rd.registrationAction(req.params.id, req.params.action, body(req), req.user!))));
rdRouter.get('/varieties', can(...VIEW), h(async (_req, res) => ok(res, await rd.listVarieties())));
