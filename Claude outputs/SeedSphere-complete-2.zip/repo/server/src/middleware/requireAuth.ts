import type { NextFunction, Request, Response } from 'express';
import { verifyAccessToken } from '../auth/jwt';
import { hasPermission, isStaff } from '../auth/permissions';
import { ForbiddenError, UnauthorizedError } from '../errors';

export interface AuthenticatedUser {
  id: string;
  email: string;
  role: string;
  organizationId: string | null;
  /** Functional (screen) role — see auth/permissions.ts. Null for legacy accounts. */
  jobRole?: string | null;
}

declare module 'express-serve-static-core' {
  interface Request {
    user?: AuthenticatedUser;
  }
}

export function requireAuth(req: Request, _res: Response, next: NextFunction): void {
  const header = req.header('authorization');
  const token = header?.startsWith('Bearer ') ? header.slice('Bearer '.length) : undefined;

  if (!token) {
    next(new UnauthorizedError('Missing bearer access token'));
    return;
  }

  try {
    const payload = verifyAccessToken(token);
    req.user = {
      id: payload.sub,
      email: payload.email,
      role: payload.role,
      organizationId: payload.organizationId,
      jobRole: payload.jobRole ?? null,
    };
    next();
  } catch {
    next(new UnauthorizedError('Invalid or expired access token'));
  }
}

export function requireRole(...roles: string[]) {
  return (req: Request, _res: Response, next: NextFunction): void => {
    if (!req.user) {
      next(new UnauthorizedError());
      return;
    }
    if (!roles.includes(req.user.role)) {
      next(new ForbiddenError(`This action requires one of these roles: ${roles.join(', ')}`));
      return;
    }
    next();
  };
}

/**
 * Gate for the modules built from the development plan: passes when the
 * user's job role holds ANY of the listed permissions (see
 * auth/permissions.ts). Legacy Admin accounts with no job role pass.
 */
export function requirePermission(...permissions: string[]) {
  return (req: Request, _res: Response, next: NextFunction): void => {
    if (!req.user) {
      next(new UnauthorizedError());
      return;
    }
    const user = req.user;
    if (!permissions.some((p) => hasPermission(user.jobRole, user.role, p))) {
      next(new ForbiddenError(`This action requires the permission: ${permissions.join(' or ')}`));
      return;
    }
    next();
  };
}

/** Internal records are for staff; grower and dealer portal accounts are refused. */
export function requireStaff(req: Request, _res: Response, next: NextFunction): void {
  if (!req.user) {
    next(new UnauthorizedError());
    return;
  }
  if (!isStaff(req.user.jobRole)) {
    next(new ForbiddenError('This area is for company staff — portal accounts see their own records in the portal'));
    return;
  }
  next();
}

export function userHasPermission(user: AuthenticatedUser, permission: string): boolean {
  return hasPermission(user.jobRole, user.role, permission);
}
