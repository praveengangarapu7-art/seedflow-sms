import { BASE_ROLE_FOR_JOB_ROLE, type JobRole } from '../auth/permissions';
import { hashPassword } from '../auth/password';
import { ROLES_REQUIRING_ORGANIZATION } from '../auth/roles';
import { pool } from './pool';

/**
 * Server accounts for the demo staff directory in src/data/demoAccounts.ts
 * (same emails, password `password123`), each with its job role, so a person
 * signed in as "Purchase Manager" on the screen acts as a Purchase Manager on
 * the server. Also seeds one grower and one dealer portal account.
 *
 * inspector@seedsphere.com already exists as the legacy Inspector account
 * (password Inspector123!); it keeps its password and gains the procurement
 * field inspector job role.
 */
const STAFF: [JobRole, string, string][] = [
  ['purchase_executive', 'Aarav Mehta', 'executive@seedsphere.com'],
  ['purchase_executive', 'Sneha Kulkarni', 'executive2@seedsphere.com'],
  ['purchase_executive', 'Rahul Bansal', 'executive3@seedsphere.com'],
  ['purchase_manager', 'Priya Sharma', 'manager@seedsphere.com'],
  ['purchase_manager', 'Nikhil Ahuja', 'manager2@seedsphere.com'],
  ['purchase_manager', 'Divya Menon', 'manager3@seedsphere.com'],
  ['finance_manager', 'Rohan Verma', 'finance@seedsphere.com'],
  ['finance_manager', 'Lakshmi Narayan', 'finance2@seedsphere.com'],
  ['finance_manager', 'Imran Qureshi', 'finance3@seedsphere.com'],
  ['procurement_quality_field_inspector', 'Sanjay Iyer', 'inspector@seedsphere.com'],
  ['procurement_quality_field_inspector', 'Ritu Chandra', 'inspector2@seedsphere.com'],
  ['procurement_quality_field_inspector', 'Mahesh Yadav', 'inspector3@seedsphere.com'],
  ['warehouse_supervisor', 'Vikram Nair', 'supervisor@seedsphere.com'],
  ['warehouse_supervisor', 'Farida Sheikh', 'supervisor2@seedsphere.com'],
  ['warehouse_supervisor', 'Tarun Bose', 'supervisor3@seedsphere.com'],
  ['warehouse_manager', 'Anjali Rao', 'whmanager@seedsphere.com'],
  ['warehouse_manager', 'Suresh Babu', 'whmanager2@seedsphere.com'],
  ['warehouse_manager', 'Kavita Tandon', 'whmanager3@seedsphere.com'],
  ['warehouse_quality_field_inspector', 'Karthik Reddy', 'whinspector@seedsphere.com'],
  ['warehouse_quality_field_inspector', 'Nandini Ghosh', 'whinspector2@seedsphere.com'],
  ['warehouse_quality_field_inspector', 'Ajay Solanki', 'whinspector3@seedsphere.com'],
  ['safety_officer', 'Neha Joshi', 'safety@seedsphere.com'],
  ['safety_officer', 'Gopal Krishnan', 'safety2@seedsphere.com'],
  ['safety_officer', 'Zoya Mirza', 'safety3@seedsphere.com'],
  ['rd_executive', 'Ishaan Gupta', 'rdexecutive@seedsphere.com'],
  ['rd_executive', 'Ananya Bose', 'rdexecutive2@seedsphere.com'],
  ['rd_executive', 'Vivek Rathore', 'rdexecutive3@seedsphere.com'],
  ['rd_manager', 'Meera Pillai', 'rdmanager@seedsphere.com'],
  ['rd_manager', 'Dr. Samuel Thomas', 'rdmanager2@seedsphere.com'],
  ['rd_manager', 'Harshad Patel', 'rdmanager3@seedsphere.com'],
  ['rd_quality_field_inspector', 'Arjun Malhotra', 'rdinspector@seedsphere.com'],
  ['rd_quality_field_inspector', 'Swati Deshpande', 'rdinspector2@seedsphere.com'],
  ['rd_quality_field_inspector', 'Rakesh Barman', 'rdinspector3@seedsphere.com'],
  ['plant_supervisor', 'Deepak Chauhan', 'plantsupervisor@seedsphere.com'],
  ['plant_supervisor', 'Yasmin Ali', 'plantsupervisor2@seedsphere.com'],
  ['plant_supervisor', 'Naveen Kamath', 'plantsupervisor3@seedsphere.com'],
  ['plant_manager', 'Sunita Desai', 'plantmanager@seedsphere.com'],
  ['plant_manager', 'Bhaskar Rout', 'plantmanager2@seedsphere.com'],
  ['plant_manager', 'Alok Trivedi', 'plantmanager3@seedsphere.com'],
  ['processing_quality_field_inspector', 'Kabir Sethi', 'procinspector@seedsphere.com'],
  ['processing_quality_field_inspector', 'Preeti Saxena', 'procinspector2@seedsphere.com'],
  ['processing_quality_field_inspector', 'Manoj Dutta', 'procinspector3@seedsphere.com'],
  ['lab_manager', 'Dr. Anita Krishnan', 'labmanager@seedsphere.com'],
  ['lab_manager', 'Dr. Faisal Khan', 'labmanager2@seedsphere.com'],
  ['lab_manager', 'Shalini Prabhu', 'labmanager3@seedsphere.com'],
  ['lab_technician', 'Ravi Patil', 'labtechnician@seedsphere.com'],
  ['lab_technician', 'Aisha Fernandes', 'labtechnician2@seedsphere.com'],
  ['lab_technician', 'Gaurav Sinha', 'labtechnician3@seedsphere.com'],
  ['quality_manager', 'Dr. Sunita Deshmukh', 'qualitymanager@seedsphere.com'],
  ['quality_manager', 'Harish Kulkarni', 'qualitymanager2@seedsphere.com'],
  ['quality_officer', 'Rekha Jadhav', 'qualityofficer@seedsphere.com'],
  ['quality_officer', 'Omkar Shinde', 'qualityofficer2@seedsphere.com'],
  ['quality_officer', 'Vaishali More', 'qualityofficer3@seedsphere.com'],
  ['lab_quality_analyst', 'Pooja Bhatt', 'labanalyst@seedsphere.com'],
  ['lab_quality_analyst', 'Sridhar Acharya', 'labanalyst2@seedsphere.com'],
  ['lab_quality_analyst', 'Ruchi Kapoor', 'labanalyst3@seedsphere.com'],
  ['super_admin', 'Vikram Rao', 'superadmin@seedsphere.com'],
  ['super_admin', 'Meera Iyer', 'superadmin2@seedsphere.com'],
  ['system_admin', 'Arjun Nair', 'sysadmin@seedsphere.com'],
  ['system_admin', 'Farah Qureshi', 'sysadmin2@seedsphere.com'],
  ['compliance_auditor', 'Deepak Joshi', 'auditor@seedsphere.com'],
  ['compliance_auditor', 'Lakshmi Rangan', 'auditor2@seedsphere.com'],
  ['grower', 'Ramesh Reddy (grower)', 'grower@seedsphere.com'],
  ['dealer', 'Sri Lakshmi Agro (dealer)', 'dealer@seedsphere.com'],
];

const PASSWORD = 'password123';

async function companyOrganization(): Promise<string> {
  const name = process.env.COMPANY_NAME ?? 'SeedSphere Seeds Pvt Ltd';
  const existing = await pool.query<{ id: string }>('SELECT id FROM organizations WHERE name = $1', [name]);
  if (existing.rows[0]) return existing.rows[0].id;
  const r = await pool.query<{ id: string }>(`INSERT INTO organizations (name, type) VALUES ($1, 'producer') RETURNING id`, [name]);
  return r.rows[0].id;
}

async function run(): Promise<void> {
  const orgId = await companyOrganization();
  const hash = await hashPassword(PASSWORD);
  let created = 0;
  let updated = 0;
  for (const [jobRole, name, email] of STAFF) {
    const role = BASE_ROLE_FOR_JOB_ROLE[jobRole];
    const existing = await pool.query<{ id: string; job_role: string | null }>('SELECT id, job_role FROM users WHERE email = $1', [email]);
    if (existing.rows[0]) {
      if (!existing.rows[0].job_role) {
        await pool.query('UPDATE users SET job_role = $2 WHERE id = $1', [existing.rows[0].id, jobRole]);
        updated += 1;
      }
      continue;
    }
    const org = ROLES_REQUIRING_ORGANIZATION.includes(role) ? orgId : null;
    await pool.query(
      'INSERT INTO users (email, password_hash, name, role, organization_id, job_role) VALUES ($1, $2, $3, $4, $5, $6)',
      [email, hash, name, role, org, jobRole],
    );
    created += 1;
  }
  console.log(`Staff accounts: ${created} created, ${updated} given a job role. Password for new accounts: ${PASSWORD}`);
}

run()
  .then(() => pool.end())
  .catch((error) => {
    console.error('[seedStaff] failed:', error);
    return pool.end().finally(() => process.exit(1));
  });
