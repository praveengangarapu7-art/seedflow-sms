import { randomUUID } from 'node:crypto';
import { pool } from './pool';

/**
 * Walks one season of work through the running API as the seeded staff
 * (run `npm run seed:staff` first and start the API), so every screen of
 * phases A–C has real records to look at:
 *
 *   procurement: requisition → RFQ → award → PO (four-eyes) → GRN + gate
 *                inspection → matched invoice → payment, plus one PR left
 *                waiting in the approvals inbox
 *   growers:     agreement → delivery → intake inspection → settlement
 *   processing:  plant, machines, approved recipe → raw intake → batch
 *                through every stage → final inspection → certified lot
 *   warehouse:   godown + bins → lab test → receipt → dispatch to a
 *                licensed dealer → delivered, a return, a cycle count and
 *                a temperature sensor with a breach
 *
 * Safe to run more than once; each run adds a new, separately coded set.
 *   API_URL=http://localhost:5000/api/v1 npm run seed:demo
 */
const BASE = (process.env.API_URL ?? 'http://localhost:5000/api/v1').replace(/\/+$/, '');
const tag = randomUUID().slice(0, 4).toUpperCase();
const day = (n: number) => {
  const d = new Date();
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
};
const phone = () => `9${String(Math.floor(Math.random() * 1e9)).padStart(9, '0')}`;

type Json = Record<string, any>; // eslint-disable-line @typescript-eslint/no-explicit-any
const tokens = new Map<string, string>();

async function login(email: string): Promise<string> {
  if (tokens.has(email)) return tokens.get(email)!;
  const password = email === 'inspector@seedsphere.com' ? 'Inspector123!' : 'password123';
  const r = await fetch(`${BASE}/auth/login`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email, password }) });
  const b = (await r.json()) as Json;
  if (!r.ok) throw new Error(`login ${email}: ${b.message ?? r.status} — run npm run seed:staff first`);
  tokens.set(email, b.data.accessToken);
  return b.data.accessToken;
}

async function call(email: string, method: string, path: string, body?: object): Promise<Json> {
  const token = await login(email);
  const r = await fetch(`${BASE}${path}`, {
    method,
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
    body: body ? JSON.stringify(body) : undefined,
  });
  const b = (await r.json().catch(() => ({}))) as Json;
  if (!r.ok) throw new Error(`${method} ${path} as ${email} → ${r.status}: ${b.message ?? JSON.stringify(b)}`);
  return b.data;
}
const get = (who: string, path: string) => call(who, 'GET', path);
const post = (who: string, path: string, body: object = {}) => call(who, 'POST', path, body);
const put = (who: string, path: string, body: object = {}) => call(who, 'PUT', path, body);

const EXEC = 'executive@seedsphere.com';
const PMGR = 'manager@seedsphere.com';
const PMGR2 = 'manager2@seedsphere.com';
const FIN = 'finance@seedsphere.com';
const FIN2 = 'finance2@seedsphere.com';
const GATE = 'inspector@seedsphere.com';
const PSUP = 'plantsupervisor@seedsphere.com';
const PLMGR = 'plantmanager@seedsphere.com';
const PINSP = 'procinspector@seedsphere.com';
const WSUP = 'supervisor@seedsphere.com';
const WMGR = 'whmanager@seedsphere.com';
const WINSP = 'whinspector@seedsphere.com';

async function approve(who: string, entityType: string, entityId: string) {
  const reqs = (await get(who, `/approvals/entity/${entityType}/${entityId}`)) as Json[];
  const open = reqs.find((r) => r.status === 'pending');
  if (!open) throw new Error(`no pending ${entityType} approval`);
  return post(who, `/approvals/requests/${open.id}/decide`, { decision: 'approve', comment: 'Checked — OK', password: 'password123' });
}

async function party(type: string, name: string, extra: Json = {}) {
  const p = await post(EXEC, '/parties', { partyType: type, name, phone: phone(), state: 'Andhra Pradesh', ...extra });
  await post(PMGR, `/parties/${p.id}/approve`);
  return p;
}

async function inspect(who: string, opts: { type: string; template?: RegExp; subjectType: string; subjectId: string }, values: Record<string, number>, decision = 'accept') {
  const list = (await get(who, `/inspections/templates?type=${opts.type}&status=active`)) as Json[];
  const summary = opts.template ? list.find((t) => opts.template!.test(t.name)) : list[0];
  if (!summary) throw new Error(`no active ${opts.type} template`);
  const t = await get(who, `/inspections/templates/${summary.id}`);
  const started = await post(who, '/inspections', { templateId: t.id, subjectType: opts.subjectType, subjectId: opts.subjectId });
  const results = (t.items as Json[]).map((i) => {
    if (i.label in values) return { itemId: i.id, numericValue: values[i.label] };
    if (i.item_type === 'numeric') return { itemId: i.id, numericValue: i.min_value !== null ? Number(i.min_value) + 1 : i.max_value !== null ? Number(i.max_value) / 2 : 1 };
    if (i.item_type === 'pass_fail') return { itemId: i.id, boolValue: true };
    return { itemId: i.id, textValue: 'Satisfactory' };
  });
  await put(who, `/inspections/${started.id}/results`, { results });
  return post(who, `/inspections/${started.id}/submit`, { decision, decisionNotes: 'Within limits' });
}

async function procurement() {
  console.log('• procurement: requisition → RFQ → PO → GRN → invoice → payment');
  const seed = await post(EXEC, '/procurement/items', { name: `Paddy BPT-5204 raw seed (${tag})`, category: 'seed', unit: 'kg', crop: 'Paddy', variety: 'BPT-5204', gstRate: 0 });
  const bags = await post(EXEC, '/procurement/items', { name: `HDPE bag 25 kg (${tag})`, category: 'packaging', unit: 'nos', gstRate: 18 });
  await post(EXEC, '/procurement/items', { name: `Carbendazim 50% WP (${tag})`, category: 'chemical', unit: 'kg', gstRate: 18 });
  const cc = await post(FIN, '/procurement/cost-centres', { code: `KH${tag}`, name: `Kharif procurement ${tag}`, budgetAmount: 2500000 });
  const sA = await party('supplier', `Sri Lakshmi Agro Traders ${tag}`, { village: 'Guntur', district: 'Guntur', gstin: '' });
  const sB = await party('supplier', `Krishna Seeds & Packaging ${tag}`, { village: 'Vijayawada', district: 'Krishna' });

  const pr = await post(EXEC, '/procurement/requisitions', {
    title: 'Raw seed and bags for kharif',
    department: 'procurement',
    costCentreId: cc.id,
    lines: [
      { itemId: seed.id, quantity: 1000, unitPrice: 40 },
      { itemId: bags.id, quantity: 40, unitPrice: 20 },
    ],
  });
  await post(EXEC, `/procurement/requisitions/${pr.id}/submit`);
  await approve(PMGR, 'purchase_requisition', pr.id);

  const rfq = await post(EXEC, '/procurement/rfqs', { title: `Kharif raw seed ${tag}`, dueDate: day(5), requisitionId: pr.id });
  const [l1, l2] = rfq.lines as Json[];
  await post(EXEC, `/procurement/rfqs/${rfq.id}/quotes`, { supplierId: sA.id, lines: [{ rfqLineId: l1.id, unitPrice: 39 }, { rfqLineId: l2.id, unitPrice: 19 }], deliveryDays: 10 });
  const withQuotes = await post(EXEC, `/procurement/rfqs/${rfq.id}/quotes`, { supplierId: sB.id, lines: [{ rfqLineId: l1.id, unitPrice: 41 }, { rfqLineId: l2.id, unitPrice: 20 }], deliveryDays: 12 });
  const quoteA = (withQuotes.quotes as Json[]).find((q) => q.supplier_id === sA.id)!;
  const awarded = await post(PMGR, `/procurement/rfqs/${rfq.id}/award`, { quoteId: quoteA.id, expectedDeliveryDate: day(10), deliveryAddress: 'Plant 1, Guntur', costCentreId: cc.id });
  const po = awarded.order;
  await post(PMGR, `/procurement/orders/${po.id}/submit`);
  await approve(PMGR2, 'purchase_order', po.id);
  await post(EXEC, `/procurement/orders/${po.id}/send`);

  const full = await get(EXEC, `/procurement/orders/${po.id}`);
  const seedLine = (full.lines as Json[]).find((l) => l.item_id === seed.id)!;
  const bagLine = (full.lines as Json[]).find((l) => l.item_id === bags.id)!;
  await post(EXEC, '/procurement/receipts', { poId: po.id, lines: [{ poLineId: bagLine.id, receivedQuantity: 40 }] });
  const grn = await post(EXEC, '/procurement/receipts', { poId: po.id, grossWeightKg: 12500, tareWeightKg: 11500, vehicleNumber: 'AP09TX4471', lines: [{ poLineId: seedLine.id, receivedQuantity: 1000 }] });
  await inspect(GATE, { type: 'procurement_receipt', template: /Procurement receipt/, subjectType: 'goods_receipt', subjectId: grn.id }, { Moisture: 11.5, 'Physical purity': 98.6 });

  const inv = await post(EXEC, '/procurement/invoices', {
    poId: po.id,
    supplierInvoiceNo: `SLA-${tag}-001`,
    invoiceDate: day(0),
    lines: [
      { poLineId: seedLine.id, quantity: 1000, unitPrice: 39 },
      { poLineId: bagLine.id, quantity: 40, unitPrice: 19 },
    ],
  });
  await post(EXEC, `/procurement/invoices/${inv.id}/submit`, {});
  await approve(FIN, 'invoice_payment', inv.id);
  await post(FIN2, `/procurement/invoices/${inv.id}/pay`, { paymentReference: `UTR${tag}0001`, paymentMode: 'neft' });

  // one requisition left for the manager's approvals inbox
  const pending = await post(EXEC, '/procurement/requisitions', { title: 'Seed treatment chemical for rabi', department: 'production', costCentreId: cc.id, lines: [{ itemId: bags.id, quantity: 500, unitPrice: 20 }] });
  await post(EXEC, `/procurement/requisitions/${pending.id}/submit`);
  console.log(`  ${pr.pr_number} → ${po.po_number} paid; ${pending.pr_number} waiting for approval`);
}

async function growersAndProcessing() {
  console.log('• contract growers: agreement → delivery → inspection → settlement');
  const org = await pool.query(`SELECT id FROM organizations WHERE name = 'SeedSphere Seeds Pvt Ltd' LIMIT 1`);
  const variety = `BPT-5204-${tag}`;
  const foundation = await pool.query(
    `INSERT INTO seed_lots (lot_code, crop, variety, stage, quantity_total, quantity_allocated, unit, status, organization_id, low_stock_threshold, production_date)
     VALUES ($1, 'Paddy', $2, 'Foundation', 3000, 0, 'kg', 'active', $3, 100, $4) RETURNING id, lot_code`,
    [`FS-PAD-${tag}`, variety, org.rows[0]?.id ?? null, day(-150)],
  );
  const grower = await party('contract_grower', `Ramesh Reddy ${tag}`, {
    village: 'Ponnur',
    district: 'Guntur',
    bankAccountName: 'Ramesh Reddy',
    bankAccountNumber: '123456789012',
    bankIfsc: 'SBIN0001234',
  });
  const a = await post(EXEC, '/procurement/growers/agreements', {
    growerId: grower.id,
    season: 'kharif',
    seasonYear: new Date().getFullYear(),
    crop: 'Paddy',
    variety,
    seedClass: 'Certified',
    plotVillage: 'Ponnur',
    plotSurveyNumber: '112/3',
    areaAcres: 4,
    parentLotId: foundation.rows[0].id,
    parentQtyIssuedKg: 80,
    expectedYieldKg: 10000,
    buybackPricePerKg: 30,
    procurementWindowStart: day(-3),
    procurementWindowEnd: day(30),
  });
  await post(EXEC, `/procurement/growers/agreements/${a.id}/submit`);
  await approve(PMGR, 'grower_agreement', a.id);
  const d = await post(EXEC, '/procurement/growers/deliveries', { agreementId: a.id, grossWeightKg: 7000, tareWeightKg: 5000, bags: 50, vehicleNumber: 'AP07TC1102' });
  await inspect(GATE, { type: 'procurement_receipt', template: /Grower delivery/, subjectType: 'grower_delivery', subjectId: d.id }, { Moisture: 15, 'Physical purity': 98.5 });
  try {
    const st = await post(EXEC, '/procurement/growers/settlements', { agreementId: a.id });
    console.log(`  settlement ${st.settlement_number ?? st.id} drafted`);
  } catch (e) {
    console.log(`  (settlement left for the screen: ${(e as Error).message})`);
  }

  console.log('• processing: plant, recipe, intake → batch → certified lot');
  const plant = await post(PLMGR, '/processing/plants', { code: `GNT${tag}`, name: `Guntur seed plant ${tag}`, capacityKgPerDay: 20000 });
  for (const [code, name, machineType] of [
    ['PC', 'Pre-cleaner 5 t/h', 'pre_cleaner'],
    ['DRY', 'LSU dryer 5 t', 'dryer'],
    ['CG', 'Fine cleaner-grader', 'cleaner_grader'],
    ['TRT', 'Seed treater', 'treater'],
  ])
    await post(PLMGR, '/processing/machines', { plantId: plant.id, code: `${code}-${tag}`, name, machineType, capacityKgPerHour: 1500, serviceIntervalDays: 60 });
  const recipe = await post(PSUP, '/processing/recipes', {
    name: `Paddy standard line ${tag}`,
    crop: 'Paddy',
    targetMoisturePct: 12,
    stages: [
      { stage: 'pre_cleaning', machineType: 'pre_cleaner', maxLossPct: 3 },
      { stage: 'drying', machineType: 'dryer', parameters: 'Air 42 °C max', maxLossPct: 4 },
      { stage: 'cleaning_grading', machineType: 'cleaner_grader', parameters: 'Top screen 2.8 mm slotted', maxLossPct: 8 },
      { stage: 'treatment', machineType: 'treater', maxLossPct: 1 },
    ],
    chemicals: [{ chemicalName: 'Carbendazim 50% WP', dosePerKg: 2, doseUnit: 'g', purpose: 'Seed-borne fungi' }],
  });
  await post(PSUP, `/processing/recipes/${recipe.id}/submit`);
  await approve(PLMGR, 'processing_recipe', recipe.id);
  const intake = await post(PSUP, '/processing/intake', { sourceType: 'grower_delivery', sourceId: d.id, plantId: plant.id });
  await inspect(PINSP, { type: 'processing_pre', subjectType: 'raw_intake', subjectId: intake.id }, {});
  const batch = await post(PSUP, '/processing/batches', { recipeId: recipe.id, plantId: plant.id, inputs: [{ rawIntakeId: intake.id, quantityKg: 2000 }] });
  await post(PSUP, `/processing/batches/${batch.id}/start`);
  await post(PSUP, `/processing/batches/${batch.id}/stages/1`, { outputKg: 1950 });
  await post(PSUP, `/processing/batches/${batch.id}/stages/2`, { outputKg: 1885 });
  await post(PSUP, `/processing/batches/${batch.id}/stages/3`, { outputKg: 1760 });
  await post(PSUP, `/processing/batches/${batch.id}/treatments`, { chemicalName: 'Carbendazim 50% WP', quantityUsed: 3520, supplierLot: `CBZ-${tag}` });
  await post(PSUP, `/processing/batches/${batch.id}/stages/4`, { outputKg: 1756 });
  await inspect(PINSP, { type: 'processing_final', subjectType: 'processing_batch', subjectId: batch.id }, { Moisture: 11.2, 'Physical purity': 98.8, 'Germination (quick test)': 88 });
  const done = await post(PLMGR, `/processing/batches/${batch.id}/complete`);
  console.log(`  ${batch.batch_number} → lot ${done.lot.lot_code} (${done.lot.quantity_total} kg)`);

  // a second delivery waiting in raw intake for the next batch
  const d2 = await post(EXEC, '/procurement/growers/deliveries', { agreementId: a.id, grossWeightKg: 6200, tareWeightKg: 5000, bags: 30, vehicleNumber: 'AP07TC1188' });
  await inspect(GATE, { type: 'procurement_receipt', template: /Grower delivery/, subjectType: 'grower_delivery', subjectId: d2.id }, { Moisture: 16.5, 'Physical purity': 98 });
  await post(PSUP, '/processing/intake', { sourceType: 'grower_delivery', sourceId: d2.id, plantId: plant.id });
  return { lot: done.lot as Json, grower };
}

async function warehouse(lot: Json): Promise<{ dealer: Json }> {
  console.log('• warehouse: receipt → dispatch → delivery, return, count, sensor');
  const w = await post(WMGR, '/warehouse/warehouses', { code: `WH${tag}`, name: `Guntur central godown ${tag}` });
  const binA = await post(WMGR, '/warehouse/locations', { warehouseId: w.id, code: 'A-01-01', zone: 'A', capacityKg: 20000 });
  const binB = await post(WMGR, '/warehouse/locations', { warehouseId: w.id, code: 'B-01-01', zone: 'B', capacityKg: 20000 });
  const quarantine = ((await get(WMGR, `/warehouse/locations?warehouseId=${w.id}`)) as Json[]).find((l) => l.location_type === 'quarantine')!;
  await post(WSUP, '/warehouse/lot-tests', { seedLotId: lot.id, testedOn: day(-2), germinationPct: 89, minGerminationPct: 80, physicalPurityPct: 98.8, moisturePct: 11.2, laboratory: 'State Seed Testing Laboratory, Guntur', reportNumber: `STL-${tag}` });
  await post(WSUP, '/warehouse/receipts', { seedLotId: lot.id, locationId: binA.id, quantityKg: 1200, sourceType: 'processing' });
  await post(WSUP, '/warehouse/receipts', { seedLotId: lot.id, locationId: binB.id, quantityKg: 500, sourceType: 'processing' });

  const dealer = await party('dealer', `Venkateswara Agro Centre ${tag}`, { village: 'Tenali', district: 'Guntur', licenceNumber: `SDL/GNT/${tag}`, licenceValidUntil: day(300) });
  const d = await post(WSUP, '/warehouse/dispatches', { dealerId: dealer.id, warehouseId: w.id, requestedDate: day(1), lines: [{ seedLotId: lot.id, locationId: binA.id, quantityKg: 300 }] });
  await post(WSUP, `/warehouse/dispatches/${d.id}/submit`);
  await approve(WMGR, 'dispatch_order', d.id);
  await post(WSUP, `/warehouse/dispatches/${d.id}/ship`, { vehicleNumber: 'AP07TB2231', lrNumber: `LR-${tag}` });
  await post(WSUP, `/warehouse/dispatches/${d.id}/deliver`, { receivedByName: 'K. Srinivas' });

  const d2 = await post(WSUP, '/warehouse/dispatches', { dealerId: dealer.id, warehouseId: w.id, requestedDate: day(3), lines: [{ seedLotId: lot.id, locationId: binA.id, quantityKg: 200 }] });
  await post(WSUP, `/warehouse/dispatches/${d2.id}/submit`); // waiting for the warehouse manager

  const ret = await post(WSUP, '/warehouse/returns', { dealerId: dealer.id, dispatchId: d.id, seedLotId: lot.id, quarantineLocationId: quarantine.id, quantityKg: 25, reason: 'quality_complaint', details: 'Two bags wet at the bottom', complaintSeverity: 'minor' });
  await inspect(WINSP, { type: 'warehouse_return', subjectType: 'stock_return', subjectId: ret.id }, {});

  const adj = await post(WSUP, '/warehouse/adjustments', { seedLotId: lot.id, locationId: binB.id, quantityChange: -10, reason: 'damage', details: 'One bag torn by forklift' });
  void adj; // left for the warehouse manager to approve
  const count = await post(WMGR, '/warehouse/counts', { warehouseId: w.id, zone: 'A' });
  void count;

  const s = await post(WMGR, '/warehouse/sensors', { code: `T-${tag}-A`, locationId: binA.id, sensorType: 'temperature', unit: '°C', minValue: 10, maxValue: 25 });
  for (const v of [21.5, 22.1, 23.4, 26.8, 27.5, 24.2, 22.9]) await post(WSUP, `/warehouse/sensors/${s.sensor.id}/readings`, { value: v });
  await post(WMGR, '/warehouse/sensors', { code: `H-${tag}-A`, locationId: binA.id, sensorType: 'humidity', unit: '%RH', maxValue: 65 }).then((h: Json) => post(WSUP, `/warehouse/sensors/${h.sensor.id}/readings`, { value: 58 }));
  console.log(`  ${d.dispatch_number} delivered to ${dealer.name}; ${d2.dispatch_number} awaiting approval; return ${ret.return_number}; sensor ${s.sensor.code}`);
  return { dealer };
}

const SYSADMIN = 'sysadmin@seedsphere.com';

async function reach(lot: Json, grower: Json, dealer: Json) {
  console.log('• reach: pack tags, portal logins, dealer request, farmer complaint, messages');
  const made = await post(PLMGR, '/reach/tags', { seedLotId: lot.id, count: 12, packSizeKg: 10 });
  // portal logins: grower@ and dealer@ are linked to this season's records (once)
  for (const [party, email] of [[grower, 'grower@seedsphere.com'], [dealer, 'dealer@seedsphere.com']] as const) {
    try {
      await post(PMGR, `/parties/${party.id}/portal-user`, { email });
      console.log(`  ${email} now sees ${party.name}`);
    } catch (e) {
      console.log(`  (${email} was already linked to an earlier record)`);
    }
  }
  try {
    await call('dealer@seedsphere.com', 'POST', '/portal/dealer/indents', { crop: 'Paddy', variety: 'BPT-5204', quantityKg: 800, neededBy: day(10), notes: 'For the kharif sowing season' });
  } catch {
    /* dealer@ belongs to an earlier set — fine */
  }
  const farmer = await fetch(`${BASE}/public/complaints`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name: 'Narayana Rao', phone: phone(), village: 'Tenali', tagCode: made.tagCodes[0], complaintType: 'germination', description: 'About half of the seeds did not sprout after 10 days.' }),
  }).then((r) => r.json() as Promise<Json>);
  await post(SYSADMIN, '/reach/messages/flush');
  console.log(`  tags ${made.tagCodes[0]} … ${made.tagCodes[made.tagCodes.length - 1]} — open /verify/${made.tagCodes[0]}`);
  console.log(`  farmer complaint ${farmer.data?.code ?? farmer.message}`);
}

async function assurance(lot: Json) {
  console.log('• assurance: trial → candidate, audit, training, recall draft');
  const RDX = 'rdexecutive@seedsphere.com', RDM = 'rdmanager@seedsphere.com', QO = 'qualityofficer@seedsphere.com', QM = 'qualitymanager@seedsphere.com';
  const crop = `Chilli-${tag}`;
  const t = await post(RDX, '/assurance/rd/trials', { title: `Yield trial ${tag}`, crop, season: 'Kharif 2026', location: 'Guntur', replications: 2, traits: [{ name: 'yield', unit: 'q/ha', higherIsBetter: true }, { name: 'days_to_flower', unit: 'days', higherIsBetter: false }], entries: [{ name: 'Check hybrid', isCheck: true }, { name: 'Line A' }, { name: 'Line B' }] });
  await post(RDX, `/assurance/rd/trials/${t.id}/submit`);
  await approve(RDM, 'trial_protocol', t.id);
  await post(RDX, `/assurance/rd/trials/${t.id}/start`);
  const detail = await get(RDX, `/assurance/rd/trials/${t.id}`);
  const id = (n: string) => detail.entries.find((e: Json) => e.name === n).id;
  const obs: Json[] = [];
  for (const rep of [1, 2]) for (const [n, y, d] of [['Check hybrid', 20, 50], ['Line A', 25, 45], ['Line B', 18, 55]] as const) obs.push({ entryId: id(n), replication: rep, trait: 'yield', value: y + rep * 0.2 }, { entryId: id(n), replication: rep, trait: 'days_to_flower', value: d });
  await post(RDX, `/assurance/rd/trials/${t.id}/observations`, { observations: obs });
  await post(RDX, `/assurance/rd/trials/${t.id}/complete`);
  const c = await post(RDX, '/assurance/rd/candidates', { name: `Line A ${tag}`, sourceTrialId: t.id });
  const adv = await post(RDX, `/assurance/rd/candidates/${c.id}/advance`, { toStage: 'multi_location', justification: 'Beat the check by 25% on yield and flowers 5 days earlier' });
  await approve(RDM, 'variety_advancement', adv.id);
  console.log(`  trial ${t.trial_code}, candidate ${c.candidate_code} now in multi-location trials — open /rd/release`);

  const a = await post(QO, '/assurance/audits', { auditType: 'dealer', title: `Dealer premises check ${tag}`, auditee: 'Sri Sai Seeds, Tenali', scheduledDate: day(0), leadAuditor: 'Quality officer' });
  await post(QO, `/assurance/audits/${a.id}/start`);
  await post(QO, `/assurance/audits/${a.id}/findings`, { severity: 'minor', description: 'Storage racks not labelled by variety' });
  await post(QO, `/assurance/audits/${a.id}/findings`, { severity: 'major', description: 'Seed stored next to pesticide stock' });
  console.log(`  audit ${a.audit_number} with a major finding (a non-conformance was opened)`);

  const course = await post(QO, '/assurance/training/courses', { title: `Seed sampling and handling ${tag}`, requiredFor: ['plant_supervisor', 'warehouse_supervisor', 'quality_officer'], validityMonths: 12 });
  const staff = (await get(QO, '/assurance/training/staff')) as Json[];
  const who = staff.filter((u) => ['plant_supervisor', 'quality_officer'].includes(u.job_role)).map((u) => u.id);
  if (who.length) await post(QO, '/assurance/training/records', { courseId: course.id, userIds: who, completedOn: day(-30), trainer: 'Quality manager' });
  console.log(`  training ${course.course_code}: some staff trained, others show as missing`);
  const rc = await post(QO, '/assurance/recalls', { title: `Recall drill ${tag}`, reason: 'Mock recall to practise the trace and notice flow', recallClass: 'III', actionRequired: 'Keep aside and wait for our call.', lotIds: [lot.id] });
  console.log(`  recall ${rc.recall_number} drafted (not sent for approval) — open /quality/recalls`);
  void QM;
}

async function rdPrograms() {
  console.log('• R&D: germplasm, breeding programme, nursery');
  const RDX = 'rdexecutive@seedsphere.com';
  const crop = `Chilli-${tag}`;
  const a1 = await post(RDX, '/rd/accessions', { crop, name: `Guntur Local ${tag}`, accessionType: 'landrace', originState: 'Andhra Pradesh', originSite: 'Guntur', custody: 'cold_store' });
  const a2 = await post(RDX, '/rd/accessions', { crop, name: `Byadgi Selection ${tag}`, accessionType: 'landrace', originState: 'Karnataka', originSite: 'Byadgi', custody: 'cold_store' });
  await post(RDX, `/rd/accessions/${a1.id}/phenotypes`, { trait: 'days_to_flower', value: 48, unit: 'days', season: 'Kharif 2026' }).catch(() => undefined);
  const pr = await post(RDX, '/rd/programs', { name: `Pungency improvement ${tag}`, crop, objective: 'yield', leadBreeder: 'Rd executive', startDate: day(-30), expectedEndDate: day(300), budget: 250000, status: 'active', maleParentId: a1.id, femaleParentId: a2.id });
  await post(RDX, '/rd/nurseries', { name: `Nursery block A ${tag}`, programId: pr.id, crop, season: 'Kharif 2026', location: 'Guntur', areaAcres: 2.5 });
  console.log(`  accessions ${a1.accession_code}, ${a2.accession_code}; programme ${pr.program_code} — open /rd/dashboard`);
}

async function productionPlanning() {
  console.log('• production planning: farmers, farms, crop plans, inspections, harvest requests');
  const SA = 'superadmin@seedsphere.com', INSP = 'inspector@seedsphere.com';
  const cropRows: [string, string, string][] = [['Chilli', 'Vegetable', 'Kharif'], ['Maize', 'Food Grain', 'Kharif'], ['Cotton', 'Fibre Crop', 'Kharif'], ['Tomato', 'Vegetable', 'Rabi']];
  for (const [name, category, season] of cropRows) await pool.query(`INSERT INTO crops (name, category, season) VALUES ($1,$2,$3) ON CONFLICT (name) DO NOTHING`, [name, category, season]);
  const vars: [string, string, string][] = [['Chilli', 'Teja Gold', 'Capsicum annuum'], ['Maize', 'Surya 202', 'Zea mays'], ['Cotton', 'Bunny BT', 'Gossypium hirsutum']];
  for (const [crop, v, bot] of vars) await pool.query(`INSERT INTO varieties (crop, variety_name, botanical_name, status, created_by) VALUES ($1,$2,$3,'approved','seed-demo') ON CONFLICT (crop, variety_name) DO NOTHING`, [crop, v, bot]);
  const vid = async (crop: string) => (await pool.query(`SELECT id FROM varieties WHERE crop = $1 AND status = 'approved' ORDER BY created_at LIMIT 1`, [crop])).rows[0].id as string;
  const people: [string, string, string][] = [['Ramesh Reddy', 'Guntur', 'Tenali'], ['Lakshmi Devi', 'Warangal', 'Hanamkonda'], ['Suresh Naik', 'Kurnool', 'Adoni']];
  const farmerIds: string[] = [];
  for (const [name, region, location] of people) {
    const n = `${name} ${tag}`;
    farmerIds.push((await pool.query(`INSERT INTO farmers (name, phone, region, location) VALUES ($1,$2,$3,$4) RETURNING id`, [n, phone(), region, location])).rows[0].id);
  }
  const farmDefs: [number, string, string, number, string, string][] = [[0, 'North plot', 'Chilli', 6.5, 'red', 'drip'], [0, 'River field', 'Maize', 10, 'alluvial', 'canal'], [1, 'Hill block', 'Cotton', 8, 'black', 'borewell'], [2, 'Main field', 'Chilli', 4, 'loamy', 'drip']];
  const farms: { id: string; crop: string; farmerId: string }[] = [];
  for (const [fi, name, crop, area, soil, irr] of farmDefs) {
    const f = await post(SA, '/master-data/farms', { farmerId: farmerIds[fi], name: `${name} ${tag}`, location: people[fi][2], area, soilType: soil, irrigationType: irr, currentCrop: crop, cropHistory: ['Paddy'] });
    farms.push({ id: f.id, crop, farmerId: farmerIds[fi] });
  }
  const states = ['Planned', 'Growing', 'Sown', 'Planned'];
  const plans: Json[] = [];
  for (const [i, f] of farms.entries()) {
    plans.push(await post(SA, '/production/crop-plans', { farmId: f.id, varietyId: await vid(f.crop), crop: f.crop, season: 'Kharif 2026', targetArea: farmDefs[i][3], targetProduction: farmDefs[i][3] * 400, sowingDate: day(-20 + i * 10), harvestDate: day(90 + i * 7), status: states[i] }));
  }
  const stages = ['Vegetative', 'Flowering', 'Germination', 'Seed Development'];
  for (const [i, f] of farms.entries()) {
    await post(INSP, '/production/farm-inspections', { farmId: f.id, cropStage: stages[i], healthScore: [88, 72, 55, 91][i], diseaseDetected: i === 2, diseaseName: i === 2 ? 'Leaf curl' : undefined, notes: 'Routine visit', inspectionDate: day(-3 - i), aiPrediction: { diseaseRiskPercent: [12, 30, 68, 8][i], pestsDetected: i === 2 ? ['Whitefly'] : [], recommendations: ['Re-inspect in 7 days'] } });
    const rec = await post(INSP, '/production/inspections', { farmId: f.id, crop: f.crop, status: i < 2 ? 'Completed' : 'Scheduled', inspectionDate: day(-2 + i) });
    if (i === 0) await call(SA, 'PATCH', `/production/inspections/${rec.id}/approve`);
  }
  const hr = await post('supervisor@seedsphere.com', '/production/harvests', { farmId: farms[0].id, varietyId: await vid('Chilli'), crop: 'Chilli', cropPlanId: plans[0].id, estimatedQuantityKg: 2400, requestedHarvestDate: day(5), notes: 'First picking ready' });
  await post(SA, `/production/harvests/${hr.id}/approve`, { inspectorNotes: 'Pods mature, moisture ok' });
  await post('supervisor@seedsphere.com', '/production/harvests', { farmId: farms[3].id, varietyId: await vid('Chilli'), crop: 'Chilli', estimatedQuantityKg: 1500, requestedHarvestDate: day(9) });
  console.log(`  ${farms.length} farms, ${plans.length} crop plans, harvest ${hr.request_code ?? hr.requestCode} approved — open /crop-planning, /farms, /harvests/approval`);
}

async function safety() {
  console.log('• safety & environment: incidents and chemical register');
  const WH = 'supervisor@seedsphere.com', MGR = 'whmanager@seedsphere.com';
  const chem = `Thiram-${tag}`;
  await post(MGR, '/safety/chemicals', { chemical: chem, action: 'received', quantity: 25, unit: 'kg', supplier: 'Agri Chem Traders' });
  await post(MGR, '/safety/chemicals', { chemical: chem, action: 'used', quantity: 6.5, unit: 'kg', notes: 'Seed treatment, one batch' });
  await post(MGR, '/safety/chemicals', { chemical: chem, action: 'disposed', quantity: 0.5, unit: 'kg', disposalMethod: 'Collected by licensed hazardous-waste contractor' });
  await post(WH, '/safety/incidents', { incidentType: 'near_miss', severity: 'minor', area: 'warehouse', occurredAt: new Date(Date.now() - 6 * 86400000).toISOString(), location: 'Bay 3', description: 'Pallet stack leaned while being moved; no one hurt.', immediateAction: 'Stack re-built, forklift route marked' });
  const inc = await post(WH, '/safety/incidents', { incidentType: 'chemical_spill', severity: 'major', area: 'processing', occurredAt: new Date(Date.now() - 2 * 86400000).toISOString(), location: 'Treatment room', description: 'Bag of treatment powder split while loading; floor contaminated.', chemical: chem, quantity: 0.8, unit: 'kg', immediateAction: 'Area cordoned, spill kit used' });
  await post(MGR, `/safety/incidents/${inc.id}/investigate`, {});
  console.log(`  incident ${inc.incident_number} (non-conformance raised) — open /warehouse/safety`);
}

async function main() {
  console.log(`Seeding demo records (set ${tag}) through ${BASE}`);
  if (process.env.ONLY === 'safety') { await safety(); console.log('Done.'); return; }
  await procurement();
  const { lot, grower } = await growersAndProcessing();
  const { dealer } = await warehouse(lot);
  await reach(lot, grower, dealer);
  await assurance(lot);
  await rdPrograms();
  await productionPlanning();
  await safety();
  console.log('Done.');
}

main()
  .catch((e) => {
    console.error(e instanceof Error ? e.message : e);
    process.exitCode = 1;
  })
  .finally(() => pool.end());
