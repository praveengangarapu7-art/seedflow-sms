import { rdRouter } from './modules/rd/rd.routes';
import { safetyRouter } from './modules/safety/safety.routes';
import { farmOpsRouter } from './modules/farmOps/farmOps.routes';
import { assuranceRouter, recallPortalRouter } from './modules/assurance/assurance.routes';
import { portalRouter, publicRouter, reachRouter } from './modules/reach/reach.routes';
import cookieParser from 'cookie-parser';
import cors from 'cors';
import express from 'express';
import { env } from './config/env';
import { cronRouter } from './modules/cron/cron.routes';
import { apiMetricsMiddleware } from './middleware/apiMetrics';
import { errorHandler } from './middleware/errorHandler';
import { allocationsRouter } from './modules/allocations/allocations.routes';
import { analyticsRouter } from './modules/analytics/analytics.routes';
import { auditLogsRouter } from './modules/auditLogs/auditLogs.routes';
import { breedingAnalyticsRouter } from './modules/breedingAnalytics/breedingAnalytics.routes';
import { climateSmartSelectionRouter } from './modules/climateSmartSelection/climateSmartSelection.routes';
import { authRouter } from './modules/auth/auth.routes';
import { authenticityRouter } from './modules/authenticity/authenticity.routes';
import { complianceRouter } from './modules/compliance/compliance.routes';
import { cropPlanningRouter } from './modules/cropPlanning/cropPlanning.routes';
import { cropVarietiesRouter } from './modules/cropVarieties/cropVarieties.routes';
import { cropsRouter } from './modules/crops/crops.routes';
import { dataGovernanceRouter } from './modules/dataGovernance/dataGovernance.routes';
import { demandPlanningRouter } from './modules/demandPlanning/demandPlanning.routes';
import { farmerEducationRouter } from './modules/farmerEducation/farmerEducation.routes';
import { farmersRouter } from './modules/farmers/farmers.routes';
import { financingRouter } from './modules/financing/financing.routes';
import { feedbackLoopRouter } from './modules/feedbackLoop/feedbackLoop.routes';
import { govProgramsRouter } from './modules/govPrograms/govPrograms.routes';
import { marketIntelligenceRouter } from './modules/marketIntelligence/marketIntelligence.routes';
import { labTestingRouter } from './modules/labTesting/labTesting.routes';
import { assistantRouter } from './modules/assistant/assistant.routes';
import { aiRouter } from './modules/ai/ai.routes';
import { monitoringRouter } from './modules/monitoring/monitoring.routes';
import { organizationsRouter } from './modules/organizations/organizations.routes';
import { packagingRouter } from './modules/packaging/packaging.routes';
import { partnersRouter } from './modules/partners/partners.routes';
import { performanceRatingsRouter } from './modules/performanceRatings/performanceRatings.routes';
import { privacyRouter } from './modules/privacy/privacy.routes';
import { qualityRouter } from './modules/quality/quality.routes';
import { reconciliationRouter } from './modules/reconciliation/reconciliation.routes';
import { pushNotificationsRouter } from './modules/pushNotifications/pushNotifications.routes';
import { seedLotsRouter } from './modules/seedLots/seedLots.routes';
import { seedRequestsRouter } from './modules/seedRequests/seedRequests.routes';
import { storageRouter } from './modules/storage/storage.routes';
import { usersRouter } from './modules/users/users.routes';
import { varietiesRouter } from './modules/varieties/varieties.routes';
import { customFieldsRouter } from './modules/customFields/customFields.routes';
import { workflowsRouter } from './modules/workflows/workflows.routes';
import { approvalsRouter } from './modules/approvals/approvals.routes';
import { attachmentsRouter } from './modules/attachments/attachments.routes';
import { inspectionsRouter } from './modules/inspections/inspections.routes';
import { partiesRouter } from './modules/parties/parties.routes';
import { lookupsRouter } from './modules/lookups/lookups.routes';
import { procurementRouter } from './modules/procurement/procurement.routes';
import { processingRouter } from './modules/processing/processing.routes';
import { warehouseDeviceRouter, warehouseRouter } from './modules/warehouse/warehouse.routes';

export function createApp() {
  const app = express();

  // Behind Vercel's (or any) proxy, trust the first hop so rate limiting and
  // logs see the real client IP instead of the proxy's.
  if (process.env.VERCEL || process.env.TRUST_PROXY === 'true') app.set('trust proxy', 1);

  // credentials:true requires a specific origin (not '*') so the browser
  // will actually send/accept the httpOnly refresh-token cookie cross-port.
  // FRONTEND_ORIGIN may list several origins, comma separated. Outside
  // production the same dev server is also accepted on 127.0.0.1, which
  // browsers treat as a different origin from localhost.
  const origins = env.frontendOrigin.split(',').map((o) => o.trim()).filter(Boolean);
  if (env.nodeEnv !== 'production') {
    for (const o of [...origins]) if (o.includes('//localhost')) origins.push(o.replace('//localhost', '//127.0.0.1'));
  }
  app.use(cors({ origin: origins.length === 1 ? origins[0] : origins, credentials: true }));
  app.use(cookieParser());
  // 6mb: the AI Center posts compressed photos (~0.3-1 MB base64). Vercel caps
  // a function request body at 4.5 MB, so the client resizes before upload.
  app.use(express.json({ limit: '6mb' }));
  app.use(apiMetricsMiddleware);

  app.get('/api/v1/health', (_req, res) => {
    res.json({ success: true, data: { status: 'ok' } });
  });

  // Production planning screens (farms, crop plans, inspections, harvests). Mounted first so its
  // exact paths win over the broader routers below.
  app.use('/api/v1', farmOpsRouter);

  app.use('/api/v1/auth', authRouter);
  app.use('/api/v1/organizations', organizationsRouter);
  app.use('/api/v1/users', usersRouter);
  app.use('/api/v1/production/seed-lots', seedLotsRouter);
  app.use('/api/v1/production/allocations', allocationsRouter);
  app.use('/api/v1/audit-logs', auditLogsRouter);
  app.use('/api/v1/production/analytics', analyticsRouter);
  app.use('/api/v1/production/compliance', complianceRouter);
  app.use('/api/v1/production/workflows', workflowsRouter);
  app.use('/api/v1/production/demand-planning', demandPlanningRouter);
  app.use('/api/v1/farmers', farmersRouter);
  app.use('/api/v1/production/seed-requests', seedRequestsRouter);
  app.use('/api/v1/production/performance-ratings', performanceRatingsRouter);
  app.use('/api/v1/production/packaging', packagingRouter);
  app.use('/api/v1/production/storage', storageRouter);
  app.use('/api/v1/production/field-inspections', feedbackLoopRouter);
  app.use('/api/v1/production/data-governance', dataGovernanceRouter);
  app.use('/api/v1/production/varieties', varietiesRouter);
  app.use('/api/v1/crops', cropsRouter);
  app.use('/api/v1/crop-varieties', cropVarietiesRouter);
  app.use('/api/v1/production/lab-testing', labTestingRouter);
  app.use('/api/v1/production/crop-planning', cropPlanningRouter);
  app.use('/api/v1/push-notifications', pushNotificationsRouter);
  app.use('/api/v1/monitoring', monitoringRouter);
  app.use('/api/v1/privacy', privacyRouter);
  app.use('/api/v1/master-data', reconciliationRouter);
  app.use('/api/v1/authenticity', authenticityRouter);
  app.use('/api/v1/partners', partnersRouter);
  app.use('/api/v1/government-programs', govProgramsRouter);
  app.use('/api/v1/production/market-intelligence', marketIntelligenceRouter);
  app.use('/api/v1/production/breeding-analytics', breedingAnalyticsRouter);
  app.use('/api/v1/production/climate-smart', climateSmartSelectionRouter);
  app.use('/api/v1/financing', financingRouter);
  app.use('/api/v1/farmer-education', farmerEducationRouter);
  app.use('/api/v1/assistant', assistantRouter);
  app.use('/api/v1/ai', aiRouter);
  app.use('/api/v1/custom-fields', customFieldsRouter);
  app.use('/api/v1/quality', qualityRouter);

  // Phase A foundations shared by every module
  app.use('/api/v1/parties', partiesRouter);
  app.use('/api/v1/attachments', attachmentsRouter);
  app.use('/api/v1/approvals', approvalsRouter);
  app.use('/api/v1/inspections', inspectionsRouter);
  app.use('/api/v1/lookups', lookupsRouter);

  // Phase B
  app.use('/api/v1/procurement', procurementRouter);
  app.use('/api/v1/processing', processingRouter);

  // Phase C
  app.use('/api/v1/warehouse/devices', warehouseDeviceRouter);
  app.use('/api/v1/warehouse', warehouseRouter);

  // Phase D
  app.use('/api/v1/public', publicRouter);
  app.use('/api/v1/cron', cronRouter);
  app.use('/api/v1/portal', portalRouter);
  app.use('/api/v1/reach', reachRouter);
  app.use('/api/v1/assurance', assuranceRouter);
  app.use('/api/v1/safety', safetyRouter);
  app.use('/api/v1/rd', rdRouter);
  app.use('/api/v1/portal/recalls', recallPortalRouter);

  app.use((_req, res) => {
    res.status(404).json({ success: false, message: 'Not found' });
  });

  app.use(errorHandler);

  return app;
}
