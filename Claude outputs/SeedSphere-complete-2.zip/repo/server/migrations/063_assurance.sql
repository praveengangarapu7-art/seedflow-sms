-- Phase E — assurance: R&D trials and variety release, recalls, audits, training.

-- R&D trials ---------------------------------------------------------------
CREATE TABLE rd_trials (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  trial_code VARCHAR(20) NOT NULL UNIQUE,
  title VARCHAR(200) NOT NULL,
  crop VARCHAR(100) NOT NULL,
  season VARCHAR(30) NOT NULL,
  location VARCHAR(150) NOT NULL,
  design VARCHAR(20) NOT NULL DEFAULT 'rcbd' CHECK (design IN ('rcbd', 'crd', 'augmented', 'observational')),
  replications INT NOT NULL DEFAULT 3 CHECK (replications BETWEEN 1 AND 12),
  traits JSONB NOT NULL DEFAULT '[]',
  protocol_note TEXT,
  status VARCHAR(20) NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'pending_approval', 'approved', 'rejected', 'running', 'completed')),
  rejection_reason TEXT,
  created_by VARCHAR(100) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE rd_trial_entries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  trial_id UUID NOT NULL REFERENCES rd_trials(id) ON DELETE CASCADE,
  entry_code VARCHAR(30) NOT NULL,
  name VARCHAR(150) NOT NULL,
  is_check BOOLEAN NOT NULL DEFAULT FALSE,
  UNIQUE (trial_id, entry_code)
);
CREATE TABLE rd_trial_observations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  trial_id UUID NOT NULL REFERENCES rd_trials(id) ON DELETE CASCADE,
  entry_id UUID NOT NULL REFERENCES rd_trial_entries(id) ON DELETE CASCADE,
  replication INT NOT NULL CHECK (replication > 0),
  trait VARCHAR(60) NOT NULL,
  value NUMERIC(14, 4) NOT NULL,
  recorded_by VARCHAR(100) NOT NULL,
  recorded_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (entry_id, replication, trait)
);
CREATE INDEX idx_rd_obs_trial ON rd_trial_observations (trial_id);

-- Candidates, advancement, spec handover -----------------------------------
CREATE TABLE rd_candidates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  candidate_code VARCHAR(20) NOT NULL UNIQUE,
  name VARCHAR(150) NOT NULL,
  crop VARCHAR(100) NOT NULL,
  botanical_name VARCHAR(150) NOT NULL,
  source_trial_id UUID REFERENCES rd_trials(id) ON DELETE SET NULL,
  stage VARCHAR(20) NOT NULL DEFAULT 'candidate' CHECK (stage IN ('candidate', 'multi_location', 'pre_release', 'released', 'dropped')),
  variety_id UUID REFERENCES varieties(id) ON DELETE SET NULL,
  created_by VARCHAR(100) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (crop, name)
);
CREATE TABLE rd_advancements (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  adv_number VARCHAR(20) NOT NULL UNIQUE,
  candidate_id UUID NOT NULL REFERENCES rd_candidates(id) ON DELETE CASCADE,
  from_stage VARCHAR(20) NOT NULL,
  to_stage VARCHAR(20) NOT NULL CHECK (to_stage IN ('multi_location', 'pre_release', 'released', 'dropped')),
  justification TEXT NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'pending_approval' CHECK (status IN ('pending_approval', 'approved', 'rejected')),
  rejection_reason TEXT,
  proposed_by VARCHAR(100) NOT NULL,
  proposed_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_rd_adv_candidate ON rd_advancements (candidate_id);
CREATE TABLE rd_variety_specs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  candidate_id UUID NOT NULL UNIQUE REFERENCES rd_candidates(id) ON DELETE CASCADE,
  descriptors JSONB NOT NULL DEFAULT '{}',
  min_germination_pct NUMERIC(5, 2) CHECK (min_germination_pct BETWEEN 0 AND 100),
  min_purity_pct NUMERIC(5, 2) CHECK (min_purity_pct BETWEEN 0 AND 100),
  max_moisture_pct NUMERIC(5, 2) CHECK (max_moisture_pct BETWEEN 0 AND 100),
  recommended_regions TEXT,
  maintenance_notes TEXT,
  status VARCHAR(12) NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'ready', 'handed_over')),
  handed_over_at TIMESTAMPTZ,
  handed_over_by VARCHAR(100),
  updated_by VARCHAR(100) NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Recalls ------------------------------------------------------------------
CREATE TABLE recalls (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  recall_number VARCHAR(20) NOT NULL UNIQUE,
  title VARCHAR(200) NOT NULL,
  reason TEXT NOT NULL,
  recall_class VARCHAR(4) NOT NULL CHECK (recall_class IN ('I', 'II', 'III')),
  action_required TEXT NOT NULL,
  complaint_id UUID REFERENCES quality_complaints(id) ON DELETE SET NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'pending_approval', 'approved', 'in_progress', 'closed', 'rejected')),
  rejection_reason TEXT,
  closure_note TEXT,
  created_by VARCHAR(100) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  started_at TIMESTAMPTZ,
  closed_at TIMESTAMPTZ
);
CREATE TABLE recall_lots (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  recall_id UUID NOT NULL REFERENCES recalls(id) ON DELETE CASCADE,
  seed_lot_id UUID NOT NULL REFERENCES seed_lots(id) ON DELETE RESTRICT,
  UNIQUE (recall_id, seed_lot_id)
);
CREATE INDEX idx_recall_lots_lot ON recall_lots (seed_lot_id);
CREATE TABLE recall_recipients (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  recall_id UUID NOT NULL REFERENCES recalls(id) ON DELETE CASCADE,
  dealer_id UUID NOT NULL REFERENCES parties(id) ON DELETE RESTRICT,
  seed_lot_id UUID NOT NULL REFERENCES seed_lots(id) ON DELETE RESTRICT,
  dispatched_kg NUMERIC(12, 2) NOT NULL,
  notified_at TIMESTAMPTZ,
  acknowledged_at TIMESTAMPTZ,
  acknowledged_by VARCHAR(100),
  ack_note TEXT,
  UNIQUE (recall_id, dealer_id, seed_lot_id)
);

-- Audits -------------------------------------------------------------------
CREATE TABLE audits (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  audit_number VARCHAR(20) NOT NULL UNIQUE,
  audit_type VARCHAR(20) NOT NULL CHECK (audit_type IN ('internal', 'dealer', 'supplier', 'grower_field', 'certification', 'regulatory')),
  title VARCHAR(200) NOT NULL,
  auditee VARCHAR(200) NOT NULL,
  party_id UUID REFERENCES parties(id) ON DELETE SET NULL,
  scheduled_date DATE NOT NULL,
  lead_auditor VARCHAR(150) NOT NULL,
  status VARCHAR(12) NOT NULL DEFAULT 'planned' CHECK (status IN ('planned', 'in_progress', 'completed', 'closed', 'cancelled')),
  summary TEXT,
  created_by VARCHAR(100) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  completed_at TIMESTAMPTZ,
  closed_at TIMESTAMPTZ
);
CREATE TABLE audit_findings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  audit_id UUID NOT NULL REFERENCES audits(id) ON DELETE CASCADE,
  finding_no INT NOT NULL,
  description TEXT NOT NULL,
  severity VARCHAR(10) NOT NULL CHECK (severity IN ('observation', 'minor', 'major', 'critical')),
  status VARCHAR(8) NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'closed')),
  ncr_id UUID REFERENCES non_conformances(id) ON DELETE SET NULL,
  closure_note TEXT,
  closed_by VARCHAR(100),
  closed_at TIMESTAMPTZ,
  UNIQUE (audit_id, finding_no)
);

-- Training -----------------------------------------------------------------
CREATE TABLE training_courses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  course_code VARCHAR(20) NOT NULL UNIQUE,
  title VARCHAR(200) NOT NULL,
  required_for TEXT[] NOT NULL DEFAULT '{}',
  validity_months INT CHECK (validity_months > 0),
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_by VARCHAR(100) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE training_records (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  course_id UUID NOT NULL REFERENCES training_courses(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  completed_on DATE NOT NULL,
  trainer VARCHAR(150),
  score NUMERIC(5, 2),
  passed BOOLEAN NOT NULL DEFAULT TRUE,
  note TEXT,
  recorded_by VARCHAR(100) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_training_records_user ON training_records (user_id, course_id);

-- Approval rules -----------------------------------------------------------
INSERT INTO approval_rules (entity_type, step_order, step_name, required_permission, min_amount) VALUES
  ('trial_protocol', 1, 'R&D manager approves the protocol', 'approve_trial_protocol', 0),
  ('variety_advancement', 1, 'R&D manager approves advancement', 'approve_variety_advancement', 0),
  ('variety_release', 1, 'R&D manager approves release', 'approve_variety_release', 0),
  ('variety_release', 2, 'Quality manager signs off release', 'sign_off_variety_release', 0),
  ('recall', 1, 'Quality manager approves recall', 'approve_recall', 0);
