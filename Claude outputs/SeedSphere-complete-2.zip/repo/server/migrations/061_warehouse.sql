-- Phase C: warehouse and dispatch.
--   warehouses & locations   — bin-level storage, including a quarantine area
--   stock ledger             — every movement of a seed lot is one signed line;
--                              stock is the sum of the lines (never a typed figure)
--   lot tests                — germination test dates and validity, so expired or
--                              untested seed cannot be dispatched
--   dispatch orders          — to licensed dealers, approved, picked, shipped, delivered
--   returns                  — quarantined, inspected, then restocked / retested / destroyed
--   adjustments & counts     — every write-off goes through approval
--   sensors                  — readings, breaches, and a non-conformance when a breach opens

CREATE TABLE wh_warehouses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code VARCHAR(20) NOT NULL UNIQUE,
  name VARCHAR(150) NOT NULL,
  address TEXT,
  licence_number VARCHAR(60),
  status VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
  created_by VARCHAR(100) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE wh_locations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  warehouse_id UUID NOT NULL REFERENCES wh_warehouses(id) ON DELETE RESTRICT,
  code VARCHAR(40) NOT NULL,
  zone VARCHAR(60) NOT NULL,
  location_type VARCHAR(20) NOT NULL DEFAULT 'bin' CHECK (location_type IN ('bin', 'floor', 'cold_room', 'quarantine', 'dispatch_bay')),
  capacity_kg NUMERIC(12, 2) CHECK (capacity_kg > 0),
  status VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'blocked', 'inactive')),
  created_by VARCHAR(100) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT uq_wh_location_code UNIQUE (warehouse_id, code)
);

CREATE TABLE wh_stock_moves (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  seed_lot_id UUID NOT NULL REFERENCES seed_lots(id) ON DELETE RESTRICT,
  location_id UUID NOT NULL REFERENCES wh_locations(id) ON DELETE RESTRICT,
  quantity_kg NUMERIC(12, 2) NOT NULL CHECK (quantity_kg <> 0),
  bags INT,
  move_type VARCHAR(20) NOT NULL CHECK (move_type IN ('receipt', 'transfer_out', 'transfer_in', 'dispatch', 'return', 'adjustment', 'disposal', 'restock_out', 'restock_in')),
  reference_type VARCHAR(30),
  reference_id UUID,
  reference_code VARCHAR(40),
  reason TEXT,
  created_by VARCHAR(100) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_wh_moves_lot_location ON wh_stock_moves (seed_lot_id, location_id);
CREATE INDEX idx_wh_moves_location ON wh_stock_moves (location_id);
CREATE INDEX idx_wh_moves_created_at ON wh_stock_moves (created_at DESC);

CREATE VIEW wh_stock AS
  SELECT m.seed_lot_id, m.location_id, l.warehouse_id, SUM(m.quantity_kg) AS quantity_kg, COALESCE(SUM(m.bags), 0) AS bags
    FROM wh_stock_moves m JOIN wh_locations l ON l.id = m.location_id
   GROUP BY m.seed_lot_id, m.location_id, l.warehouse_id
  HAVING SUM(m.quantity_kg) <> 0;

-- Germination tests recorded outside the lab module (e.g. a state seed
-- testing laboratory report). Lab-module results are read directly.
CREATE TABLE wh_lot_tests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  seed_lot_id UUID NOT NULL REFERENCES seed_lots(id) ON DELETE RESTRICT,
  tested_on DATE NOT NULL,
  germination_pct NUMERIC(5, 2) NOT NULL CHECK (germination_pct BETWEEN 0 AND 100),
  min_germination_pct NUMERIC(5, 2) NOT NULL CHECK (min_germination_pct BETWEEN 0 AND 100),
  passed BOOLEAN NOT NULL,
  laboratory VARCHAR(150) NOT NULL,
  report_number VARCHAR(60),
  valid_until DATE NOT NULL,
  recorded_by VARCHAR(100) NOT NULL,
  recorded_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT chk_lot_test_validity CHECK (valid_until > tested_on)
);
CREATE INDEX idx_wh_lot_tests_lot ON wh_lot_tests (seed_lot_id, tested_on DESC);

CREATE TABLE wh_receipts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  receipt_number VARCHAR(20) NOT NULL UNIQUE,
  seed_lot_id UUID NOT NULL REFERENCES seed_lots(id) ON DELETE RESTRICT,
  location_id UUID NOT NULL REFERENCES wh_locations(id) ON DELETE RESTRICT,
  source_type VARCHAR(20) NOT NULL CHECK (source_type IN ('processing', 'purchase', 'transfer', 'opening_stock')),
  source_reference VARCHAR(60),
  quantity_kg NUMERIC(12, 2) NOT NULL CHECK (quantity_kg > 0),
  bags INT CHECK (bags > 0),
  received_by VARCHAR(100) NOT NULL,
  received_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE wh_dispatches (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  dispatch_number VARCHAR(20) NOT NULL UNIQUE,
  dealer_id UUID NOT NULL REFERENCES parties(id) ON DELETE RESTRICT,
  warehouse_id UUID NOT NULL REFERENCES wh_warehouses(id) ON DELETE RESTRICT,
  requested_date DATE NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'pending_approval', 'approved', 'dispatched', 'delivered', 'cancelled', 'rejected')),
  transporter_id UUID REFERENCES parties(id) ON DELETE RESTRICT,
  vehicle_number VARCHAR(20),
  lr_number VARCHAR(40),
  eway_bill_number VARCHAR(20),
  invoice_reference VARCHAR(60),
  notes TEXT,
  rejection_reason TEXT,
  cancel_reason TEXT,
  dispatched_at TIMESTAMPTZ,
  dispatched_by VARCHAR(100),
  delivered_at TIMESTAMPTZ,
  received_by_name VARCHAR(150),
  created_by VARCHAR(100) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT chk_dispatch_shipped CHECK (status NOT IN ('dispatched', 'delivered') OR (dispatched_at IS NOT NULL AND vehicle_number IS NOT NULL)),
  CONSTRAINT chk_dispatch_delivered CHECK (status <> 'delivered' OR (delivered_at IS NOT NULL AND received_by_name IS NOT NULL))
);
CREATE INDEX idx_wh_dispatches_dealer ON wh_dispatches (dealer_id);
CREATE INDEX idx_wh_dispatches_status ON wh_dispatches (status);

CREATE TABLE wh_dispatch_lines (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  dispatch_id UUID NOT NULL REFERENCES wh_dispatches(id) ON DELETE CASCADE,
  seed_lot_id UUID NOT NULL REFERENCES seed_lots(id) ON DELETE RESTRICT,
  location_id UUID NOT NULL REFERENCES wh_locations(id) ON DELETE RESTRICT,
  quantity_kg NUMERIC(12, 2) NOT NULL CHECK (quantity_kg > 0),
  bags INT CHECK (bags > 0)
);
CREATE INDEX idx_wh_dispatch_lines_lot ON wh_dispatch_lines (seed_lot_id);

CREATE TABLE wh_returns (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  return_number VARCHAR(20) NOT NULL UNIQUE,
  dealer_id UUID NOT NULL REFERENCES parties(id) ON DELETE RESTRICT,
  dispatch_id UUID REFERENCES wh_dispatches(id) ON DELETE SET NULL,
  seed_lot_id UUID NOT NULL REFERENCES seed_lots(id) ON DELETE RESTRICT,
  quarantine_location_id UUID NOT NULL REFERENCES wh_locations(id) ON DELETE RESTRICT,
  quantity_kg NUMERIC(12, 2) NOT NULL CHECK (quantity_kg > 0),
  reason VARCHAR(30) NOT NULL CHECK (reason IN ('damaged', 'expired', 'unsold', 'quality_complaint', 'wrong_supply')),
  details TEXT,
  status VARCHAR(20) NOT NULL DEFAULT 'quarantined' CHECK (status IN ('quarantined', 'inspected', 'restocked', 'retest', 'destroyed')),
  inspection_id UUID REFERENCES inspections(id) ON DELETE SET NULL,
  complaint_id UUID REFERENCES quality_complaints(id) ON DELETE SET NULL,
  disposition_note TEXT,
  credit_note_amount NUMERIC(14, 2) CHECK (credit_note_amount >= 0),
  decided_by VARCHAR(100),
  decided_at TIMESTAMPTZ,
  created_by VARCHAR(100) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_wh_returns_status ON wh_returns (status);

CREATE TABLE wh_adjustments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  adjustment_number VARCHAR(20) NOT NULL UNIQUE,
  seed_lot_id UUID NOT NULL REFERENCES seed_lots(id) ON DELETE RESTRICT,
  location_id UUID NOT NULL REFERENCES wh_locations(id) ON DELETE RESTRICT,
  quantity_change NUMERIC(12, 2) NOT NULL CHECK (quantity_change <> 0),
  reason VARCHAR(30) NOT NULL CHECK (reason IN ('count_variance', 'damage', 'pest', 'moisture_loss', 'sampling', 'data_correction', 'other')),
  details TEXT NOT NULL,
  count_id UUID,
  status VARCHAR(20) NOT NULL DEFAULT 'pending_approval' CHECK (status IN ('pending_approval', 'approved', 'rejected')),
  rejection_reason TEXT,
  created_by VARCHAR(100) NOT NULL,
  decided_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE wh_counts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  count_number VARCHAR(20) NOT NULL UNIQUE,
  warehouse_id UUID NOT NULL REFERENCES wh_warehouses(id) ON DELETE RESTRICT,
  zone VARCHAR(60),
  status VARCHAR(20) NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'submitted', 'cancelled')),
  scheduled_for DATE NOT NULL,
  created_by VARCHAR(100) NOT NULL,
  submitted_by VARCHAR(100),
  submitted_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE wh_adjustments ADD CONSTRAINT fk_wh_adjustment_count FOREIGN KEY (count_id) REFERENCES wh_counts(id) ON DELETE SET NULL;

CREATE TABLE wh_count_lines (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  count_id UUID NOT NULL REFERENCES wh_counts(id) ON DELETE CASCADE,
  seed_lot_id UUID NOT NULL REFERENCES seed_lots(id) ON DELETE RESTRICT,
  location_id UUID NOT NULL REFERENCES wh_locations(id) ON DELETE RESTRICT,
  system_kg NUMERIC(12, 2) NOT NULL,
  counted_kg NUMERIC(12, 2) CHECK (counted_kg >= 0),
  counted_by VARCHAR(100),
  counted_at TIMESTAMPTZ,
  CONSTRAINT uq_count_line UNIQUE (count_id, seed_lot_id, location_id)
);

CREATE TABLE wh_sensors (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code VARCHAR(40) NOT NULL UNIQUE,
  location_id UUID NOT NULL REFERENCES wh_locations(id) ON DELETE RESTRICT,
  sensor_type VARCHAR(20) NOT NULL CHECK (sensor_type IN ('temperature', 'humidity', 'co2', 'phosphine')),
  unit VARCHAR(10) NOT NULL,
  min_value NUMERIC(10, 2),
  max_value NUMERIC(10, 2),
  device_key_hash CHAR(64),
  status VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
  last_value NUMERIC(10, 2),
  last_reading_at TIMESTAMPTZ,
  created_by VARCHAR(100) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT chk_sensor_range CHECK (min_value IS NULL OR max_value IS NULL OR min_value < max_value),
  CONSTRAINT chk_sensor_has_limit CHECK (min_value IS NOT NULL OR max_value IS NOT NULL)
);

CREATE TABLE wh_sensor_readings (
  id BIGSERIAL PRIMARY KEY,
  sensor_id UUID NOT NULL REFERENCES wh_sensors(id) ON DELETE CASCADE,
  value NUMERIC(10, 2) NOT NULL,
  recorded_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  source VARCHAR(20) NOT NULL DEFAULT 'manual' CHECK (source IN ('manual', 'device')),
  recorded_by VARCHAR(100)
);
CREATE INDEX idx_wh_sensor_readings_sensor_time ON wh_sensor_readings (sensor_id, recorded_at DESC);

CREATE TABLE wh_sensor_breaches (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  sensor_id UUID NOT NULL REFERENCES wh_sensors(id) ON DELETE CASCADE,
  started_at TIMESTAMPTZ NOT NULL,
  ended_at TIMESTAMPTZ,
  worst_value NUMERIC(10, 2) NOT NULL,
  ncr_id UUID REFERENCES non_conformances(id) ON DELETE SET NULL,
  resolved_by VARCHAR(100),
  resolution_note TEXT
);
CREATE UNIQUE INDEX uq_wh_open_breach ON wh_sensor_breaches (sensor_id) WHERE ended_at IS NULL;
