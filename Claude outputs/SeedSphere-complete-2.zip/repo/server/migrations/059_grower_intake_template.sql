-- Raw seed from contract growers routinely arrives wetter than storage
-- standard and is dried at the plant; the grower agreement prices that
-- moisture (dry-weight equivalent) and sets its own reject limits. So the
-- intake checklist records moisture and purity without failing the gate on
-- them, and keeps the true gate failures (insects, wrong variety) critical.
DO $$
DECLARE
  t UUID;
  n INT;
BEGIN
  IF EXISTS (SELECT 1 FROM inspection_templates WHERE name = 'Grower delivery — raw seed intake') THEN
    RETURN;
  END IF;
  -- take the next code from the shared counter, so it never collides with
  -- a checklist someone has already created
  INSERT INTO quality_counters (counter_key, last_value) VALUES ('ITP', 1)
    ON CONFLICT (counter_key) DO UPDATE SET last_value = quality_counters.last_value + 1
    RETURNING last_value INTO n;
  INSERT INTO inspection_templates (template_code, name, inspection_type, status, description, created_by, activated_by, activated_at)
  VALUES ('ITP-' || LPAD(n::text, 3, '0'), 'Grower delivery — raw seed intake', 'procurement_receipt', 'active',
          'Weighbridge intake of a contract grower''s delivery. Moisture and purity are priced under the grower agreement; its reject limits apply on acceptance.',
          'system', 'system', now())
  RETURNING id INTO t;
  INSERT INTO inspection_template_items (template_id, seq, label, item_type, unit, min_value, max_value, is_critical, guidance) VALUES
    (t, 1, 'Moisture', 'numeric', '%', NULL, 25, FALSE, 'Composite sample from at least 5 bags; priced under the agreement'),
    (t, 2, 'Physical purity', 'numeric', '%', 85, NULL, FALSE, 'Pure seed fraction of the working sample'),
    (t, 3, 'Variety identity matches the agreement', 'pass_fail', NULL, NULL, NULL, TRUE, 'Grain type and colour consistent with the contracted variety'),
    (t, 4, 'No live insect infestation', 'pass_fail', NULL, NULL, NULL, TRUE, NULL),
    (t, 5, 'Bags tagged with grower and plot', 'pass_fail', NULL, NULL, NULL, FALSE, NULL);
END $$;
