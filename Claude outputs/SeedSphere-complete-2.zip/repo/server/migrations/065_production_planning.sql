-- Production Planning on live data: richer farms and crop plans, farm inspections, harvest requests.
ALTER TABLE farms ADD COLUMN IF NOT EXISTS location VARCHAR(150);
ALTER TABLE farms ADD COLUMN IF NOT EXISTS gps_coordinates VARCHAR(60);
ALTER TABLE farms ADD COLUMN IF NOT EXISTS current_crop VARCHAR(100);
ALTER TABLE farms ADD COLUMN IF NOT EXISTS crop_history TEXT[] NOT NULL DEFAULT '{}';

ALTER TABLE crop_plans ADD COLUMN IF NOT EXISTS plan_code VARCHAR(20);
ALTER TABLE crop_plans ADD COLUMN IF NOT EXISTS season VARCHAR(30);
ALTER TABLE crop_plans ADD COLUMN IF NOT EXISTS target_production NUMERIC(12, 2);
ALTER TABLE crop_plans ADD COLUMN IF NOT EXISTS harvest_date DATE;
ALTER TABLE crop_plans ADD COLUMN IF NOT EXISTS lifecycle VARCHAR(20) NOT NULL DEFAULT 'Planned' CHECK (lifecycle IN ('Planned', 'Sown', 'Growing', 'Harvested', 'Cancelled'));
UPDATE crop_plans c SET plan_code = 'CRP-' || to_char(c.created_at, 'YYYY') || '-' || lpad(n.rn::text, 4, '0')
  FROM (SELECT id, row_number() OVER (ORDER BY created_at, id) AS rn FROM crop_plans WHERE plan_code IS NULL) n WHERE n.id = c.id;
CREATE UNIQUE INDEX IF NOT EXISTS uq_crop_plans_plan_code ON crop_plans (plan_code);

CREATE TABLE farm_field_inspections (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  inspection_code VARCHAR(20) NOT NULL UNIQUE,
  farm_id UUID NOT NULL REFERENCES farms(id) ON DELETE RESTRICT,
  crop_stage VARCHAR(40) NOT NULL,
  inspector_name VARCHAR(150) NOT NULL,
  health_score NUMERIC(5, 2) NOT NULL CHECK (health_score BETWEEN 0 AND 100),
  disease_detected BOOLEAN NOT NULL DEFAULT false,
  disease_name VARCHAR(150),
  notes TEXT,
  photos JSONB NOT NULL DEFAULT '[]',
  inspection_date DATE NOT NULL DEFAULT CURRENT_DATE,
  ai_prediction JSONB,
  created_by VARCHAR(100) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_farm_field_inspections_farm ON farm_field_inspections (farm_id);

CREATE TABLE farm_inspection_records (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  inspection_code VARCHAR(20) NOT NULL UNIQUE,
  farm_id UUID NOT NULL REFERENCES farms(id) ON DELETE RESTRICT,
  crop VARCHAR(100) NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'Scheduled' CHECK (status IN ('Scheduled', 'Completed', 'Approved', 'Rejected')),
  inspection_date DATE,
  notes TEXT,
  created_by VARCHAR(100) NOT NULL,
  approved_by VARCHAR(100),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_farm_inspection_records_farm ON farm_inspection_records (farm_id);

CREATE TABLE harvest_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  request_code VARCHAR(20) NOT NULL UNIQUE,
  farm_id UUID NOT NULL REFERENCES farms(id) ON DELETE RESTRICT,
  farmer_id UUID NOT NULL REFERENCES farmers(id) ON DELETE RESTRICT,
  variety_id UUID REFERENCES varieties(id) ON DELETE SET NULL,
  crop VARCHAR(100) NOT NULL,
  crop_plan_id UUID REFERENCES crop_plans(id) ON DELETE SET NULL,
  estimated_quantity_kg NUMERIC(12, 2) NOT NULL CHECK (estimated_quantity_kg > 0),
  actual_quantity_kg NUMERIC(12, 2),
  requested_harvest_date DATE NOT NULL,
  harvested_date DATE,
  notes TEXT,
  status VARCHAR(30) NOT NULL DEFAULT 'Pending Approval' CHECK (status IN ('Pending Approval', 'Changes Requested', 'Approved', 'Rejected', 'Harvested', 'Transport Authorized', 'Delivered to Processing')),
  requested_by VARCHAR(150) NOT NULL,
  inspector_name VARCHAR(150),
  inspector_notes TEXT,
  reviewed_at TIMESTAMPTZ,
  lot_id VARCHAR(20) UNIQUE,
  transport JSONB,
  history JSONB NOT NULL DEFAULT '[]',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_harvest_requests_status ON harvest_requests (status);
