-- Phase B, part 1: procurement and contract growers.
--   items & cost centres    — what is bought and whose budget pays for it
--   requisition -> RFQ -> purchase order -> goods receipt -> invoice -> payment
--   contracts               — rate contracts and supply agreements with renewal alerts
--   grower agreements       — buy-back contracts with seed growers, deliveries at the
--                             weighbridge, quality-based pricing, a ledger and payments
-- Approvals go through the approval engine (057); inspections through the
-- inspection engine (057); suppliers and growers are parties (057).

-- Items and budgets -------------------------------------------------------
CREATE TABLE proc_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  item_code VARCHAR(20) NOT NULL UNIQUE,
  name VARCHAR(200) NOT NULL,
  category VARCHAR(20) NOT NULL CHECK (category IN ('seed', 'packaging', 'chemical', 'fertilizer', 'equipment', 'service', 'other')),
  unit VARCHAR(20) NOT NULL,
  crop VARCHAR(100),
  variety VARCHAR(100),
  hsn_code VARCHAR(10),
  gst_rate NUMERIC(5, 2) NOT NULL DEFAULT 0 CHECK (gst_rate >= 0 AND gst_rate <= 28),
  -- Seed and chemicals are inspected at the gate before they are accepted.
  requires_inspection BOOLEAN NOT NULL DEFAULT FALSE,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_by VARCHAR(100) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT uq_proc_item_name UNIQUE (name)
);

CREATE TABLE proc_cost_centres (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code VARCHAR(20) NOT NULL,
  name VARCHAR(150) NOT NULL,
  fiscal_year VARCHAR(7) NOT NULL CHECK (fiscal_year ~ '^\d{4}-\d{2}$'),
  budget_amount NUMERIC(14, 2) NOT NULL CHECK (budget_amount >= 0),
  owner_email VARCHAR(100),
  created_by VARCHAR(100) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT uq_cost_centre_year UNIQUE (code, fiscal_year)
);
CREATE TRIGGER trg_proc_cost_centres_touch BEFORE UPDATE ON proc_cost_centres FOR EACH ROW EXECUTE FUNCTION touch_updated_at();

-- Requisitions -------------------------------------------------------------
CREATE TABLE proc_requisitions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  pr_number VARCHAR(20) NOT NULL UNIQUE,
  title VARCHAR(200) NOT NULL,
  department VARCHAR(30) NOT NULL,
  cost_centre_id UUID REFERENCES proc_cost_centres(id) ON DELETE RESTRICT,
  needed_by DATE,
  justification TEXT,
  status VARCHAR(20) NOT NULL DEFAULT 'draft'
    CHECK (status IN ('draft', 'pending_approval', 'approved', 'rejected', 'cancelled', 'ordered')),
  estimated_total NUMERIC(14, 2) NOT NULL DEFAULT 0,
  source VARCHAR(20) NOT NULL DEFAULT 'manual' CHECK (source IN ('manual', 'demand_plan', 'low_stock')),
  source_ref VARCHAR(60),
  rejection_reason TEXT,
  requested_by VARCHAR(100) NOT NULL,
  submitted_at TIMESTAMPTZ,
  decided_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_proc_requisitions_status ON proc_requisitions (status);
CREATE TRIGGER trg_proc_requisitions_touch BEFORE UPDATE ON proc_requisitions FOR EACH ROW EXECUTE FUNCTION touch_updated_at();

CREATE TABLE proc_requisition_lines (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  requisition_id UUID NOT NULL REFERENCES proc_requisitions(id) ON DELETE CASCADE,
  line_no INT NOT NULL,
  item_id UUID NOT NULL REFERENCES proc_items(id) ON DELETE RESTRICT,
  description TEXT,
  quantity NUMERIC(12, 3) NOT NULL CHECK (quantity > 0),
  unit VARCHAR(20) NOT NULL,
  estimated_unit_price NUMERIC(12, 2) NOT NULL DEFAULT 0 CHECK (estimated_unit_price >= 0),
  ordered_quantity NUMERIC(12, 3) NOT NULL DEFAULT 0 CHECK (ordered_quantity >= 0),
  CONSTRAINT uq_pr_line UNIQUE (requisition_id, line_no)
);

-- Contracts ----------------------------------------------------------------
CREATE TABLE proc_contracts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  contract_number VARCHAR(20) NOT NULL UNIQUE,
  contract_type VARCHAR(20) NOT NULL CHECK (contract_type IN ('rate_contract', 'supply_agreement', 'service', 'transport')),
  supplier_id UUID NOT NULL REFERENCES parties(id) ON DELETE RESTRICT,
  title VARCHAR(200) NOT NULL,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  renewal_notice_days INT NOT NULL DEFAULT 30 CHECK (renewal_notice_days BETWEEN 0 AND 365),
  value_cap NUMERIC(14, 2) CHECK (value_cap > 0),
  payment_terms_days INT NOT NULL DEFAULT 30 CHECK (payment_terms_days BETWEEN 0 AND 365),
  terms TEXT,
  status VARCHAR(20) NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'active', 'terminated')),
  termination_reason TEXT,
  created_by VARCHAR(100) NOT NULL,
  activated_by VARCHAR(100),
  activated_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT chk_contract_dates CHECK (end_date >= start_date)
);
CREATE INDEX idx_proc_contracts_supplier ON proc_contracts (supplier_id);
CREATE TRIGGER trg_proc_contracts_touch BEFORE UPDATE ON proc_contracts FOR EACH ROW EXECUTE FUNCTION touch_updated_at();

CREATE TABLE proc_contract_rates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  contract_id UUID NOT NULL REFERENCES proc_contracts(id) ON DELETE CASCADE,
  item_id UUID NOT NULL REFERENCES proc_items(id) ON DELETE RESTRICT,
  unit_price NUMERIC(12, 2) NOT NULL CHECK (unit_price >= 0),
  CONSTRAINT uq_contract_rate_item UNIQUE (contract_id, item_id)
);

-- RFQs ----------------------------------------------------------------------
CREATE TABLE proc_rfqs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  rfq_number VARCHAR(20) NOT NULL UNIQUE,
  requisition_id UUID REFERENCES proc_requisitions(id) ON DELETE SET NULL,
  title VARCHAR(200) NOT NULL,
  due_date DATE NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'awarded', 'cancelled')),
  awarded_quote_id UUID,
  award_reason TEXT,
  awarded_by VARCHAR(100),
  awarded_at TIMESTAMPTZ,
  created_by VARCHAR(100) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE proc_rfq_lines (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  rfq_id UUID NOT NULL REFERENCES proc_rfqs(id) ON DELETE CASCADE,
  line_no INT NOT NULL,
  item_id UUID NOT NULL REFERENCES proc_items(id) ON DELETE RESTRICT,
  quantity NUMERIC(12, 3) NOT NULL CHECK (quantity > 0),
  unit VARCHAR(20) NOT NULL,
  requisition_line_id UUID REFERENCES proc_requisition_lines(id) ON DELETE SET NULL,
  CONSTRAINT uq_rfq_line UNIQUE (rfq_id, line_no)
);

CREATE TABLE proc_rfq_quotes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  rfq_id UUID NOT NULL REFERENCES proc_rfqs(id) ON DELETE CASCADE,
  supplier_id UUID NOT NULL REFERENCES parties(id) ON DELETE RESTRICT,
  quote_ref VARCHAR(60),
  valid_until DATE,
  delivery_days INT CHECK (delivery_days >= 0),
  payment_terms_days INT CHECK (payment_terms_days >= 0),
  notes TEXT,
  subtotal NUMERIC(14, 2) NOT NULL,
  tax_total NUMERIC(14, 2) NOT NULL,
  total_amount NUMERIC(14, 2) NOT NULL,
  recorded_by VARCHAR(100) NOT NULL,
  recorded_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT uq_rfq_supplier UNIQUE (rfq_id, supplier_id)
);

CREATE TABLE proc_rfq_quote_lines (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  quote_id UUID NOT NULL REFERENCES proc_rfq_quotes(id) ON DELETE CASCADE,
  rfq_line_id UUID NOT NULL REFERENCES proc_rfq_lines(id) ON DELETE CASCADE,
  unit_price NUMERIC(12, 2) NOT NULL CHECK (unit_price >= 0),
  gst_rate NUMERIC(5, 2) NOT NULL DEFAULT 0,
  CONSTRAINT uq_quote_line UNIQUE (quote_id, rfq_line_id)
);
ALTER TABLE proc_rfqs ADD CONSTRAINT fk_rfq_awarded_quote FOREIGN KEY (awarded_quote_id) REFERENCES proc_rfq_quotes(id) ON DELETE SET NULL;

-- Purchase orders ------------------------------------------------------------
CREATE TABLE proc_purchase_orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  po_number VARCHAR(20) NOT NULL UNIQUE,
  supplier_id UUID NOT NULL REFERENCES parties(id) ON DELETE RESTRICT,
  requisition_id UUID REFERENCES proc_requisitions(id) ON DELETE SET NULL,
  rfq_id UUID REFERENCES proc_rfqs(id) ON DELETE SET NULL,
  contract_id UUID REFERENCES proc_contracts(id) ON DELETE SET NULL,
  cost_centre_id UUID REFERENCES proc_cost_centres(id) ON DELETE RESTRICT,
  order_date DATE NOT NULL DEFAULT CURRENT_DATE,
  expected_delivery_date DATE NOT NULL,
  delivery_address TEXT NOT NULL,
  payment_terms_days INT NOT NULL DEFAULT 30 CHECK (payment_terms_days BETWEEN 0 AND 365),
  status VARCHAR(20) NOT NULL DEFAULT 'draft' CHECK (status IN
    ('draft', 'pending_approval', 'approved', 'sent', 'partially_received', 'received', 'closed', 'cancelled', 'rejected')),
  subtotal NUMERIC(14, 2) NOT NULL DEFAULT 0,
  tax_total NUMERIC(14, 2) NOT NULL DEFAULT 0,
  grand_total NUMERIC(14, 2) NOT NULL DEFAULT 0,
  budget_override_reason TEXT,
  amendment_no INT NOT NULL DEFAULT 0,
  notes TEXT,
  rejection_reason TEXT,
  cancel_reason TEXT,
  created_by VARCHAR(100) NOT NULL,
  approved_at TIMESTAMPTZ,
  sent_at TIMESTAMPTZ,
  closed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT chk_po_delivery_after_order CHECK (expected_delivery_date >= order_date)
);
CREATE INDEX idx_proc_po_supplier ON proc_purchase_orders (supplier_id);
CREATE INDEX idx_proc_po_status ON proc_purchase_orders (status);
CREATE INDEX idx_proc_po_cost_centre ON proc_purchase_orders (cost_centre_id);
CREATE TRIGGER trg_proc_po_touch BEFORE UPDATE ON proc_purchase_orders FOR EACH ROW EXECUTE FUNCTION touch_updated_at();

CREATE TABLE proc_po_lines (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  po_id UUID NOT NULL REFERENCES proc_purchase_orders(id) ON DELETE CASCADE,
  line_no INT NOT NULL,
  item_id UUID NOT NULL REFERENCES proc_items(id) ON DELETE RESTRICT,
  description TEXT,
  quantity NUMERIC(12, 3) NOT NULL CHECK (quantity > 0),
  unit VARCHAR(20) NOT NULL,
  unit_price NUMERIC(12, 2) NOT NULL CHECK (unit_price >= 0),
  gst_rate NUMERIC(5, 2) NOT NULL DEFAULT 0,
  line_total NUMERIC(14, 2) NOT NULL,
  tax_amount NUMERIC(14, 2) NOT NULL,
  received_quantity NUMERIC(12, 3) NOT NULL DEFAULT 0 CHECK (received_quantity >= 0),
  accepted_quantity NUMERIC(12, 3) NOT NULL DEFAULT 0 CHECK (accepted_quantity >= 0),
  invoiced_quantity NUMERIC(12, 3) NOT NULL DEFAULT 0 CHECK (invoiced_quantity >= 0),
  requisition_line_id UUID REFERENCES proc_requisition_lines(id) ON DELETE SET NULL,
  CONSTRAINT uq_po_line UNIQUE (po_id, line_no),
  CONSTRAINT chk_po_line_accepted_within_received CHECK (accepted_quantity <= received_quantity),
  CONSTRAINT chk_po_line_invoiced_within_accepted CHECK (invoiced_quantity <= accepted_quantity)
);

CREATE TABLE proc_po_amendments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  po_id UUID NOT NULL REFERENCES proc_purchase_orders(id) ON DELETE CASCADE,
  amendment_no INT NOT NULL,
  reason TEXT NOT NULL,
  before_state JSONB NOT NULL,
  after_state JSONB NOT NULL,
  amended_by VARCHAR(100) NOT NULL,
  amended_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT uq_po_amendment UNIQUE (po_id, amendment_no)
);

-- Goods receipts -------------------------------------------------------------
CREATE TABLE proc_goods_receipts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  grn_number VARCHAR(20) NOT NULL UNIQUE,
  po_id UUID NOT NULL REFERENCES proc_purchase_orders(id) ON DELETE RESTRICT,
  supplier_id UUID NOT NULL REFERENCES parties(id) ON DELETE RESTRICT,
  received_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  vehicle_number VARCHAR(20),
  driver_name VARCHAR(100),
  challan_number VARCHAR(60),
  weighbridge_ticket VARCHAR(60),
  gross_weight_kg NUMERIC(12, 2),
  tare_weight_kg NUMERIC(12, 2),
  net_weight_kg NUMERIC(12, 2),
  status VARCHAR(20) NOT NULL CHECK (status IN ('awaiting_inspection', 'accepted', 'partially_accepted', 'rejected', 'on_hold')),
  inspection_id UUID REFERENCES inspections(id) ON DELETE SET NULL,
  storage_location VARCHAR(100),
  notes TEXT,
  received_by VARCHAR(100) NOT NULL,
  decided_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT chk_grn_weights CHECK (gross_weight_kg IS NULL OR tare_weight_kg IS NULL OR gross_weight_kg > tare_weight_kg)
);
CREATE INDEX idx_proc_grn_po ON proc_goods_receipts (po_id);
CREATE INDEX idx_proc_grn_status ON proc_goods_receipts (status);

CREATE TABLE proc_grn_lines (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  grn_id UUID NOT NULL REFERENCES proc_goods_receipts(id) ON DELETE CASCADE,
  po_line_id UUID NOT NULL REFERENCES proc_po_lines(id) ON DELETE RESTRICT,
  received_quantity NUMERIC(12, 3) NOT NULL CHECK (received_quantity > 0),
  damaged_quantity NUMERIC(12, 3) NOT NULL DEFAULT 0 CHECK (damaged_quantity >= 0),
  accepted_quantity NUMERIC(12, 3) CHECK (accepted_quantity >= 0),
  notes TEXT,
  CONSTRAINT chk_grn_line_damaged CHECK (damaged_quantity <= received_quantity),
  CONSTRAINT chk_grn_line_accepted CHECK (accepted_quantity IS NULL OR accepted_quantity <= received_quantity - damaged_quantity)
);

-- Invoices --------------------------------------------------------------------
CREATE TABLE proc_invoices (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  invoice_number VARCHAR(20) NOT NULL UNIQUE,
  supplier_invoice_no VARCHAR(60) NOT NULL,
  supplier_id UUID NOT NULL REFERENCES parties(id) ON DELETE RESTRICT,
  po_id UUID NOT NULL REFERENCES proc_purchase_orders(id) ON DELETE RESTRICT,
  invoice_date DATE NOT NULL,
  due_date DATE NOT NULL,
  subtotal NUMERIC(14, 2) NOT NULL,
  tax_total NUMERIC(14, 2) NOT NULL,
  total_amount NUMERIC(14, 2) NOT NULL CHECK (total_amount > 0),
  match_status VARCHAR(20) NOT NULL CHECK (match_status IN ('matched', 'mismatch')),
  match_details JSONB NOT NULL,
  variance_amount NUMERIC(14, 2) NOT NULL DEFAULT 0,
  variance_reason TEXT,
  status VARCHAR(20) NOT NULL DEFAULT 'received' CHECK (status IN
    ('received', 'pending_approval', 'approved', 'paid', 'rejected', 'cancelled')),
  rejection_reason TEXT,
  payment_reference VARCHAR(60),
  payment_mode VARCHAR(20) CHECK (payment_mode IN ('neft', 'rtgs', 'imps', 'upi', 'cheque')),
  paid_at TIMESTAMPTZ,
  paid_by VARCHAR(100),
  created_by VARCHAR(100) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT uq_supplier_invoice UNIQUE (supplier_id, supplier_invoice_no),
  CONSTRAINT chk_invoice_paid CHECK (status <> 'paid' OR (payment_reference IS NOT NULL AND paid_at IS NOT NULL AND paid_by IS NOT NULL)),
  CONSTRAINT chk_invoice_mismatch_explained CHECK (match_status = 'matched' OR status IN ('received', 'cancelled', 'rejected') OR variance_reason IS NOT NULL)
);
CREATE INDEX idx_proc_invoices_status ON proc_invoices (status);
CREATE INDEX idx_proc_invoices_po ON proc_invoices (po_id);
CREATE TRIGGER trg_proc_invoices_touch BEFORE UPDATE ON proc_invoices FOR EACH ROW EXECUTE FUNCTION touch_updated_at();

CREATE TABLE proc_invoice_lines (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  invoice_id UUID NOT NULL REFERENCES proc_invoices(id) ON DELETE CASCADE,
  po_line_id UUID NOT NULL REFERENCES proc_po_lines(id) ON DELETE RESTRICT,
  quantity NUMERIC(12, 3) NOT NULL CHECK (quantity > 0),
  unit_price NUMERIC(12, 2) NOT NULL CHECK (unit_price >= 0),
  gst_rate NUMERIC(5, 2) NOT NULL DEFAULT 0,
  line_total NUMERIC(14, 2) NOT NULL,
  tax_amount NUMERIC(14, 2) NOT NULL
);

-- Contract growers ----------------------------------------------------------
CREATE TABLE grw_agreements (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  agreement_number VARCHAR(20) NOT NULL UNIQUE,
  grower_id UUID NOT NULL REFERENCES parties(id) ON DELETE RESTRICT,
  season VARCHAR(10) NOT NULL CHECK (season IN ('kharif', 'rabi', 'zaid')),
  season_year INT NOT NULL CHECK (season_year BETWEEN 2000 AND 2100),
  crop VARCHAR(100) NOT NULL,
  variety VARCHAR(100) NOT NULL,
  seed_class VARCHAR(20) NOT NULL CHECK (seed_class IN ('Foundation', 'Certified')),
  plot_village VARCHAR(100) NOT NULL,
  plot_survey_number VARCHAR(60),
  area_acres NUMERIC(8, 2) NOT NULL CHECK (area_acres > 0),
  latitude NUMERIC(9, 6),
  longitude NUMERIC(9, 6),
  parent_lot_id UUID REFERENCES seed_lots(id) ON DELETE RESTRICT,
  parent_qty_issued_kg NUMERIC(10, 2) CHECK (parent_qty_issued_kg > 0),
  expected_yield_kg NUMERIC(12, 2) NOT NULL CHECK (expected_yield_kg > 0),
  buyback_price_per_kg NUMERIC(10, 2) NOT NULL CHECK (buyback_price_per_kg > 0),
  advance_amount NUMERIC(12, 2) NOT NULL DEFAULT 0 CHECK (advance_amount >= 0),
  input_cost_amount NUMERIC(12, 2) NOT NULL DEFAULT 0 CHECK (input_cost_amount >= 0),
  -- Quality terms written into the agreement, so the grower knows before
  -- sowing exactly how a wet or impure delivery will be priced.
  standard_moisture_pct NUMERIC(5, 2) NOT NULL DEFAULT 12 CHECK (standard_moisture_pct > 0 AND standard_moisture_pct < 30),
  reject_moisture_pct NUMERIC(5, 2) NOT NULL DEFAULT 18,
  min_purity_pct NUMERIC(5, 2) NOT NULL DEFAULT 98,
  purity_deduction_per_point_pct NUMERIC(5, 2) NOT NULL DEFAULT 2 CHECK (purity_deduction_per_point_pct >= 0),
  reject_purity_pct NUMERIC(5, 2) NOT NULL DEFAULT 95,
  procurement_window_start DATE NOT NULL,
  procurement_window_end DATE NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'pending_approval', 'active', 'completed', 'cancelled', 'rejected')),
  rejection_reason TEXT,
  created_by VARCHAR(100) NOT NULL,
  approved_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT chk_agreement_window CHECK (procurement_window_end >= procurement_window_start),
  CONSTRAINT chk_agreement_reject_moisture CHECK (reject_moisture_pct > standard_moisture_pct),
  CONSTRAINT chk_agreement_reject_purity CHECK (reject_purity_pct < min_purity_pct),
  CONSTRAINT chk_agreement_parent_qty CHECK (parent_lot_id IS NULL OR parent_qty_issued_kg IS NOT NULL)
);
CREATE INDEX idx_grw_agreements_grower ON grw_agreements (grower_id);
CREATE INDEX idx_grw_agreements_status ON grw_agreements (status);
CREATE TRIGGER trg_grw_agreements_touch BEFORE UPDATE ON grw_agreements FOR EACH ROW EXECUTE FUNCTION touch_updated_at();

CREATE TABLE grw_deliveries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  delivery_number VARCHAR(20) NOT NULL UNIQUE,
  agreement_id UUID NOT NULL REFERENCES grw_agreements(id) ON DELETE RESTRICT,
  grower_id UUID NOT NULL REFERENCES parties(id) ON DELETE RESTRICT,
  delivered_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  vehicle_number VARCHAR(20),
  weighbridge_ticket VARCHAR(60),
  gross_weight_kg NUMERIC(12, 2) NOT NULL CHECK (gross_weight_kg > 0),
  tare_weight_kg NUMERIC(12, 2) NOT NULL CHECK (tare_weight_kg >= 0),
  net_weight_kg NUMERIC(12, 2) NOT NULL CHECK (net_weight_kg > 0),
  bags INT CHECK (bags > 0),
  status VARCHAR(20) NOT NULL DEFAULT 'awaiting_inspection' CHECK (status IN ('awaiting_inspection', 'accepted', 'rejected', 'on_hold')),
  inspection_id UUID REFERENCES inspections(id) ON DELETE SET NULL,
  moisture_pct NUMERIC(5, 2),
  purity_pct NUMERIC(5, 2),
  payable_weight_kg NUMERIC(12, 2),
  price_per_kg NUMERIC(10, 2),
  gross_value NUMERIC(14, 2),
  quality_deduction NUMERIC(14, 2),
  net_value NUMERIC(14, 2),
  pricing_note TEXT,
  received_by VARCHAR(100) NOT NULL,
  decided_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT chk_delivery_net CHECK (net_weight_kg = gross_weight_kg - tare_weight_kg),
  CONSTRAINT chk_delivery_priced CHECK (status <> 'accepted' OR (net_value IS NOT NULL AND payable_weight_kg IS NOT NULL))
);
CREATE INDEX idx_grw_deliveries_agreement ON grw_deliveries (agreement_id);
CREATE INDEX idx_grw_deliveries_status ON grw_deliveries (status);

CREATE TABLE grw_settlements (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  settlement_number VARCHAR(20) NOT NULL UNIQUE,
  settlement_type VARCHAR(10) NOT NULL CHECK (settlement_type IN ('advance', 'final')),
  grower_id UUID NOT NULL REFERENCES parties(id) ON DELETE RESTRICT,
  agreement_id UUID NOT NULL REFERENCES grw_agreements(id) ON DELETE RESTRICT,
  delivery_value NUMERIC(14, 2) NOT NULL DEFAULT 0,
  recoveries NUMERIC(14, 2) NOT NULL DEFAULT 0,
  net_payable NUMERIC(14, 2) NOT NULL CHECK (net_payable > 0),
  first_delivery_at TIMESTAMPTZ,
  status VARCHAR(20) NOT NULL DEFAULT 'pending_approval' CHECK (status IN ('pending_approval', 'approved', 'paid', 'rejected')),
  rejection_reason TEXT,
  payment_reference VARCHAR(60),
  payment_mode VARCHAR(20) CHECK (payment_mode IN ('neft', 'rtgs', 'imps', 'upi', 'cheque')),
  paid_at TIMESTAMPTZ,
  paid_by VARCHAR(100),
  created_by VARCHAR(100) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT chk_settlement_paid CHECK (status <> 'paid' OR (payment_reference IS NOT NULL AND paid_at IS NOT NULL))
);
CREATE INDEX idx_grw_settlements_grower ON grw_settlements (grower_id);

-- The grower's account with the company: positive = owed to the grower.
CREATE TABLE grw_ledger (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  grower_id UUID NOT NULL REFERENCES parties(id) ON DELETE RESTRICT,
  agreement_id UUID NOT NULL REFERENCES grw_agreements(id) ON DELETE RESTRICT,
  entry_date TIMESTAMPTZ NOT NULL DEFAULT now(),
  entry_type VARCHAR(20) NOT NULL CHECK (entry_type IN ('inputs', 'advance', 'delivery', 'payment', 'adjustment')),
  description TEXT NOT NULL,
  amount NUMERIC(14, 2) NOT NULL CHECK (amount <> 0),
  delivery_id UUID REFERENCES grw_deliveries(id) ON DELETE RESTRICT,
  settlement_id UUID REFERENCES grw_settlements(id) ON DELETE RESTRICT,
  -- the final settlement that paid this entry out (null = still open)
  settled_by_id UUID REFERENCES grw_settlements(id) ON DELETE RESTRICT,
  created_by VARCHAR(100) NOT NULL
);
CREATE INDEX idx_grw_ledger_grower ON grw_ledger (grower_id, entry_date);
CREATE INDEX idx_grw_ledger_agreement ON grw_ledger (agreement_id);
CREATE UNIQUE INDEX uq_grw_ledger_delivery ON grw_ledger (delivery_id) WHERE delivery_id IS NOT NULL;
