-- Electronic signatures on approvals. A rule can require the approver to sign:
-- they re-enter their password, and the signer, the meaning of the signature and
-- the time are recorded with a hash of what was signed so later edits are detectable.
ALTER TABLE approval_rules ADD COLUMN requires_signature BOOLEAN NOT NULL DEFAULT FALSE;
ALTER TABLE approval_rules ADD COLUMN signature_meaning VARCHAR(200);
UPDATE approval_rules SET requires_signature = TRUE, signature_meaning = 'I approve this recall' WHERE entity_type = 'recall';
UPDATE approval_rules SET requires_signature = TRUE, signature_meaning = 'I approve this variety for release' WHERE entity_type = 'variety_release' AND step_order = 1;
UPDATE approval_rules SET requires_signature = TRUE, signature_meaning = 'I certify the release meets quality requirements' WHERE entity_type = 'variety_release' AND step_order = 2;
UPDATE approval_rules SET requires_signature = TRUE, signature_meaning = 'I authorise this payment' WHERE entity_type IN ('invoice_payment', 'grower_settlement');

CREATE TABLE approval_signatures (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  request_id UUID NOT NULL REFERENCES approval_requests(id) ON DELETE CASCADE,
  step_id UUID NOT NULL REFERENCES approval_steps(id) ON DELETE CASCADE,
  entity_type VARCHAR(40) NOT NULL,
  entity_id UUID NOT NULL,
  entity_code VARCHAR(40) NOT NULL,
  signer_email VARCHAR(100) NOT NULL,
  signer_name VARCHAR(150) NOT NULL,
  meaning VARCHAR(200) NOT NULL,
  signed_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  record_hash CHAR(64) NOT NULL,
  CONSTRAINT uq_signature_step UNIQUE (step_id)
);
CREATE INDEX idx_signatures_entity ON approval_signatures (entity_type, entity_id);
