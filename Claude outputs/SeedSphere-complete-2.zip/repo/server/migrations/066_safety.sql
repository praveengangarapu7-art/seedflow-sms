-- Safety and environment: incident log and chemical handling register.
CREATE TABLE safety_incidents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  incident_number VARCHAR(20) NOT NULL UNIQUE,
  incident_type VARCHAR(20) NOT NULL CHECK (incident_type IN ('injury', 'near_miss', 'chemical_spill', 'fire', 'equipment', 'environmental', 'other')),
  severity VARCHAR(10) NOT NULL CHECK (severity IN ('minor', 'moderate', 'major', 'critical')),
  area VARCHAR(20) NOT NULL CHECK (area IN ('warehouse', 'processing', 'laboratory', 'field', 'transport', 'office')),
  occurred_at TIMESTAMPTZ NOT NULL,
  location VARCHAR(150),
  description TEXT NOT NULL,
  persons_involved TEXT,
  lost_time BOOLEAN NOT NULL DEFAULT false,
  chemical VARCHAR(150),
  quantity NUMERIC(12, 3),
  unit VARCHAR(10),
  immediate_action TEXT,
  batch_id UUID REFERENCES prc_batches(id) ON DELETE SET NULL,
  ncr_id UUID REFERENCES non_conformances(id) ON DELETE SET NULL,
  status VARCHAR(15) NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'investigating', 'closed')),
  root_cause TEXT,
  corrective_action TEXT,
  reported_by VARCHAR(150) NOT NULL,
  investigated_by VARCHAR(150),
  closed_by VARCHAR(150),
  closed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT chk_incident_closed CHECK (status <> 'closed' OR (root_cause IS NOT NULL AND corrective_action IS NOT NULL AND closed_at IS NOT NULL))
);
CREATE INDEX idx_safety_incidents_status ON safety_incidents (status);
CREATE INDEX idx_safety_incidents_occurred ON safety_incidents (occurred_at DESC);

CREATE TABLE safety_chemical_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  chemical VARCHAR(150) NOT NULL,
  action VARCHAR(10) NOT NULL CHECK (action IN ('received', 'used', 'disposed')),
  quantity NUMERIC(12, 3) NOT NULL CHECK (quantity > 0),
  unit VARCHAR(10) NOT NULL DEFAULT 'kg',
  batch_id UUID REFERENCES prc_batches(id) ON DELETE SET NULL,
  disposal_method VARCHAR(150),
  supplier VARCHAR(150),
  notes TEXT,
  logged_by VARCHAR(150) NOT NULL,
  logged_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT chk_disposal_method CHECK (action <> 'disposed' OR disposal_method IS NOT NULL)
);
CREATE INDEX idx_safety_chemical_log_chem ON safety_chemical_log (lower(chemical));
