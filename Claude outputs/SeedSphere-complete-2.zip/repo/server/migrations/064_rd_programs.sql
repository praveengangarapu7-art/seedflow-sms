-- Phase F — R&D on live data: germplasm, breeding programmes, nurseries, phenotyping, registrations.
CREATE TABLE rd_accessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  accession_code VARCHAR(20) NOT NULL UNIQUE,
  accession_number VARCHAR(60),
  name VARCHAR(150) NOT NULL,
  crop VARCHAR(100) NOT NULL,
  species VARCHAR(150),
  accession_type VARCHAR(20) NOT NULL DEFAULT 'cultivar' CHECK (accession_type IN ('landrace', 'cultivar', 'wild_relative', 'breeding_line', 'mutant')),
  origin_state VARCHAR(100),
  origin_site VARCHAR(150),
  donor VARCHAR(150),
  custody VARCHAR(150),
  status VARCHAR(10) NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'lost')),
  notes TEXT,
  created_by VARCHAR(100) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (crop, name)
);
CREATE INDEX idx_rd_accessions_crop ON rd_accessions (crop);

CREATE TABLE rd_phenotypes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  accession_id UUID NOT NULL REFERENCES rd_accessions(id) ON DELETE CASCADE,
  trait VARCHAR(60) NOT NULL,
  category VARCHAR(20) NOT NULL DEFAULT 'agronomic' CHECK (category IN ('agronomic', 'quality', 'stress', 'disease', 'morphology')),
  value_num NUMERIC(14, 4),
  value_text VARCHAR(100),
  unit VARCHAR(20),
  method VARCHAR(150),
  measured_on DATE NOT NULL,
  recorded_by VARCHAR(100) NOT NULL,
  recorded_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT chk_phenotype_value CHECK (value_num IS NOT NULL OR value_text IS NOT NULL)
);
CREATE INDEX idx_rd_phenotypes_acc ON rd_phenotypes (accession_id, trait, measured_on DESC);

CREATE TABLE rd_programs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  program_code VARCHAR(20) NOT NULL UNIQUE,
  name VARCHAR(200) NOT NULL,
  crop VARCHAR(100) NOT NULL,
  objective VARCHAR(40) NOT NULL,
  description TEXT,
  status VARCHAR(12) NOT NULL DEFAULT 'planning' CHECK (status IN ('planning', 'active', 'paused', 'completed', 'cancelled')),
  lead_breeder VARCHAR(150) NOT NULL,
  start_date DATE NOT NULL,
  expected_end_date DATE,
  budget NUMERIC(14, 2) CHECK (budget >= 0),
  spent_to_date NUMERIC(14, 2) NOT NULL DEFAULT 0 CHECK (spent_to_date >= 0),
  male_parent_id UUID REFERENCES rd_accessions(id) ON DELETE SET NULL,
  female_parent_id UUID REFERENCES rd_accessions(id) ON DELETE SET NULL,
  created_by VARCHAR(100) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE rd_generations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  program_id UUID NOT NULL REFERENCES rd_programs(id) ON DELETE CASCADE,
  stage VARCHAR(10) NOT NULL,
  season VARCHAR(30) NOT NULL,
  population_size INT NOT NULL CHECK (population_size > 0),
  selections_retained INT NOT NULL CHECK (selections_retained >= 0),
  criteria TEXT,
  observations TEXT,
  recorded_by VARCHAR(100) NOT NULL,
  recorded_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (program_id, stage),
  CONSTRAINT chk_retained_within_population CHECK (selections_retained <= population_size)
);

CREATE TABLE rd_nurseries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  nursery_code VARCHAR(20) NOT NULL UNIQUE,
  name VARCHAR(150) NOT NULL,
  program_id UUID REFERENCES rd_programs(id) ON DELETE SET NULL,
  crop VARCHAR(100) NOT NULL,
  season VARCHAR(30) NOT NULL,
  location VARCHAR(150) NOT NULL,
  area_acres NUMERIC(8, 2) CHECK (area_acres > 0),
  status VARCHAR(12) NOT NULL DEFAULT 'planned' CHECK (status IN ('planned', 'sown', 'growing', 'harvested', 'abandoned')),
  sown_on DATE,
  expected_harvest DATE,
  harvested_on DATE,
  created_by VARCHAR(100) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT chk_nursery_sown CHECK (status IN ('planned', 'abandoned') OR sown_on IS NOT NULL)
);
CREATE TABLE rd_nursery_notes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  nursery_id UUID NOT NULL REFERENCES rd_nurseries(id) ON DELETE CASCADE,
  note_date DATE NOT NULL,
  growth_stage VARCHAR(40),
  health VARCHAR(10) NOT NULL DEFAULT 'good' CHECK (health IN ('good', 'fair', 'poor')),
  note TEXT NOT NULL,
  recorded_by VARCHAR(100) NOT NULL,
  recorded_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE rd_registrations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  reg_code VARCHAR(20) NOT NULL UNIQUE,
  candidate_id UUID NOT NULL REFERENCES rd_candidates(id) ON DELETE RESTRICT,
  authority VARCHAR(20) NOT NULL CHECK (authority IN ('ppvfra', 'cvrc', 'svrc', 'icar', 'other')),
  reg_type VARCHAR(20) NOT NULL DEFAULT 'notification' CHECK (reg_type IN ('notification', 'ppvfra_protection', 'release', 'other')),
  status VARCHAR(12) NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'filed', 'under_review', 'granted', 'rejected', 'withdrawn')),
  filed_on DATE,
  reference_number VARCHAR(60),
  granted_on DATE,
  valid_until DATE,
  decision_note TEXT,
  created_by VARCHAR(100) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT chk_reg_filed CHECK (status IN ('draft', 'withdrawn') OR (filed_on IS NOT NULL AND reference_number IS NOT NULL)),
  CONSTRAINT chk_reg_granted CHECK (status <> 'granted' OR granted_on IS NOT NULL)
);
CREATE INDEX idx_rd_registrations_cand ON rd_registrations (candidate_id);
