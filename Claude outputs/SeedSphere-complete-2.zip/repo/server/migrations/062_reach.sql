-- Phase D — reaching growers, dealers and farmers.
--   seed_tags / seed_tag_scans  printed pack tags (QR) a farmer can verify with no login
--   msg_outbox                  SMS / WhatsApp messages queued by the system, sent by a worker
--   dealer_indents              seed requests raised by a dealer in the portal
--   quality_complaints          gains channel / tag / village so the public complaint form lands in the same quality pipeline

CREATE TABLE seed_tags (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tag_code VARCHAR(20) NOT NULL UNIQUE,
  seed_lot_id UUID NOT NULL REFERENCES seed_lots(id) ON DELETE RESTRICT,
  pack_size_kg NUMERIC(8, 2) NOT NULL CHECK (pack_size_kg > 0),
  dispatch_id UUID REFERENCES wh_dispatches(id) ON DELETE SET NULL,
  status VARCHAR(12) NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'void')),
  void_reason TEXT,
  scan_count INT NOT NULL DEFAULT 0,
  first_scanned_at TIMESTAMPTZ,
  last_scanned_at TIMESTAMPTZ,
  created_by VARCHAR(100) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT chk_tag_void_reason CHECK (status <> 'void' OR void_reason IS NOT NULL)
);
CREATE INDEX idx_seed_tags_lot ON seed_tags (seed_lot_id);

CREATE TABLE seed_tag_scans (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tag_code VARCHAR(30) NOT NULL,
  seed_tag_id UUID REFERENCES seed_tags(id) ON DELETE SET NULL,
  result VARCHAR(20) NOT NULL,
  client_hash VARCHAR(16),
  scanned_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_seed_tag_scans_tag ON seed_tag_scans (seed_tag_id);
CREATE INDEX idx_seed_tag_scans_result ON seed_tag_scans (result, scanned_at DESC);

CREATE TABLE msg_outbox (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  channel VARCHAR(10) NOT NULL CHECK (channel IN ('sms', 'whatsapp')),
  to_phone VARCHAR(20) NOT NULL,
  party_id UUID REFERENCES parties(id) ON DELETE SET NULL,
  template VARCHAR(40) NOT NULL,
  language VARCHAR(10) NOT NULL DEFAULT 'en',
  body TEXT NOT NULL,
  status VARCHAR(10) NOT NULL DEFAULT 'queued' CHECK (status IN ('queued', 'sent', 'failed', 'cancelled')),
  attempts INT NOT NULL DEFAULT 0,
  last_error TEXT,
  provider_ref VARCHAR(100),
  related_type VARCHAR(40),
  related_id UUID,
  created_by VARCHAR(100) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  sent_at TIMESTAMPTZ
);
CREATE INDEX idx_msg_outbox_status ON msg_outbox (status, created_at);
CREATE INDEX idx_msg_outbox_party ON msg_outbox (party_id);

CREATE TABLE dealer_indents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  indent_number VARCHAR(20) NOT NULL UNIQUE,
  dealer_id UUID NOT NULL REFERENCES parties(id) ON DELETE RESTRICT,
  crop VARCHAR(50) NOT NULL,
  variety VARCHAR(100),
  quantity_kg NUMERIC(12, 2) NOT NULL CHECK (quantity_kg > 0),
  needed_by DATE NOT NULL,
  notes TEXT,
  status VARCHAR(12) NOT NULL DEFAULT 'submitted' CHECK (status IN ('submitted', 'accepted', 'rejected', 'fulfilled', 'cancelled')),
  decision_note TEXT,
  decided_by VARCHAR(100),
  decided_at TIMESTAMPTZ,
  dispatch_id UUID REFERENCES wh_dispatches(id) ON DELETE SET NULL,
  created_by VARCHAR(100) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT chk_indent_decision CHECK (status IN ('submitted', 'cancelled') OR (decided_by IS NOT NULL AND decided_at IS NOT NULL))
);
CREATE INDEX idx_dealer_indents_dealer ON dealer_indents (dealer_id, created_at DESC);
CREATE INDEX idx_dealer_indents_status ON dealer_indents (status);

ALTER TABLE quality_complaints ADD COLUMN channel VARCHAR(16) NOT NULL DEFAULT 'staff' CHECK (channel IN ('staff', 'public_form', 'dealer_portal'));
ALTER TABLE quality_complaints ADD COLUMN tag_code VARCHAR(20);
ALTER TABLE quality_complaints ADD COLUMN complainant_village VARCHAR(100);
ALTER TABLE quality_complaints ADD COLUMN complaint_type VARCHAR(20);
CREATE INDEX idx_quality_complaints_channel ON quality_complaints (channel);
