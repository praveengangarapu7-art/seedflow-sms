-- Phase A foundations: the shared pieces every business module builds on.
--   1. job roles     — the 22 screen roles (plus external grower/dealer
--                      portal users) carried on the user record, so the
--                      server enforces the same authority the screens show.
--   2. parties       — one master for suppliers, contract growers, dealers,
--                      farmers and transporters.
--   3. attachments   — one store for licences, contracts, photos, reports.
--   4. approvals     — one approval engine with value-based rules.
--   5. inspections   — one template / result / decision model behind every
--                      quality field inspector and the field inspector.

-- 1. Job roles -------------------------------------------------------------
ALTER TABLE users ADD COLUMN job_role VARCHAR(50)
  CHECK (job_role IN (
    'purchase_executive', 'purchase_manager', 'finance_manager', 'procurement_quality_field_inspector',
    'warehouse_supervisor', 'warehouse_manager', 'warehouse_quality_field_inspector', 'safety_officer',
    'rd_executive', 'rd_manager', 'rd_quality_field_inspector',
    'plant_supervisor', 'plant_manager', 'processing_quality_field_inspector',
    'lab_manager', 'lab_technician', 'lab_quality_analyst',
    'quality_manager', 'quality_officer',
    'super_admin', 'system_admin', 'compliance_auditor',
    'grower', 'dealer'
  ));
CREATE INDEX idx_users_job_role ON users (job_role);

-- 2. Parties ---------------------------------------------------------------
CREATE TABLE parties (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  party_code VARCHAR(20) NOT NULL UNIQUE,
  party_type VARCHAR(20) NOT NULL CHECK (party_type IN
    ('supplier', 'contract_grower', 'dealer', 'distributor', 'farmer', 'transporter', 'customer', 'service_provider')),
  name VARCHAR(200) NOT NULL,
  contact_person VARCHAR(150),
  phone VARCHAR(20),
  email VARCHAR(150),
  preferred_language VARCHAR(10) NOT NULL DEFAULT 'en',
  address_line TEXT,
  village VARCHAR(100),
  district VARCHAR(100),
  state VARCHAR(100),
  pincode VARCHAR(10),
  gstin VARCHAR(15),
  pan VARCHAR(10),
  bank_account_name VARCHAR(150),
  bank_account_number VARCHAR(30),
  bank_ifsc VARCHAR(11),
  licence_number VARCHAR(60),
  licence_valid_until DATE,
  category VARCHAR(50),
  status VARCHAR(20) NOT NULL DEFAULT 'pending_approval'
    CHECK (status IN ('pending_approval', 'active', 'suspended', 'blacklisted')),
  status_reason TEXT,
  approved_by VARCHAR(100),
  approved_at TIMESTAMPTZ,
  user_id UUID REFERENCES users(id) ON DELETE SET NULL,
  notes TEXT,
  created_by VARCHAR(100) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  -- A party only becomes usable once a second person has approved it.
  CONSTRAINT chk_party_active_is_approved CHECK (status <> 'active' OR (approved_by IS NOT NULL AND approved_at IS NOT NULL)),
  CONSTRAINT chk_party_suspension_has_reason CHECK (status NOT IN ('suspended', 'blacklisted') OR status_reason IS NOT NULL),
  CONSTRAINT chk_party_needs_contact CHECK (phone IS NOT NULL OR email IS NOT NULL)
);
CREATE UNIQUE INDEX uq_parties_type_gstin ON parties (party_type, gstin) WHERE gstin IS NOT NULL;
CREATE UNIQUE INDEX uq_parties_user_id ON parties (user_id) WHERE user_id IS NOT NULL;
CREATE INDEX idx_parties_type_status ON parties (party_type, status);
CREATE INDEX idx_parties_licence_valid_until ON parties (licence_valid_until);
CREATE TRIGGER trg_parties_touch_updated_at BEFORE UPDATE ON parties FOR EACH ROW EXECUTE FUNCTION touch_updated_at();

-- 3. Attachments -------------------------------------------------------------
CREATE TABLE attachments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  entity_type VARCHAR(40) NOT NULL,
  entity_id VARCHAR(64) NOT NULL,
  file_name VARCHAR(255) NOT NULL,
  content_type VARCHAR(100) NOT NULL,
  size_bytes INT NOT NULL CHECK (size_bytes > 0),
  sha256 CHAR(64) NOT NULL,
  storage_key VARCHAR(200) NOT NULL UNIQUE,
  description TEXT,
  uploaded_by VARCHAR(100) NOT NULL,
  uploaded_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  deleted_by VARCHAR(100),
  deleted_at TIMESTAMPTZ
);
CREATE INDEX idx_attachments_entity ON attachments (entity_type, entity_id) WHERE deleted_at IS NULL;

-- 4. Approval engine -------------------------------------------------------
CREATE TABLE approval_rules (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  entity_type VARCHAR(40) NOT NULL,
  step_order INT NOT NULL CHECK (step_order > 0),
  step_name VARCHAR(100) NOT NULL,
  required_permission VARCHAR(60) NOT NULL,
  -- The step applies only when the request amount reaches this value, so a
  -- high-value order picks up a finance step that a small one does not.
  min_amount NUMERIC(14, 2) NOT NULL DEFAULT 0 CHECK (min_amount >= 0),
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  updated_by VARCHAR(100),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT uq_approval_rule_step UNIQUE (entity_type, step_order)
);

CREATE TABLE approval_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  entity_type VARCHAR(40) NOT NULL,
  entity_id UUID NOT NULL,
  entity_code VARCHAR(40) NOT NULL,
  title VARCHAR(250) NOT NULL,
  amount NUMERIC(14, 2),
  status VARCHAR(20) NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected', 'withdrawn')),
  requested_by VARCHAR(100) NOT NULL,
  requested_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  decided_at TIMESTAMPTZ
);
-- At most one open request per business record.
CREATE UNIQUE INDEX uq_approval_request_open ON approval_requests (entity_type, entity_id) WHERE status = 'pending';
CREATE INDEX idx_approval_requests_status ON approval_requests (status);

CREATE TABLE approval_steps (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  request_id UUID NOT NULL REFERENCES approval_requests(id) ON DELETE CASCADE,
  step_order INT NOT NULL,
  step_name VARCHAR(100) NOT NULL,
  required_permission VARCHAR(60) NOT NULL,
  status VARCHAR(20) NOT NULL CHECK (status IN ('waiting', 'pending', 'approved', 'rejected', 'cancelled')),
  decided_by VARCHAR(100),
  decided_at TIMESTAMPTZ,
  comment TEXT,
  CONSTRAINT uq_approval_step UNIQUE (request_id, step_order),
  CONSTRAINT chk_approval_step_decided CHECK (status NOT IN ('approved', 'rejected') OR (decided_by IS NOT NULL AND decided_at IS NOT NULL))
);
CREATE INDEX idx_approval_steps_pending ON approval_steps (required_permission) WHERE status = 'pending';

INSERT INTO approval_rules (entity_type, step_order, step_name, required_permission, min_amount) VALUES
  ('purchase_requisition', 1, 'Purchase manager approval', 'approve_requisition', 0),
  ('purchase_order', 1, 'Purchase manager approval', 'approve_order', 0),
  ('purchase_order', 2, 'Finance approval (high value)', 'approve_high_value_order', 500000),
  ('invoice_payment', 1, 'Finance approval for payment', 'approve_invoice_payment', 0),
  ('grower_agreement', 1, 'Purchase manager approval', 'approve_grower_agreement', 0),
  ('grower_settlement', 1, 'Finance approval for grower payment', 'approve_invoice_payment', 0),
  ('processing_recipe', 1, 'Plant manager approval', 'approve_recipe_system', 0),
  ('stock_adjustment', 1, 'Warehouse manager approval', 'approve_stock_adjustment', 0),
  ('dispatch_order', 1, 'Warehouse manager approval', 'approve_outbound_dispatch', 0);

-- 5. Inspection engine -----------------------------------------------------
CREATE TABLE inspection_templates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  template_code VARCHAR(20) NOT NULL UNIQUE,
  name VARCHAR(150) NOT NULL,
  inspection_type VARCHAR(40) NOT NULL CHECK (inspection_type IN (
    'procurement_receipt', 'warehouse_receipt', 'warehouse_return', 'storage_condition',
    'processing_pre', 'processing_in_process', 'processing_final',
    'field', 'trial_integrity', 'dealer_audit', 'other')),
  crop VARCHAR(100),
  version INT NOT NULL DEFAULT 1 CHECK (version > 0),
  status VARCHAR(20) NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'active', 'retired')),
  description TEXT,
  created_by VARCHAR(100) NOT NULL,
  activated_by VARCHAR(100),
  activated_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT uq_inspection_template_version UNIQUE (name, version)
);
CREATE TRIGGER trg_inspection_templates_touch_updated_at BEFORE UPDATE ON inspection_templates FOR EACH ROW EXECUTE FUNCTION touch_updated_at();

CREATE TABLE inspection_template_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  template_id UUID NOT NULL REFERENCES inspection_templates(id) ON DELETE CASCADE,
  seq INT NOT NULL,
  label VARCHAR(200) NOT NULL,
  item_type VARCHAR(20) NOT NULL CHECK (item_type IN ('numeric', 'pass_fail', 'text')),
  unit VARCHAR(20),
  min_value NUMERIC(12, 3),
  max_value NUMERIC(12, 3),
  is_required BOOLEAN NOT NULL DEFAULT TRUE,
  is_critical BOOLEAN NOT NULL DEFAULT FALSE,
  guidance TEXT,
  CONSTRAINT uq_template_item_seq UNIQUE (template_id, seq),
  CONSTRAINT chk_template_item_range CHECK (min_value IS NULL OR max_value IS NULL OR min_value <= max_value),
  CONSTRAINT chk_template_item_numeric_spec CHECK (item_type = 'numeric' OR (min_value IS NULL AND max_value IS NULL))
);

CREATE TABLE inspections (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  inspection_code VARCHAR(20) NOT NULL UNIQUE,
  template_id UUID NOT NULL REFERENCES inspection_templates(id) ON DELETE RESTRICT,
  inspection_type VARCHAR(40) NOT NULL,
  subject_type VARCHAR(40) NOT NULL,
  subject_id VARCHAR(64),
  subject_label VARCHAR(200) NOT NULL,
  seed_lot_id UUID REFERENCES seed_lots(id) ON DELETE RESTRICT,
  location_text VARCHAR(200),
  latitude NUMERIC(9, 6),
  longitude NUMERIC(9, 6),
  inspector_email VARCHAR(100) NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'in_progress' CHECK (status IN ('in_progress', 'submitted')),
  result VARCHAR(20) CHECK (result IN ('pass', 'conditional', 'fail')),
  decision VARCHAR(20) CHECK (decision IN ('accept', 'partial_accept', 'reject', 'hold', 'rework')),
  accepted_quantity NUMERIC(12, 2) CHECK (accepted_quantity >= 0),
  decision_notes TEXT,
  ncr_id UUID REFERENCES non_conformances(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  submitted_at TIMESTAMPTZ,
  CONSTRAINT chk_inspection_submitted_complete CHECK (
    status <> 'submitted' OR (result IS NOT NULL AND decision IS NOT NULL AND submitted_at IS NOT NULL)
  ),
  -- A failed inspection can never be waved through as a plain accept.
  CONSTRAINT chk_inspection_fail_not_accepted CHECK (result IS DISTINCT FROM 'fail' OR decision IS DISTINCT FROM 'accept')
);
CREATE INDEX idx_inspections_subject ON inspections (subject_type, subject_id);
CREATE INDEX idx_inspections_seed_lot_id ON inspections (seed_lot_id);
CREATE INDEX idx_inspections_status ON inspections (status);

CREATE TABLE inspection_results (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  inspection_id UUID NOT NULL REFERENCES inspections(id) ON DELETE CASCADE,
  template_item_id UUID NOT NULL REFERENCES inspection_template_items(id) ON DELETE RESTRICT,
  label VARCHAR(200) NOT NULL,
  item_type VARCHAR(20) NOT NULL,
  unit VARCHAR(20),
  min_value NUMERIC(12, 3),
  max_value NUMERIC(12, 3),
  is_critical BOOLEAN NOT NULL,
  numeric_value NUMERIC(12, 3),
  bool_value BOOLEAN,
  text_value TEXT,
  passed BOOLEAN,
  notes TEXT,
  CONSTRAINT uq_inspection_result_item UNIQUE (inspection_id, template_item_id)
);

-- Starter templates. Specification limits are generic starting values
-- drawn from common seed-certification practice; each company sets its own
-- per crop and variety before activating a revision.
DO $$
DECLARE
  t UUID;
BEGIN
  INSERT INTO inspection_templates (template_code, name, inspection_type, status, description, created_by, activated_by, activated_at)
  VALUES ('ITP-001', 'Procurement receipt — raw seed', 'procurement_receipt', 'active',
          'Gate inspection of raw seed delivered by a grower or supplier. Adjust limits to the crop and seed class.', 'system', 'system', now())
  RETURNING id INTO t;
  INSERT INTO inspection_template_items (template_id, seq, label, item_type, unit, min_value, max_value, is_critical, guidance) VALUES
    (t, 1, 'Moisture', 'numeric', '%', NULL, 13, TRUE, 'Moisture meter reading on a composite sample'),
    (t, 2, 'Physical purity', 'numeric', '%', 98, NULL, TRUE, 'Pure seed fraction of the working sample'),
    (t, 3, 'Inert matter', 'numeric', '%', NULL, 2, FALSE, NULL),
    (t, 4, 'Other crop seeds', 'numeric', 'per kg', NULL, 10, FALSE, NULL),
    (t, 5, 'No live insect infestation', 'pass_fail', NULL, NULL, NULL, TRUE, NULL),
    (t, 6, 'Bags intact and labelled with grower and lot', 'pass_fail', NULL, NULL, NULL, FALSE, NULL),
    (t, 7, 'Remarks', 'text', NULL, NULL, NULL, FALSE, NULL);
  UPDATE inspection_template_items SET is_required = FALSE WHERE template_id = t AND seq = 7;

  INSERT INTO inspection_templates (template_code, name, inspection_type, status, description, created_by, activated_by, activated_at)
  VALUES ('ITP-002', 'Processing — pre-processing check', 'processing_pre', 'active', 'Before a raw lot enters the line.', 'system', 'system', now())
  RETURNING id INTO t;
  INSERT INTO inspection_template_items (template_id, seq, label, item_type, unit, min_value, max_value, is_critical) VALUES
    (t, 1, 'Moisture', 'numeric', '%', NULL, 14, TRUE),
    (t, 2, 'Lot identity matches intake record', 'pass_fail', NULL, NULL, NULL, TRUE),
    (t, 3, 'Line cleaned since previous variety', 'pass_fail', NULL, NULL, NULL, TRUE);

  INSERT INTO inspection_templates (template_code, name, inspection_type, status, description, created_by, activated_by, activated_at)
  VALUES ('ITP-003', 'Processing — in-process check', 'processing_in_process', 'active', 'During cleaning, grading and treatment.', 'system', 'system', now())
  RETURNING id INTO t;
  INSERT INTO inspection_template_items (template_id, seq, label, item_type, unit, min_value, max_value, is_critical) VALUES
    (t, 1, 'Moisture after drying', 'numeric', '%', NULL, 12, TRUE),
    (t, 2, 'Physical purity after grading', 'numeric', '%', 98, NULL, TRUE),
    (t, 3, 'Treatment coverage uniform', 'pass_fail', NULL, NULL, NULL, FALSE);

  INSERT INTO inspection_templates (template_code, name, inspection_type, status, description, created_by, activated_by, activated_at)
  VALUES ('ITP-004', 'Processing — final inspection', 'processing_final', 'active', 'Finished lot before packaging release.', 'system', 'system', now())
  RETURNING id INTO t;
  INSERT INTO inspection_template_items (template_id, seq, label, item_type, unit, min_value, max_value, is_critical) VALUES
    (t, 1, 'Moisture', 'numeric', '%', NULL, 12, TRUE),
    (t, 2, 'Physical purity', 'numeric', '%', 98, NULL, TRUE),
    (t, 3, 'Germination (quick test)', 'numeric', '%', 80, NULL, TRUE),
    (t, 4, 'Treated-seed colour and warning label present', 'pass_fail', NULL, NULL, NULL, FALSE);

  INSERT INTO inspection_templates (template_code, name, inspection_type, status, description, created_by, activated_by, activated_at)
  VALUES ('ITP-005', 'Warehouse receipt', 'warehouse_receipt', 'active', 'Lot received into storage.', 'system', 'system', now())
  RETURNING id INTO t;
  INSERT INTO inspection_template_items (template_id, seq, label, item_type, unit, min_value, max_value, is_critical) VALUES
    (t, 1, 'Bag count matches document', 'pass_fail', NULL, NULL, NULL, TRUE),
    (t, 2, 'Tags and labels intact', 'pass_fail', NULL, NULL, NULL, TRUE),
    (t, 3, 'No moisture damage or infestation', 'pass_fail', NULL, NULL, NULL, TRUE);

  INSERT INTO inspection_templates (template_code, name, inspection_type, status, description, created_by, activated_by, activated_at)
  VALUES ('ITP-006', 'Returned stock', 'warehouse_return', 'active', 'Seed returned by a dealer or customer.', 'system', 'system', now())
  RETURNING id INTO t;
  INSERT INTO inspection_template_items (template_id, seq, label, item_type, unit, min_value, max_value, is_critical) VALUES
    (t, 1, 'Original seal and tag intact', 'pass_fail', NULL, NULL, NULL, TRUE),
    (t, 2, 'Within declared validity', 'pass_fail', NULL, NULL, NULL, TRUE),
    (t, 3, 'Storage damage', 'pass_fail', NULL, NULL, NULL, FALSE);

  INSERT INTO inspection_templates (template_code, name, inspection_type, status, description, created_by, activated_by, activated_at)
  VALUES ('ITP-007', 'Seed production field inspection', 'field', 'active', 'Seed plot inspection at flowering or pre-harvest.', 'system', 'system', now())
  RETURNING id INTO t;
  INSERT INTO inspection_template_items (template_id, seq, label, item_type, unit, min_value, max_value, is_critical) VALUES
    (t, 1, 'Isolation distance', 'numeric', 'm', 3, NULL, TRUE),
    (t, 2, 'Off-types', 'numeric', '%', NULL, 0.2, TRUE),
    (t, 3, 'Objectionable weed plants', 'numeric', '%', NULL, 0.02, FALSE),
    (t, 4, 'Seed-borne disease', 'numeric', '%', NULL, 0.1, TRUE),
    (t, 5, 'Crop stage', 'text', NULL, NULL, NULL, FALSE);

  INSERT INTO inspection_templates (template_code, name, inspection_type, status, description, created_by, activated_by, activated_at)
  VALUES ('ITP-008', 'Trial integrity check', 'trial_integrity', 'active', 'R&D trial plot audit.', 'system', 'system', now())
  RETURNING id INTO t;
  INSERT INTO inspection_template_items (template_id, seq, label, item_type, unit, min_value, max_value, is_critical) VALUES
    (t, 1, 'Plot layout matches design', 'pass_fail', NULL, NULL, NULL, TRUE),
    (t, 2, 'Plot labels correct', 'pass_fail', NULL, NULL, NULL, TRUE),
    (t, 3, 'Observations recorded on schedule', 'pass_fail', NULL, NULL, NULL, FALSE);
END $$;

INSERT INTO quality_counters (counter_key, last_value) VALUES ('ITP', 8)
  ON CONFLICT (counter_key) DO UPDATE SET last_value = GREATEST(quality_counters.last_value, 8);
