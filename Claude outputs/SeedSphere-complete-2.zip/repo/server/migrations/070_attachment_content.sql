-- Attachments can be kept in the database instead of on disk. Serverless hosts
-- (Vercel) have no lasting disk, so files written there would disappear.
ALTER TABLE attachments ADD COLUMN IF NOT EXISTS content bytea;
