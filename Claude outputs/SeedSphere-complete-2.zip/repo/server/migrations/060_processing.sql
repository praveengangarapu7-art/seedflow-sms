-- Phase B, part 2: seed processing.
--   plants & machines     — capacity, status and maintenance
--   raw intake            — accepted grower deliveries / goods receipts entering the plant
--   recipes               — approved process parameters and seed treatment per crop
--   batches               — the batch record: source intakes, stage-by-stage weights
--                           (mass balance), treatment applied, checkpoints, and the
--                           seed lot it produces
-- The seed lot is created when a batch completes, with its parent set to the
-- seed the grower was issued, so genealogy runs grower -> batch -> lot.

CREATE TABLE prc_plants (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code VARCHAR(20) NOT NULL UNIQUE,
  name VARCHAR(150) NOT NULL,
  location VARCHAR(200),
  capacity_kg_per_day NUMERIC(12, 2) CHECK (capacity_kg_per_day > 0),
  status VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
  created_by VARCHAR(100) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE prc_machines (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  plant_id UUID NOT NULL REFERENCES prc_plants(id) ON DELETE RESTRICT,
  code VARCHAR(20) NOT NULL UNIQUE,
  name VARCHAR(150) NOT NULL,
  machine_type VARCHAR(30) NOT NULL CHECK (machine_type IN ('pre_cleaner', 'dryer', 'cleaner_grader', 'gravity_separator', 'treater', 'packing', 'other')),
  capacity_kg_per_hour NUMERIC(10, 2) CHECK (capacity_kg_per_hour > 0),
  status VARCHAR(20) NOT NULL DEFAULT 'available' CHECK (status IN ('available', 'maintenance', 'breakdown', 'retired')),
  service_interval_days INT NOT NULL DEFAULT 90 CHECK (service_interval_days > 0),
  last_service_date DATE,
  next_service_due DATE,
  created_by VARCHAR(100) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_prc_machines_plant ON prc_machines (plant_id);

CREATE TABLE prc_maintenance (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  machine_id UUID NOT NULL REFERENCES prc_machines(id) ON DELETE CASCADE,
  maintenance_type VARCHAR(20) NOT NULL CHECK (maintenance_type IN ('preventive', 'breakdown', 'calibration')),
  scheduled_date DATE NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'scheduled' CHECK (status IN ('scheduled', 'done', 'cancelled')),
  completed_at TIMESTAMPTZ,
  downtime_hours NUMERIC(8, 2) CHECK (downtime_hours >= 0),
  notes TEXT,
  created_by VARCHAR(100) NOT NULL,
  completed_by VARCHAR(100),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT chk_maintenance_done CHECK (status <> 'done' OR (completed_at IS NOT NULL AND completed_by IS NOT NULL))
);
CREATE INDEX idx_prc_maintenance_machine ON prc_maintenance (machine_id);

CREATE TABLE prc_raw_intakes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  intake_number VARCHAR(20) NOT NULL UNIQUE,
  source_type VARCHAR(20) NOT NULL CHECK (source_type IN ('grower_delivery', 'goods_receipt')),
  grower_delivery_id UUID UNIQUE REFERENCES grw_deliveries(id) ON DELETE RESTRICT,
  goods_receipt_id UUID REFERENCES proc_goods_receipts(id) ON DELETE RESTRICT,
  grower_id UUID REFERENCES parties(id) ON DELETE RESTRICT,
  supplier_id UUID REFERENCES parties(id) ON DELETE RESTRICT,
  plant_id UUID NOT NULL REFERENCES prc_plants(id) ON DELETE RESTRICT,
  crop VARCHAR(100) NOT NULL,
  variety VARCHAR(100) NOT NULL,
  seed_class VARCHAR(20) NOT NULL CHECK (seed_class IN ('Foundation', 'Certified')),
  parent_lot_id UUID REFERENCES seed_lots(id) ON DELETE RESTRICT,
  quantity_kg NUMERIC(12, 2) NOT NULL CHECK (quantity_kg > 0),
  consumed_kg NUMERIC(12, 2) NOT NULL DEFAULT 0 CHECK (consumed_kg >= 0),
  moisture_pct NUMERIC(5, 2),
  status VARCHAR(20) NOT NULL DEFAULT 'awaiting_check' CHECK (status IN ('awaiting_check', 'ready', 'on_hold', 'rejected', 'consumed')),
  pre_inspection_id UUID REFERENCES inspections(id) ON DELETE SET NULL,
  received_by VARCHAR(100) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT chk_intake_source CHECK ((source_type = 'grower_delivery' AND grower_delivery_id IS NOT NULL) OR (source_type = 'goods_receipt' AND goods_receipt_id IS NOT NULL)),
  CONSTRAINT chk_intake_consumed CHECK (consumed_kg <= quantity_kg)
);
CREATE INDEX idx_prc_raw_intakes_status ON prc_raw_intakes (status);

CREATE TABLE prc_recipes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  recipe_code VARCHAR(20) NOT NULL UNIQUE,
  name VARCHAR(150) NOT NULL,
  crop VARCHAR(100) NOT NULL,
  version INT NOT NULL DEFAULT 1,
  status VARCHAR(20) NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'pending_approval', 'approved', 'rejected', 'retired')),
  target_moisture_pct NUMERIC(5, 2),
  notes TEXT,
  rejection_reason TEXT,
  created_by VARCHAR(100) NOT NULL,
  approved_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT uq_recipe_version UNIQUE (name, version)
);

CREATE TABLE prc_recipe_stages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  recipe_id UUID NOT NULL REFERENCES prc_recipes(id) ON DELETE CASCADE,
  seq INT NOT NULL,
  stage VARCHAR(20) NOT NULL CHECK (stage IN ('pre_cleaning', 'drying', 'cleaning_grading', 'gravity_separation', 'treatment', 'packing')),
  machine_type VARCHAR(30),
  parameters TEXT,
  max_loss_pct NUMERIC(5, 2) NOT NULL CHECK (max_loss_pct >= 0 AND max_loss_pct <= 50),
  CONSTRAINT uq_recipe_stage UNIQUE (recipe_id, seq)
);

CREATE TABLE prc_recipe_chemicals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  recipe_id UUID NOT NULL REFERENCES prc_recipes(id) ON DELETE CASCADE,
  chemical_name VARCHAR(150) NOT NULL,
  dose_per_kg NUMERIC(10, 4) NOT NULL CHECK (dose_per_kg > 0),
  dose_unit VARCHAR(10) NOT NULL CHECK (dose_unit IN ('g', 'ml')),
  purpose VARCHAR(150),
  CONSTRAINT uq_recipe_chemical UNIQUE (recipe_id, chemical_name)
);

CREATE TABLE prc_batches (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  batch_number VARCHAR(20) NOT NULL UNIQUE,
  recipe_id UUID NOT NULL REFERENCES prc_recipes(id) ON DELETE RESTRICT,
  plant_id UUID NOT NULL REFERENCES prc_plants(id) ON DELETE RESTRICT,
  crop VARCHAR(100) NOT NULL,
  variety VARCHAR(100) NOT NULL,
  seed_class VARCHAR(20) NOT NULL,
  parent_lot_id UUID REFERENCES seed_lots(id) ON DELETE RESTRICT,
  input_kg NUMERIC(12, 2) NOT NULL CHECK (input_kg > 0),
  output_kg NUMERIC(12, 2) CHECK (output_kg >= 0),
  status VARCHAR(20) NOT NULL DEFAULT 'planned' CHECK (status IN ('planned', 'in_progress', 'completed', 'cancelled')),
  planned_date DATE NOT NULL DEFAULT CURRENT_DATE,
  started_at TIMESTAMPTZ,
  completed_at TIMESTAMPTZ,
  output_lot_id UUID REFERENCES seed_lots(id) ON DELETE RESTRICT,
  is_treated BOOLEAN NOT NULL DEFAULT FALSE,
  notes TEXT,
  cancel_reason TEXT,
  created_by VARCHAR(100) NOT NULL,
  completed_by VARCHAR(100),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT chk_batch_completed CHECK (status <> 'completed' OR (output_kg IS NOT NULL AND output_lot_id IS NOT NULL AND completed_at IS NOT NULL)),
  CONSTRAINT chk_batch_output CHECK (output_kg IS NULL OR output_kg <= input_kg)
);
CREATE INDEX idx_prc_batches_status ON prc_batches (status);
CREATE UNIQUE INDEX uq_prc_batches_output_lot ON prc_batches (output_lot_id) WHERE output_lot_id IS NOT NULL;

CREATE TABLE prc_batch_inputs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  batch_id UUID NOT NULL REFERENCES prc_batches(id) ON DELETE CASCADE,
  raw_intake_id UUID NOT NULL REFERENCES prc_raw_intakes(id) ON DELETE RESTRICT,
  quantity_kg NUMERIC(12, 2) NOT NULL CHECK (quantity_kg > 0),
  CONSTRAINT uq_batch_input UNIQUE (batch_id, raw_intake_id)
);

CREATE TABLE prc_batch_stages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  batch_id UUID NOT NULL REFERENCES prc_batches(id) ON DELETE CASCADE,
  seq INT NOT NULL,
  stage VARCHAR(20) NOT NULL,
  max_loss_pct NUMERIC(5, 2) NOT NULL,
  parameters TEXT,
  machine_id UUID REFERENCES prc_machines(id) ON DELETE SET NULL,
  operator_email VARCHAR(100),
  input_kg NUMERIC(12, 2),
  output_kg NUMERIC(12, 2),
  loss_kg NUMERIC(12, 2),
  loss_pct NUMERIC(6, 2),
  loss_reason TEXT,
  actual_parameters TEXT,
  started_at TIMESTAMPTZ,
  completed_at TIMESTAMPTZ,
  ncr_id UUID REFERENCES non_conformances(id) ON DELETE SET NULL,
  CONSTRAINT uq_batch_stage UNIQUE (batch_id, seq),
  CONSTRAINT chk_stage_balance CHECK (output_kg IS NULL OR (output_kg <= input_kg AND loss_kg = input_kg - output_kg))
);

CREATE TABLE prc_batch_treatments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  batch_id UUID NOT NULL REFERENCES prc_batches(id) ON DELETE CASCADE,
  chemical_name VARCHAR(150) NOT NULL,
  dose_per_kg NUMERIC(10, 4) NOT NULL,
  dose_unit VARCHAR(10) NOT NULL,
  expected_quantity NUMERIC(12, 3) NOT NULL,
  quantity_used NUMERIC(12, 3) NOT NULL CHECK (quantity_used > 0),
  supplier_lot VARCHAR(60) NOT NULL,
  deviation_reason TEXT,
  applied_by VARCHAR(100) NOT NULL,
  applied_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_prc_batch_treatments_batch ON prc_batch_treatments (batch_id);
