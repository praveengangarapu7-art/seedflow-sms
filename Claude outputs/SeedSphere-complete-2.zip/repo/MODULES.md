# SeedSphere by module

Everything is organised by the module a team works in. Log in as `superadmin@seedsphere.com` (password `password123`) to see all of them, or use the module login shown. Setup is in `RUN_SEEDSPHERE.md`.

Sign-in is checked by the server, and what each person sees follows their own job role: menus, links and pages appear only when that person can open them, and every record they create or approve is logged under their name. Administrators create accounts and assign job roles under Administration → Users.

## Procurement — `manager@seedsphere.com`
Purchase requisitions, RFQ and quotations, purchase orders (a second person must approve), rate contracts, item master, suppliers and contract growers with agreements, goods receipt with gate inspection, grower deliveries and settlements, invoices with three-way match and payment, budget and cost control, reports. Pages under `/procurement/…`.

## Production Planning — `superadmin@seedsphere.com`
Farmers, farms, crop plans (planned → sown → growing → harvested), seed requirement and seed-lot reservation, field inspections with health score and disease risk, farm inspection approvals, harvest requests (a different person must approve; approval creates the lot ID; then harvest, transport authorisation, delivery to processing), seed lot inventory and genealogy, demand planning, variety catalog, cold storage, packaging and labelling, financing, farmer education, government programmes. Start at `/crop-planning`, `/farms`, `/harvests/approval`, `/inspections`.

## Research & Development — `rdexecutive@seedsphere.com`, `rdmanager@seedsphere.com`
Germplasm catalogue, phenotyping measurements, breeding programmes with generations and budget, nurseries (sow, harvest, notes), multi-location trials, release pipeline (candidate → multi-location → pre-release → released, with approvals), variety registrations, varieties. `/rd/…`.

## Processing — `plantmanager@seedsphere.com`
Raw intake, processing batches through every stage with loss limits, plants and machines, treatment recipes (approved before use), yield and loss, plant scheduling against capacity, certification register, packaging and QR tags, traceability, inspections, approvals. `/processing/…`.

## Laboratory — `superadmin@seedsphere.com`
Sample submissions to partner labs, germination, purity and vigour results scored against certification thresholds, automatic quality flags, certificates, lab performance. `/lab/…`.

## Warehouse — `whmanager@seedsphere.com`
Inventory by lot and bin, inbound receiving, outbound dispatch to licensed dealers, dealer requests, pack tags and QR codes, stock movements and adjustments, cycle counting, returns, temperature and humidity monitoring with breach alerts, safety and environment, inspections, reports. `/warehouse/…`. Dealers see their own portal at `/portal/dealer` (`dealer@seedsphere.com`); the public QR check is `/verify/<tag code>`.

## Quality — `qualitymanager@seedsphere.com`, `qualityofficer@seedsphere.com`
SOP register with acknowledgements, non-conformances, CAPA, farmer complaints, lot holds, compliance register, inspections and checklists, recalls (trace affected dealers, approve, notify), audits with findings, safety and environment, training records, management dashboard, SATHI registers export. `/quality/…`.

## Administration — `sysadmin@seedsphere.com`
Company-wide dashboard, users, roles and permissions, organisations, audit logs, system health, data governance and privacy, approval workflows and rules, approvals inbox, alerts, SMS/WhatsApp message log, party master, settings. `/admin/…`. Growers use `/portal/grower` (`grower@seedsphere.com`).

## Safety & environment — `/warehouse/safety`, `/processing/safety`, `/quality/safety`
Report incidents and near misses (injury, chemical spill, fire, equipment, environmental) with severity, area and lost-time. Major and critical incidents open a non-conformance automatically. Safety staff and managers investigate, then close with a root cause and corrective action. The chemical register tracks received, used and disposed with a running balance; it refuses to use or dispose of more than is on record. Dashboard shows open incidents, near misses, days since the last lost-time incident and chemicals on hand.

## Electronic signatures
Recalls, variety releases (both steps), invoice payments and grower settlements are signed approvals: the approver re-enters their password, and the signer, the meaning of the signature, the time and a hash of the record are stored and shown on the approval trail. Wrong password means nothing is approved. Administrators can switch signing on for any approval step through the rules (`requiresSignature`).

## Assistant
The “Ask SeedSphere” box answers from live data across stock, laboratory, quality (non-conformances, recalls), safety, approvals waiting, procurement, processing batches and dispatches, and lists the records it used. It is read-only. With no AI model configured it answers by rules from the same data.

## Mobile field inspection (`mobile/`)
An Expo app for inspectors: sign in, see the farms (kept on the phone for offline), record a visit (crop stage, health, disease, notes, photo, location). With no signal the visit is saved on the phone and sent automatically when the connection returns (Sync tab). Run with `cd mobile && npm install && npx expo start`; to use the deployed system set `EXPO_PUBLIC_API_BASE_URL=https://<your-domain>/api/v1` (on a phone testing against your computer, use the computer's Wi-Fi address instead).

## AI Center — `/ai` (AI Center button in the header)
Quality-risk score for every seed lot with a 90-day germination forecast, stock-cover and label-expiry forecasts, field-crop and seed photo screening (in the browser, or by a vision model when one is configured), findings for every module, a knowledge base the assistant searches, and the assistant itself. Every module also shows an **AI insights** strip at the top with what needs attention there, from live data (approvals waiting, overdue orders, storage breaches, batches running late, serious safety incidents and more). Numbers are always computed from records; an AI model, when configured (`AI_API_KEY`), only writes the briefings.

## Custom fields — `/admin/custom-fields`
Administrators define extra fields (text, number, date, choice, yes/no) for seed lots, suppliers, purchase orders, goods receipts, processing batches, warehouse lots, lab submissions and non-conformances. Fields defined for seed lots are shared: the same value shows in every module that displays that lot.

## Shared by every module
One approvals inbox and rule engine, one inspection and checklist engine, one audit log, and file attachments, so each module behaves the same way.
