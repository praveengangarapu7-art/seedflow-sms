import { Router, type Request, type Response } from 'express';
import { asyncHandler } from '../../middleware/asyncHandler';
import { requireAuth } from '../../middleware/requireAuth';
import { ValidationError } from '../../errors';
import { aiStatus, analyzePhoto, forecastReport, labRiskReport } from './ai.service';
import { allModuleInsights, isModuleKey, moduleInsights } from './moduleInsights';

/**
 * AI Center endpoints. Read-only over existing data (like the assistant), so
 * any authenticated role may call them; photo analysis stores nothing.
 */
export const aiRouter = Router();

aiRouter.use(requireAuth);

aiRouter.get('/status', (_req: Request, res: Response) => {
  res.json({ success: true, data: aiStatus() });
});

aiRouter.get(
  '/lab-risk',
  asyncHandler(async (_req: Request, res: Response) => {
    res.json({ success: true, data: await labRiskReport() });
  }),
);

aiRouter.get(
  '/forecasts',
  asyncHandler(async (_req: Request, res: Response) => {
    res.json({ success: true, data: await forecastReport() });
  }),
);

aiRouter.get(
  '/insights',
  asyncHandler(async (_req: Request, res: Response) => {
    res.json({ success: true, data: await allModuleInsights() });
  }),
);

aiRouter.get(
  '/insights/:module',
  asyncHandler(async (req: Request, res: Response) => {
    const key = String(req.params.module);
    if (!isModuleKey(key)) throw new ValidationError(`Unknown module "${key}"`);
    res.json({ success: true, data: await moduleInsights(key, { narrate: req.query.briefing === 'true' }) });
  }),
);

aiRouter.post(
  '/photo-analysis',
  asyncHandler(async (req: Request, res: Response) => {
    res.json({ success: true, data: await analyzePhoto(req.body ?? {}) });
  }),
);
