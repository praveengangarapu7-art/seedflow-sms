import type { Permission } from '@/utils/permissions';
import {
  LayoutDashboard,
  Boxes,
  PackagePlus,
  MapPin,
  PackageMinus,
  ArrowLeftRight,
  Edit3,
  ClipboardList,
  Undo2,
  Thermometer,
  BarChart3,
  CheckSquare,
  Store,
  QrCode,
  Inbox,
} from 'lucide-react';
import type { NavItem } from '@/types';

export interface WarehouseNavItem extends NavItem {
  permission: Permission;
}

export const warehouseNav: WarehouseNavItem[] = [
  { label: 'Dashboard', path: '/warehouse/dashboard', icon: LayoutDashboard, permission: 'view_warehouse_dashboard' },
  { label: 'Inventory', path: '/warehouse/inventory', icon: Boxes, permission: 'view_inventory' },
  { label: 'Inbound (Receiving)', path: '/warehouse/inbound', icon: PackagePlus, permission: 'view_inbound' },
  { label: 'Storage & Locations', path: '/warehouse/locations', icon: MapPin, permission: 'view_storage_locations' },
  { label: 'Outbound (Dispatch)', path: '/warehouse/outbound', icon: PackageMinus, permission: 'view_outbound' },
  { label: 'Dealers & customers', path: '/warehouse/dealers', icon: Store, permission: 'view_outbound' },
  { label: 'Dealer requests', path: '/warehouse/indents', icon: Inbox, permission: 'view_dealer_indents' },
  { label: 'Pack tags & QR', path: '/warehouse/tags', icon: QrCode, permission: 'view_pack_tags' },
  { label: 'Stock Movements', path: '/warehouse/movements', icon: ArrowLeftRight, permission: 'view_stock_movements' },
  { label: 'Stock Adjustments', path: '/warehouse/adjustments', icon: Edit3, permission: 'view_stock_adjustments' },
  { label: 'Cycle Counting', path: '/warehouse/cycle-counting', icon: ClipboardList, permission: 'view_cycle_counting' },
  { label: 'Returns Management', path: '/warehouse/returns', icon: Undo2, permission: 'view_returns' },
  { label: 'IoT Monitoring', path: '/warehouse/iot', icon: Thermometer, permission: 'view_iot_monitoring' },
  { label: 'Inspections', path: '/warehouse/inspections', icon: ClipboardList, permission: 'view_inspections' },
  { label: 'Approvals', path: '/warehouse/approvals', icon: CheckSquare, permission: 'view_approvals_inbox' },
  { label: 'Reports & Analytics', path: '/warehouse/reports', icon: BarChart3, permission: 'view_warehouse_reports' },
];
