import { useCallback, useEffect, useRef, useState, type ReactNode } from 'react';
import { Button } from '@/components/common/Button/Button';
import { Modal } from '@/components/common/Modal/Modal';
import { useToast } from '@/components/common/Toast/ToastContext';
import styles from './Live.module.css';

export { styles };

// ------------------------------------------------------------------ format

export function fmtDate(value: string | null | undefined): string {
  if (!value) return '—';
  const d = new Date(value.length === 10 ? `${value}T00:00:00` : value);
  return Number.isNaN(d.getTime()) ? '—' : d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
}

export function fmtDateTime(value: string | null | undefined): string {
  if (!value) return '—';
  const d = new Date(value);
  return Number.isNaN(d.getTime()) ? '—' : d.toLocaleString('en-IN', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
}

/** Indian rupees with lakh grouping, e.g. ₹12,34,567.50 */
export function fmtMoney(value: number | string | null | undefined, decimals = 2): string {
  if (value === null || value === undefined || value === '') return '—';
  const n = Number(value);
  if (!Number.isFinite(n)) return '—';
  return `₹${n.toLocaleString('en-IN', { minimumFractionDigits: decimals, maximumFractionDigits: decimals })}`;
}

export function fmtQty(value: number | string | null | undefined, unit?: string | null, decimals = 2): string {
  if (value === null || value === undefined || value === '') return '—';
  const n = Number(value);
  if (!Number.isFinite(n)) return '—';
  return `${n.toLocaleString('en-IN', { maximumFractionDigits: decimals })}${unit ? ` ${unit}` : ''}`;
}

export function fmtPct(value: number | string | null | undefined, decimals = 1): string {
  if (value === null || value === undefined || value === '') return '—';
  const n = Number(value);
  return Number.isFinite(n) ? `${n.toFixed(decimals)}%` : '—';
}

export function humanize(value: string | null | undefined): string {
  if (!value) return '—';
  return value.replace(/_/g, ' ').replace(/^\w/, (c) => c.toUpperCase());
}

/** Today as YYYY-MM-DD in local time — what <input type="date"> speaks. */
export function todayIso(): string {
  const d = new Date();
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

export function addDays(iso: string, days: number): string {
  const d = new Date(`${iso}T00:00:00`);
  d.setDate(d.getDate() + days);
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

// ------------------------------------------------------------------- pills

export type Tone = 'good' | 'warn' | 'bad' | 'info' | 'neutral';
const TONE_CLASS: Record<Tone, string> = {
  good: styles.badgeGood,
  warn: styles.badgeWarn,
  bad: styles.badgeBad,
  info: styles.badgeInfo,
  neutral: styles.badgeNeutral,
};

export function Pill({ tone, children }: { tone: Tone; children: ReactNode }) {
  return <span className={`${styles.badge} ${TONE_CLASS[tone]}`}>{children}</span>;
}

const STATUS_TONE: Record<string, Tone> = {
  // generic
  draft: 'neutral',
  pending: 'warn',
  pending_approval: 'warn',
  submitted: 'info',
  approved: 'good',
  active: 'good',
  rejected: 'bad',
  cancelled: 'neutral',
  withdrawn: 'neutral',
  closed: 'good',
  completed: 'good',
  in_progress: 'warn',
  suspended: 'warn',
  blacklisted: 'bad',
  retired: 'neutral',
  expired: 'bad',
  // inspections
  pass: 'good',
  conditional: 'warn',
  fail: 'bad',
  // procurement
  sent: 'info',
  partially_received: 'warn',
  received: 'good',
  verified: 'info',
  matched: 'good',
  mismatch: 'bad',
  paid: 'good',
  awaiting_inspection: 'warn',
  accepted: 'good',
  on_hold: 'bad',
  open: 'info',
  awarded: 'good',
  settled: 'good',
  // stock
  sellable: 'good',
  retest_due: 'warn',
  quarantine: 'bad',
  dispatched: 'info',
  delivered: 'good',
  picked: 'info',
};

export function StatusPill({ status, label }: { status: string | null | undefined; label?: string }) {
  if (!status) return <span className={styles.muted}>—</span>;
  return <Pill tone={STATUS_TONE[status] ?? 'neutral'}>{label ?? humanize(status)}</Pill>;
}

// ------------------------------------------------------------------ blocks

export function Notice({ tone = 'neutral', children }: { tone?: 'neutral' | 'warn' | 'bad' | 'good'; children: ReactNode }) {
  const cls = tone === 'warn' ? styles.noticeWarn : tone === 'bad' ? styles.noticeBad : tone === 'good' ? styles.noticeGood : '';
  return <div className={`${styles.notice} ${cls}`}>{children}</div>;
}

export function ErrorCard({ message }: { message: string | null | undefined }) {
  if (!message) return null;
  return (
    <div className={styles.card} role="alert">
      <span className={styles.errorText}>{message}</span>
    </div>
  );
}

export function Field({ label, htmlFor, hint, children }: { label: string; htmlFor?: string; hint?: string; children: ReactNode }) {
  return (
    <div className={styles.field}>
      <label className={styles.label} htmlFor={htmlFor}>
        {label}
      </label>
      {children}
      {hint && <span className={styles.muted} style={{ fontSize: '0.78rem' }}>{hint}</span>}
    </div>
  );
}

export function Section({ title, subtitle, actions, children }: { title: string; subtitle?: ReactNode; actions?: ReactNode; children: ReactNode }) {
  return (
    <section className={styles.card}>
      <div style={{ display: 'flex', justifyContent: 'space-between', gap: 12, alignItems: 'flex-start', flexWrap: 'wrap', marginBottom: 12 }}>
        <div>
          <h2 className={styles.sectionTitle}>{title}</h2>
          {subtitle && <p className={styles.sectionSubtitle}>{subtitle}</p>}
        </div>
        {actions && <div className={styles.actionsRow}>{actions}</div>}
      </div>
      {children}
    </section>
  );
}

export function KeyValues({ rows }: { rows: [string, ReactNode][] }) {
  return (
    <dl className={styles.kv}>
      {rows.map(([k, v]) => (
        <div key={k} style={{ display: 'contents' }}>
          <dt>{k}</dt>
          <dd>{v === null || v === undefined || v === '' ? '—' : v}</dd>
        </div>
      ))}
    </dl>
  );
}

export function Empty({ children }: { children: ReactNode }) {
  return <div className={styles.emptyState}>{children}</div>;
}

export function PageHeader({ title, subtitle, actions }: { title: string; subtitle?: ReactNode; actions?: ReactNode }) {
  return (
    <div className={styles.header}>
      <div>
        <h1 className={styles.title}>{title}</h1>
        {subtitle && <p className={styles.subtitle}>{subtitle}</p>}
      </div>
      {actions && <div className={styles.controls}>{actions}</div>}
    </div>
  );
}

export function Tabs<T extends string>({ tabs, active, onChange }: { tabs: { key: T; label: string; count?: number }[]; active: T; onChange: (key: T) => void }) {
  return (
    <div className={styles.tabs} role="tablist">
      {tabs.map((t) => (
        <button key={t.key} role="tab" aria-selected={active === t.key} className={`${styles.tab} ${active === t.key ? styles.tabActive : ''}`} onClick={() => onChange(t.key)}>
          {t.label}
          {t.count !== undefined ? ` (${t.count})` : ''}
        </button>
      ))}
    </div>
  );
}

export function Chips<T extends string>({ options, active, onChange }: { options: { key: T; label: string; count?: number }[]; active: T; onChange: (key: T) => void }) {
  return (
    <div className={styles.filterBar}>
      {options.map((o) => (
        <button key={o.key} className={`${styles.chip} ${active === o.key ? styles.chipActive : ''}`} onClick={() => onChange(o.key)}>
          {o.label}
          {o.count !== undefined ? ` · ${o.count}` : ''}
        </button>
      ))}
    </div>
  );
}

// ------------------------------------------------------------------- hooks

/** Loads data with a token; exposes loading/error/reload. `deps` decides when to reload. */
export function useLoad<T>(token: string | null, loader: (token: string) => Promise<T>, deps: unknown[] = []) {
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const loaderRef = useRef(loader);
  loaderRef.current = loader;

  const reload = useCallback(async () => {
    if (!token) return;
    setLoading(true);
    setError(null);
    try {
      setData(await loaderRef.current(token));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to load data');
    } finally {
      setLoading(false);
    }
  }, [token]);

  useEffect(() => {
    void reload();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [reload, ...deps]);

  return { data, loading, error, reload, setData };
}

/** Runs a mutation and reports the outcome with a toast; returns undefined on failure. */
export function useAction() {
  const { addToast } = useToast();
  const [busy, setBusy] = useState(false);
  const run = useCallback(
    async <T,>(action: () => Promise<T>, success: string | ((r: T) => string)): Promise<T | undefined> => {
      setBusy(true);
      try {
        const r = await action();
        addToast(typeof success === 'function' ? success(r) : success, 'success');
        return r;
      } catch (err) {
        addToast(err instanceof Error ? err.message : 'Action failed', 'error');
        return undefined;
      } finally {
        setBusy(false);
      }
    },
    [addToast],
  );
  return { run, busy };
}

// ------------------------------------------------------------------ modals

interface PromptModalProps {
  isOpen: boolean;
  title: string;
  label: string;
  placeholder?: string;
  confirmLabel: string;
  confirmVariant?: 'primary' | 'danger';
  description?: ReactNode;
  required?: boolean;
  busy?: boolean;
  onClose: () => void;
  onSubmit: (text: string) => unknown;
}

/** Collects one piece of free text (a reason, a comment) before an action. */
export function PromptModal({ isOpen, title, label, placeholder, confirmLabel, confirmVariant = 'primary', description, required = true, busy, onClose, onSubmit }: PromptModalProps) {
  const [text, setText] = useState('');
  const { addToast } = useToast();
  useEffect(() => {
    if (isOpen) setText('');
  }, [isOpen]);
  const submit = async () => {
    if (required && !text.trim()) {
      addToast(`${label} is required.`, 'error');
      return;
    }
    await onSubmit(text.trim());
  };
  return (
    <Modal isOpen={isOpen} onClose={onClose} title={title}>
      <div className={styles.modalStack}>
        {description}
        <div>
          <label className={styles.label} htmlFor="live-prompt-text">
            {label}
          </label>
          <textarea id="live-prompt-text" className={styles.textArea} value={text} placeholder={placeholder} onChange={(e) => setText(e.target.value)} />
        </div>
        <div className={styles.actionsRow}>
          <Button variant={confirmVariant} isLoading={busy} onClick={() => void submit()}>
            {confirmLabel}
          </Button>
          <Button variant="secondary" onClick={onClose}>
            Cancel
          </Button>
        </div>
      </div>
    </Modal>
  );
}

/** Small controlled-form helper: one state object, typed setters. */
export function useForm<T extends Record<string, unknown>>(initial: T) {
  const [form, setForm] = useState<T>(initial);
  const set = useCallback(<K extends keyof T>(key: K, value: T[K]) => setForm((f) => ({ ...f, [key]: value })), []);
  const reset = useCallback(() => setForm(initial), [initial]);
  return { form, set, setForm, reset };
}

/** Converts '' to undefined and numeric strings to numbers for API payloads. */
export function cleanPayload(obj: Record<string, unknown>, numericKeys: string[] = []): Record<string, unknown> {
  const out: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(obj)) {
    if (v === '' || v === undefined || v === null) continue;
    out[k] = numericKeys.includes(k) && typeof v === 'string' ? Number(v) : v;
  }
  return out;
}
