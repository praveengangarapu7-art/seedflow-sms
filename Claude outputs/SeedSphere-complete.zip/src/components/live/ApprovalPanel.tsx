import { useState } from 'react';
import { Check, X } from 'lucide-react';
import { Button } from '@/components/common/Button/Button';
import { decideApproval, fetchEntityApprovals, type ApprovalRequest } from '@/services/live/foundations';
import { Empty, PromptModal, Section, StatusPill, fmtDateTime, fmtMoney, humanize, styles, useAction, useLoad } from './ui';

interface ApprovalPanelProps {
  token: string | null;
  entityType: string;
  entityId: string;
  /** Server permissions of the viewer — decides whether decide buttons appear. */
  can: (permission: string) => boolean;
  currentEmail: string | null | undefined;
  /** Bump to reload after the record is submitted. */
  refreshKey?: unknown;
  onDecided?: () => void;
}

/** The approval trail of one record, with approve/reject for the person whose step it is. */
export function ApprovalPanel({ token, entityType, entityId, can, currentEmail, refreshKey, onDecided }: ApprovalPanelProps) {
  const history = useLoad<ApprovalRequest[]>(token, (t) => fetchEntityApprovals(t, entityType, entityId), [entityType, entityId, refreshKey]);
  const { run, busy } = useAction();
  const [rejecting, setRejecting] = useState<ApprovalRequest | null>(null);
  const requests = history.data ?? [];

  const decide = async (req: ApprovalRequest, decision: 'approve' | 'reject', comment?: string) => {
    if (!token) return;
    const r = await run(() => decideApproval(token, req.id, decision, comment), (res) =>
      res.status === 'approved' ? `${res.entity_code} approved` : res.status === 'rejected' ? `${res.entity_code} rejected` : 'Approved — passed to the next approver',
    );
    if (r) {
      setRejecting(null);
      await history.reload();
      onDecided?.();
    }
  };

  return (
    <Section title="Approvals" subtitle="Each step needs a different person holding the step's permission; nobody approves their own request.">
      {history.error && <p className={styles.errorText}>{history.error}</p>}
      {!history.loading && requests.length === 0 && <Empty>Not submitted for approval yet.</Empty>}
      {requests.map((req) => {
        const pending = req.steps?.find((s) => s.status === 'pending');
        const decidedByMe = req.steps?.some((s) => s.decided_by === currentEmail);
        const mayDecide = req.status === 'pending' && pending && can(pending.required_permission) && req.requested_by !== currentEmail && !decidedByMe;
        return (
          <div key={req.id} style={{ marginBottom: 16 }}>
            <p className={styles.muted} style={{ marginBottom: 8 }}>
              Submitted by {req.requested_by} · {fmtDateTime(req.requested_at)}
              {req.amount ? ` · ${fmtMoney(req.amount)}` : ''} · <StatusPill status={req.status} />
            </p>
            <ol className={styles.stepList}>
              {req.steps?.map((s) => (
                <li key={s.id} className={styles.stepItem}>
                  <span>
                    <strong>
                      {s.step_order}. {s.step_name}
                    </strong>
                    <br />
                    <span className={styles.muted}>
                      {s.decided_by ? `${humanize(s.status)} by ${s.decided_by} · ${fmtDateTime(s.decided_at)}` : `Needs ${humanize(s.required_permission)}`}
                      {s.comment ? ` — “${s.comment}”` : ''}
                    </span>
                  </span>
                  <StatusPill status={s.status} />
                </li>
              ))}
            </ol>
            {mayDecide && (
              <div className={styles.actionsRow} style={{ marginTop: 10 }}>
                <Button leftIcon={Check} isLoading={busy} onClick={() => void decide(req, 'approve')}>
                  Approve
                </Button>
                <Button variant="danger" leftIcon={X} onClick={() => setRejecting(req)}>
                  Reject
                </Button>
              </div>
            )}
          </div>
        );
      })}
      <PromptModal
        isOpen={!!rejecting}
        title={`Reject ${rejecting?.entity_code ?? ''}`}
        label="Reason for rejecting"
        confirmLabel="Reject"
        confirmVariant="danger"
        busy={busy}
        onClose={() => setRejecting(null)}
        onSubmit={(text) => rejecting && decide(rejecting, 'reject', text)}
      />
    </Section>
  );
}
