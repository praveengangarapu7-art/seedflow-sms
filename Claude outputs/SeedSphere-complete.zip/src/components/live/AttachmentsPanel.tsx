import { useRef, useState } from 'react';
import { Download, Paperclip, Trash2, Upload } from 'lucide-react';
import { Button } from '@/components/common/Button/Button';
import { useToast } from '@/components/common/Toast/ToastContext';
import { ACCEPTED_FILE_TYPES, deleteAttachment, downloadAttachment, fetchAttachments, uploadAttachment, type Attachment } from '@/services/live/foundations';
import { Empty, Section, fmtDateTime, styles, useLoad } from './ui';

interface AttachmentsPanelProps {
  token: string | null;
  entityType: string;
  entityId: string;
  title?: string;
  subtitle?: string;
  canUpload?: boolean;
  currentEmail?: string | null;
  onChange?: (count: number) => void;
}

/** Files attached to one record — licences, contracts, photos, reports. Every file is checksummed on upload. */
export function AttachmentsPanel({ token, entityType, entityId, title = 'Documents and photos', subtitle, canUpload = true, currentEmail, onChange }: AttachmentsPanelProps) {
  const { addToast } = useToast();
  const input = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const files = useLoad<Attachment[]>(token, (t) => fetchAttachments(t, entityType, entityId), [entityType, entityId]);
  const rows = files.data ?? [];

  const onPick = async (list: FileList | null) => {
    if (!token || !list?.length) return;
    setUploading(true);
    let okCount = 0;
    for (const file of Array.from(list)) {
      try {
        await uploadAttachment(token, entityType, entityId, file);
        okCount += 1;
      } catch (err) {
        addToast(`${file.name}: ${err instanceof Error ? err.message : 'upload failed'}`, 'error');
      }
    }
    setUploading(false);
    if (input.current) input.current.value = '';
    if (okCount) addToast(`${okCount} file(s) uploaded`, 'success');
    await files.reload();
    onChange?.(rows.length + okCount);
  };

  const remove = async (a: Attachment) => {
    if (!token) return;
    try {
      await deleteAttachment(token, a.id);
      addToast(`${a.file_name} removed`, 'success');
      await files.reload();
      onChange?.(Math.max(0, rows.length - 1));
    } catch (err) {
      addToast(err instanceof Error ? err.message : 'Unable to remove the file', 'error');
    }
  };

  return (
    <Section
      title={title}
      subtitle={subtitle ?? 'PDF, images, CSV, Excel or Word up to 10 MB. Files are checksummed so a changed file is detected.'}
      actions={
        canUpload && (
          <>
            <input ref={input} type="file" multiple accept={ACCEPTED_FILE_TYPES} style={{ display: 'none' }} onChange={(e) => void onPick(e.target.files)} />
            <Button variant="secondary" size="sm" leftIcon={Upload} isLoading={uploading} onClick={() => input.current?.click()}>
              Upload
            </Button>
          </>
        )
      }
    >
      {files.error && <p className={styles.errorText}>{files.error}</p>}
      {!files.loading && rows.length === 0 && <Empty>No files attached yet.</Empty>}
      {rows.map((a) => (
        <div key={a.id} className={styles.fileRow}>
          <span style={{ display: 'flex', alignItems: 'center', gap: 8, minWidth: 0 }}>
            <Paperclip size={14} />
            <span style={{ overflow: 'hidden', textOverflow: 'ellipsis' }}>{a.file_name}</span>
            <span className={styles.muted}>
              {(a.size_bytes / 1024).toFixed(0)} KB · {a.uploaded_by} · {fmtDateTime(a.uploaded_at)}
            </span>
          </span>
          <span className={styles.actionsRow}>
            <Button variant="ghost" size="sm" leftIcon={Download} onClick={() => token && void downloadAttachment(token, a).catch((e) => addToast(e.message, 'error'))}>
              Download
            </Button>
            {currentEmail === a.uploaded_by && (
              <Button variant="ghost" size="sm" leftIcon={Trash2} onClick={() => void remove(a)}>
                Remove
              </Button>
            )}
          </span>
        </div>
      ))}
    </Section>
  );
}
