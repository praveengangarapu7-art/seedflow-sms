/**
 * Lean client for the modules built from the development plan. Unlike the
 * older seedLotRealtimeClient it never substitutes sample data: these screens
 * carry live business records (orders, payments, stock), so when the server
 * cannot be reached the page says so instead of showing invented figures.
 */
const rawApiBaseUrl = (import.meta.env.VITE_API_BASE_URL as string | undefined) ?? 'http://localhost:5000/api/v1';
export const API_BASE_URL = rawApiBaseUrl.replace(/\/+$/, '');

export class ApiError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

export const OFFLINE_MESSAGE =
  'Cannot reach the SeedSphere server. Live records need the server running — check the connection and try again.';

function messageFor(status: number, serverMessage?: string): string {
  if (serverMessage) return serverMessage;
  if (status === 401) return 'Your session has expired — please sign in again.';
  if (status === 403) return "Your role doesn't allow that.";
  if (status === 404) return 'That record could not be found.';
  if (status >= 500) return 'The server ran into a problem. Please try again in a moment.';
  return 'Something went wrong. Please try again.';
}

async function call<T>(method: string, path: string, token: string | null, body?: unknown): Promise<T> {
  let response: Response;
  try {
    response = await fetch(`${API_BASE_URL}${path}`, {
      method,
      headers: {
        ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}),
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
  } catch {
    throw new ApiError(0, OFFLINE_MESSAGE);
  }
  const text = await response.text();
  let payload: { success?: boolean; data?: T; message?: string } | null = null;
  try {
    payload = text ? JSON.parse(text) : null;
  } catch {
    payload = null;
  }
  if (!response.ok || payload?.success === false) throw new ApiError(response.status, messageFor(response.status, payload?.message));
  return (payload?.data ?? (undefined as unknown)) as T;
}

/** Query string from an object, skipping empty values. */
export function qs(params: Record<string, string | number | boolean | null | undefined>): string {
  const parts = Object.entries(params)
    .filter(([, v]) => v !== undefined && v !== null && v !== '')
    .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(String(v))}`);
  return parts.length ? `?${parts.join('&')}` : '';
}

export const api = {
  get: <T>(path: string, token: string | null) => call<T>('GET', path, token),
  post: <T>(path: string, token: string | null, body: unknown = {}) => call<T>('POST', path, token, body),
  put: <T>(path: string, token: string | null, body: unknown = {}) => call<T>('PUT', path, token, body),
  patch: <T>(path: string, token: string | null, body: unknown = {}) => call<T>('PATCH', path, token, body),
  del: <T>(path: string, token: string | null) => call<T>('DELETE', path, token),

  /** Sends a file as the raw request body (see server attachments.routes.ts). */
  async upload<T>(path: string, token: string | null, file: File): Promise<T> {
    let response: Response;
    try {
      response = await fetch(`${API_BASE_URL}${path}`, {
        method: 'POST',
        headers: { 'Content-Type': file.type || 'application/octet-stream', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
        body: file,
      });
    } catch {
      throw new ApiError(0, OFFLINE_MESSAGE);
    }
    const payload = await response.json().catch(() => null);
    if (!response.ok || payload?.success === false) throw new ApiError(response.status, messageFor(response.status, payload?.message));
    return payload.data as T;
  },

  /** Fetches a file and hands it to the browser as a download. */
  async download(path: string, token: string | null, fileName: string): Promise<void> {
    let response: Response;
    try {
      response = await fetch(`${API_BASE_URL}${path}`, { headers: token ? { Authorization: `Bearer ${token}` } : {} });
    } catch {
      throw new ApiError(0, OFFLINE_MESSAGE);
    }
    if (!response.ok) {
      const payload = await response.json().catch(() => null);
      throw new ApiError(response.status, messageFor(response.status, payload?.message));
    }
    const blob = await response.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  },
};
