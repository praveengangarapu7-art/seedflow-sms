import { api, qs } from '../liveApi';
import type { ApprovalRequest } from './foundations';

/** Client for server/src/modules/warehouse. Numbers are numbers; DATE columns are 'YYYY-MM-DD'. */

export type SaleStatus = 'sellable' | 'retest_due' | 'expired' | 'untested' | 'failed' | 'on_hold';
export const SALE_STATUS_LABEL: Record<SaleStatus, string> = {
  sellable: 'Saleable',
  retest_due: 'Retest due',
  expired: 'Validity expired',
  untested: 'Not tested',
  failed: 'Failed germination',
  on_hold: 'On quality hold',
};

export interface SaleInfo {
  status: SaleStatus;
  tested_on: string | null;
  germination_pct: number | null;
  valid_until: string | null;
  days_to_expiry: number | null;
  hold_reason: string | null;
}

export interface Warehouse {
  id: string;
  code: string;
  name: string;
  address: string | null;
  licence_number: string | null;
  status: 'active' | 'inactive';
  locations: number;
  stock_kg: number;
}

export interface Location {
  id: string;
  warehouse_id: string;
  warehouse_code: string;
  code: string;
  zone: string;
  location_type: 'bin' | 'floor' | 'cold_room' | 'quarantine' | 'dispatch_bay';
  capacity_kg: number | null;
  status: 'active' | 'blocked' | 'inactive';
  stock_kg: number;
  lots: number;
  utilisation_pct: number | null;
}

export interface StockRow extends SaleInfo {
  seed_lot_id: string;
  lot_code: string;
  crop: string;
  variety: string;
  stage: string;
  production_date: string;
  is_treated: boolean;
  quantity_kg: number;
  bags: number | null;
  locations: { location_id: string; location_code: string; zone: string; location_type: string; warehouse_code: string; quantity_kg: number }[];
}

export interface Movement {
  id: string;
  seed_lot_id: string;
  lot_code: string;
  variety: string;
  location_id: string;
  location_code: string;
  warehouse_code: string;
  quantity_kg: number;
  bags: number | null;
  move_type: string;
  reference_type: string | null;
  reference_id: string | null;
  reference_code: string | null;
  reason: string | null;
  created_by: string;
  created_at: string;
}

export interface LotStock {
  lot: { id: string; lot_code: string; crop: string; variety: string; stage: string; quantity_total: number; production_date: string; notes: string | null };
  sale: SaleInfo;
  locations: { location_id: string; quantity_kg: number; bags: number | null; location_code: string; zone: string; location_type: string; warehouse_code: string }[];
  moves: Movement[];
  externalTests: { id: string; tested_on: string; germination_pct: number; min_germination_pct: number; passed: boolean; laboratory: string; report_number: string | null; valid_until: string; recorded_by: string }[];
}

export const fetchWarehouses = (t: string) => api.get<Warehouse[]>('/warehouse/warehouses', t);
export const createWarehouse = (t: string, input: { code: string; name: string; address?: string; licenceNumber?: string }) => api.post<Warehouse>('/warehouse/warehouses', t, input);
export const fetchLocations = (t: string, warehouseId?: string) => api.get<Location[]>(`/warehouse/locations${qs({ warehouseId })}`, t);
export const createLocation = (t: string, input: { warehouseId: string; code: string; zone: string; locationType?: string; capacityKg?: number }) => api.post<Location>('/warehouse/locations', t, input);
export const setLocationStatus = (t: string, id: string, status: string) => api.post<Location>(`/warehouse/locations/${id}/status`, t, { status });

export const fetchStock = (t: string, f: { warehouseId?: string; q?: string; status?: string } = {}) => api.get<StockRow[]>(`/warehouse/stock${qs(f)}`, t);
export const fetchLotStock = (t: string, lotId: string) => api.get<LotStock>(`/warehouse/stock/lots/${lotId}`, t);
export const fetchMovements = (t: string, f: { lotId?: string; type?: string; limit?: number } = {}) => api.get<Movement[]>(`/warehouse/movements${qs(f)}`, t);
export const receiveStock = (t: string, input: { seedLotId: string; locationId: string; quantityKg: number; bags?: number; sourceType: string; sourceReference?: string }) =>
  api.post<{ id: string; receipt_number: string; quantity_kg: number }>('/warehouse/receipts', t, input);
export const transferStock = (t: string, input: { seedLotId: string; fromLocationId: string; toLocationId: string; quantityKg: number; reason?: string }) =>
  api.post<{ reference: string }>('/warehouse/transfers', t, input);
export const recordLotTest = (
  t: string,
  input: { seedLotId: string; testedOn: string; germinationPct: number; minGerminationPct: number; laboratory: string; reportNumber?: string; validityMonths?: number },
) => api.post('/warehouse/lot-tests', t, input);

export const ADJUSTMENT_REASONS = [
  { value: 'damage', label: 'Damage' },
  { value: 'pest', label: 'Pest' },
  { value: 'moisture_loss', label: 'Moisture loss' },
  { value: 'sampling', label: 'Sampling' },
  { value: 'data_correction', label: 'Data correction' },
  { value: 'count_variance', label: 'Count variance' },
  { value: 'other', label: 'Other' },
] as const;

export interface Adjustment {
  id: string;
  adjustment_number: string;
  seed_lot_id: string;
  lot_code: string;
  variety: string;
  location_id: string;
  location_code: string;
  quantity_change: number;
  reason: string;
  details: string;
  count_id: string | null;
  count_number: string | null;
  status: 'pending_approval' | 'approved' | 'rejected';
  rejection_reason: string | null;
  created_by: string;
  decided_at: string | null;
  created_at: string;
}

export const fetchAdjustments = (t: string, status?: string) => api.get<Adjustment[]>(`/warehouse/adjustments${qs({ status })}`, t);
export const proposeAdjustment = (t: string, input: { seedLotId: string; locationId: string; quantityChange: number; reason: string; details: string }) => api.post<Adjustment>('/warehouse/adjustments', t, input);

export interface CountSheet {
  id: string;
  count_number: string;
  warehouse_id: string;
  warehouse_code: string;
  zone: string | null;
  status: 'open' | 'submitted' | 'cancelled';
  scheduled_for: string;
  created_by: string;
  submitted_by: string | null;
  submitted_at: string | null;
  created_at: string;
  lines?: { id: string; seed_lot_id: string; lot_code: string; variety: string; location_id: string; location_code: string; zone: string; system_kg: number; counted_kg: number | null; counted_by: string | null; counted_at: string | null }[];
  adjustments?: { id: string; adjustment_number: string; status: string; quantity_change: number; seed_lot_id: string }[];
  counted?: number;
  line_count?: number;
}

export const fetchCounts = (t: string) => api.get<CountSheet[]>('/warehouse/counts', t);
export const fetchCount = (t: string, id: string) => api.get<CountSheet>(`/warehouse/counts/${id}`, t);
export const createCount = (t: string, input: { warehouseId: string; zone?: string; scheduledFor?: string }) => api.post<CountSheet>('/warehouse/counts', t, input);
export const saveCountLines = (t: string, id: string, lines: { lineId: string; countedKg: number }[]) => api.put<CountSheet>(`/warehouse/counts/${id}/lines`, t, { lines });
export const submitCount = (t: string, id: string) => api.post<{ count: CountSheet; adjustments: Adjustment[] }>(`/warehouse/counts/${id}/submit`, t);

export interface DispatchLine {
  id: string;
  seed_lot_id: string;
  lot_code: string;
  crop: string;
  variety: string;
  stage: string;
  location_id: string;
  location_code: string;
  quantity_kg: number;
  bags: number | null;
  is_treated: boolean;
  sale?: SaleInfo;
}

export interface Dispatch {
  id: string;
  dispatch_number: string;
  dealer_id: string;
  dealer_name: string;
  dealer_code: string;
  dealer_licence?: string | null;
  dealer_licence_valid_until?: string | null;
  dealer_town?: string | null;
  dealer_district?: string | null;
  dealer_phone?: string | null;
  warehouse_id: string;
  warehouse_code: string;
  warehouse_name?: string;
  requested_date: string;
  status: 'draft' | 'pending_approval' | 'approved' | 'dispatched' | 'delivered' | 'cancelled' | 'rejected';
  transporter_id: string | null;
  transporter_name?: string | null;
  vehicle_number: string | null;
  lr_number: string | null;
  eway_bill_number: string | null;
  invoice_reference: string | null;
  notes: string | null;
  rejection_reason: string | null;
  cancel_reason: string | null;
  dispatched_at: string | null;
  dispatched_by: string | null;
  delivered_at: string | null;
  received_by_name: string | null;
  created_by: string;
  created_at: string;
  total_kg?: number;
  lots?: string;
  lines?: DispatchLine[];
  approvals?: ApprovalRequest[];
  warnings?: string[];
}

export const fetchDispatches = (t: string, f: { status?: string; dealerId?: string } = {}) => api.get<Dispatch[]>(`/warehouse/dispatches${qs(f)}`, t);
export const fetchDispatch = (t: string, id: string) => api.get<Dispatch>(`/warehouse/dispatches/${id}`, t);
export const createDispatch = (
  t: string,
  input: { dealerId: string; warehouseId: string; requestedDate: string; transporterId?: string; invoiceReference?: string; notes?: string; lines: { seedLotId: string; locationId: string; quantityKg: number; bags?: number }[] },
) => api.post<Dispatch>('/warehouse/dispatches', t, input);
export const submitDispatch = (t: string, id: string) => api.post<Dispatch>(`/warehouse/dispatches/${id}/submit`, t);
export const shipDispatch = (t: string, id: string, input: { vehicleNumber: string; lrNumber?: string; ewayBillNumber?: string; invoiceReference?: string }) => api.post<Dispatch>(`/warehouse/dispatches/${id}/ship`, t, input);
export const confirmDelivery = (t: string, id: string, receivedByName: string) => api.post<Dispatch>(`/warehouse/dispatches/${id}/deliver`, t, { receivedByName });
export const cancelDispatch = (t: string, id: string, reason: string) => api.post<Dispatch>(`/warehouse/dispatches/${id}/cancel`, t, { reason });

export interface LotRecipient {
  dealer_id: string;
  party_code: string;
  name: string;
  phone: string | null;
  village: string | null;
  district: string | null;
  preferred_language: string;
  dispatched_kg: number;
  returned_kg: number;
  last_dispatched_at: string;
  dispatches: string;
}
export const fetchLotRecipients = (t: string, lotId: string) => api.get<LotRecipient[]>(`/warehouse/lots/${lotId}/recipients`, t);

export const RETURN_REASONS = [
  { value: 'damaged', label: 'Damaged in transit' },
  { value: 'expired', label: 'Validity expired' },
  { value: 'unsold', label: 'Unsold at season end' },
  { value: 'quality_complaint', label: 'Quality complaint' },
  { value: 'wrong_supply', label: 'Wrong variety / supply' },
] as const;

export interface StockReturn {
  id: string;
  return_number: string;
  dealer_id: string;
  dealer_name: string;
  dealer_code?: string;
  dispatch_id: string | null;
  dispatch_number: string | null;
  seed_lot_id: string;
  lot_code: string;
  crop?: string;
  variety: string;
  quarantine_location_id: string;
  quarantine_code?: string;
  quantity_kg: number;
  reason: string;
  details: string | null;
  status: 'quarantined' | 'inspected' | 'restocked' | 'retest' | 'destroyed';
  inspection_id: string | null;
  inspection_code: string | null;
  inspection_result: string | null;
  inspection_decision?: string | null;
  complaint_id: string | null;
  complaint_code: string | null;
  disposition_note: string | null;
  credit_note_amount: number | null;
  decided_by: string | null;
  decided_at: string | null;
  created_by: string;
  created_at: string;
}

export const fetchReturns = (t: string, status?: string) => api.get<StockReturn[]>(`/warehouse/returns${qs({ status })}`, t);
export const fetchReturn = (t: string, id: string) => api.get<StockReturn>(`/warehouse/returns/${id}`, t);
export const logReturn = (
  t: string,
  input: { dealerId: string; dispatchId?: string; seedLotId: string; quarantineLocationId: string; quantityKg: number; reason: string; details?: string; complaintSeverity?: string },
) => api.post<StockReturn>('/warehouse/returns', t, input);
export const decideReturn = (t: string, id: string, input: { disposition: 'restock' | 'retest' | 'destroy'; note: string; toLocationId?: string; creditNoteAmount?: number }) =>
  api.post<StockReturn>(`/warehouse/returns/${id}/decide`, t, input);

export interface Sensor {
  id: string;
  code: string;
  location_id: string;
  location_code: string;
  zone: string;
  warehouse_code: string;
  sensor_type: 'temperature' | 'humidity' | 'co2' | 'phosphine';
  unit: string;
  min_value: number | null;
  max_value: number | null;
  status: 'active' | 'inactive';
  last_value: number | null;
  last_reading_at: string | null;
  stale: boolean;
  open_breach_id: string | null;
  breach_started_at: string | null;
  breach_worst: number | null;
  breach_ncr_code: string | null;
  breach_ncr_id: string | null;
}

export interface SensorHistory {
  readings: { value: number; recorded_at: string; source: string }[];
  breaches: { id: string; started_at: string; ended_at: string | null; worst_value: number; ncr_id: string | null; ncr_code: string | null; resolved_by: string | null; resolution_note: string | null }[];
}

export const fetchSensors = (t: string) => api.get<Sensor[]>('/warehouse/sensors', t);
export const fetchSensorHistory = (t: string, id: string, hours = 72) => api.get<SensorHistory>(`/warehouse/sensors/${id}/history${qs({ hours })}`, t);
export const createSensor = (t: string, input: { code: string; locationId: string; sensorType: string; unit: string; minValue?: number; maxValue?: number }) =>
  api.post<{ sensor: Sensor; deviceKey: string }>('/warehouse/sensors', t, input);
export const updateSensorThresholds = (t: string, id: string, input: { minValue?: number; maxValue?: number }) => api.patch(`/warehouse/sensors/${id}`, t, input);
export const recordSensorReading = (t: string, id: string, value: number) => api.post<{ value: number; outOfRange: boolean }>(`/warehouse/sensors/${id}/readings`, t, { value });
export const resolveBreach = (t: string, id: string, note: string) => api.post(`/warehouse/breaches/${id}/resolve`, t, { note });

export interface WarehouseDashboardData {
  counts: {
    stock_kg: number;
    dispatches_pending: number;
    dispatches_to_ship: number;
    in_transit: number;
    returns_open: number;
    adjustments_pending: number;
    open_breaches: number;
    counts_open: number;
  };
  byStatus: Partial<Record<SaleStatus, { lots: number; kg: number }>>;
  expiring: (SaleInfo & { id: string; lot_code: string; variety: string })[];
}

export const fetchWarehouseDashboard = (t: string) => api.get<WarehouseDashboardData>('/warehouse/dashboard', t);
