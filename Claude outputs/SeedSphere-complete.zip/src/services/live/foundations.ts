import { api, qs } from '../liveApi';

// ------------------------------------------------------------------ parties

export const PARTY_TYPES = [
  { value: 'supplier', label: 'Supplier' },
  { value: 'contract_grower', label: 'Contract grower' },
  { value: 'dealer', label: 'Dealer' },
  { value: 'distributor', label: 'Distributor' },
  { value: 'farmer', label: 'Farmer' },
  { value: 'transporter', label: 'Transporter' },
  { value: 'customer', label: 'Customer' },
  { value: 'service_provider', label: 'Service provider' },
] as const;
export type PartyType = (typeof PARTY_TYPES)[number]['value'];

export const LANGUAGES = [
  { value: 'en', label: 'English' },
  { value: 'hi', label: 'Hindi' },
  { value: 'te', label: 'Telugu' },
  { value: 'ta', label: 'Tamil' },
  { value: 'kn', label: 'Kannada' },
  { value: 'mr', label: 'Marathi' },
  { value: 'gu', label: 'Gujarati' },
  { value: 'pa', label: 'Punjabi' },
  { value: 'bn', label: 'Bengali' },
  { value: 'or', label: 'Odia' },
];

export interface Party {
  id: string;
  party_code: string;
  party_type: PartyType;
  name: string;
  contact_person: string | null;
  phone: string | null;
  email: string | null;
  preferred_language: string;
  address_line: string | null;
  village: string | null;
  district: string | null;
  state: string | null;
  pincode: string | null;
  gstin: string | null;
  pan: string | null;
  bank_account_name: string | null;
  bank_account_number: string | null;
  bank_ifsc: string | null;
  licence_number: string | null;
  licence_valid_until: string | null;
  licence_expired: boolean | null;
  category: string | null;
  status: 'pending_approval' | 'active' | 'suspended' | 'blacklisted';
  status_reason: string | null;
  approved_by: string | null;
  approved_at: string | null;
  notes: string | null;
  created_by: string;
  created_at: string;
  updated_at: string;
}

export interface PartyInput {
  partyType?: PartyType;
  name?: string;
  contactPerson?: string;
  phone?: string;
  email?: string;
  preferredLanguage?: string;
  addressLine?: string;
  village?: string;
  district?: string;
  state?: string;
  pincode?: string;
  gstin?: string;
  pan?: string;
  bankAccountName?: string;
  bankAccountNumber?: string;
  bankIfsc?: string;
  licenceNumber?: string;
  licenceValidUntil?: string;
  category?: string;
  notes?: string;
}

export const partyTypeLabel = (t: string) => PARTY_TYPES.find((p) => p.value === t)?.label ?? t;

export const fetchParties = (token: string, f: { type?: string; status?: string; q?: string } = {}) => api.get<Party[]>(`/parties${qs(f)}`, token);
export const fetchParty = (token: string, id: string) => api.get<{ party: Party; history: { action: string; performed_by: string; created_at: string }[] }>(`/parties/${id}`, token);
export const fetchPartyAlerts = (token: string) =>
  api.get<{ licences: (Pick<Party, 'id' | 'party_code' | 'party_type' | 'name' | 'licence_number' | 'licence_valid_until'> & { expired: boolean })[]; pendingApproval: number }>('/parties/alerts', token);
export const createParty = (token: string, input: PartyInput) => api.post<Party>('/parties', token, input);
export const updateParty = (token: string, id: string, input: PartyInput) => api.patch<Party>(`/parties/${id}`, token, input);
export const approveParty = (token: string, id: string) => api.post<Party>(`/parties/${id}/approve`, token);
export const suspendParty = (token: string, id: string, reason: string, blacklist = false) => api.post<Party>(`/parties/${id}/suspend`, token, { reason, blacklist });
export const reactivateParty = (token: string, id: string) => api.post<Party>(`/parties/${id}/reactivate`, token);

// -------------------------------------------------------------- attachments

export interface Attachment {
  id: string;
  entity_type: string;
  entity_id: string;
  file_name: string;
  content_type: string;
  size_bytes: number;
  sha256: string;
  description: string | null;
  uploaded_by: string;
  uploaded_at: string;
}

export const ACCEPTED_FILE_TYPES = '.pdf,.png,.jpg,.jpeg,.webp,.csv,.txt,.xlsx,.docx';

export const fetchAttachments = (token: string, entityType: string, entityId: string) => api.get<Attachment[]>(`/attachments${qs({ entityType, entityId })}`, token);
export const uploadAttachment = (token: string, entityType: string, entityId: string, file: File, description?: string) =>
  api.upload<Attachment>(`/attachments${qs({ entityType, entityId, fileName: file.name, description })}`, token, file);
export const downloadAttachment = (token: string, a: Attachment) => api.download(`/attachments/${a.id}/download`, token, a.file_name);
export const deleteAttachment = (token: string, id: string) => api.del<{ deleted: boolean }>(`/attachments/${id}`, token);

// ---------------------------------------------------------------- approvals

export interface ApprovalStep {
  id: string;
  step_order: number;
  step_name: string;
  required_permission: string;
  status: 'waiting' | 'pending' | 'approved' | 'rejected' | 'cancelled';
  decided_by: string | null;
  decided_at: string | null;
  comment: string | null;
}

export interface ApprovalRequest {
  id: string;
  entity_type: string;
  entity_id: string;
  entity_code: string;
  title: string;
  amount: string | null;
  status: 'pending' | 'approved' | 'rejected' | 'withdrawn';
  requested_by: string;
  requested_at: string;
  decided_at: string | null;
  steps?: ApprovalStep[];
}

export interface InboxItem {
  id: string;
  entity_type: string;
  entity_id: string;
  entity_code: string;
  title: string;
  amount: string | null;
  requested_by: string;
  requested_at: string;
  step_name: string;
  required_permission: string;
  step_order: number;
  total_steps: number;
}

export interface ApprovalRule {
  id: string;
  entity_type: string;
  step_order: number;
  step_name: string;
  required_permission: string;
  min_amount: string;
  is_active: boolean;
  updated_by: string | null;
  updated_at: string;
}

export const ENTITY_LABELS: Record<string, string> = {
  purchase_requisition: 'Purchase requisition',
  purchase_order: 'Purchase order',
  invoice_payment: 'Invoice payment',
  grower_agreement: 'Grower agreement',
  grower_settlement: 'Grower payment',
  processing_recipe: 'Processing recipe',
  stock_adjustment: 'Stock adjustment',
  dispatch_order: 'Dispatch order',
};

/** Where each approvable record opens in the app. */
export function entityPath(entityType: string, entityId: string): string | null {
  switch (entityType) {
    case 'purchase_requisition':
      return `/procurement/requisitions/${entityId}`;
    case 'purchase_order':
      return `/procurement/orders/${entityId}`;
    case 'invoice_payment':
      return `/procurement/invoices/${entityId}`;
    case 'grower_agreement':
      return `/procurement/growers/agreements/${entityId}`;
    case 'grower_settlement':
      return `/procurement/growers/settlements/${entityId}`;
    case 'processing_recipe':
      return `/processing/recipes/${entityId}`;
    case 'stock_adjustment':
      return `/warehouse/adjustments`;
    case 'dispatch_order':
      return `/warehouse/outbound/${entityId}`;
    default:
      return null;
  }
}

export const fetchInbox = (token: string) => api.get<InboxItem[]>('/approvals/inbox', token);
export const fetchApprovalRequests = (token: string, f: { status?: string; entityType?: string; mine?: boolean } = {}) =>
  api.get<ApprovalRequest[]>(`/approvals/requests${qs(f)}`, token);
export const fetchEntityApprovals = (token: string, entityType: string, entityId: string) => api.get<ApprovalRequest[]>(`/approvals/entity/${entityType}/${entityId}`, token);
export const decideApproval = (token: string, requestId: string, decision: 'approve' | 'reject', comment?: string) =>
  api.post<ApprovalRequest>(`/approvals/requests/${requestId}/decide`, token, { decision, comment });
export const fetchApprovalRules = (token: string) => api.get<ApprovalRule[]>('/approvals/rules', token);
export const updateApprovalRule = (token: string, id: string, input: { minAmount?: number; isActive?: boolean }) => api.patch<ApprovalRule>(`/approvals/rules/${id}`, token, input);

// -------------------------------------------------------------- inspections

export const INSPECTION_TYPES = [
  { value: 'procurement_receipt', label: 'Procurement receipt' },
  { value: 'warehouse_receipt', label: 'Warehouse receipt' },
  { value: 'warehouse_return', label: 'Returned stock' },
  { value: 'storage_condition', label: 'Storage condition' },
  { value: 'processing_pre', label: 'Processing — pre' },
  { value: 'processing_in_process', label: 'Processing — in-process' },
  { value: 'processing_final', label: 'Processing — final' },
  { value: 'field', label: 'Seed production field' },
  { value: 'trial_integrity', label: 'Trial integrity' },
  { value: 'dealer_audit', label: 'Dealer audit' },
  { value: 'other', label: 'Other' },
] as const;
export const inspectionTypeLabel = (t: string) => INSPECTION_TYPES.find((x) => x.value === t)?.label ?? t;

export interface TemplateItem {
  id: string;
  seq: number;
  label: string;
  item_type: 'numeric' | 'pass_fail' | 'text';
  unit: string | null;
  min_value: string | null;
  max_value: string | null;
  is_required: boolean;
  is_critical: boolean;
  guidance: string | null;
}

export interface InspectionTemplate {
  id: string;
  template_code: string;
  name: string;
  inspection_type: string;
  crop: string | null;
  version: number;
  status: 'draft' | 'active' | 'retired';
  description: string | null;
  created_by: string;
  activated_by: string | null;
  activated_at: string | null;
  created_at: string;
  item_count?: number;
  critical_count?: number;
  items?: TemplateItem[];
}

export interface TemplateItemInput {
  label: string;
  itemType: 'numeric' | 'pass_fail' | 'text';
  unit?: string;
  minValue?: number;
  maxValue?: number;
  isRequired?: boolean;
  isCritical?: boolean;
  guidance?: string;
}

export interface InspectionResult {
  id: string;
  template_item_id: string;
  seq: number;
  label: string;
  item_type: 'numeric' | 'pass_fail' | 'text';
  unit: string | null;
  min_value: string | null;
  max_value: string | null;
  is_critical: boolean;
  is_required: boolean;
  guidance: string | null;
  numeric_value: string | null;
  bool_value: boolean | null;
  text_value: string | null;
  passed: boolean | null;
  notes: string | null;
}

export interface Inspection {
  id: string;
  inspection_code: string;
  template_id: string;
  template_name: string;
  template_code?: string;
  template_version: number;
  inspection_type: string;
  subject_type: string;
  subject_id: string | null;
  subject_label: string;
  seed_lot_id: string | null;
  lot_code: string | null;
  location_text: string | null;
  latitude: string | null;
  longitude: string | null;
  inspector_email: string;
  status: 'in_progress' | 'submitted';
  result: 'pass' | 'conditional' | 'fail' | null;
  decision: 'accept' | 'partial_accept' | 'reject' | 'hold' | 'rework' | null;
  accepted_quantity: string | null;
  decision_notes: string | null;
  ncr_id: string | null;
  ncr_code: string | null;
  ncr_status?: string | null;
  failed_checks?: number;
  created_at: string;
  submitted_at: string | null;
  results?: InspectionResult[];
  attachment_count?: number;
}

export const DECISIONS = [
  { value: 'accept', label: 'Accept' },
  { value: 'partial_accept', label: 'Partial accept' },
  { value: 'reject', label: 'Reject' },
  { value: 'hold', label: 'Hold (quality hold on the lot)' },
  { value: 'rework', label: 'Rework' },
] as const;

export const fetchTemplates = (token: string, f: { type?: string; status?: string } = {}) => api.get<InspectionTemplate[]>(`/inspections/templates${qs(f)}`, token);
export const fetchTemplate = (token: string, id: string) => api.get<InspectionTemplate>(`/inspections/templates/${id}`, token);
export const createTemplate = (token: string, input: { name: string; inspectionType: string; crop?: string; description?: string; items: TemplateItemInput[] }) =>
  api.post<InspectionTemplate>('/inspections/templates', token, input);
export const reviseTemplate = (token: string, id: string, input: { items?: TemplateItemInput[]; description?: string } = {}) => api.post<InspectionTemplate>(`/inspections/templates/${id}/revise`, token, input);
export const activateTemplate = (token: string, id: string) => api.post<InspectionTemplate>(`/inspections/templates/${id}/activate`, token);
export const retireTemplate = (token: string, id: string) => api.post<InspectionTemplate>(`/inspections/templates/${id}/retire`, token);

export const fetchInspections = (
  token: string,
  f: { type?: string; status?: string; result?: string; subjectType?: string; subjectId?: string; seedLotId?: string; mine?: boolean } = {},
) => api.get<Inspection[]>(`/inspections${qs(f)}`, token);
export const fetchInspection = (token: string, id: string) => api.get<Inspection>(`/inspections/${id}`, token);
export const startInspection = (
  token: string,
  input: { templateId: string; subjectType: string; subjectId?: string; subjectLabel?: string; seedLotId?: string; locationText?: string; latitude?: number; longitude?: number },
) => api.post<Inspection>('/inspections', token, input);
export const saveInspectionResults = (
  token: string,
  id: string,
  results: { itemId: string; numericValue?: number | null; boolValue?: boolean | null; textValue?: string | null; notes?: string | null }[],
) => api.put<Inspection>(`/inspections/${id}/results`, token, { results });
export const submitInspection = (token: string, id: string, input: { decision: string; acceptedQuantity?: number; decisionNotes?: string }) =>
  api.post<Inspection>(`/inspections/${id}/submit`, token, input);

// ------------------------------------------------------------------ seed lots (lookup)

export interface LotOption {
  id: string;
  lot_code: string;
  crop: string;
  variety: string;
  stage: string;
  quantity_total: string;
  quantity_allocated: string;
  unit: string;
  production_date: string | null;
  on_hold: boolean;
}

export const fetchLotOptions = (token: string, q?: string, crop?: string) => api.get<LotOption[]>(`/lookups/lots${qs({ q, crop })}`, token);
export const fetchVarietyOptions = (token: string, crop?: string) => api.get<{ crop: string; variety: string }[]>(`/lookups/varieties${qs({ crop })}`, token);

/**
 * Link that opens a module's inspection list with the start dialog prefilled
 * for one subject — used by receipts, deliveries, intakes and batches.
 */
export function inspectionStartPath(
  basePath: string,
  p: { subjectType: string; subjectId: string; subjectLabel?: string; type?: string; template?: string; seedLotId?: string },
): string {
  const q = new URLSearchParams({ start: '1', subjectType: p.subjectType, subjectId: p.subjectId });
  if (p.subjectLabel) q.set('subjectLabel', p.subjectLabel);
  if (p.type) q.set('type', p.type);
  if (p.template) q.set('template', p.template);
  if (p.seedLotId) q.set('seedLotId', p.seedLotId);
  return `${basePath}?${q.toString()}`;
}
