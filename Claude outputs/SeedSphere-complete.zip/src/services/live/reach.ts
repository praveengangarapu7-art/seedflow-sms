import { api, qs } from '../liveApi';

/** Client for server/src/modules/reach — pack tags, the public pages, portals, indents and the message outbox. */

export type Verdict = 'genuine' | 'caution' | 'on_hold' | 'expired' | 'failed' | 'unverified' | 'void' | 'recalled' | 'not_found';

export interface VerifyResult {
  verdict: Verdict;
  message: string;
  tagCode: string;
  timesChecked?: number;
  product?: {
    company: string | null;
    crop: string;
    variety: string;
    seedClass: string;
    lotCode: string;
    packSizeKg: number;
    productionDate: string | null;
    germinationPct?: number | null;
    testedOn?: string | null;
    validUntil?: string | null;
  };
}

// ----- public (no token)
export const verifyTag = (code: string) => api.get<VerifyResult>(`/public/verify/${encodeURIComponent(code)}`, null);
export const COMPLAINT_TYPE_LABEL: Record<string, string> = {
  germination: 'Seeds did not sprout / poor germination',
  purity: 'Mixed or impure seed',
  disease: 'Disease or pest in the crop',
  packaging: 'Damaged or tampered packing',
  suspected_fake: 'I think the seed is fake',
  other: 'Something else',
};
export const submitFarmerComplaint = (input: { name: string; phone: string; village?: string; tagCode?: string; complaintType: string; description: string }) =>
  api.post<{ code: string; escalated: boolean; message: string }>('/public/complaints', null, input);
export const trackComplaint = (code: string, phone: string) =>
  api.get<{ code: string; status: string; statusLabel: string; receivedOn: string; resolvedAt: string | null; outcome: string | null }>(`/public/complaints/${encodeURIComponent(code)}${qs({ phone })}`, null);

// ----- tags (staff)
export interface TagLotSummary { seed_lot_id: string; lot_code: string; crop: string; variety: string; tags: number; tagged_kg: number; scans: number; quantity_total: number }
export interface SeedTag { id: string; tag_code: string; seed_lot_id: string; lot_code: string; crop: string; variety: string; pack_size_kg: number; status: 'active' | 'void'; void_reason: string | null; scan_count: number; first_scanned_at: string | null; last_scanned_at: string | null; created_at: string; created_by: string }
export interface ScanActivity { recent: { tag_code: string; result: string; scanned_at: string }[]; last30Days: Record<string, number>; suspicious: { tag_code: string; lot_code: string; scan_count: number; devices: number }[] }
export const fetchTagLots = (t: string) => api.get<TagLotSummary[]>('/reach/tags/lots', t);
export const fetchTags = (t: string, f: { lotId?: string; status?: string } = {}) => api.get<SeedTag[]>(`/reach/tags${qs(f)}`, t);
export const fetchScanActivity = (t: string) => api.get<ScanActivity>('/reach/tags/activity', t);
export const generateTags = (t: string, input: { seedLotId: string; count: number; packSizeKg: number }) =>
  api.post<{ seedLotId: string; lotCode: string; count: number; packSizeKg: number; tagCodes: string[] }>('/reach/tags', t, input);
export const voidTag = (t: string, code: string, reason: string) => api.post(`/reach/tags/${encodeURIComponent(code)}/void`, t, { reason });

// ----- dealer indents
export interface Indent { id: string; indent_number: string; dealer_id: string; dealer_name?: string; dealer_code?: string; dealer_district?: string | null; crop: string; variety: string | null; quantity_kg: number; needed_by: string; notes: string | null; status: 'submitted' | 'accepted' | 'rejected' | 'fulfilled' | 'cancelled'; decision_note: string | null; decided_by: string | null; decided_at: string | null; dispatch_number?: string | null; created_at: string }
export const fetchIndents = (t: string, status?: string) => api.get<Indent[]>(`/reach/indents${qs({ status })}`, t);
export const decideIndent = (t: string, id: string, input: { decision: 'accept' | 'reject'; note?: string }) => api.post<Indent>(`/reach/indents/${id}/decide`, t, input);
export const fulfilIndent = (t: string, id: string) => api.post<Indent>(`/reach/indents/${id}/fulfilled`, t, {});

// ----- message outbox
export interface OutboxMessage { id: string; channel: 'sms' | 'whatsapp'; to_phone: string; party_name: string | null; party_code: string | null; template: string; language: string; body: string; status: 'queued' | 'sent' | 'failed' | 'cancelled'; attempts: number; last_error: string | null; related_type: string | null; created_at: string; sent_at: string | null }
export interface OutboxSummary { queued: number; sent: number; failed: number; cancelled: number; provider: string; templates: string[] }
export const fetchMessages = (t: string, status?: string) => api.get<OutboxMessage[]>(`/reach/messages${qs({ status })}`, t);
export const fetchOutboxSummary = (t: string) => api.get<OutboxSummary>('/reach/messages/summary', t);
export const flushOutbox = (t: string) => api.post<{ attempted: number; sent: number; failed: number }>('/reach/messages/flush', t, {});
export const sendMessage = (t: string, input: { partyId: string; text: string; channel?: 'sms' | 'whatsapp' }) => api.post('/reach/messages/send', t, input);
export const retryMessage = (t: string, id: string) => api.post(`/reach/messages/${id}/retry`, t, {});
export const cancelMessage = (t: string, id: string) => api.post(`/reach/messages/${id}/cancel`, t, {});

// ----- portals
export interface PartnerParty { id: string; party_code: string; party_type: string; name: string; contact_person: string | null; phone: string | null; village: string | null; district: string | null; status: string; licence_number: string | null; licence_valid_until: string | null }
export interface GrowerHome {
  party: PartnerParty;
  balance: number;
  avgDaysToPayment: number | null;
  agreements: { id: string; agreement_number: string; status: string; season: string; season_year: number; crop: string; variety: string; seed_class: string; area_acres: number; buyback_price_per_kg: number; expected_yield_kg: number; delivered_kg: number; balance: number; procurement_window_start: string; procurement_window_end: string }[];
  deliveries: { id: string; delivery_number: string; agreement_number: string; crop: string; variety: string; delivered_at: string; net_weight_kg: number | null; moisture_pct: number | null; purity_pct: number | null; status: string; payable_amount: number | null; inspection_code: string | null }[];
  settlements: { id: string; settlement_number: string; settlement_type: string; status: string; net_payable: number; paid_at: string | null; payment_reference: string | null }[];
  ledger: { id: string; entry_date: string; entry_type: string; description: string; amount: number; running_balance: number; agreement_number: string }[];
  windows: { agreement_number: string; crop: string; variety: string; procurement_window_start: string; procurement_window_end: string }[];
  messages: { id: string; channel: string; body: string; status: string; created_at: string }[];
}
export interface DealerHome {
  party: PartnerParty;
  licenceDaysLeft: number | null;
  dispatches: { id: string; dispatch_number: string; status: string; requested_date: string; total_kg: number; lots: string; vehicle_number: string | null; dispatched_at: string | null; delivered_at: string | null }[];
  indents: Indent[];
  returns: { return_number: string; status: string; quantity_kg: number; reason: string; created_at: string; lot_code: string }[];
  complaints: { complaint_code: string; title: string; status: string; severity: string; received_date: string }[];
  notices: { id: string; channel: string; template: string; body: string; status: string; created_at: string }[];
}
export interface DealerDispatchDetail {
  id: string; dispatch_number: string; status: string; requested_date: string; vehicle_number: string | null; lr_number: string | null; dispatched_at: string | null; delivered_at: string | null; received_by_name: string | null; transporter_name: string | null; tag_count: number;
  lines: { lot_code: string; crop: string; variety: string; stage: string; quantity_kg: number; bags: number | null; is_treated: boolean; germination_pct: number | null; valid_until: string | null }[];
}
export const fetchGrowerHome = (t: string) => api.get<GrowerHome>('/portal/grower', t);
export const fetchDealerHome = (t: string) => api.get<DealerHome>('/portal/dealer', t);
export const fetchDealerDispatch = (t: string, id: string) => api.get<DealerDispatchDetail>(`/portal/dealer/dispatches/${id}`, t);
export const confirmReceipt = (t: string, id: string, receivedByName?: string) => api.post(`/portal/dealer/dispatches/${id}/confirm-receipt`, t, { receivedByName });
export const raiseIndent = (t: string, input: { crop: string; variety?: string; quantityKg: number; neededBy: string; notes?: string }) => api.post<Indent>('/portal/dealer/indents', t, input);
export const cancelIndent = (t: string, id: string) => api.post(`/portal/dealer/indents/${id}/cancel`, t, {});
export const raiseDealerComplaint = (t: string, input: { seedLotId?: string; title: string; description: string; severity?: string }) => api.post('/portal/dealer/complaints', t, input);
