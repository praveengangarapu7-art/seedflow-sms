import { api, qs } from '../liveApi';
import type { ApprovalRequest } from './foundations';

/**
 * Client for server/src/modules/procurement. NUMERIC columns arrive as
 * numbers; DATE columns as 'YYYY-MM-DD' strings; timestamps as ISO strings.
 */

// ------------------------------------------------------------------- items

export const ITEM_CATEGORIES = ['seed', 'packaging', 'chemical', 'fertilizer', 'equipment', 'service', 'other'] as const;
export type ItemCategory = (typeof ITEM_CATEGORIES)[number];

export interface Item {
  id: string;
  item_code: string;
  name: string;
  category: ItemCategory;
  unit: string;
  crop: string | null;
  variety: string | null;
  hsn_code: string | null;
  gst_rate: number;
  requires_inspection: boolean;
  is_active: boolean;
  last_price: number | null;
}

export const fetchItems = (t: string, f: { category?: string; q?: string; includeInactive?: boolean } = {}) => api.get<Item[]>(`/procurement/items${qs(f)}`, t);
export const createItem = (t: string, input: { name: string; category: ItemCategory; unit: string; crop?: string; variety?: string; hsnCode?: string; gstRate?: number; requiresInspection?: boolean }) =>
  api.post<Item>('/procurement/items', t, input);
export const updateItem = (t: string, id: string, input: { gstRate?: number; isActive?: boolean; requiresInspection?: boolean; hsnCode?: string }) => api.patch<Item>(`/procurement/items/${id}`, t, input);

// ------------------------------------------------------------ cost centres

export interface CostCentre {
  id: string;
  code: string;
  name: string;
  fiscal_year: string;
  budget_amount: number;
  owner_email: string | null;
  committed: number;
  spent: number;
  remaining: number;
  utilisation_pct: number | null;
}

export const fetchCostCentres = (t: string, fiscalYear?: string) => api.get<CostCentre[]>(`/procurement/cost-centres${qs({ fiscalYear })}`, t);
export const createCostCentre = (t: string, input: { code: string; name: string; fiscalYear?: string; budgetAmount: number; ownerEmail?: string }) => api.post<CostCentre>('/procurement/cost-centres', t, input);
export const changeBudget = (t: string, id: string, budgetAmount: number, reason: string) => api.patch<CostCentre>(`/procurement/cost-centres/${id}`, t, { budgetAmount, reason });

// ------------------------------------------------------------ requisitions

export interface LineInput {
  itemId: string;
  quantity: number;
  unitPrice?: number;
  gstRate?: number;
  description?: string;
  requisitionLineId?: string;
}

export interface RequisitionLine {
  id: string;
  line_no: number;
  item_id: string;
  item_code: string;
  item_name: string;
  category: string;
  description: string | null;
  quantity: number;
  unit: string;
  estimated_unit_price: number;
  ordered_quantity: number;
}

export interface Requisition {
  id: string;
  pr_number: string;
  title: string;
  department: string;
  cost_centre_id: string | null;
  cost_centre_code: string | null;
  cost_centre_name?: string | null;
  needed_by: string | null;
  justification: string | null;
  status: 'draft' | 'pending_approval' | 'approved' | 'rejected' | 'cancelled' | 'ordered';
  estimated_total: number;
  source: string;
  source_ref: string | null;
  rejection_reason: string | null;
  requested_by: string;
  submitted_at: string | null;
  decided_at: string | null;
  created_at: string;
  line_count?: number;
  lines?: RequisitionLine[];
  orders?: { id: string; po_number: string; status: string; grand_total: number }[];
  approvals?: ApprovalRequest[];
}

export interface RequisitionInput {
  title: string;
  department: string;
  costCentreId?: string;
  neededBy?: string;
  justification?: string;
  lines: LineInput[];
}

export const fetchRequisitions = (t: string, f: { status?: string; mine?: boolean } = {}) => api.get<Requisition[]>(`/procurement/requisitions${qs(f)}`, t);
export const fetchRequisition = (t: string, id: string) => api.get<Requisition>(`/procurement/requisitions/${id}`, t);
export const createRequisition = (t: string, input: RequisitionInput) => api.post<Requisition>('/procurement/requisitions', t, input);
export const updateRequisition = (t: string, id: string, input: Partial<RequisitionInput>) => api.patch<Requisition>(`/procurement/requisitions/${id}`, t, input);
export const submitRequisition = (t: string, id: string) => api.post<Requisition>(`/procurement/requisitions/${id}/submit`, t);
export const cancelRequisition = (t: string, id: string, reason: string) => api.post<Requisition>(`/procurement/requisitions/${id}/cancel`, t, { reason });

export interface DemandSuggestion {
  id: string;
  po_number: string;
  crop: string;
  variety: string;
  quantity_requested: number;
  unit: string;
  status: string;
  expected_delivery_date: string | null;
  created_at: string;
  requisition_number: string | null;
}
export const fetchDemandSuggestions = (t: string) => api.get<DemandSuggestion[]>('/procurement/demand-suggestions', t);
export const convertDemandSuggestion = (t: string, input: { suggestionId: string; itemId: string; estimatedUnitPrice?: number; costCentreId?: string }) =>
  api.post<Requisition>('/procurement/demand-suggestions/convert', t, input);

// -------------------------------------------------------------------- RFQs

export interface RfqLine {
  id: string;
  line_no: number;
  item_id: string;
  item_code: string;
  item_name: string;
  quantity: number;
  unit: string;
  requisition_line_id: string | null;
}

export interface RfqQuote {
  id: string;
  supplier_id: string;
  supplier_name: string;
  supplier_code: string;
  quote_ref: string | null;
  valid_until: string | null;
  delivery_days: number | null;
  payment_terms_days: number | null;
  notes: string | null;
  subtotal: number;
  tax_total: number;
  total_amount: number;
  recorded_by: string;
  recorded_at: string;
  lines: { rfq_line_id: string; unit_price: number; gst_rate: number }[];
}

export interface Rfq {
  id: string;
  rfq_number: string;
  requisition_id: string | null;
  pr_number: string | null;
  title: string;
  due_date: string;
  status: 'open' | 'awarded' | 'cancelled';
  awarded_quote_id: string | null;
  award_reason: string | null;
  awarded_by: string | null;
  awarded_at: string | null;
  created_by: string;
  created_at: string;
  quote_count?: number;
  lowest_total?: number | null;
  lines?: RfqLine[];
  quotes?: RfqQuote[];
  order?: { id: string; po_number: string; status: string } | null;
}

export const fetchRfqs = (t: string, status?: string) => api.get<Rfq[]>(`/procurement/rfqs${qs({ status })}`, t);
export const fetchRfq = (t: string, id: string) => api.get<Rfq>(`/procurement/rfqs/${id}`, t);
export const createRfq = (t: string, input: { title: string; dueDate: string; requisitionId?: string; lines?: LineInput[] }) => api.post<Rfq>('/procurement/rfqs', t, input);
export const recordQuote = (
  t: string,
  rfqId: string,
  input: { supplierId: string; quoteRef?: string; validUntil?: string; deliveryDays?: number; paymentTermsDays?: number; notes?: string; lines: { rfqLineId: string; unitPrice: number; gstRate?: number }[] },
) => api.post<Rfq>(`/procurement/rfqs/${rfqId}/quotes`, t, input);
export const awardRfq = (t: string, rfqId: string, input: { quoteId: string; reason?: string; expectedDeliveryDate: string; deliveryAddress: string; costCentreId?: string }) =>
  api.post<{ rfq: Rfq; order: PurchaseOrder }>(`/procurement/rfqs/${rfqId}/award`, t, input);
export const cancelRfq = (t: string, rfqId: string, reason: string) => api.post<Rfq>(`/procurement/rfqs/${rfqId}/cancel`, t, { reason });

// --------------------------------------------------------- purchase orders

export type PoStatus = 'draft' | 'pending_approval' | 'approved' | 'sent' | 'partially_received' | 'received' | 'closed' | 'cancelled' | 'rejected';

export interface PoLine {
  id: string;
  line_no: number;
  item_id: string;
  item_code: string;
  item_name: string;
  category: string;
  requires_inspection: boolean;
  description: string | null;
  quantity: number;
  unit: string;
  unit_price: number;
  gst_rate: number;
  line_total: number;
  tax_amount: number;
  received_quantity: number;
  accepted_quantity: number;
  requisition_line_id: string | null;
}

export interface PurchaseOrder {
  id: string;
  po_number: string;
  supplier_id: string;
  supplier_name: string;
  supplier_code: string;
  supplier_phone?: string | null;
  supplier_email?: string | null;
  supplier_gstin?: string | null;
  requisition_id: string | null;
  pr_number?: string | null;
  rfq_id: string | null;
  rfq_number?: string | null;
  contract_id: string | null;
  contract_number?: string | null;
  cost_centre_id: string | null;
  cost_centre_code?: string | null;
  cost_centre_name?: string | null;
  order_date: string;
  expected_delivery_date: string;
  delivery_address: string;
  payment_terms_days: number;
  status: PoStatus;
  subtotal: number;
  tax_total: number;
  grand_total: number;
  budget_override_reason: string | null;
  amendment_no: number;
  notes: string | null;
  rejection_reason: string | null;
  cancel_reason: string | null;
  created_by: string;
  approved_at: string | null;
  sent_at: string | null;
  created_at: string;
  is_late?: boolean;
  received_fraction?: number;
  lines?: PoLine[];
  receipts?: { id: string; grn_number: string; status: string; received_at: string; net_weight_kg: number | null }[];
  invoices?: { id: string; invoice_number: string; supplier_invoice_no: string; status: string; match_status: string; total_amount: number; due_date: string }[];
  amendments?: { id: string; amendment_no: number; reason: string; amended_by: string; amended_at: string; before_state: unknown; after_state: unknown }[];
  approvals?: ApprovalRequest[];
}

export interface OrderInput {
  supplierId: string;
  requisitionId?: string;
  contractId?: string;
  costCentreId?: string;
  expectedDeliveryDate: string;
  deliveryAddress: string;
  paymentTermsDays?: number;
  notes?: string;
  lines: LineInput[];
}

export const fetchOrders = (t: string, f: { status?: string; supplierId?: string; q?: string } = {}) => api.get<PurchaseOrder[]>(`/procurement/orders${qs(f)}`, t);
export const fetchOrder = (t: string, id: string) => api.get<PurchaseOrder>(`/procurement/orders/${id}`, t);
export const createOrder = (t: string, input: OrderInput) => api.post<PurchaseOrder>('/procurement/orders', t, input);
export const updateOrder = (t: string, id: string, input: Partial<OrderInput>) => api.patch<PurchaseOrder>(`/procurement/orders/${id}`, t, input);
export const submitOrder = (t: string, id: string, budgetOverrideReason?: string) => api.post<PurchaseOrder>(`/procurement/orders/${id}/submit`, t, { budgetOverrideReason });
export const sendOrder = (t: string, id: string) => api.post<PurchaseOrder>(`/procurement/orders/${id}/send`, t);
export const amendOrder = (t: string, id: string, input: { reason: string; expectedDeliveryDate?: string; deliveryAddress?: string; paymentTermsDays?: number; lines?: LineInput[] }) =>
  api.post<PurchaseOrder>(`/procurement/orders/${id}/amend`, t, input);
export const cancelOrder = (t: string, id: string, reason: string) => api.post<PurchaseOrder>(`/procurement/orders/${id}/cancel`, t, { reason });
export const closeOrder = (t: string, id: string, reason?: string) => api.post<PurchaseOrder>(`/procurement/orders/${id}/close`, t, { reason });

// ------------------------------------------------------------ goods receipt

export interface GrnLine {
  id: string;
  po_line_id: string;
  line_no: number;
  item_code: string;
  item_name: string;
  requires_inspection: boolean;
  ordered_quantity: number;
  unit: string;
  unit_price: number;
  received_quantity: number;
  damaged_quantity: number;
  accepted_quantity: number | null;
  notes: string | null;
}

export interface GoodsReceipt {
  id: string;
  grn_number: string;
  po_id: string;
  po_number: string;
  supplier_id: string;
  supplier_name: string;
  supplier_code?: string;
  received_at: string;
  vehicle_number: string | null;
  driver_name: string | null;
  challan_number: string | null;
  weighbridge_ticket: string | null;
  gross_weight_kg: number | null;
  tare_weight_kg: number | null;
  net_weight_kg: number | null;
  status: 'awaiting_inspection' | 'accepted' | 'partially_accepted' | 'rejected' | 'on_hold';
  inspection_id: string | null;
  inspection_code: string | null;
  inspection_result: string | null;
  inspection_decision?: string | null;
  ncr_id?: string | null;
  ncr_code?: string | null;
  storage_location: string | null;
  notes: string | null;
  received_by: string;
  decided_at: string | null;
  expected_delivery_date?: string;
  received_total?: number;
  accepted_total?: number | null;
  lines?: GrnLine[];
  inspections?: { id: string; inspection_code: string; status: string; result: string | null; decision: string | null; created_at: string }[];
}

export const fetchReceipts = (t: string, f: { status?: string; poId?: string } = {}) => api.get<GoodsReceipt[]>(`/procurement/receipts${qs(f)}`, t);
export const fetchReceipt = (t: string, id: string) => api.get<GoodsReceipt>(`/procurement/receipts/${id}`, t);
export const createReceipt = (
  t: string,
  input: {
    poId: string;
    vehicleNumber?: string;
    driverName?: string;
    challanNumber?: string;
    weighbridgeTicket?: string;
    grossWeightKg?: number;
    tareWeightKg?: number;
    storageLocation?: string;
    notes?: string;
    lines: { poLineId: string; receivedQuantity: number; damagedQuantity?: number; notes?: string }[];
  },
) => api.post<GoodsReceipt>('/procurement/receipts', t, input);

// ----------------------------------------------------------------- invoices

export const PAYMENT_MODES = ['neft', 'rtgs', 'imps', 'upi', 'cheque'] as const;

export interface MatchLine {
  poLineId: string;
  lineNo: number;
  item: string;
  quantity: number;
  unitPrice: number;
  poUnitPrice: number;
  acceptedQuantity: number;
  previouslyInvoiced: number;
  available: number;
  quantityOk: boolean;
  priceOk: boolean;
  variance: number;
}

export interface Invoice {
  id: string;
  invoice_number: string;
  supplier_invoice_no: string;
  supplier_id: string;
  supplier_name: string;
  supplier_code?: string;
  po_id: string;
  po_number: string;
  invoice_date: string;
  due_date: string;
  subtotal: number;
  tax_total: number;
  total_amount: number;
  match_status: 'matched' | 'mismatch';
  match_details: { lines: MatchLine[]; statedTotal: number | null; computedTotal: number; totalOk: boolean };
  variance_amount: number;
  variance_reason: string | null;
  status: 'received' | 'pending_approval' | 'approved' | 'paid' | 'rejected' | 'cancelled';
  rejection_reason: string | null;
  payment_reference: string | null;
  payment_mode: string | null;
  paid_at: string | null;
  paid_by: string | null;
  created_by: string;
  created_at: string;
  is_overdue?: boolean;
  bank_account_name?: string | null;
  bank_ifsc?: string | null;
  bank_account_last4?: string | null;
  lines?: { id: string; po_line_id: string; line_no: number; item_name: string; unit: string; quantity: number; unit_price: number; gst_rate: number; line_total: number; tax_amount: number }[];
  approvals?: ApprovalRequest[];
}

export const fetchInvoices = (t: string, f: { status?: string; supplierId?: string; overdue?: boolean } = {}) => api.get<Invoice[]>(`/procurement/invoices${qs(f)}`, t);
export const fetchInvoice = (t: string, id: string) => api.get<Invoice>(`/procurement/invoices/${id}`, t);
export const createInvoice = (
  t: string,
  input: { poId: string; supplierInvoiceNo: string; invoiceDate: string; statedTotal?: number; lines: { poLineId: string; quantity: number; unitPrice: number; gstRate?: number }[] },
) => api.post<Invoice>('/procurement/invoices', t, input);
export const submitInvoice = (t: string, id: string, varianceReason?: string) => api.post<Invoice>(`/procurement/invoices/${id}/submit`, t, { varianceReason });
export const payInvoice = (t: string, id: string, paymentReference: string, paymentMode: string) => api.post<Invoice>(`/procurement/invoices/${id}/pay`, t, { paymentReference, paymentMode });
export const cancelInvoice = (t: string, id: string, reason: string) => api.post<Invoice>(`/procurement/invoices/${id}/cancel`, t, { reason });

// ---------------------------------------------------------------- contracts

export const CONTRACT_TYPES = [
  { value: 'rate_contract', label: 'Rate contract' },
  { value: 'supply_agreement', label: 'Supply agreement' },
  { value: 'service', label: 'Service' },
  { value: 'transport', label: 'Transport' },
] as const;

export interface Contract {
  id: string;
  contract_number: string;
  contract_type: string;
  supplier_id: string;
  supplier_name: string;
  supplier_code: string;
  title: string;
  start_date: string;
  end_date: string;
  renewal_notice_days: number;
  value_cap: number | null;
  payment_terms_days: number;
  terms: string | null;
  status: 'draft' | 'active' | 'terminated';
  termination_reason: string | null;
  created_by: string;
  activated_by: string | null;
  activated_at: string | null;
  ordered_value: number;
  days_left: number;
  lifecycle: 'draft' | 'terminated' | 'expired' | 'not_started' | 'renewal_due' | 'in_force';
  rates?: { id: string; item_id: string; item_code: string; item_name: string; unit: string; unit_price: number }[];
  orders?: { id: string; po_number: string; status: string; grand_total: number; order_date: string }[];
}

export const fetchContracts = (t: string, f: { supplierId?: string; status?: string } = {}) => api.get<Contract[]>(`/procurement/contracts${qs(f)}`, t);
export const fetchContract = (t: string, id: string) => api.get<Contract>(`/procurement/contracts/${id}`, t);
export const createContract = (
  t: string,
  input: { contractType: string; supplierId: string; title: string; startDate: string; endDate: string; renewalNoticeDays?: number; valueCap?: number; paymentTermsDays?: number; terms?: string; rates?: { itemId: string; unitPrice: number }[] },
) => api.post<Contract>('/procurement/contracts', t, input);
export const activateContract = (t: string, id: string) => api.post<Contract>(`/procurement/contracts/${id}/activate`, t);
export const terminateContract = (t: string, id: string, reason: string) => api.post<Contract>(`/procurement/contracts/${id}/terminate`, t, { reason });

// ------------------------------------------------------------------ growers

export interface GrowerAgreement {
  id: string;
  agreement_number: string;
  grower_id: string;
  grower_name: string;
  grower_code: string;
  grower_village?: string | null;
  grower_phone?: string | null;
  season: 'kharif' | 'rabi' | 'zaid';
  season_year: number;
  crop: string;
  variety: string;
  seed_class: 'Foundation' | 'Certified';
  plot_village: string;
  plot_survey_number: string | null;
  area_acres: number;
  latitude: number | null;
  longitude: number | null;
  parent_lot_id: string | null;
  parent_lot_code: string | null;
  parent_qty_issued_kg: number | null;
  expected_yield_kg: number;
  buyback_price_per_kg: number;
  advance_amount: number;
  input_cost_amount: number;
  standard_moisture_pct: number;
  reject_moisture_pct: number;
  min_purity_pct: number;
  purity_deduction_per_point_pct: number;
  reject_purity_pct: number;
  procurement_window_start: string;
  procurement_window_end: string;
  status: 'draft' | 'pending_approval' | 'active' | 'completed' | 'cancelled' | 'rejected';
  rejection_reason: string | null;
  created_by: string;
  approved_at: string | null;
  created_at: string;
  delivered_kg?: number;
  balance?: number;
  deliveries?: GrowerDelivery[];
  ledger?: LedgerEntry[];
  settlements?: Settlement[];
  approvals?: ApprovalRequest[];
}

export interface AgreementInput {
  growerId: string;
  season: string;
  seasonYear: number;
  crop: string;
  variety: string;
  seedClass: string;
  plotVillage: string;
  plotSurveyNumber?: string;
  areaAcres: number;
  latitude?: number;
  longitude?: number;
  parentLotId?: string;
  parentQtyIssuedKg?: number;
  expectedYieldKg: number;
  buybackPricePerKg: number;
  advanceAmount?: number;
  inputCostAmount?: number;
  standardMoisturePct?: number;
  rejectMoisturePct?: number;
  minPurityPct?: number;
  purityDeductionPerPointPct?: number;
  rejectPurityPct?: number;
  procurementWindowStart: string;
  procurementWindowEnd: string;
}

export interface GrowerDelivery {
  id: string;
  delivery_number: string;
  agreement_id: string;
  agreement_number?: string;
  grower_id: string;
  grower_name?: string;
  crop?: string;
  variety?: string;
  seed_class?: string;
  delivered_at: string;
  vehicle_number: string | null;
  weighbridge_ticket: string | null;
  gross_weight_kg: number;
  tare_weight_kg: number;
  net_weight_kg: number;
  bags: number | null;
  status: 'awaiting_inspection' | 'accepted' | 'rejected' | 'on_hold';
  inspection_id: string | null;
  inspection_code: string | null;
  inspection_result?: string | null;
  moisture_pct: number | null;
  purity_pct: number | null;
  payable_weight_kg: number | null;
  price_per_kg: number | null;
  gross_value: number | null;
  quality_deduction: number | null;
  net_value: number | null;
  pricing_note: string | null;
  received_by: string;
  decided_at: string | null;
}

export interface LedgerEntry {
  id: string;
  grower_id: string;
  agreement_id: string;
  agreement_number: string;
  entry_date: string;
  entry_type: 'inputs' | 'advance' | 'delivery' | 'payment' | 'adjustment';
  description: string;
  amount: number;
  delivery_id: string | null;
  settlement_id: string | null;
  settled_by_id: string | null;
  settled_by_number: string | null;
  running_balance: number;
}

export interface Settlement {
  id: string;
  settlement_number: string;
  settlement_type: 'advance' | 'final';
  grower_id: string;
  grower_name?: string;
  grower_code?: string;
  agreement_id: string;
  agreement_number?: string;
  delivery_value: number;
  recoveries: number;
  net_payable: number;
  first_delivery_at: string | null;
  status: 'pending_approval' | 'approved' | 'paid' | 'rejected';
  rejection_reason: string | null;
  payment_reference: string | null;
  payment_mode: string | null;
  paid_at: string | null;
  paid_by: string | null;
  created_by: string;
  created_at: string;
  days_to_payment?: number | null;
  bank_account_name?: string | null;
  bank_ifsc?: string | null;
  bank_account_last4?: string | null;
  entries?: LedgerEntry[];
  approvals?: ApprovalRequest[];
}

export interface GrowerAccount {
  grower: { id: string; party_code: string; name: string; village: string | null; district: string | null; phone: string | null; preferred_language: string; status: string };
  balance: number;
  avgDaysToPayment: number | null;
  agreements: GrowerAgreement[];
  deliveries: GrowerDelivery[];
  settlements: Settlement[];
  ledger: LedgerEntry[];
}

export const fetchAgreements = (t: string, f: { status?: string; growerId?: string; season?: string } = {}) => api.get<GrowerAgreement[]>(`/procurement/growers/agreements${qs(f)}`, t);
export const fetchAgreement = (t: string, id: string) => api.get<GrowerAgreement>(`/procurement/growers/agreements/${id}`, t);
export const createAgreement = (t: string, input: AgreementInput) => api.post<GrowerAgreement>('/procurement/growers/agreements', t, input);
export const updateAgreement = (t: string, id: string, input: Partial<AgreementInput>) => api.patch<GrowerAgreement>(`/procurement/growers/agreements/${id}`, t, input);
export const submitAgreement = (t: string, id: string) => api.post<GrowerAgreement>(`/procurement/growers/agreements/${id}/submit`, t);
export const cancelAgreement = (t: string, id: string, reason: string) => api.post<GrowerAgreement>(`/procurement/growers/agreements/${id}/cancel`, t, { reason });
export const completeAgreement = (t: string, id: string) => api.post<GrowerAgreement>(`/procurement/growers/agreements/${id}/complete`, t);
export const fetchDeliveries = (t: string, f: { status?: string; growerId?: string } = {}) => api.get<GrowerDelivery[]>(`/procurement/growers/deliveries${qs(f)}`, t);
export const recordDelivery = (t: string, input: { agreementId: string; grossWeightKg: number; tareWeightKg: number; bags?: number; vehicleNumber?: string; weighbridgeTicket?: string }) =>
  api.post<GrowerDelivery>('/procurement/growers/deliveries', t, input);
export const fetchSettlements = (t: string, status?: string) => api.get<Settlement[]>(`/procurement/growers/settlements${qs({ status })}`, t);
export const fetchSettlement = (t: string, id: string) => api.get<Settlement>(`/procurement/growers/settlements/${id}`, t);
export const createSettlement = (t: string, agreementId: string) => api.post<Settlement>('/procurement/growers/settlements', t, { agreementId });
export const paySettlement = (t: string, id: string, paymentReference: string, paymentMode: string) => api.post<Settlement>(`/procurement/growers/settlements/${id}/pay`, t, { paymentReference, paymentMode });
export const fetchGrowerAccount = (t: string, growerId: string) => api.get<GrowerAccount>(`/procurement/growers/${growerId}/account`, t);

// ---------------------------------------------------------------- analytics

export interface ProcurementDashboardData {
  counts: {
    prs_pending: number;
    pos_pending: number;
    pos_open: number;
    pos_late: number;
    grns_awaiting_inspection: number;
    deliveries_awaiting_inspection: number;
    invoices_overdue: number;
    payable_now: number;
    invoices_mismatch: number;
    agreements_active: number;
    grower_payments_pending: number;
    grower_unsettled_value: number;
    avg_days_to_grower_payment: number | null;
  };
  recentOrders: { id: string; po_number: string; status: string; grand_total: number; order_date: string; supplier_name: string }[];
  statusMix: { status: string; n: number }[];
  contractAlerts: Contract[];
  spend: { month: string; ordered: number; paid: number; growerPaid: number }[];
}

export interface SpendAnalysis {
  byMonth: { month: string; ordered: number; paid: number; growerPaid: number }[];
  byCategory: { category: string; amount: number }[];
  bySupplier: { id: string; name: string; party_code: string; amount: number; orders: number }[];
  priceTrend: { item_id: string; name: string; unit: string; month: string; avg_price: number; min_price: number; max_price: number }[];
  costCentres: CostCentre[];
}

export interface SupplierScore {
  id: string;
  party_code: string;
  name: string;
  status: string;
  orders: number;
  order_value: number;
  receipts: number;
  on_time_pct: number | null;
  rejection_pct: number | null;
  price_variance_pct: number | null;
  ncrs: number;
  score: number | null;
}

export interface GrowerScore {
  id: string;
  party_code: string;
  name: string;
  village: string | null;
  agreements: number;
  acres: number;
  deliveries: number;
  accepted: number;
  rejected: number;
  accepted_kg: number;
  avg_moisture: number | null;
  avg_purity: number | null;
  balance: number;
  avg_days_to_payment: number | null;
}

export const fetchProcurementDashboard = (t: string) => api.get<ProcurementDashboardData>('/procurement/dashboard', t);
export const fetchSpendAnalysis = (t: string, months = 12) => api.get<SpendAnalysis>(`/procurement/analytics/spend${qs({ months })}`, t);
export const fetchSupplierScores = (t: string) => api.get<SupplierScore[]>('/procurement/analytics/suppliers', t);
export const fetchGrowerScores = (t: string) => api.get<GrowerScore[]>('/procurement/analytics/growers', t);
