import { api, qs } from '../liveApi';

/** Client for server/src/modules/rd — germplasm, programmes, nurseries, phenotyping, registrations, varieties. */
const R = '/rd';
export interface Accession { id: string; accession_code: string; accession_number: string | null; name: string; crop: string; species: string | null; accession_type: string; origin_state: string | null; origin_site: string | null; donor: string | null; custody: string | null; status: string; notes: string | null; trait_count?: number }
export interface Phenotype { id: string; trait: string; category: string; value_num: number | null; value_text: string | null; unit: string | null; method: string | null; measured_on: string; recorded_by: string; accession_id?: string; accession_code?: string; accession_name?: string; crop?: string }
export interface AccessionDetail extends Accession { phenotypes: Phenotype[]; programs: { id: string; program_code: string; name: string; status: string }[] }
export interface Program { id: string; program_code: string; name: string; crop: string; objective: string; description: string | null; status: string; lead_breeder: string; start_date: string; expected_end_date: string | null; budget_f: number | null; spent_f: number; current_stage: string | null; generation_count: number; male_name?: string | null; female_name?: string | null }
export interface Generation { id: string; stage: string; season: string; population_size: number; selections_retained: number; criteria: string | null; observations: string | null }
export interface ProgramDetail extends Program { generations: Generation[]; nurseries: { id: string; nursery_code: string; name: string; status: string; season: string }[] }
export interface Nursery { id: string; nursery_code: string; name: string; program_id: string | null; program_name: string | null; crop: string; season: string; location: string; area_f: number | null; status: string; sown_on: string | null; expected_harvest: string | null; harvested_on: string | null; note_count: number; latest_health: string | null }
export interface NurseryDetail extends Nursery { notes: { id: string; note_date: string; growth_stage: string | null; health: string; note: string; recorded_by: string }[] }
export interface Registration { id: string; reg_code: string; candidate_id: string; candidate_name: string; candidate_code: string; crop: string; stage: string; authority: string; reg_type: string; status: string; filed_on: string | null; reference_number: string | null; granted_on: string | null; valid_until: string | null; decision_note: string | null }
export interface VarietyRow { candidate_id: string; candidate_code: string; name: string; crop: string; stage: string; variety_id: string | null; spec_status: string | null; min_germination_pct: number | null; min_purity_pct: number | null; max_moisture_pct: number | null; recommended_regions: string | null; lots: number; registrations: { code: string; authority: string; status: string }[] | null }
export interface RdDashboard {
  accessions: { total: number; crops: number }; programs: { active: number; planning: number; budget: number; spent: number }; nurseries: { growing: number; overdue: number };
  trials: { running: number; awaiting_approval: number; completed: number }; pipeline: { stage: string; n: number }[]; registrations: { in_process: number; granted: number; expiring: number };
  recent: { kind: string; text: string; on_date: string }[];
}

export const fetchRdDashboard = (t: string) => api.get<RdDashboard>(`${R}/dashboard`, t);
export const fetchAccessions = (t: string, f: { crop?: string; q?: string } = {}) => api.get<Accession[]>(`${R}/accessions${qs(f)}`, t);
export const fetchAccession = (t: string, id: string) => api.get<AccessionDetail>(`${R}/accessions/${id}`, t);
export const createAccession = (t: string, b: unknown) => api.post<Accession>(`${R}/accessions`, t, b);
export const setAccessionStatus = (t: string, id: string, status: string) => api.patch<Accession>(`${R}/accessions/${id}/status`, t, { status });
export const fetchPhenotypes = (t: string, f: { crop?: string; trait?: string } = {}) => api.get<Phenotype[]>(`${R}/phenotypes${qs(f)}`, t);
export const recordPhenotype = (t: string, b: unknown) => api.post<Phenotype>(`${R}/phenotypes`, t, b);
export const fetchPrograms = (t: string) => api.get<Program[]>(`${R}/programs`, t);
export const fetchProgram = (t: string, id: string) => api.get<ProgramDetail>(`${R}/programs/${id}`, t);
export const createProgram = (t: string, b: unknown) => api.post<Program>(`${R}/programs`, t, b);
export const updateProgram = (t: string, id: string, b: unknown) => api.patch<Program>(`${R}/programs/${id}`, t, b);
export const addGeneration = (t: string, id: string, b: unknown) => api.post<Generation>(`${R}/programs/${id}/generations`, t, b);
export const fetchNurseries = (t: string) => api.get<Nursery[]>(`${R}/nurseries`, t);
export const fetchNursery = (t: string, id: string) => api.get<NurseryDetail>(`${R}/nurseries/${id}`, t);
export const createNursery = (t: string, b: unknown) => api.post<Nursery>(`${R}/nurseries`, t, b);
export const nurseryAction = (t: string, id: string, a: 'sow' | 'harvest' | 'abandon', b: unknown = {}) => api.post<Nursery>(`${R}/nurseries/${id}/${a}`, t, b);
export const addNurseryNote = (t: string, id: string, b: unknown) => api.post<unknown>(`${R}/nurseries/${id}/notes`, t, b);
export const fetchRegistrations = (t: string) => api.get<Registration[]>(`${R}/registrations`, t);
export const createRegistration = (t: string, b: unknown) => api.post<Registration>(`${R}/registrations`, t, b);
export const registrationAction = (t: string, id: string, a: 'file' | 'review' | 'grant' | 'reject' | 'withdraw', b: unknown = {}) => api.post<Registration>(`${R}/registrations/${id}/${a}`, t, b);
export const fetchRdVarieties = (t: string) => api.get<VarietyRow[]>(`${R}/varieties`, t);
export { fetchCandidates } from './assurance';

export interface WarehouseReports {
  monthly: { month: string; received: number; dispatched: number; returned: number }[];
  byCrop: { crop: string; kg: number; lots: number }[];
  expiry: { bucket: string; lots: number; kg: number }[];
  topDealers: { name: string; district: string | null; kg: number; dispatches: number }[];
  returnsByReason: { reason: string; n: number; kg: number }[];
  coverDays: number | null; onHandKg: number; dispatched90dKg: number;
}
export const fetchWarehouseReports = (t: string, months = 12) => api.get<WarehouseReports>(`/warehouse/reports${qs({ months })}`, t);
