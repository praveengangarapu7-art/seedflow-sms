import { useCallback, useEffect, useState } from 'react';
import { useAuth } from '@/context/AuthContext';
import { DEMO_ACCOUNTS_BY_ROLE, DEMO_PASSWORD } from '@/data/demoAccounts';
import { api } from '@/services/liveApi';
import type { UserRole } from '@/types';

/**
 * Signs the screen user in to the server as the matching staff account, so
 * the server enforces that person's job role. The demo login screen does not
 * check passwords, so this maps the signed-in email to its server account
 * (seeded by `npm run seed:staff` with the same emails); an email that is not
 * in the demo directory falls back to the first account for the user's role.
 */
export interface ServerUser {
  id: string;
  email: string;
  name: string;
  role: string;
  jobRole: string | null;
  permissions: string[] | 'all';
}

interface CachedSession {
  token: string;
  user: ServerUser;
  expiresAt: number;
}

// Access tokens live 15 minutes on the server; re-sign in a little earlier.
const TOKEN_LIFETIME_MS = 13 * 60 * 1000;
const cache = new Map<string, CachedSession>();
const inflight = new Map<string, Promise<CachedSession>>();

function accountFor(email: string | undefined, role: UserRole | undefined): { email: string; password: string } | null {
  if (email) {
    for (const accounts of Object.values(DEMO_ACCOUNTS_BY_ROLE)) {
      const match = accounts.find((a) => a.email.toLowerCase() === email.toLowerCase());
      if (match) return { email: match.email, password: match.password ?? DEMO_PASSWORD };
    }
  }
  if (role && DEMO_ACCOUNTS_BY_ROLE[role]?.[0]) {
    const first = DEMO_ACCOUNTS_BY_ROLE[role][0];
    return { email: first.email, password: first.password ?? DEMO_PASSWORD };
  }
  return null;
}

async function signIn(email: string, password: string): Promise<CachedSession> {
  const existing = cache.get(email);
  if (existing && existing.expiresAt > Date.now()) return existing;
  const pending = inflight.get(email);
  if (pending) return pending;
  const p = api
    .post<{ accessToken: string; user: ServerUser }>('/auth/login', null, { email, password })
    .then((r) => {
      const session = { token: r.accessToken, user: r.user, expiresAt: Date.now() + TOKEN_LIFETIME_MS };
      cache.set(email, session);
      return session;
    })
    .finally(() => inflight.delete(email));
  inflight.set(email, p);
  return p;
}

/** Bearer token for the signed-in screen user, for API clients that are not React hooks. */
export async function getServerToken(): Promise<string | null> {
  try {
    const raw = window.localStorage.getItem('seedflow_auth');
    if (!raw) return null;
    const saved = JSON.parse(raw) as { email?: string; role?: UserRole };
    const account = accountFor(saved.email, saved.role);
    if (!account) return null;
    return (await signIn(account.email, account.password)).token;
  } catch {
    return null;
  }
}

export interface StaffSession {
  token: string | null;
  me: ServerUser | null;
  loading: boolean;
  error: string | null;
  /** True when the server says this user holds the permission. */
  can: (permission: string) => boolean;
  reload: () => void;
}

export function useStaffSession(): StaffSession {
  const { user } = useAuth();
  const [session, setSession] = useState<CachedSession | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [nonce, setNonce] = useState(0);

  useEffect(() => {
    let cancelled = false;
    const account = accountFor(user?.email, user?.role);
    if (!account) {
      setLoading(false);
      setError('No server account is set up for this role.');
      return;
    }
    setLoading(true);
    setError(null);
    signIn(account.email, account.password)
      .then((s) => {
        if (!cancelled) setSession(s);
      })
      .catch((err: unknown) => {
        if (!cancelled) setError(err instanceof Error ? err.message : 'Unable to sign in to the server');
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    // Refresh shortly before the token lapses so long-open pages keep working.
    const timer = window.setTimeout(() => setNonce((n) => n + 1), TOKEN_LIFETIME_MS);
    return () => {
      cancelled = true;
      window.clearTimeout(timer);
    };
  }, [user?.email, user?.role, nonce]);

  const can = useCallback(
    (permission: string) => {
      const perms = session?.user.permissions;
      if (!perms) return false;
      return perms === 'all' || perms.includes(permission);
    },
    [session],
  );

  const reload = useCallback(() => {
    if (user?.email) cache.clear();
    setNonce((n) => n + 1);
  }, [user?.email]);

  return { token: session?.token ?? null, me: session?.user ?? null, loading, error, can, reload };
}
