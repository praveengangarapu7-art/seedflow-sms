import { randomUUID } from 'node:crypto';
import { describe, expect, it } from 'vitest';
import request from 'supertest';
import { pool } from '../../src/db/pool';
import { registerApprovalHandler } from '../../src/modules/approvals/approvals.service';
import { createTestSeedLot } from '../factories';
import { loginAs } from './authHelper';
import { api, jobActor, legacyActor, phone, inDays, type Actor } from './helpers/actors';
import { app } from './testApp';

const parties = api('/api/v1/parties');
const approvals = api('/api/v1/approvals');
const inspections = api('/api/v1/inspections');

function newSupplier(overrides: Record<string, unknown> = {}) {
  return {
    partyType: 'supplier',
    name: `Agro Inputs ${randomUUID().slice(0, 6)}`,
    phone: phone(),
    category: 'packaging',
    ...overrides,
  };
}

describe('job roles', () => {
  it('logs in with the job role and its permissions, and enforces them on the server', async () => {
    const exec = await jobActor('purchase_executive');
    const res = await request(app).post('/api/v1/auth/login').send({ email: exec.user.email, password: exec.user.password });
    expect(res.body.data.user.jobRole).toBe('purchase_executive');
    expect(res.body.data.user.permissions).toContain('create_order');
    expect(res.body.data.user.permissions).not.toContain('approve_order');

    const finance = await jobActor('finance_manager');
    expect((await parties(finance).post('/', newSupplier())).status).toBe(403);
    expect((await parties(exec).post('/', newSupplier())).status).toBe(201);
  });

  it('keeps grower and dealer portal accounts out of internal records', async () => {
    const grower = await jobActor('grower');
    expect((await parties(grower).get('/')).status).toBe(403);
    expect((await inspections(grower).get('/')).status).toBe(403);
  });

  it('lets a legacy Admin with no job role act everywhere', async () => {
    const admin = await legacyActor('Admin');
    expect((await parties(admin).post('/', newSupplier())).status).toBe(201);
  });
});

describe('party master', () => {
  it('needs a second person to approve a new party', async () => {
    const exec = await jobActor('purchase_executive');
    const manager = await jobActor('purchase_manager');
    const created = await parties(exec).post('/', newSupplier());
    expect(created.status).toBe(201);
    expect(created.body.data.status).toBe('pending_approval');
    expect(created.body.data.party_code).toMatch(/^SUP-\d{4}$/);

    const managerOwn = await parties(manager).post('/', newSupplier());
    expect((await parties(manager).post(`/${managerOwn.body.data.id}/approve`)).status).toBe(403);

    const approved = await parties(manager).post(`/${created.body.data.id}/approve`);
    expect(approved.status).toBe(200);
    expect(approved.body.data.status).toBe('active');
    expect(approved.body.data.approved_by).toBe(manager.user.email);
  });

  it('validates identifiers and requires a licence for dealers', async () => {
    const exec = await jobActor('purchase_executive');
    expect((await parties(exec).post('/', newSupplier({ gstin: 'NOT-A-GSTIN' }))).status).toBe(400);
    expect((await parties(exec).post('/', newSupplier({ phone: '12345' }))).status).toBe(400);
    expect((await parties(exec).post('/', newSupplier({ phone: undefined, email: undefined }))).status).toBe(400);
    expect((await parties(exec).post('/', newSupplier({ bankAccountNumber: '123456789' }))).status).toBe(400);
    const dealerNoLicence = await parties(exec).post('/', { partyType: 'dealer', name: 'Village Agro', phone: phone() });
    expect(dealerNoLicence.status).toBe(400);
    const dealer = await parties(exec).post('/', { partyType: 'dealer', name: 'Village Agro', phone: phone(), licenceNumber: 'SDL/2026/114', licenceValidUntil: inDays(200) });
    expect(dealer.status).toBe(201);
  });

  it('sends a party back for approval when its bank details change, and masks the account in lists', async () => {
    const exec = await jobActor('purchase_executive');
    const manager = await jobActor('purchase_manager');
    const created = await parties(exec).post('/', newSupplier({ bankAccountName: 'Agro Inputs', bankAccountNumber: '123456789012', bankIfsc: 'SBIN0001234' }));
    const id = created.body.data.id;
    await parties(manager).post(`/${id}/approve`);

    const changed = await parties(manager).patch(`/${id}`, { bankAccountNumber: '999988887777' });
    expect(changed.status).toBe(200);
    expect(changed.body.data.status).toBe('pending_approval');
    // the person who changed the bank details cannot approve that change
    expect((await parties(manager).post(`/${id}/approve`)).status).toBe(403);

    const list = await parties(exec).get(`/?q=${encodeURIComponent(created.body.data.party_code)}`);
    expect(list.body.data[0].bank_account_number).toMatch(/^•+7777$/);
    const auditor = await jobActor('compliance_auditor');
    const detail = await parties(auditor).get(`/${id}`);
    expect(detail.body.data.party.bank_account_number).toMatch(/^•+7777$/);
  });

  it('suspends with a reason and never edits a blacklisted party', async () => {
    const exec = await jobActor('purchase_executive');
    const manager = await jobActor('purchase_manager');
    const created = await parties(exec).post('/', newSupplier());
    const id = created.body.data.id;
    await parties(manager).post(`/${id}/approve`);
    expect((await parties(manager).post(`/${id}/suspend`, {})).status).toBe(400);
    expect((await parties(manager).post(`/${id}/suspend`, { reason: 'Late deliveries' })).body.data.status).toBe('suspended');
    expect((await parties(manager).post(`/${id}/reactivate`)).body.data.status).toBe('active');
    expect((await parties(manager).post(`/${id}/suspend`, { reason: 'Fake invoices', blacklist: true })).body.data.status).toBe('blacklisted');
    expect((await parties(manager).post(`/${id}/reactivate`)).status).toBe(409);
    expect((await parties(exec).patch(`/${id}`, { name: 'New name' })).status).toBe(409);
  });
});

describe('attachments', () => {
  const PDF = Buffer.from('%PDF-1.4\n1 0 obj<<>>endobj\ntrailer<<>>\n%%EOF');

  async function upload(a: Actor, data: Buffer, contentType: string, fileName = 'licence.pdf') {
    return request(app)
      .post(`/api/v1/attachments?entityType=party&entityId=${randomUUID()}&fileName=${encodeURIComponent(fileName)}`)
      .set('Authorization', `Bearer ${a.token}`)
      .set('Content-Type', contentType)
      .send(data);
  }

  it('stores a file with its checksum and serves it back unchanged', async () => {
    const exec = await jobActor('purchase_executive');
    const up = await upload(exec, PDF, 'application/pdf');
    expect(up.status).toBe(201);
    expect(up.body.data.size_bytes).toBe(PDF.length);
    const list = await request(app)
      .get(`/api/v1/attachments?entityType=party&entityId=${up.body.data.entity_id}`)
      .set('Authorization', `Bearer ${exec.token}`);
    expect(list.body.data).toHaveLength(1);
    const dl = await request(app).get(`/api/v1/attachments/${up.body.data.id}/download`).set('Authorization', `Bearer ${exec.token}`).buffer(true).parse((res, cb) => {
      const chunks: Buffer[] = [];
      res.on('data', (c: Buffer) => chunks.push(c));
      res.on('end', () => cb(null, Buffer.concat(chunks)));
    });
    expect(dl.status).toBe(200);
    expect(Buffer.compare(dl.body as Buffer, PDF)).toBe(0);
  });

  it('refuses disallowed types and content that does not match its type', async () => {
    const exec = await jobActor('purchase_executive');
    expect((await upload(exec, Buffer.from('MZ....'), 'application/x-msdownload', 'x.exe')).status).toBe(400);
    expect((await upload(exec, Buffer.from('not really a pdf'), 'application/pdf')).status).toBe(400);
  });

  it('lets only the uploader or an administrator remove a file', async () => {
    const exec = await jobActor('purchase_executive');
    const other = await jobActor('purchase_manager');
    const up = await upload(exec, PDF, 'application/pdf');
    expect((await request(app).delete(`/api/v1/attachments/${up.body.data.id}`).set('Authorization', `Bearer ${other.token}`)).status).toBe(403);
    expect((await request(app).delete(`/api/v1/attachments/${up.body.data.id}`).set('Authorization', `Bearer ${exec.token}`)).status).toBe(200);
  });
});

describe('approval engine', () => {
  const decided: { id: string; outcome: string }[] = [];
  registerApprovalHandler('test_document', {
    onApproved: async (_c, id) => {
      decided.push({ id, outcome: 'approved' });
    },
    onRejected: async (_c, id) => {
      decided.push({ id, outcome: 'rejected' });
    },
  });

  async function ensureRules() {
    await pool.query(
      `INSERT INTO approval_rules (entity_type, step_order, step_name, required_permission, min_amount) VALUES
        ('test_document', 1, 'Manager', 'approve_order', 0),
        ('test_document', 2, 'Finance (high value)', 'approve_high_value_order', 100000)
       ON CONFLICT (entity_type, step_order) DO NOTHING`,
    );
  }

  async function submit(requester: Actor, amount: number) {
    const { withTransaction } = await import('../../src/db/transaction');
    const { submitForApprovalTx } = await import('../../src/modules/approvals/approvals.service');
    const entityId = randomUUID();
    const user = { id: requester.user.id, email: requester.user.email, role: requester.user.role, organizationId: requester.user.organizationId, jobRole: requester.user.jobRole };
    const r = await withTransaction((c) => submitForApprovalTx(c, { entityType: 'test_document', entityId, entityCode: 'TD-1', title: 'Test document', amount }, user));
    return { entityId, requestId: r.request.id, steps: r.steps };
  }

  it('adds a finance step only above the threshold and runs the handler on final approval', async () => {
    await ensureRules();
    const exec = await jobActor('purchase_executive');
    const manager = await jobActor('purchase_manager');
    const finance = await jobActor('finance_manager');

    const small = await submit(exec, 5000);
    expect(small.steps).toHaveLength(1);
    const big = await submit(exec, 250000);
    expect(big.steps).toHaveLength(2);

    // inbox shows the request to the manager, not to finance (step 2 still waiting)
    expect((await approvals(manager).get('/inbox')).body.data.some((r: { id: string }) => r.id === big.requestId)).toBe(true);
    expect((await approvals(finance).get('/inbox')).body.data.some((r: { id: string }) => r.id === big.requestId)).toBe(false);

    expect((await approvals(finance).post(`/requests/${big.requestId}/decide`, { decision: 'approve' })).status).toBe(403);
    const s1 = await approvals(manager).post(`/requests/${big.requestId}/decide`, { decision: 'approve' });
    expect(s1.body.data.status).toBe('pending');
    expect(decided.find((d) => d.id === big.entityId)).toBeUndefined();
    const s2 = await approvals(finance).post(`/requests/${big.requestId}/decide`, { decision: 'approve' });
    expect(s2.body.data.status).toBe('approved');
    expect(decided.find((d) => d.id === big.entityId)?.outcome).toBe('approved');
  });

  it('refuses self-approval, one person deciding two steps, and a rejection without a reason', async () => {
    await ensureRules();
    const manager = await jobActor('purchase_manager');
    const superAdmin = await jobActor('super_admin');
    const own = await submit(manager, 1000);
    expect((await approvals(manager).post(`/requests/${own.requestId}/decide`, { decision: 'approve' })).status).toBe(403);

    const exec = await jobActor('purchase_executive');
    const big = await submit(exec, 500000);
    expect((await approvals(superAdmin).post(`/requests/${big.requestId}/decide`, { decision: 'approve' })).status).toBe(200);
    expect((await approvals(superAdmin).post(`/requests/${big.requestId}/decide`, { decision: 'approve' })).status).toBe(403);

    const another = await submit(exec, 1000);
    expect((await approvals(manager).post(`/requests/${another.requestId}/decide`, { decision: 'reject' })).status).toBe(400);
    const rej = await approvals(manager).post(`/requests/${another.requestId}/decide`, { decision: 'reject', comment: 'Budget not available' });
    expect(rej.body.data.status).toBe('rejected');
    expect(decided.find((d) => d.id === another.entityId)?.outcome).toBe('rejected');
  });
});

describe('inspection engine', () => {
  async function receiptTemplate(a: Actor) {
    const list = await inspections(a).get('/templates?type=procurement_receipt&status=active');
    const t = list.body.data.find((x: { name: string }) => /^Procurement receipt/.test(x.name));
    const full = await inspections(a).get(`/templates/${t.id}`);
    return full.body.data as { id: string; items: { id: string; label: string; item_type: string }[] };
  }

  function fill(items: { id: string; label: string; item_type: string }[], moisture: number) {
    return items.map((i) => {
      if (i.label === 'Moisture') return { itemId: i.id, numericValue: moisture };
      if (i.label === 'Physical purity') return { itemId: i.id, numericValue: 98.6 };
      if (i.label === 'Inert matter') return { itemId: i.id, numericValue: 1.1 };
      if (i.label === 'Other crop seeds') return { itemId: i.id, numericValue: 4 };
      if (i.item_type === 'pass_fail') return { itemId: i.id, boolValue: true };
      return { itemId: i.id, textValue: 'ok' };
    });
  }

  it('only inspectors start inspections, and a failed critical check cannot be accepted', async () => {
    const inspector = await jobActor('procurement_quality_field_inspector');
    const exec = await jobActor('purchase_executive');
    const t = await receiptTemplate(inspector);
    expect((await inspections(exec).post('/', { templateId: t.id, subjectType: 'adhoc', subjectLabel: 'Truck AP09' })).status).toBe(403);

    const started = await inspections(inspector).post('/', { templateId: t.id, subjectType: 'adhoc', subjectLabel: 'Truck AP09 TX 4471' });
    expect(started.status).toBe(201);
    const id = started.body.data.id;

    expect((await inspections(inspector).post(`/${id}/submit`, { decision: 'accept' })).status).toBe(400); // nothing recorded yet
    const saved = await inspections(inspector).put(`/${id}/results`, { results: fill(t.items, 15.2) });
    expect(saved.status).toBe(200);
    expect(saved.body.data.results.find((r: { label: string }) => r.label === 'Moisture').passed).toBe(false);

    expect((await inspections(inspector).post(`/${id}/submit`, { decision: 'accept', decisionNotes: 'x' })).status).toBe(400);
    expect((await inspections(inspector).post(`/${id}/submit`, { decision: 'hold', decisionNotes: 'wet' })).status).toBe(400); // no lot
    const rejected = await inspections(inspector).post(`/${id}/submit`, { decision: 'reject', decisionNotes: 'Moisture 15.2% — too wet to store' });
    expect(rejected.status).toBe(200);
    expect(rejected.body.data.result).toBe('fail');
    expect(rejected.body.data.ncr_code).toMatch(/^NCR-/);
    expect((await inspections(inspector).put(`/${id}/results`, { results: fill(t.items, 10) })).status).toBe(409);
  });

  it('a hold decision on a lot raises a non-conformance and puts the lot on quality hold', async () => {
    const inspector = await jobActor('warehouse_quality_field_inspector');
    const lot = await createTestSeedLot();
    const t = await receiptTemplate(inspector);
    const started = await inspections(inspector).post('/', { templateId: t.id, subjectType: 'adhoc', subjectLabel: `Lot ${lot.lot_code}`, seedLotId: lot.id });
    const id = started.body.data.id;
    await inspections(inspector).put(`/${id}/results`, { results: fill(t.items, 14) });
    const held = await inspections(inspector).post(`/${id}/submit`, { decision: 'hold', decisionNotes: 'Dry and retest' });
    expect(held.status).toBe(200);
    const hold = await pool.query('SELECT * FROM quality_lot_holds WHERE seed_lot_id = $1 AND released_at IS NULL', [lot.id]);
    expect(hold.rows).toHaveLength(1);
  });

  it('passes cleanly when every check is within specification', async () => {
    const inspector = await jobActor('procurement_quality_field_inspector');
    const t = await receiptTemplate(inspector);
    const started = await inspections(inspector).post('/', { templateId: t.id, subjectType: 'adhoc', subjectLabel: 'Truck KA01' });
    await inspections(inspector).put(`/${started.body.data.id}/results`, { results: fill(t.items, 11.5) });
    const done = await inspections(inspector).post(`/${started.body.data.id}/submit`, { decision: 'accept' });
    expect(done.body.data.result).toBe('pass');
    expect(done.body.data.ncr_id).toBeNull();
  });

  it('a template is activated by someone other than its author and revisions get a new version', async () => {
    const officer = await jobActor('quality_officer');
    const manager = await jobActor('quality_manager');
    const name = `Dealer shop audit ${randomUUID().slice(0, 6)}`;
    const created = await inspections(officer).post('/templates', {
      name,
      inspectionType: 'dealer_audit',
      items: [
        { label: 'Licence displayed', itemType: 'pass_fail', isCritical: true },
        { label: 'Store temperature', itemType: 'numeric', unit: '°C', maxValue: 30 },
      ],
    });
    expect(created.status).toBe(201);
    expect((await inspections(officer).post(`/templates/${created.body.data.id}/activate`)).status).toBe(403);
    expect((await inspections(manager).post(`/templates/${created.body.data.id}/activate`)).status).toBe(200);
    const revised = await inspections(officer).post(`/templates/${created.body.data.id}/revise`, {});
    expect(revised.status).toBe(201);
    expect(revised.body.data.version).toBe(2);
    expect(revised.body.data.status).toBe('draft');
    expect((await inspections(officer).post('/templates', { name: 'x', inspectionType: 'other', items: [{ label: 'a', itemType: 'pass_fail', minValue: 1 }] })).status).toBe(400);
  });
});

describe('user administration', () => {
  it('sets and clears a job role, recording it as a role change', async () => {
    const admin = await legacyActor('Admin');
    const target = await jobActor('purchase_executive');
    const users = api('/api/v1/users')(admin);
    expect((await users.patch(`/${target.user.id}`, { jobRole: 'nonsense' })).status).toBe(400);
    const res = await users.patch(`/${target.user.id}`, { jobRole: 'purchase_manager' });
    expect(res.body.data.job_role).toBe('purchase_manager');
    const token = await loginAs(target.user);
    expect(token).toBeTruthy();
  });
});
