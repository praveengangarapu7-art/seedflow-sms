import type { Role } from './roles';

/**
 * Job roles: the functional roles the screens are built around. A user's
 * base `role` (Admin, Breeder, Producer, Inspector, Warehouse Manager) still
 * gates the older modules; every module built from the development plan
 * gates on these permissions instead, so a Purchase Manager can approve a
 * purchase order and a Finance Manager cannot — enforced here, not only
 * hidden in the screen. Permission names match src/utils/permissions.ts.
 */
export const JOB_ROLES = [
  'purchase_executive',
  'purchase_manager',
  'finance_manager',
  'procurement_quality_field_inspector',
  'warehouse_supervisor',
  'warehouse_manager',
  'warehouse_quality_field_inspector',
  'safety_officer',
  'rd_executive',
  'rd_manager',
  'rd_quality_field_inspector',
  'plant_supervisor',
  'plant_manager',
  'processing_quality_field_inspector',
  'lab_manager',
  'lab_technician',
  'lab_quality_analyst',
  'quality_manager',
  'quality_officer',
  'super_admin',
  'system_admin',
  'compliance_auditor',
  'grower',
  'dealer',
] as const;
export type JobRole = (typeof JOB_ROLES)[number];

export function isJobRole(value: unknown): value is JobRole {
  return typeof value === 'string' && (JOB_ROLES as readonly string[]).includes(value);
}

/** External portal users: they see only their own records. */
export const EXTERNAL_JOB_ROLES: JobRole[] = ['grower', 'dealer'];

/** The base role a seeded/new account gets for each job role, so the older role-gated modules keep working. */
export const BASE_ROLE_FOR_JOB_ROLE: Record<JobRole, Role> = {
  purchase_executive: 'Producer',
  purchase_manager: 'Producer',
  finance_manager: 'Producer',
  procurement_quality_field_inspector: 'Inspector',
  warehouse_supervisor: 'Warehouse Manager',
  warehouse_manager: 'Warehouse Manager',
  warehouse_quality_field_inspector: 'Inspector',
  safety_officer: 'Warehouse Manager',
  rd_executive: 'Breeder',
  rd_manager: 'Breeder',
  rd_quality_field_inspector: 'Inspector',
  plant_supervisor: 'Producer',
  plant_manager: 'Producer',
  processing_quality_field_inspector: 'Inspector',
  lab_manager: 'Inspector',
  lab_technician: 'Inspector',
  lab_quality_analyst: 'Inspector',
  quality_manager: 'Admin',
  quality_officer: 'Inspector',
  super_admin: 'Admin',
  system_admin: 'Admin',
  compliance_auditor: 'Inspector',
  grower: 'Producer',
  dealer: 'Producer',
};

// --- shared building blocks ------------------------------------------------
const PARTY_EDIT = ['manage_parties'];
const PARTY_APPROVE = ['approve_parties'];
const INSPECT = ['conduct_inspection'];
const TEMPLATE_ADMIN = ['manage_inspection_templates'];
const APPROVAL_ADMIN = ['manage_approval_rules'];

const PROCUREMENT_EXEC = [
  'create_requisition',
  'create_order',
  'create_grn',
  'create_invoice',
  'verify_invoice',
  'create_rfq',
  'manage_grower_agreements',
  'record_grower_delivery',
];
const PROCUREMENT_MGR = [
  ...PROCUREMENT_EXEC,
  'approve_requisition',
  'approve_order',
  'award_rfq',
  'approve_grower_agreement',
  'manage_contracts',
];
const FINANCE = ['approve_high_value_order', 'approve_invoice_payment', 'release_payment', 'allocate_budget', 'settle_grower_payment'];

const WAREHOUSE_FLOOR = [
  'receive_incoming_goods',
  'assign_storage_location',
  'log_stock_movement',
  'propose_stock_adjustment',
  'execute_cycle_count',
  'prepare_outbound_dispatch',
  'log_return',
  'record_sensor_reading',
];
const WAREHOUSE_MGR = [
  ...WAREHOUSE_FLOOR,
  'approve_stock_adjustment',
  'approve_outbound_dispatch',
  'approve_cycle_count',
  'schedule_cycle_count',
  'approve_return_disposition',
  'define_storage_zones',
  'configure_iot_thresholds',
];

const PLANT_FLOOR = ['create_raw_intake', 'create_processing_batch', 'update_batch_stage', 'create_recipe', 'mark_machine_status', 'generate_packages'];
const PLANT_MGR = [
  ...PLANT_FLOOR,
  'approve_recipe_system',
  'approve_batch_recipe',
  'configure_plant',
  'configure_machine',
  'schedule_maintenance',
  'approve_finished_lot_dispatch',
  'cancel_batch',
];

const RD_EXEC = ['catalog_germplasm', 'design_trial', 'execute_trial', 'record_phenotyping', 'analyze_trial_data', 'file_variety_registration', 'propose_variety_advancement'];
const RD_MGR = [...RD_EXEC, 'approve_trial_protocol', 'approve_variety_advancement', 'approve_variety_release', 'manage_variety_specs', 'view_management_dashboard'];

const QUALITY_OFFICER = [...INSPECT, ...TEMPLATE_ADMIN, 'manage_recalls', 'manage_audits', 'manage_training', 'raise_ncr', 'manage_farmer_complaints', 'export_sathi'];
const QUALITY_MANAGER = [...QUALITY_OFFICER, 'approve_recall', 'close_audit', 'manage_dealers', 'sign_off_variety_release', 'view_management_dashboard'];

const LAB = ['manage_lab_controls'];

export const PERMISSIONS_BY_JOB_ROLE: Record<JobRole, readonly string[]> = {
  purchase_executive: [...PROCUREMENT_EXEC, ...PARTY_EDIT],
  purchase_manager: [...PROCUREMENT_MGR, ...PARTY_EDIT, ...PARTY_APPROVE, 'view_management_dashboard'],
  finance_manager: [...FINANCE],
  procurement_quality_field_inspector: [...INSPECT],
  warehouse_supervisor: [...WAREHOUSE_FLOOR],
  warehouse_manager: [...WAREHOUSE_MGR, ...PARTY_EDIT, 'view_management_dashboard'],
  warehouse_quality_field_inspector: [...INSPECT, 'quality_assess_returns'],
  safety_officer: ['record_sensor_reading', 'resolve_safety_alerts', 'manage_safety_incidents'],
  rd_executive: [...RD_EXEC],
  rd_manager: [...RD_MGR],
  rd_quality_field_inspector: [...INSPECT, 'verify_field_observations'],
  plant_supervisor: [...PLANT_FLOOR],
  plant_manager: [...PLANT_MGR, 'view_management_dashboard'],
  processing_quality_field_inspector: [...INSPECT],
  lab_manager: [...LAB, ...INSPECT],
  lab_technician: [...LAB],
  lab_quality_analyst: [...LAB],
  quality_manager: [...QUALITY_MANAGER],
  quality_officer: [...QUALITY_OFFICER],
  super_admin: ['*'],
  system_admin: [...PARTY_EDIT, ...PARTY_APPROVE, ...APPROVAL_ADMIN, ...TEMPLATE_ADMIN, 'manage_dealers', 'manage_notifications', 'view_management_dashboard'],
  compliance_auditor: ['view_management_dashboard'],
  grower: ['portal_grower'],
  dealer: ['portal_dealer'],
};

/** Read access to internal records is for staff; growers and dealers see only their portal. */
export function isStaff(jobRole: string | null | undefined): boolean {
  return !jobRole || !(EXTERNAL_JOB_ROLES as string[]).includes(jobRole);
}

/**
 * The permissions a user holds. A user with a job role holds exactly that
 * role's permissions. A legacy account with no job role holds everything
 * only if its base role is Admin, and nothing in the new modules otherwise.
 */
export function permissionsFor(jobRole: string | null | undefined, baseRole: string): ReadonlySet<string> | 'all' {
  if (jobRole && isJobRole(jobRole)) {
    const list = PERMISSIONS_BY_JOB_ROLE[jobRole];
    return list.includes('*') ? 'all' : new Set(list);
  }
  return baseRole === 'Admin' ? 'all' : new Set();
}

export function hasPermission(jobRole: string | null | undefined, baseRole: string, permission: string): boolean {
  const held = permissionsFor(jobRole, baseRole);
  return held === 'all' || held.has(permission);
}
