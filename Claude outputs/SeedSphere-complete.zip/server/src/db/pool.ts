import { Pool, types } from 'pg';
import { env } from '../config/env';

// pg returns NUMERIC as a string by default to avoid float precision loss;
// seed lot quantities are demo-scale, so parse to number for a cleaner API.
types.setTypeParser(1700, (value: string) => parseFloat(value));
// DATE columns stay as 'YYYY-MM-DD' strings. Turning a calendar date into a
// JS Date at local midnight shifts it by the server's UTC offset when it is
// serialised (an IST server would send 2026-10-12 as 2026-10-11T18:30Z).
types.setTypeParser(1082, (value: string) => value);

export const pool = new Pool({
  connectionString: env.databaseUrl,
  max: 10,
  idleTimeoutMillis: 30000,
});

pool.on('error', (err) => {
  console.error('[db] Unexpected error on idle client', err);
});
