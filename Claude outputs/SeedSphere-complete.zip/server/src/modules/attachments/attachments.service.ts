import { createHash, randomUUID } from 'crypto';
import { mkdir, readFile, writeFile } from 'fs/promises';
import { dirname, join, resolve } from 'path';
import { env } from '../../config/env';
import { pool } from '../../db/pool';
import { withTransaction } from '../../db/transaction';
import { ForbiddenError, NotFoundError, ValidationError } from '../../errors';
import type { AuthenticatedUser } from '../../middleware/requireAuth';
import { insertAuditLog } from '../auditLogs/auditLogs.service';

export const ALLOWED_CONTENT_TYPES: Record<string, string> = {
  'application/pdf': 'pdf',
  'image/png': 'png',
  'image/jpeg': 'jpg',
  'image/webp': 'webp',
  'text/csv': 'csv',
  'text/plain': 'txt',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': 'xlsx',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document': 'docx',
};

const ENTITY_TYPE = /^[a-z][a-z_]{1,39}$/;
const ENTITY_ID = /^[A-Za-z0-9-]{1,64}$/;

export interface AttachmentRow {
  id: string;
  entity_type: string;
  entity_id: string;
  file_name: string;
  content_type: string;
  size_bytes: number;
  sha256: string;
  storage_key: string;
  description: string | null;
  uploaded_by: string;
  uploaded_at: string;
}

function root(): string {
  return resolve(env.uploadDir);
}

/** Magic-number check, so a renamed executable is not stored as a "PDF". */
function sniffMatches(contentType: string, data: Buffer): boolean {
  const starts = (...bytes: number[]) => bytes.every((b, i) => data[i] === b);
  switch (contentType) {
    case 'application/pdf':
      return data.subarray(0, 5).toString('latin1') === '%PDF-';
    case 'image/png':
      return starts(0x89, 0x50, 0x4e, 0x47);
    case 'image/jpeg':
      return starts(0xff, 0xd8, 0xff);
    case 'image/webp':
      return data.subarray(0, 4).toString('latin1') === 'RIFF' && data.subarray(8, 12).toString('latin1') === 'WEBP';
    case 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet':
    case 'application/vnd.openxmlformats-officedocument.wordprocessingml.document':
      return starts(0x50, 0x4b, 0x03, 0x04);
    default:
      // text types: refuse obvious binaries (NUL bytes in the first 1 KB)
      return !data.subarray(0, 1024).includes(0);
  }
}

function safeFileName(name: string): string {
  const base = name.split(/[\\/]/).pop() ?? 'file';
  const cleaned = base.replace(/[^A-Za-z0-9._ ()-]/g, '_').trim();
  if (!cleaned) throw new ValidationError('fileName is required');
  return cleaned.slice(0, 200);
}

export async function uploadAttachment(
  params: { entityType: unknown; entityId: unknown; fileName: unknown; description?: unknown; contentType: string | undefined },
  data: Buffer,
  user: AuthenticatedUser,
): Promise<AttachmentRow> {
  const entityType = typeof params.entityType === 'string' ? params.entityType : '';
  const entityId = typeof params.entityId === 'string' ? params.entityId : '';
  if (!ENTITY_TYPE.test(entityType)) throw new ValidationError('entityType is required (lowercase letters and underscores)');
  if (!ENTITY_ID.test(entityId)) throw new ValidationError('entityId is required');
  const fileName = safeFileName(typeof params.fileName === 'string' ? params.fileName : '');
  const contentType = (params.contentType ?? '').split(';')[0].trim().toLowerCase();
  const ext = ALLOWED_CONTENT_TYPES[contentType];
  if (!ext) throw new ValidationError(`File type ${contentType || 'unknown'} is not accepted. Allowed: PDF, PNG, JPEG, WebP, CSV, TXT, XLSX, DOCX`);
  if (!Buffer.isBuffer(data) || data.length === 0) throw new ValidationError('The file is empty');
  if (data.length > env.maxUploadBytes) throw new ValidationError(`The file is larger than ${Math.round(env.maxUploadBytes / 1024 / 1024)} MB`);
  if (!sniffMatches(contentType, data)) throw new ValidationError(`The file content does not match its declared type (${contentType})`);
  const description = typeof params.description === 'string' && params.description.trim() ? params.description.trim().slice(0, 500) : null;

  const sha256 = createHash('sha256').update(data).digest('hex');
  const storageKey = `${new Date().getUTCFullYear()}/${randomUUID()}.${ext}`;
  const path = join(root(), storageKey);
  await mkdir(dirname(path), { recursive: true });
  await writeFile(path, data, { flag: 'wx' });

  return withTransaction(async (client) => {
    const r = await client.query<AttachmentRow>(
      `INSERT INTO attachments (entity_type, entity_id, file_name, content_type, size_bytes, sha256, storage_key, description, uploaded_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9) RETURNING *`,
      [entityType, entityId, fileName, contentType, data.length, sha256, storageKey, description, user.email],
    );
    await insertAuditLog(client, {
      entityType: 'attachment',
      entityId: r.rows[0].id,
      action: 'UPLOAD',
      performedBy: user.email,
      metadata: { entityType, entityId, fileName, sha256, sizeBytes: data.length },
    });
    return r.rows[0];
  });
}

export async function listAttachments(entityType: string | undefined, entityId: string | undefined): Promise<AttachmentRow[]> {
  if (!entityType || !entityId) throw new ValidationError('entityType and entityId are required');
  const r = await pool.query<AttachmentRow>(
    `SELECT * FROM attachments WHERE entity_type = $1 AND entity_id = $2 AND deleted_at IS NULL ORDER BY uploaded_at DESC`,
    [entityType, entityId],
  );
  return r.rows;
}

export async function countAttachments(entityType: string, entityId: string): Promise<number> {
  const r = await pool.query<{ n: number }>(
    `SELECT COUNT(*)::int AS n FROM attachments WHERE entity_type = $1 AND entity_id = $2 AND deleted_at IS NULL`,
    [entityType, entityId],
  );
  return r.rows[0].n;
}

export async function readAttachment(id: string): Promise<{ row: AttachmentRow; data: Buffer }> {
  const r = await pool.query<AttachmentRow>('SELECT * FROM attachments WHERE id = $1 AND deleted_at IS NULL', [id]);
  const row = r.rows[0];
  if (!row) throw new NotFoundError('Attachment not found');
  const path = resolve(root(), row.storage_key);
  if (!path.startsWith(root())) throw new NotFoundError('Attachment not found');
  const data = await readFile(path).catch(() => {
    throw new NotFoundError('The stored file is missing');
  });
  const actual = createHash('sha256').update(data).digest('hex');
  if (actual !== row.sha256) throw new ValidationError('The stored file no longer matches its recorded checksum');
  return { row, data };
}

export async function deleteAttachment(id: string, user: AuthenticatedUser): Promise<void> {
  await withTransaction(async (client) => {
    const r = await client.query<AttachmentRow>('SELECT * FROM attachments WHERE id = $1 AND deleted_at IS NULL FOR UPDATE', [id]);
    const row = r.rows[0];
    if (!row) throw new NotFoundError('Attachment not found');
    if (row.uploaded_by !== user.email && user.role !== 'Admin') throw new ForbiddenError('Only the person who uploaded a file, or an administrator, can remove it');
    // Soft delete: the file stays on disk and the row stays for the audit
    // trail; it simply stops being listed as evidence.
    await client.query('UPDATE attachments SET deleted_at = now(), deleted_by = $2 WHERE id = $1', [id, user.email]);
    await insertAuditLog(client, { entityType: 'attachment', entityId: id, action: 'DELETE', performedBy: user.email, metadata: { entityType: row.entity_type, entityId: row.entity_id, fileName: row.file_name } });
  });
}
