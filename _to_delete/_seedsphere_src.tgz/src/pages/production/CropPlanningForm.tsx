import { useEffect, useMemo, useState } from 'react';
import { ArrowLeft, Save } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/common/Button/Button';
import { Input } from '@/components/common/Input/Input';
import { masterDataApi, productionApi, type Crop, type CropPlan, type Farm, type Farmer, type SeedVariety } from '@/services/api';
import { useToast } from '@/components/common/Toast/ToastContext';
import { daysBetween, recommendedSeasonForCrop, seedCrops, seedFarmers, seedFarms, seedVarieties } from './cropPlanningData';
import styles from './production.module.css';

export default function CropPlanningForm() {
  const navigate = useNavigate();
  const { addToast } = useToast();

  const [farmers, setFarmers] = useState<Farmer[]>(seedFarmers);
  const [farms, setFarms] = useState<Farm[]>(seedFarms);
  const [varieties, setVarieties] = useState<SeedVariety[]>(seedVarieties);
  const [crops, setCrops] = useState<Crop[]>(seedCrops);

  const [farmerId, setFarmerId] = useState('');
  const [farmId, setFarmId] = useState('');
  const [varietyId, setVarietyId] = useState('');
  const [targetYield, setTargetYield] = useState('');
  const [sowingDate, setSowingDate] = useState('');
  const [harvestDate, setHarvestDate] = useState('');

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const load = async () => {
      try {
        const [farmersData, farmsData, varietiesData, cropsData] = await Promise.all([
          masterDataApi.getFarmers(),
          masterDataApi.getFarms(),
          masterDataApi.getVarieties(),
          masterDataApi.getCrops(),
        ]);
        setFarmers(Array.isArray(farmersData) && farmersData.length > 0 ? farmersData : seedFarmers);
        setFarms(Array.isArray(farmsData) && farmsData.length > 0 ? farmsData : seedFarms);
        setVarieties(Array.isArray(varietiesData) && varietiesData.length > 0 ? varietiesData : seedVarieties);
        setCrops(Array.isArray(cropsData) && cropsData.length > 0 ? cropsData : seedCrops);
      } catch {
        setFarmers(seedFarmers);
        setFarms(seedFarms);
        setVarieties(seedVarieties);
        setCrops(seedCrops);
      }
    };

    void load();
  }, []);

  const farmsForFarmer = useMemo(() => farms.filter((farm) => farm.farmerId === farmerId), [farms, farmerId]);
  const selectedVariety = useMemo(() => varieties.find((variety) => variety.id === varietyId), [varieties, varietyId]);
  const recommendedSeason = useMemo(
    () => (selectedVariety ? recommendedSeasonForCrop(selectedVariety.crop, crops) : undefined),
    [selectedVariety, crops],
  );
  const daysToHarvest = useMemo(() => daysBetween(sowingDate, harvestDate), [sowingDate, harvestDate]);

  const handleFarmerChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setFarmerId(e.target.value);
    setFarmId('');
  };

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    setError(null);

    if (!farmerId) {
      setError('Please select a farmer.');
      return;
    }
    if (!farmId) {
      setError('Please select a farm.');
      return;
    }
    if (!varietyId) {
      setError('Please select a variety.');
      return;
    }
    const yieldValue = Number(targetYield);
    if (!targetYield || Number.isNaN(yieldValue) || yieldValue <= 0) {
      setError('Target yield must be a positive number.');
      return;
    }
    if (!sowingDate) {
      setError('Sowing date is required.');
      return;
    }
    if (!harvestDate) {
      setError('Harvest date is required.');
      return;
    }
    if (daysToHarvest === null || daysToHarvest <= 0) {
      setError('Harvest date must be after the sowing date.');
      return;
    }

    setLoading(true);

    try {
      const payload: Partial<CropPlan> = {
        planCode: `CP-${Date.now()}`,
        farmerId,
        farmId,
        varietyId,
        crop: selectedVariety?.crop ?? '',
        season: recommendedSeason ?? '',
        targetYield: yieldValue,
        sowingDate,
        harvestDate,
        status: 'Planned',
      };

      await productionApi.createCropPlan(payload);
      addToast('Crop plan created successfully', 'success');
      navigate('/crop-planning');
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Unable to save crop plan';
      setError(message);
      addToast(message, 'error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={styles.page}>
      <div className={styles.header}>
        <div>
          <h1 className={styles.title}>Create Crop Plan</h1>
          <p className={styles.subtitle}>Allocate a farmer's farm and parent seed variety, and set the season timeline.</p>
        </div>
        <Button variant="secondary" leftIcon={ArrowLeft} onClick={() => navigate('/crop-planning')}>
          Back to list
        </Button>
      </div>

      <div className={styles.card}>
        <form className={styles.form} onSubmit={handleSubmit}>
          {error ? <div className={styles.errorText}>{error}</div> : null}

          <div className={styles.formGrid}>
            <div className={styles.field}>
              <label className={styles.label} htmlFor="farmer">Farmer</label>
              <select id="farmer" className={styles.select} value={farmerId} onChange={handleFarmerChange}>
                <option value="">Select a farmer</option>
                {farmers.map((farmer) => (
                  <option key={farmer.id} value={farmer.id}>
                    {farmer.name}
                  </option>
                ))}
              </select>
            </div>

            <div className={styles.field}>
              <label className={styles.label} htmlFor="farm">Farm</label>
              <select
                id="farm"
                className={styles.select}
                value={farmId}
                onChange={(e) => setFarmId(e.target.value)}
                disabled={!farmerId}
              >
                <option value="">{farmerId ? 'Select a farm' : 'Select a farmer first'}</option>
                {farmsForFarmer.map((farm) => (
                  <option key={farm.id} value={farm.id}>
                    {farm.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className={styles.formGrid}>
            <div className={styles.field}>
              <label className={styles.label} htmlFor="variety">Variety</label>
              <select id="variety" className={styles.select} value={varietyId} onChange={(e) => setVarietyId(e.target.value)}>
                <option value="">Select a variety</option>
                {varieties.map((variety) => (
                  <option key={variety.id} value={variety.id}>
                    {variety.name} ({variety.crop})
                  </option>
                ))}
              </select>
              {selectedVariety ? (
                <span className={styles.helperText}>
                  Recommended season: {recommendedSeason ?? 'Not available'}
                </span>
              ) : null}
            </div>

            <div className={styles.field}>
              <label className={styles.label} htmlFor="targetYield">Target Yield (kg)</label>
              <Input
                id="targetYield"
                type="number"
                min="0"
                value={targetYield}
                onChange={(e) => setTargetYield(e.target.value)}
                placeholder="e.g. 4500"
              />
            </div>
          </div>

          <div className={styles.formGrid}>
            <div className={styles.field}>
              <label className={styles.label} htmlFor="sowingDate">Sowing Date</label>
              <input
                id="sowingDate"
                type="date"
                className={styles.input}
                value={sowingDate}
                onChange={(e) => setSowingDate(e.target.value)}
              />
            </div>

            <div className={styles.field}>
              <label className={styles.label} htmlFor="harvestDate">Harvest Date</label>
              <input
                id="harvestDate"
                type="date"
                className={styles.input}
                value={harvestDate}
                onChange={(e) => setHarvestDate(e.target.value)}
              />
            </div>
          </div>

          {sowingDate && harvestDate ? (
            <div className={styles.computedBox}>
              <span className={styles.computedLabel}>Days to Harvest</span>
              {daysToHarvest !== null && daysToHarvest > 0
                ? `${daysToHarvest} days from sowing to harvest`
                : 'Harvest date must be after the sowing date.'}
            </div>
          ) : null}

          <div className={styles.actions}>
            <Button leftIcon={Save} isLoading={loading} type="submit">
              Create crop plan
            </Button>
            <Button variant="secondary" type="button" onClick={() => navigate('/crop-planning')}>
              Cancel
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
