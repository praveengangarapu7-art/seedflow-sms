import { useState, type FormEvent } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { AuthLayout } from '@/components/auth/AuthLayout/AuthLayout';
import { Input } from '@/components/common/Input/Input';
import { Button } from '@/components/common/Button/Button';
import { useAuth } from '@/context/AuthContext';
import type { UserRole } from '@/types';
import { PROCUREMENT_ROLES, WAREHOUSE_ROLES, RD_ROLES, PROCESSING_ROLES } from '@/types';
import styles from './Login.module.css';

const DEMO_CREDENTIALS: Record<UserRole, { email: string; password: string }> = {
  purchase_executive: { email: 'executive@seedsphere.com', password: 'password123' },
  purchase_manager: { email: 'manager@seedsphere.com', password: 'password123' },
  finance_manager: { email: 'finance@seedsphere.com', password: 'password123' },
  procurement_quality_field_inspector: { email: 'inspector@seedsphere.com', password: 'password123' },
  warehouse_supervisor: { email: 'supervisor@seedsphere.com', password: 'password123' },
  warehouse_manager: { email: 'whmanager@seedsphere.com', password: 'password123' },
  warehouse_quality_field_inspector: { email: 'whinspector@seedsphere.com', password: 'password123' },
  safety_officer: { email: 'safety@seedsphere.com', password: 'password123' },
  rd_executive: { email: 'rdexecutive@seedsphere.com', password: 'password123' },
  rd_manager: { email: 'rdmanager@seedsphere.com', password: 'password123' },
  rd_quality_field_inspector: { email: 'rdinspector@seedsphere.com', password: 'password123' },
  plant_supervisor: { email: 'plantsupervisor@seedsphere.com', password: 'password123' },
  plant_manager: { email: 'plantmanager@seedsphere.com', password: 'password123' },
  processing_quality_field_inspector: { email: 'procinspector@seedsphere.com', password: 'password123' },
};

function getPostLoginRoute(role: UserRole): string {
  if (PROCUREMENT_ROLES.includes(role)) return '/procurement/dashboard';
  if (WAREHOUSE_ROLES.includes(role)) return '/warehouse/dashboard';
  if (RD_ROLES.includes(role)) return '/rd/dashboard';
  if (PROCESSING_ROLES.includes(role)) return '/processing/dashboard';
  return '/modules';
}

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [role, setRole] = useState<UserRole>('purchase_executive');
  const [email, setEmail] = useState(DEMO_CREDENTIALS.purchase_executive.email);
  const [password, setPassword] = useState(DEMO_CREDENTIALS.purchase_executive.password);
  const [remember, setRemember] = useState(false);

  function handleRoleChange(selectedRole: UserRole) {
    setRole(selectedRole);
    setEmail(DEMO_CREDENTIALS[selectedRole].email);
    setPassword(DEMO_CREDENTIALS[selectedRole].password);
  }

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    login(email, password, role);
    navigate(getPostLoginRoute(role));
  }

  return (
    <AuthLayout>
      <h1 className={styles.heading}>Welcome back</h1>
      <p className={styles.subheading}>Log in to access your seed management dashboard</p>

      <form className={styles.form} onSubmit={handleSubmit}>
        <div className={styles.demoRoleSelector}>
          <label className={styles.demoLabel}>Demo: Log in as</label>
          <select 
            value={role} 
            onChange={(e) => handleRoleChange(e.target.value as UserRole)}
            className={styles.demoSelect}
          >
            <optgroup label="Procurement Module">
              <option value="purchase_executive">Purchase Executive</option>
              <option value="purchase_manager">Purchase Manager</option>
              <option value="finance_manager">Finance Manager</option>
              <option value="procurement_quality_field_inspector">Quality Field Inspector (Procurement)</option>
            </optgroup>
            <optgroup label="Warehouse Module">
              <option value="warehouse_supervisor">Warehouse Supervisor</option>
              <option value="warehouse_manager">Warehouse Manager</option>
              <option value="warehouse_quality_field_inspector">Quality Field Inspector (Warehouse)</option>
              <option value="safety_officer">Safety Officer</option>
            </optgroup>
            <optgroup label="R&D Module">
              <option value="rd_executive">R&D Executive</option>
              <option value="rd_manager">R&D Manager</option>
              <option value="rd_quality_field_inspector">Quality Field Inspector (R&D)</option>
            </optgroup>
            <optgroup label="Processing Module">
              <option value="plant_supervisor">Plant Supervisor</option>
              <option value="plant_manager">Plant Manager</option>
              <option value="processing_quality_field_inspector">Quality Field Inspector (Processing)</option>
            </optgroup>
          </select>
          <p className={styles.demoHint}>Select a role to preview their custom interface.</p>
        </div>

        <Input
          label="Work email"
          type="email"
          placeholder="you@company.com"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />

        <Input
          label="Password"
          type="password"
          placeholder="Your password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        />

        <div className={styles.rememberRow}>
          <div className={styles.rememberLeft}>
            <input
              id="remember"
              className={styles.checkbox}
              type="checkbox"
              checked={remember}
              onChange={(e) => setRemember(e.target.checked)}
            />
            <label htmlFor="remember" className={styles.rememberLabel}>Keep me signed in</label>
          </div>
          <a
            href="#"
            className={styles.forgotLink}
            onClick={(e) => e.preventDefault()}
          >
            Forgot password?
          </a>
        </div>

        <Button type="submit" variant="primary" fullWidth size="lg">
          Log in
        </Button>

        <p className={styles.footer}>
          Don't have an account?{' '}
          <Link to="/signup">Sign up</Link>
        </p>
      </form>
    </AuthLayout>
  );
}
