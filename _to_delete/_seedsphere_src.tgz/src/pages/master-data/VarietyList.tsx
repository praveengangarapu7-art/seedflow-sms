import { useEffect, useMemo, useState } from 'react';
import { Plus, Search, RefreshCw } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/common/Button/Button';
import { VarietyTable } from '@/components/VarietyTable/VarietyTable';
import { masterDataApi, type SeedVariety } from '@/services/api';
import { useToast } from '@/components/common/Toast/ToastContext';
import styles from './master-data.module.css';

export default function VarietyList() {
  const [varieties, setVarieties] = useState<SeedVariety[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const navigate = useNavigate();
  const { addToast } = useToast();

  const loadVarieties = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await masterDataApi.getVarieties();
      setVarieties(Array.isArray(data) ? data : []);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Unable to load varieties';
      setError(message);
      addToast(message, 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void loadVarieties();
  }, []);

  const filteredVarieties = useMemo(() => {
    const query = search.trim().toLowerCase();
    if (!query) return varieties;
    return varieties.filter((item) => item.name.toLowerCase().includes(query) || item.crop.toLowerCase().includes(query));
  }, [search, varieties]);

  const handleDelete = async (variety: SeedVariety) => {
    const confirmed = window.confirm(`Delete ${variety.name}?`);
    if (!confirmed) return;

    try {
      await masterDataApi.deleteVariety(variety.id);
      addToast('Variety deleted successfully', 'success');
      await loadVarieties();
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Deletion failed';
      addToast(message, 'error');
    }
  };

  return (
    <div className={styles.page}>
      <div className={styles.header}>
        <div>
          <h1 className={styles.title}>Variety Management</h1>
          <p className={styles.subtitle}>Create, edit, and manage seed varieties in SeedSphere.</p>
        </div>
        <div className={styles.actions}>
          <Button variant="secondary" leftIcon={RefreshCw} onClick={() => void loadVarieties()}>
            Refresh
          </Button>
          <Button leftIcon={Plus} onClick={() => navigate('/varieties/new')}>
            Create New
          </Button>
        </div>
      </div>

      <div className={styles.card}>
        <div className={styles.controls}>
          <label style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', flex: 1 }}>
            <Search size={16} />
            <input
              className={styles.searchInput}
              placeholder="Search by variety or crop"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </label>
        </div>

        {error ? <div className={styles.errorText}>{error}</div> : null}

        {filteredVarieties.length === 0 && !loading ? (
          <div className={styles.emptyState}>No varieties match your current filter.</div>
        ) : (
          <VarietyTable
            varieties={filteredVarieties}
            loading={loading}
            onView={(item) => navigate(`/varieties/${item.id}`)}
            onEdit={(item) => navigate(`/varieties/${item.id}/edit`)}
            onDelete={handleDelete}
          />
        )}
      </div>
    </div>
  );
}
