import { useEffect, useMemo, useState } from 'react';
import { ArrowLeft, Save } from 'lucide-react';
import { useNavigate, useParams } from 'react-router-dom';
import { Button } from '@/components/common/Button/Button';
import { Input } from '@/components/common/Input/Input';
import { masterDataApi } from '@/services/api';
import { useToast } from '@/components/common/Toast/ToastContext';
import styles from './master-data.module.css';

const categoryOptions = ['Food Grain', 'Cash Crop', 'Oilseed', 'Vegetable', 'Pulse', 'Fibre Crop'];
const seasonOptions = ['Kharif', 'Rabi', 'Summer', 'Year-round', 'Winter'];

export default function CropForm() {
  const navigate = useNavigate();
  const { id } = useParams();
  const isEdit = Boolean(id);
  const { addToast } = useToast();

  const [name, setName] = useState('');
  const [category, setCategory] = useState(categoryOptions[0]);
  const [season, setSeason] = useState(seasonOptions[0]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const pageTitle = useMemo(() => (isEdit ? 'Edit Crop' : 'Create Crop'), [isEdit]);

  useEffect(() => {
    if (!isEdit) return;

    const load = async () => {
      try {
        const data = await masterDataApi.getCrop(id!);
        setName(data.name ?? '');
        setCategory(data.category ?? categoryOptions[0]);
        setSeason(data.season ?? seasonOptions[0]);
      } catch (err) {
        const message = err instanceof Error ? err.message : 'Unable to load crop';
        setError(message);
      }
    };

    void load();
  }, [id, isEdit]);

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    setError(null);

    if (!name.trim()) {
      setError('Crop name is required.');
      return;
    }

    setLoading(true);

    try {
      const payload = {
        name: name.trim(),
        category,
        season,
        active: true,
      };

      if (isEdit) {
        await masterDataApi.updateCrop(id!, payload);
        addToast('Crop updated successfully', 'success');
      } else {
        await masterDataApi.createCrop(payload);
        addToast('Crop created successfully', 'success');
      }
      navigate('/crops');
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Unable to save crop';
      setError(message);
      addToast(message, 'error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={styles.page}>
      <div className={styles.header}>
        <div>
          <h1 className={styles.title}>{pageTitle}</h1>
          <p className={styles.subtitle}>Capture crop master data for SeedSphere.</p>
        </div>
        <Button variant="secondary" leftIcon={ArrowLeft} onClick={() => navigate('/crops')}>
          Back to list
        </Button>
      </div>

      <div className={styles.card}>
        <form className={styles.form} onSubmit={handleSubmit}>
          {error ? <div className={styles.errorText}>{error}</div> : null}

          <div className={styles.field}>
            <label className={styles.label} htmlFor="name">Name</label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Paddy"
              errorText={!name.trim() && error ? 'Required' : undefined}
            />
          </div>

          <div className={styles.field}>
            <label className={styles.label} htmlFor="category">Category</label>
            <select id="category" className={styles.select} value={category} onChange={(e) => setCategory(e.target.value)}>
              {categoryOptions.map((option) => (
                <option key={option} value={option}>
                  {option}
                </option>
              ))}
            </select>
          </div>

          <div className={styles.field}>
            <label className={styles.label} htmlFor="season">Season</label>
            <select id="season" className={styles.select} value={season} onChange={(e) => setSeason(e.target.value)}>
              {seasonOptions.map((option) => (
                <option key={option} value={option}>
                  {option}
                </option>
              ))}
            </select>
          </div>

          <div className={styles.actions}>
            <Button leftIcon={Save} isLoading={loading} type="submit">
              {isEdit ? 'Save changes' : 'Create crop'}
            </Button>
            <Button variant="secondary" type="button" onClick={() => navigate('/crops')}>
              Cancel
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
