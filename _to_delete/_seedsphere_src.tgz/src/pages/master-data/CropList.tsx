import { useEffect, useMemo, useState } from 'react';
import { Plus, Search, RefreshCw } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/common/Button/Button';
import { CropTable } from '@/components/CropTable/CropTable';
import { masterDataApi, type Crop } from '@/services/api';
import { useToast } from '@/components/common/Toast/ToastContext';
import styles from './master-data.module.css';

const seedCrops: Crop[] = [
  { id: 'crop-1', name: 'Paddy', category: 'Food Grain', season: 'Kharif', active: true },
  { id: 'crop-2', name: 'Maize', category: 'Food Grain', season: 'Rabi', active: true },
  { id: 'crop-3', name: 'Cotton', category: 'Cash Crop', season: 'Kharif', active: true },
  { id: 'crop-4', name: 'Groundnut', category: 'Oilseed', season: 'Summer', active: true },
  { id: 'crop-5', name: 'Tomato', category: 'Vegetable', season: 'Year-round', active: true },
];

export default function CropList() {
  const [crops, setCrops] = useState<Crop[]>(seedCrops);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const navigate = useNavigate();
  const { addToast } = useToast();

  const loadCrops = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await masterDataApi.getCrops();
      const nextCrops = Array.isArray(data) && data.length > 0 ? data : seedCrops;
      setCrops(nextCrops);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Unable to load crops';
      setError(message);
      setCrops(seedCrops);
      addToast(message, 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void loadCrops();
  }, []);

  const filteredCrops = useMemo(() => {
    const query = search.trim().toLowerCase();
    if (!query) return crops;
    return crops.filter((item) => item.name.toLowerCase().includes(query));
  }, [crops, search]);

  const handleDelete = async (crop: Crop) => {
    const confirmed = window.confirm(`Delete ${crop.name}?`);
    if (!confirmed) return;

    try {
      await masterDataApi.deleteCrop(crop.id);
      addToast('Crop deleted successfully', 'success');
      await loadCrops();
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Deletion failed';
      addToast(message, 'error');
    }
  };

  return (
    <div className={styles.page}>
      <div className={styles.header}>
        <div>
          <h1 className={styles.title}>Crop Management</h1>
          <p className={styles.subtitle}>Create, edit, and manage crop master data in SeedSphere.</p>
        </div>
        <div className={styles.actions}>
          <Button variant="secondary" leftIcon={RefreshCw} onClick={() => void loadCrops()}>
            Refresh
          </Button>
          <Button leftIcon={Plus} onClick={() => navigate('/crops/new')}>
            Create New
          </Button>
        </div>
      </div>

      <div className={styles.card}>
        <div className={styles.controls}>
          <label style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', flex: 1 }}>
            <Search size={16} />
            <input
              className={styles.searchInput}
              placeholder="Search by crop name"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </label>
        </div>

        {error ? <div className={styles.errorText}>{error}</div> : null}

        {filteredCrops.length === 0 && !loading ? (
          <div className={styles.emptyState}>No crops match your current filter.</div>
        ) : (
          <CropTable
            crops={filteredCrops}
            loading={loading}
            onView={(item) => navigate(`/crops/${item.id}`)}
            onEdit={(item) => navigate(`/crops/${item.id}/edit`)}
            onDelete={handleDelete}
          />
        )}
      </div>
    </div>
  );
}
