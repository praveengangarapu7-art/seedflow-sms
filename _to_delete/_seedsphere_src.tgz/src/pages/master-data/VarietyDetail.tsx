import { useEffect, useState } from 'react';
import { ArrowLeft, Edit3, Trash2 } from 'lucide-react';
import { useNavigate, useParams } from 'react-router-dom';
import { Button } from '@/components/common/Button/Button';
import { masterDataApi, type SeedVariety } from '@/services/api';
import { useToast } from '@/components/common/Toast/ToastContext';
import styles from './master-data.module.css';

export default function VarietyDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { addToast } = useToast();
  const [variety, setVariety] = useState<SeedVariety | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const load = async () => {
      if (!id) return;
      setLoading(true);
      try {
        const data = await masterDataApi.getVariety(id);
        setVariety(data);
      } catch (err) {
        const message = err instanceof Error ? err.message : 'Unable to load variety';
        setError(message);
      } finally {
        setLoading(false);
      }
    };

    void load();
  }, [id]);

  const handleDelete = async () => {
    if (!variety) return;
    const confirmed = window.confirm(`Delete ${variety.name}?`);
    if (!confirmed) return;

    try {
      await masterDataApi.deleteVariety(variety.id);
      addToast('Variety deleted successfully', 'success');
      navigate('/varieties');
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Deletion failed';
      addToast(message, 'error');
    }
  };

  return (
    <div className={styles.page}>
      <div className={styles.header}>
        <div>
          <h1 className={styles.title}>Variety Details</h1>
          <p className={styles.subtitle}>Inspect full variety details and manage the record.</p>
        </div>
        <div className={styles.actions}>
          <Button variant="secondary" leftIcon={ArrowLeft} onClick={() => navigate('/varieties')}>
            Back to list
          </Button>
          <Button leftIcon={Edit3} onClick={() => navigate(`/varieties/${id}/edit`)}>
            Edit
          </Button>
          <Button variant="danger" leftIcon={Trash2} onClick={handleDelete}>
            Delete
          </Button>
        </div>
      </div>

      <div className={styles.card}>
        {loading ? <div className={styles.emptyState}>Loading variety…</div> : null}
        {error ? <div className={styles.errorText}>{error}</div> : null}
        {!loading && variety ? (
          <div className={styles.detailGrid}>
            <div className={styles.detailItem}>
              <span className={styles.detailLabel}>Name</span>
              <div className={styles.detailValue}>{variety.name}</div>
            </div>
            <div className={styles.detailItem}>
              <span className={styles.detailLabel}>Crop</span>
              <div className={styles.detailValue}>{variety.crop}</div>
            </div>
            <div className={styles.detailItem}>
              <span className={styles.detailLabel}>Description</span>
              <div className={styles.detailValue}>{variety.description ?? 'No description provided.'}</div>
            </div>
            <div className={styles.detailItem}>
              <span className={styles.detailLabel}>ID</span>
              <div className={styles.detailValue}>{variety.id}</div>
            </div>
          </div>
        ) : null}
      </div>
    </div>
  );
}
