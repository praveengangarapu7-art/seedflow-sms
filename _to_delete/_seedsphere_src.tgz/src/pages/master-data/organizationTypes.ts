import type { Organization } from '@/services/api';

export const organizationTypeOptions: { value: Organization['type']; label: string }[] = [
  { value: 'breeder', label: 'Breeder' },
  { value: 'producer', label: 'Producer' },
  { value: 'laboratory', label: 'Laboratory' },
  { value: 'warehouse', label: 'Warehouse' },
  { value: 'dealer', label: 'Dealer' },
];

export function organizationTypeLabel(type: Organization['type']): string {
  return organizationTypeOptions.find((option) => option.value === type)?.label ?? type;
}
