import { useEffect, useState } from 'react';
import { ArrowLeft, Edit3, Trash2 } from 'lucide-react';
import { useNavigate, useParams } from 'react-router-dom';
import { Button } from '@/components/common/Button/Button';
import { masterDataApi, type Crop } from '@/services/api';
import { useToast } from '@/components/common/Toast/ToastContext';
import styles from './master-data.module.css';

export default function CropDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { addToast } = useToast();
  const [crop, setCrop] = useState<Crop | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const load = async () => {
      if (!id) return;
      setLoading(true);
      try {
        const data = await masterDataApi.getCrop(id);
        setCrop(data);
      } catch (err) {
        const message = err instanceof Error ? err.message : 'Unable to load crop';
        setError(message);
      } finally {
        setLoading(false);
      }
    };

    void load();
  }, [id]);

  const handleDelete = async () => {
    if (!crop) return;
    const confirmed = window.confirm(`Delete ${crop.name}?`);
    if (!confirmed) return;

    try {
      await masterDataApi.deleteCrop(crop.id);
      addToast('Crop deleted successfully', 'success');
      navigate('/crops');
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Deletion failed';
      addToast(message, 'error');
    }
  };

  return (
    <div className={styles.page}>
      <div className={styles.header}>
        <div>
          <h1 className={styles.title}>Crop Details</h1>
          <p className={styles.subtitle}>Inspect full crop details and manage the record.</p>
        </div>
        <div className={styles.actions}>
          <Button variant="secondary" leftIcon={ArrowLeft} onClick={() => navigate('/crops')}>
            Back to list
          </Button>
          <Button leftIcon={Edit3} onClick={() => navigate(`/crops/${id}/edit`)}>
            Edit
          </Button>
          <Button variant="danger" leftIcon={Trash2} onClick={handleDelete}>
            Delete
          </Button>
        </div>
      </div>

      <div className={styles.card}>
        {loading ? <div className={styles.emptyState}>Loading crop…</div> : null}
        {error ? <div className={styles.errorText}>{error}</div> : null}
        {!loading && crop ? (
          <div className={styles.detailGrid}>
            <div className={styles.detailItem}>
              <span className={styles.detailLabel}>Name</span>
              <div className={styles.detailValue}>{crop.name}</div>
            </div>
            <div className={styles.detailItem}>
              <span className={styles.detailLabel}>Category</span>
              <div className={styles.detailValue}>{crop.category}</div>
            </div>
            <div className={styles.detailItem}>
              <span className={styles.detailLabel}>Season</span>
              <div className={styles.detailValue}>{crop.season}</div>
            </div>
            <div className={styles.detailItem}>
              <span className={styles.detailLabel}>ID</span>
              <div className={styles.detailValue}>{crop.id}</div>
            </div>
          </div>
        ) : null}
      </div>
    </div>
  );
}
