import { useEffect, useMemo, useState } from 'react';
import { ArrowLeft, Save } from 'lucide-react';
import { useNavigate, useParams } from 'react-router-dom';
import { Button } from '@/components/common/Button/Button';
import { Input } from '@/components/common/Input/Input';
import { masterDataApi, type Organization } from '@/services/api';
import { useToast } from '@/components/common/Toast/ToastContext';
import { organizationTypeOptions } from './organizationTypes';
import styles from './master-data.module.css';

export default function OrganizationForm() {
  const navigate = useNavigate();
  const { id } = useParams();
  const isEdit = Boolean(id);
  const { addToast } = useToast();

  const [name, setName] = useState('');
  const [type, setType] = useState<Organization['type']>(organizationTypeOptions[0].value);
  const [location, setLocation] = useState('');
  const [contactPerson, setContactPerson] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const pageTitle = useMemo(() => (isEdit ? 'Edit Organization' : 'Create Organization'), [isEdit]);

  useEffect(() => {
    if (!isEdit) return;

    const load = async () => {
      try {
        const data = await masterDataApi.getOrganization(id!);
        setName(data.name ?? '');
        setType(data.type ?? organizationTypeOptions[0].value);
        setLocation(data.location ?? '');
        setContactPerson(data.contactPerson ?? '');
      } catch (err) {
        const message = err instanceof Error ? err.message : 'Unable to load organization';
        setError(message);
      }
    };

    void load();
  }, [id, isEdit]);

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    setError(null);

    if (!name.trim()) {
      setError('Organization name is required.');
      return;
    }
    if (!location.trim()) {
      setError('Location is required.');
      return;
    }
    if (!contactPerson.trim()) {
      setError('Contact person is required.');
      return;
    }

    setLoading(true);

    try {
      const payload = {
        name: name.trim(),
        type,
        location: location.trim(),
        contactPerson: contactPerson.trim(),
        active: true,
      };

      if (isEdit) {
        await masterDataApi.updateOrganization(id!, payload);
        addToast('Organization updated successfully', 'success');
      } else {
        await masterDataApi.createOrganization(payload);
        addToast('Organization created successfully', 'success');
      }
      navigate('/organizations');
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Unable to save organization';
      setError(message);
      addToast(message, 'error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={styles.page}>
      <div className={styles.header}>
        <div>
          <h1 className={styles.title}>{pageTitle}</h1>
          <p className={styles.subtitle}>Capture organization master data for SeedSphere.</p>
        </div>
        <Button variant="secondary" leftIcon={ArrowLeft} onClick={() => navigate('/organizations')}>
          Back to list
        </Button>
      </div>

      <div className={styles.card}>
        <form className={styles.form} onSubmit={handleSubmit}>
          {error ? <div className={styles.errorText}>{error}</div> : null}

          <div className={styles.field}>
            <label className={styles.label} htmlFor="name">Name</label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. GreenFields Breeders"
              errorText={!name.trim() && error ? 'Required' : undefined}
            />
          </div>

          <div className={styles.field}>
            <label className={styles.label} htmlFor="type">Type</label>
            <select id="type" className={styles.select} value={type} onChange={(e) => setType(e.target.value as Organization['type'])}>
              {organizationTypeOptions.map((option) => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
          </div>

          <div className={styles.field}>
            <label className={styles.label} htmlFor="location">Location</label>
            <Input
              id="location"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              placeholder="e.g. Hyderabad, Telangana"
              errorText={!location.trim() && error ? 'Required' : undefined}
            />
          </div>

          <div className={styles.field}>
            <label className={styles.label} htmlFor="contactPerson">Contact Person</label>
            <Input
              id="contactPerson"
              value={contactPerson}
              onChange={(e) => setContactPerson(e.target.value)}
              placeholder="e.g. Ramesh Kumar"
              errorText={!contactPerson.trim() && error ? 'Required' : undefined}
            />
          </div>

          <div className={styles.actions}>
            <Button leftIcon={Save} isLoading={loading} type="submit">
              {isEdit ? 'Save changes' : 'Create organization'}
            </Button>
            <Button variant="secondary" type="button" onClick={() => navigate('/organizations')}>
              Cancel
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
