import { useEffect, useMemo, useState } from 'react';
import { Plus, Search, RefreshCw } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/common/Button/Button';
import { OrganizationTable } from '@/components/OrganizationTable/OrganizationTable';
import { masterDataApi, type Organization } from '@/services/api';
import { useToast } from '@/components/common/Toast/ToastContext';
import { organizationTypeOptions } from './organizationTypes';
import styles from './master-data.module.css';

const seedOrganizations: Organization[] = [
  { id: 'org-1', name: 'GreenFields Breeders', type: 'breeder', location: 'Hyderabad, Telangana', contactPerson: 'Ramesh Kumar', active: true },
  { id: 'org-2', name: 'AgriGrow Seed Producers', type: 'producer', location: 'Nashik, Maharashtra', contactPerson: 'Sunita Patel', active: true },
  { id: 'org-3', name: 'National Seed Testing Lab', type: 'laboratory', location: 'Bengaluru, Karnataka', contactPerson: 'Dr. Anil Sharma', active: true },
  { id: 'org-4', name: 'Krishna Cold Storage & Warehouse', type: 'warehouse', location: 'Guntur, Andhra Pradesh', contactPerson: 'Venkat Rao', active: true },
  { id: 'org-5', name: 'Sri Lakshmi Agro Dealers', type: 'dealer', location: 'Coimbatore, Tamil Nadu', contactPerson: 'Lakshmi Narayanan', active: true },
];

export default function OrganizationList() {
  const [organizations, setOrganizations] = useState<Organization[]>(seedOrganizations);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState<Organization['type'] | 'all'>('all');
  const navigate = useNavigate();
  const { addToast } = useToast();

  const loadOrganizations = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await masterDataApi.getOrganizations();
      const nextOrganizations = Array.isArray(data) && data.length > 0 ? data : seedOrganizations;
      setOrganizations(nextOrganizations);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Unable to load organizations';
      setError(message);
      setOrganizations(seedOrganizations);
      addToast(message, 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void loadOrganizations();
  }, []);

  const filteredOrganizations = useMemo(() => {
    const query = search.trim().toLowerCase();
    return organizations.filter((item) => {
      const matchesQuery = !query || item.name.toLowerCase().includes(query);
      const matchesType = typeFilter === 'all' || item.type === typeFilter;
      return matchesQuery && matchesType;
    });
  }, [organizations, search, typeFilter]);

  const handleDelete = async (organization: Organization) => {
    const confirmed = window.confirm(`Delete ${organization.name}?`);
    if (!confirmed) return;

    try {
      await masterDataApi.deleteOrganization(organization.id);
      addToast('Organization deleted successfully', 'success');
      await loadOrganizations();
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Deletion failed';
      addToast(message, 'error');
    }
  };

  return (
    <div className={styles.page}>
      <div className={styles.header}>
        <div>
          <h1 className={styles.title}>Organization Management</h1>
          <p className={styles.subtitle}>Create, edit, and manage organization master data in SeedSphere.</p>
        </div>
        <div className={styles.actions}>
          <Button variant="secondary" leftIcon={RefreshCw} onClick={() => void loadOrganizations()}>
            Refresh
          </Button>
          <Button leftIcon={Plus} onClick={() => navigate('/organizations/new')}>
            Create New
          </Button>
        </div>
      </div>

      <div className={styles.card}>
        <div className={styles.controls}>
          <label style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', flex: 1 }}>
            <Search size={16} />
            <input
              className={styles.searchInput}
              placeholder="Search by organization name"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </label>
          <select
            className={styles.select}
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value as Organization['type'] | 'all')}
          >
            <option value="all">All types</option>
            {organizationTypeOptions.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </div>

        {error ? <div className={styles.errorText}>{error}</div> : null}

        {filteredOrganizations.length === 0 && !loading ? (
          <div className={styles.emptyState}>No organizations match your current filter.</div>
        ) : (
          <OrganizationTable
            organizations={filteredOrganizations}
            loading={loading}
            onView={(item) => navigate(`/organizations/${item.id}`)}
            onEdit={(item) => navigate(`/organizations/${item.id}/edit`)}
            onDelete={handleDelete}
          />
        )}
      </div>
    </div>
  );
}
