import { useEffect, useMemo, useState } from 'react';
import { ArrowLeft, Save } from 'lucide-react';
import { useNavigate, useParams } from 'react-router-dom';
import { Button } from '@/components/common/Button/Button';
import { Input } from '@/components/common/Input/Input';
import { masterDataApi } from '@/services/api';
import { useToast } from '@/components/common/Toast/ToastContext';
import styles from './master-data.module.css';

const cropOptions = ['Paddy', 'Maize', 'Cotton', 'Wheat', 'Sorghum', 'Groundnut', 'Tomato'];

export default function VarietyForm() {
  const navigate = useNavigate();
  const { id } = useParams();
  const isEdit = Boolean(id);
  const { addToast } = useToast();

  const [name, setName] = useState('');
  const [crop, setCrop] = useState(cropOptions[0]);
  const [description, setDescription] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const pageTitle = useMemo(() => (isEdit ? 'Edit Variety' : 'Create Variety'), [isEdit]);

  useEffect(() => {
    if (!isEdit) return;

    const load = async () => {
      try {
        const data = await masterDataApi.getVariety(id!);
        setName(data.name ?? '');
        setCrop(data.crop ?? cropOptions[0]);
        setDescription(data.description ?? '');
      } catch (err) {
        const message = err instanceof Error ? err.message : 'Unable to load variety';
        setError(message);
      }
    };

    void load();
  }, [id, isEdit]);

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    setError(null);

    if (!name.trim()) {
      setError('Variety name is required.');
      return;
    }

    setLoading(true);

    try {
      const payload = {
        name: name.trim(),
        crop,
        description: description.trim(),
      };

      if (isEdit) {
        await masterDataApi.updateVariety(id!, payload);
        addToast('Variety updated successfully', 'success');
      } else {
        await masterDataApi.createVariety(payload);
        addToast('Variety created successfully', 'success');
      }
      navigate('/varieties');
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Unable to save variety';
      setError(message);
      addToast(message, 'error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={styles.page}>
      <div className={styles.header}>
        <div>
          <h1 className={styles.title}>{pageTitle}</h1>
          <p className={styles.subtitle}>Capture the variety details for SeedSphere master data.</p>
        </div>
        <Button variant="secondary" leftIcon={ArrowLeft} onClick={() => navigate('/varieties')}>
          Back to list
        </Button>
      </div>

      <div className={styles.card}>
        <form className={styles.form} onSubmit={handleSubmit}>
          {error ? <div className={styles.errorText}>{error}</div> : null}

          <div className={styles.field}>
            <label className={styles.label} htmlFor="name">Name</label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Paddy-101"
              errorText={!name.trim() && error ? 'Required' : undefined}
            />
          </div>

          <div className={styles.field}>
            <label className={styles.label} htmlFor="crop">Crop</label>
            <select id="crop" className={styles.select} value={crop} onChange={(e) => setCrop(e.target.value)}>
              {cropOptions.map((option) => (
                <option key={option} value={option}>
                  {option}
                </option>
              ))}
            </select>
          </div>

          <div className={styles.field}>
            <label className={styles.label} htmlFor="description">Description</label>
            <textarea
              id="description"
              className={styles.textarea}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Add variety description, traits, or notes"
            />
          </div>

          <div className={styles.actions}>
            <Button leftIcon={Save} isLoading={loading} type="submit">
              {isEdit ? 'Save changes' : 'Create variety'}
            </Button>
            <Button variant="secondary" type="button" onClick={() => navigate('/varieties')}>
              Cancel
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
