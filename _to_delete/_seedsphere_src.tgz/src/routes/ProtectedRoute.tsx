import { Navigate, Outlet } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';

import { hasPermission, type Permission } from '@/utils/permissions';

interface ProtectedRouteProps {
  permission?: Permission;
}

export function ProtectedRoute({ permission }: ProtectedRouteProps = {}) {
  const { isAuthenticated, user } = useAuth();
  if (!isAuthenticated) return <Navigate to="/login" replace />;
  if (permission && user && !hasPermission(user.role, permission)) {
    return <Navigate to="/unauthorized" replace />;
  }
  return <Outlet />;
}
