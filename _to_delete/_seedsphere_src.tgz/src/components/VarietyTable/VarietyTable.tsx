import { useMemo, useState } from 'react';
import { Edit3, Trash2, Eye } from 'lucide-react';
import { Button } from '@/components/common/Button/Button';
import type { SeedVariety } from '@/services/api';

interface VarietyTableProps {
  varieties: SeedVariety[];
  loading?: boolean;
  onEdit?: (variety: SeedVariety) => void;
  onDelete?: (variety: SeedVariety) => void;
  onView?: (variety: SeedVariety) => void;
}

export function VarietyTable({
  varieties,
  loading = false,
  onEdit,
  onDelete,
  onView,
}: VarietyTableProps) {
  const [sortKey, setSortKey] = useState<'name' | 'crop' | 'description'>('name');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [page, setPage] = useState(1);
  const pageSize = 10;

  const sortedVarieties = useMemo(() => {
    const copy = [...varieties];
    copy.sort((a, b) => {
      const left = (a[sortKey] ?? '').toString().toLowerCase();
      const right = (b[sortKey] ?? '').toString().toLowerCase();
      if (left < right) return sortDirection === 'asc' ? -1 : 1;
      if (left > right) return sortDirection === 'asc' ? 1 : -1;
      return 0;
    });
    return copy;
  }, [sortDirection, sortKey, varieties]);

  const totalPages = Math.max(1, Math.ceil(sortedVarieties.length / pageSize));
  const pagedVarieties = sortedVarieties.slice((page - 1) * pageSize, page * pageSize);

  const handleSort = (key: 'name' | 'crop' | 'description') => {
    if (sortKey === key) {
      setSortDirection((prev) => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortKey(key);
      setSortDirection('asc');
    }
    setPage(1);
  };

  if (loading) {
    return <div style={{ padding: '1rem' }}>Loading varieties…</div>;
  }

  return (
    <div>
      <div style={{ overflowX: 'auto' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr style={{ background: '#f7f9f7', textAlign: 'left' }}>
              <th style={{ padding: '0.75rem', cursor: 'pointer' }} onClick={() => handleSort('name')}>Name</th>
              <th style={{ padding: '0.75rem', cursor: 'pointer' }} onClick={() => handleSort('crop')}>Crop</th>
              <th style={{ padding: '0.75rem', cursor: 'pointer' }} onClick={() => handleSort('description')}>Description</th>
              <th style={{ padding: '0.75rem' }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {pagedVarieties.map((variety) => (
              <tr key={variety.id} style={{ borderTop: '1px solid #e8efe8' }}>
                <td style={{ padding: '0.75rem' }}>{variety.name}</td>
                <td style={{ padding: '0.75rem' }}>{variety.crop}</td>
                <td style={{ padding: '0.75rem' }}>{variety.description ?? '—'}</td>
                <td style={{ padding: '0.75rem' }}>
                  <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
                    {onView && (
                      <Button size="sm" variant="secondary" leftIcon={Eye} onClick={() => onView(variety)}>
                        View
                      </Button>
                    )}
                    {onEdit && (
                      <Button size="sm" variant="accent" leftIcon={Edit3} onClick={() => onEdit(variety)}>
                        Edit
                      </Button>
                    )}
                    {onDelete && (
                      <Button size="sm" variant="danger" leftIcon={Trash2} onClick={() => onDelete(variety)}>
                        Delete
                      </Button>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '1rem', gap: '1rem', flexWrap: 'wrap' }}>
        <span>
          Showing {(page - 1) * pageSize + 1}–{Math.min(page * pageSize, sortedVarieties.length)} of {sortedVarieties.length}
        </span>
        <div style={{ display: 'flex', gap: '0.5rem' }}>
          <Button size="sm" variant="secondary" onClick={() => setPage((prev) => Math.max(1, prev - 1))} disabled={page === 1}>
            Previous
          </Button>
          <Button size="sm" variant="secondary" onClick={() => setPage((prev) => Math.min(totalPages, prev + 1))} disabled={page === totalPages}>
            Next
          </Button>
        </div>
      </div>
    </div>
  );
}
